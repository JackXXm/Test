package com.edip.mapper;

import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

public interface StampMapperVos {

    List<Map<String, Object>> queryStampList(Map<String, Object> params);

    Integer auditStamp(Map param);

    List<Map<String, Object>> queryStampDetail(@RequestParam("stampID") String stampID);

    String getProAddress(@RequestParam("id") String id);

    String getCityAddress(@RequestParam("id") String id);

    String getAreaAddress(@RequestParam("id") String id);

    Map getStampById(@RequestParam("stampID")Integer stampID);

    void updateStampHistory(Map<String , Object> param);

    List<Map<String , Object>> getStampHistory(@RequestParam("stampID") String stampID);
    //删除公司的时候同步删除证书和印章
    void deleteCert(Map param);
    void deleteStamp(Map param);
}