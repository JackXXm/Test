package com.edip.entity;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;

/**
 * @author 
 */
public class Stamp implements Serializable {
    /**
     * 印章ID
     */
    private Integer stampid;

    /**
     * 印章名称
     */
    private String stampname;

    /**
     * 印章类别,参考dic的type=stampType
     */
    private String stamptype;

    /**
     * 归属公司
     */
    private Integer compid;

    /**
     * 帐号ID
     */
    private Integer accountid;

    /**
     * 生效日期
     */
    private Date validdate;

    /**
     * 失效日期
     */
    private Date invaliddate;

    /**
     * 管理端帐号ID
     */
    private Integer operid;

    /**
     * 状态、0:正常、1:待审批、2:待下载、3:过期、9:审批失败
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createdate;

    /**
     * 更新时间
     */
    private Date lupdate;

    /**
     * 审核意见
     */
    private String auditinfo;

    /**
     * 附件url
     */
    private String docurl;

    /**
     * 申请人
     */
    private String accountName;

    /**
     * 印章图片,使用html中的base64图片格式存储
     */
    private byte[] stampcontent;

    private String companyName;

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    private static final long serialVersionUID = 1L;

    public Integer getStampid() {
        return stampid;
    }

    public void setStampid(Integer stampid) {
        this.stampid = stampid;
    }

    public String getStampname() {
        return stampname;
    }

    public void setStampname(String stampname) {
        this.stampname = stampname;
    }

    public String getStamptype() {
        return stamptype;
    }

    public void setStamptype(String stamptype) {
        this.stamptype = stamptype;
    }

    public Integer getCompid() {
        return compid;
    }

    public void setCompid(Integer compid) {
        this.compid = compid;
    }

    public Integer getAccountid() {
        return accountid;
    }

    public void setAccountid(Integer accountid) {
        this.accountid = accountid;
    }

    public Date getValiddate() {
        return validdate;
    }

    public void setValiddate(Date validdate) {
        this.validdate = validdate;
    }

    public Date getInvaliddate() {
        return invaliddate;
    }

    public void setInvaliddate(Date invaliddate) {
        this.invaliddate = invaliddate;
    }

    public Integer getOperid() {
        return operid;
    }

    public void setOperid(Integer operid) {
        this.operid = operid;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getLupdate() {
        return lupdate;
    }

    public void setLupdate(Date lupdate) {
        this.lupdate = lupdate;
    }

    public String getAuditinfo() {
        return auditinfo;
    }

    public void setAuditinfo(String auditinfo) {
        this.auditinfo = auditinfo;
    }

    public String getDocurl() {
        return docurl;
    }

    public void setDocurl(String docurl) {
        this.docurl = docurl;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public byte[] getStampcontent() {
        return stampcontent;
    }

    public void setStampcontent(byte[] stampcontent) {
        this.stampcontent = stampcontent;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Stamp other = (Stamp) that;
        return (this.getStampid() == null ? other.getStampid() == null : this.getStampid().equals(other.getStampid()))
            && (this.getStampname() == null ? other.getStampname() == null : this.getStampname().equals(other.getStampname()))
            && (this.getStamptype() == null ? other.getStamptype() == null : this.getStamptype().equals(other.getStamptype()))
            && (this.getCompid() == null ? other.getCompid() == null : this.getCompid().equals(other.getCompid()))
            && (this.getAccountid() == null ? other.getAccountid() == null : this.getAccountid().equals(other.getAccountid()))
            && (this.getValiddate() == null ? other.getValiddate() == null : this.getValiddate().equals(other.getValiddate()))
            && (this.getInvaliddate() == null ? other.getInvaliddate() == null : this.getInvaliddate().equals(other.getInvaliddate()))
            && (this.getOperid() == null ? other.getOperid() == null : this.getOperid().equals(other.getOperid()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getCreatedate() == null ? other.getCreatedate() == null : this.getCreatedate().equals(other.getCreatedate()))
            && (this.getLupdate() == null ? other.getLupdate() == null : this.getLupdate().equals(other.getLupdate()))
            && (this.getAuditinfo() == null ? other.getAuditinfo() == null : this.getAuditinfo().equals(other.getAuditinfo()))
            && (this.getDocurl() == null ? other.getDocurl() == null : this.getDocurl().equals(other.getDocurl()))
            && (this.getAccountName() == null ? other.getAccountName() == null : this.getAccountName().equals(other.getAccountName()))
            && (Arrays.equals(this.getStampcontent(), other.getStampcontent()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getStampid() == null) ? 0 : getStampid().hashCode());
        result = prime * result + ((getStampname() == null) ? 0 : getStampname().hashCode());
        result = prime * result + ((getStamptype() == null) ? 0 : getStamptype().hashCode());
        result = prime * result + ((getCompid() == null) ? 0 : getCompid().hashCode());
        result = prime * result + ((getAccountid() == null) ? 0 : getAccountid().hashCode());
        result = prime * result + ((getValiddate() == null) ? 0 : getValiddate().hashCode());
        result = prime * result + ((getInvaliddate() == null) ? 0 : getInvaliddate().hashCode());
        result = prime * result + ((getOperid() == null) ? 0 : getOperid().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getCreatedate() == null) ? 0 : getCreatedate().hashCode());
        result = prime * result + ((getLupdate() == null) ? 0 : getLupdate().hashCode());
        result = prime * result + ((getAuditinfo() == null) ? 0 : getAuditinfo().hashCode());
        result = prime * result + ((getDocurl() == null) ? 0 : getDocurl().hashCode());
        result = prime * result + ((getAccountName() == null) ? 0 : getAccountName().hashCode());
        result = prime * result + (Arrays.hashCode(getStampcontent()));
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", stampid=").append(stampid);
        sb.append(", stampname=").append(stampname);
        sb.append(", stamptype=").append(stamptype);
        sb.append(", compid=").append(compid);
        sb.append(", accountid=").append(accountid);
        sb.append(", validdate=").append(validdate);
        sb.append(", invaliddate=").append(invaliddate);
        sb.append(", operid=").append(operid);
        sb.append(", status=").append(status);
        sb.append(", createdate=").append(createdate);
        sb.append(", lupdate=").append(lupdate);
        sb.append(", auditinfo=").append(auditinfo);
        sb.append(", docurl=").append(docurl);
        sb.append(", accountName=").append(accountName);
        sb.append(", stampcontent=").append(stampcontent);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}