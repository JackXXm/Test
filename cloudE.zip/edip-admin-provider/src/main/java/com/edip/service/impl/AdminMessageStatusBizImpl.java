package com.edip.service.impl;

import java.util.List;

import com.edip.entity.AdminMessagestatus;
import com.edip.entity.AdminMessagestatusExample;
import com.edip.mapper.AdminMessagestatusMapper;
import com.edip.service.AdminMessageStatusBiz;
import com.edip.utils.AdminMessagestatusConvert;
import com.edip.utils.AdminMessagestatusVoConvert;
import com.edip.vo.AdminMessagestatusVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by qiaoxiaolong on 2017/6/4.
 */
@Service
public class AdminMessageStatusBizImpl implements AdminMessageStatusBiz {
    private static final Logger   LOGGER = LoggerFactory.getLogger(AdminMessageStatusBizImpl.class);
    @Autowired
    protected AdminMessagestatusMapper messagestatusMapper;

    @Override
    public List<AdminMessagestatusVo> selectByExample(AdminMessagestatusExample example) {
        List<AdminMessagestatus> list = null;
        try {
            list = messagestatusMapper.selectByExample(example);
        } catch (Exception e) {
            LOGGER.error("MessageStatusBizImpl-->selectByExample:" + e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
        return AdminMessagestatusVoConvert.convert(list);
    }

    @Override
    public int insert(AdminMessagestatus record) {
        return messagestatusMapper.insert(record);
    }

    @Override
    public int insert(AdminMessagestatusVo messagestatusVo) {
        int result;
        try {
            result = messagestatusMapper.insert(AdminMessagestatusConvert.convert(messagestatusVo));
        } catch (Exception e) {
            LOGGER.error("MessageStatusBizImpl-->insert:" + e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
        return result;
    }

    @Override
    public int insertIfNo(AdminMessagestatusVo messagestatusVo) {
        int result = 0;
        try {
            AdminMessagestatusExample example = new AdminMessagestatusExample();
            example.createCriteria().andFromflagEqualTo(messagestatusVo.getFromflag())
                .andAccountidEqualTo(messagestatusVo.getAccountid()).andFromidEqualTo(messagestatusVo.getFromid());
            List<AdminMessagestatus> list = messagestatusMapper.selectByExample(example);
            if (list.size() == 0) {
                result = messagestatusMapper.insert(AdminMessagestatusConvert.convert(messagestatusVo));
            }
        } catch (Exception e) {
            LOGGER.error("MessageStatusBizImpl-->insert:" + e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
        return result;
    }

    @Override
    public int countIs(AdminMessagestatus record) {
        return messagestatusMapper.countIs(record);
    }
}
