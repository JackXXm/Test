package com.edip.mapper;

import com.edip.entity.AdminArea;
import com.edip.entity.AdminCity;

public interface AdminCityAreaMapper {
//    int countByExample(CityExample example);

//    int deleteByExample(CityExample example);

    int deleteByPrimaryKey(Integer CITY_ID);

    int insert(AdminCity record);

    int insertSelective(AdminCity record);

//    List<AdminCity> selectByExampleWithPage(@Param("example") CityExample example, @Param("from") Integer from, @Param("to") Integer to);

//    List<AdminCity> selectByExample(CityExample example);

    AdminCity selectByPrimaryKey(Integer CITY_ID);

//    int updateByExampleSelective(@Param("record") AdminCity record, @Param("example") CityExample example);

//    int updateByExample(@Param("record") AdminCity record, @Param("example") CityExample example);

    int updateByPrimaryKeySelective(AdminCity record);

    int updateByPrimaryKey(AdminCity record);

    AdminArea selectAreaByAreaId(Integer areaID);
}