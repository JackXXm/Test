package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RechargeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public RechargeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andRechargeidIsNull() {
            addCriterion("rechargeID is null");
            return (Criteria) this;
        }

        public Criteria andRechargeidIsNotNull() {
            addCriterion("rechargeID is not null");
            return (Criteria) this;
        }

        public Criteria andRechargeidEqualTo(Integer value) {
            addCriterion("rechargeID =", value, "rechargeid");
            return (Criteria) this;
        }

        public Criteria andRechargeidNotEqualTo(Integer value) {
            addCriterion("rechargeID <>", value, "rechargeid");
            return (Criteria) this;
        }

        public Criteria andRechargeidGreaterThan(Integer value) {
            addCriterion("rechargeID >", value, "rechargeid");
            return (Criteria) this;
        }

        public Criteria andRechargeidGreaterThanOrEqualTo(Integer value) {
            addCriterion("rechargeID >=", value, "rechargeid");
            return (Criteria) this;
        }

        public Criteria andRechargeidLessThan(Integer value) {
            addCriterion("rechargeID <", value, "rechargeid");
            return (Criteria) this;
        }

        public Criteria andRechargeidLessThanOrEqualTo(Integer value) {
            addCriterion("rechargeID <=", value, "rechargeid");
            return (Criteria) this;
        }

        public Criteria andRechargeidIn(List<Integer> values) {
            addCriterion("rechargeID in", values, "rechargeid");
            return (Criteria) this;
        }

        public Criteria andRechargeidNotIn(List<Integer> values) {
            addCriterion("rechargeID not in", values, "rechargeid");
            return (Criteria) this;
        }

        public Criteria andRechargeidBetween(Integer value1, Integer value2) {
            addCriterion("rechargeID between", value1, value2, "rechargeid");
            return (Criteria) this;
        }

        public Criteria andRechargeidNotBetween(Integer value1, Integer value2) {
            addCriterion("rechargeID not between", value1, value2, "rechargeid");
            return (Criteria) this;
        }

        public Criteria andCompidIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompidIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompidEqualTo(Integer value) {
            addCriterion("compID =", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThan(Integer value) {
            addCriterion("compID >", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThan(Integer value) {
            addCriterion("compID <", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidIn(List<Integer> values) {
            addCriterion("compID in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andBillaccountIsNull() {
            addCriterion("billAccount is null");
            return (Criteria) this;
        }

        public Criteria andBillaccountIsNotNull() {
            addCriterion("billAccount is not null");
            return (Criteria) this;
        }

        public Criteria andBillaccountEqualTo(String value) {
            addCriterion("billAccount =", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountNotEqualTo(String value) {
            addCriterion("billAccount <>", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountGreaterThan(String value) {
            addCriterion("billAccount >", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountGreaterThanOrEqualTo(String value) {
            addCriterion("billAccount >=", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountLessThan(String value) {
            addCriterion("billAccount <", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountLessThanOrEqualTo(String value) {
            addCriterion("billAccount <=", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountLike(String value) {
            addCriterion("billAccount like", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountNotLike(String value) {
            addCriterion("billAccount not like", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountIn(List<String> values) {
            addCriterion("billAccount in", values, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountNotIn(List<String> values) {
            addCriterion("billAccount not in", values, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountBetween(String value1, String value2) {
            addCriterion("billAccount between", value1, value2, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountNotBetween(String value1, String value2) {
            addCriterion("billAccount not between", value1, value2, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillnumIsNull() {
            addCriterion("billNum is null");
            return (Criteria) this;
        }

        public Criteria andBillnumIsNotNull() {
            addCriterion("billNum is not null");
            return (Criteria) this;
        }

        public Criteria andBillnumEqualTo(Float value) {
            addCriterion("billNum =", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumNotEqualTo(Float value) {
            addCriterion("billNum <>", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumGreaterThan(Float value) {
            addCriterion("billNum >", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumGreaterThanOrEqualTo(Float value) {
            addCriterion("billNum >=", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumLessThan(Float value) {
            addCriterion("billNum <", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumLessThanOrEqualTo(Float value) {
            addCriterion("billNum <=", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumIn(List<Float> values) {
            addCriterion("billNum in", values, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumNotIn(List<Float> values) {
            addCriterion("billNum not in", values, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumBetween(Float value1, Float value2) {
            addCriterion("billNum between", value1, value2, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumNotBetween(Float value1, Float value2) {
            addCriterion("billNum not between", value1, value2, "billnum");
            return (Criteria) this;
        }

        public Criteria andOperidIsNull() {
            addCriterion("operID is null");
            return (Criteria) this;
        }

        public Criteria andOperidIsNotNull() {
            addCriterion("operID is not null");
            return (Criteria) this;
        }

        public Criteria andOperidEqualTo(Integer value) {
            addCriterion("operID =", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidNotEqualTo(Integer value) {
            addCriterion("operID <>", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidGreaterThan(Integer value) {
            addCriterion("operID >", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidGreaterThanOrEqualTo(Integer value) {
            addCriterion("operID >=", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidLessThan(Integer value) {
            addCriterion("operID <", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidLessThanOrEqualTo(Integer value) {
            addCriterion("operID <=", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidIn(List<Integer> values) {
            addCriterion("operID in", values, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidNotIn(List<Integer> values) {
            addCriterion("operID not in", values, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidBetween(Integer value1, Integer value2) {
            addCriterion("operID between", value1, value2, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidNotBetween(Integer value1, Integer value2) {
            addCriterion("operID not between", value1, value2, "operid");
            return (Criteria) this;
        }

        public Criteria andModeidIsNull() {
            addCriterion("modeID is null");
            return (Criteria) this;
        }

        public Criteria andModeidIsNotNull() {
            addCriterion("modeID is not null");
            return (Criteria) this;
        }

        public Criteria andModeidEqualTo(Integer value) {
            addCriterion("modeID =", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidNotEqualTo(Integer value) {
            addCriterion("modeID <>", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidGreaterThan(Integer value) {
            addCriterion("modeID >", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidGreaterThanOrEqualTo(Integer value) {
            addCriterion("modeID >=", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidLessThan(Integer value) {
            addCriterion("modeID <", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidLessThanOrEqualTo(Integer value) {
            addCriterion("modeID <=", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidIn(List<Integer> values) {
            addCriterion("modeID in", values, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidNotIn(List<Integer> values) {
            addCriterion("modeID not in", values, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidBetween(Integer value1, Integer value2) {
            addCriterion("modeID between", value1, value2, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidNotBetween(Integer value1, Integer value2) {
            addCriterion("modeID not between", value1, value2, "modeid");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreatedateEqualTo(Date value) {
            addCriterion("createDate =", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThan(Date value) {
            addCriterion("createDate <", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateIn(List<Date> values) {
            addCriterion("createDate in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andNoteIsNull() {
            addCriterion("note is null");
            return (Criteria) this;
        }

        public Criteria andNoteIsNotNull() {
            addCriterion("note is not null");
            return (Criteria) this;
        }

        public Criteria andNoteEqualTo(String value) {
            addCriterion("note =", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotEqualTo(String value) {
            addCriterion("note <>", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThan(String value) {
            addCriterion("note >", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThanOrEqualTo(String value) {
            addCriterion("note >=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThan(String value) {
            addCriterion("note <", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThanOrEqualTo(String value) {
            addCriterion("note <=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLike(String value) {
            addCriterion("note like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotLike(String value) {
            addCriterion("note not like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteIn(List<String> values) {
            addCriterion("note in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotIn(List<String> values) {
            addCriterion("note not in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteBetween(String value1, String value2) {
            addCriterion("note between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotBetween(String value1, String value2) {
            addCriterion("note not between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andGivenumIsNull() {
            addCriterion("giveNum is null");
            return (Criteria) this;
        }

        public Criteria andGivenumIsNotNull() {
            addCriterion("giveNum is not null");
            return (Criteria) this;
        }

        public Criteria andGivenumEqualTo(Float value) {
            addCriterion("giveNum =", value, "givenum");
            return (Criteria) this;
        }

        public Criteria andGivenumNotEqualTo(Float value) {
            addCriterion("giveNum <>", value, "givenum");
            return (Criteria) this;
        }

        public Criteria andGivenumGreaterThan(Float value) {
            addCriterion("giveNum >", value, "givenum");
            return (Criteria) this;
        }

        public Criteria andGivenumGreaterThanOrEqualTo(Float value) {
            addCriterion("giveNum >=", value, "givenum");
            return (Criteria) this;
        }

        public Criteria andGivenumLessThan(Float value) {
            addCriterion("giveNum <", value, "givenum");
            return (Criteria) this;
        }

        public Criteria andGivenumLessThanOrEqualTo(Float value) {
            addCriterion("giveNum <=", value, "givenum");
            return (Criteria) this;
        }

        public Criteria andGivenumIn(List<Float> values) {
            addCriterion("giveNum in", values, "givenum");
            return (Criteria) this;
        }

        public Criteria andGivenumNotIn(List<Float> values) {
            addCriterion("giveNum not in", values, "givenum");
            return (Criteria) this;
        }

        public Criteria andGivenumBetween(Float value1, Float value2) {
            addCriterion("giveNum between", value1, value2, "givenum");
            return (Criteria) this;
        }

        public Criteria andGivenumNotBetween(Float value1, Float value2) {
            addCriterion("giveNum not between", value1, value2, "givenum");
            return (Criteria) this;
        }

        public Criteria andChargeDateIsNull() {
            addCriterion("charge_date is null");
            return (Criteria) this;
        }

        public Criteria andChargeDateIsNotNull() {
            addCriterion("charge_date is not null");
            return (Criteria) this;
        }

        public Criteria andChargeDateEqualTo(Date value) {
            addCriterion("charge_date =", value, "chargeDate");
            return (Criteria) this;
        }

        public Criteria andChargeDateNotEqualTo(Date value) {
            addCriterion("charge_date <>", value, "chargeDate");
            return (Criteria) this;
        }

        public Criteria andChargeDateGreaterThan(Date value) {
            addCriterion("charge_date >", value, "chargeDate");
            return (Criteria) this;
        }

        public Criteria andChargeDateGreaterThanOrEqualTo(Date value) {
            addCriterion("charge_date >=", value, "chargeDate");
            return (Criteria) this;
        }

        public Criteria andChargeDateLessThan(Date value) {
            addCriterion("charge_date <", value, "chargeDate");
            return (Criteria) this;
        }

        public Criteria andChargeDateLessThanOrEqualTo(Date value) {
            addCriterion("charge_date <=", value, "chargeDate");
            return (Criteria) this;
        }

        public Criteria andChargeDateIn(List<Date> values) {
            addCriterion("charge_date in", values, "chargeDate");
            return (Criteria) this;
        }

        public Criteria andChargeDateNotIn(List<Date> values) {
            addCriterion("charge_date not in", values, "chargeDate");
            return (Criteria) this;
        }

        public Criteria andChargeDateBetween(Date value1, Date value2) {
            addCriterion("charge_date between", value1, value2, "chargeDate");
            return (Criteria) this;
        }

        public Criteria andChargeDateNotBetween(Date value1, Date value2) {
            addCriterion("charge_date not between", value1, value2, "chargeDate");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}