package com.edip.controller;

import com.alibaba.fastjson.JSONObject;
import com.edip.dto.ServerResponse;
import com.edip.entity.*;
import com.edip.mapper.*;
import org.omg.CORBA.OBJ_ADAPTER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class ImportOldData {
    /**
     * 获取我要发送资质信息
     *
     * @param exchangeInfo
     * @param request
     * @return
     * @throws Exception
     */
    @Autowired
    InspectExchangeFileItemMapper mapper;
    @Autowired
    ExchangeJobMapper exchangeJobMapper;
    @Autowired
    ExchangeProjectMapper exchangeProjectMapper;
    @Autowired
    ExchangeJobReceiveCompanyMapper exchangeJobReceiveCompanyMapper;
    @Autowired
    ExchangeFileItemMapper exchangeFileItemMapper;

    //@RequestMapping("/add.ajax")
    public ServerResponse getSendReportDocDetail() throws Exception {
        List<Map<String, Object>> items = mapper.queryAlltransmitItems(null);
        
        items.forEach(map -> {
            insertJob(map);

        });
        return null;
    }

    private Integer insertJob(Map<String, Object> map) {
        Integer itemId = (Integer) map.get("transmitItemsId");
        Map<String, Object> args = new HashMap<>();
        args.put("id", itemId);
        ExchangeJob exchangeJob = new ExchangeJob();
        Date date = (Date) map.get("createDate");
        exchangeJob.setCreateTime(date);

        exchangeJob.setUpdateTime(date);
        Integer accountId = (Integer) map.get("transmitAccountID");
        Integer receiveId = (Integer) map.get("receiveCompID");
        Integer companyId = (Integer) map.get("transmitCompID");
        exchangeJob.setAccountID(accountId);
        exchangeJob.setCompanyId(companyId);
        exchangeJob.setStatus(6);
        exchangeJob.setCreateAccountId(accountId);
        String companyName = mapper.getCompanyName(companyId);
        String sender = mapper.getAccountName(accountId);
        String recevieName = mapper.getCompanyName(receiveId);
        exchangeJob.setCreateUser(sender);
        if (recevieName == null) {

            return null;
        }
        exchangeJob.setSender(sender);
        exchangeJob.setSendCompany(companyName);
        exchangeJob.setReceiveCompanyName(recevieName);
        exchangeJob.setNote("");
        exchangeJob.setCreateAccountId(accountId);
        ExchangeProject exchangeProject = new ExchangeProject();


        JSONObject yaopingObject = new JSONObject();

        String offlinecooperate = (String) map.get("transmitCompany");
        yaopingObject.put("specifications", (String) map.get("specifications"));
        yaopingObject.put("unit_noun", (String) map.get("unitNoun"));
        yaopingObject.put("uni_name", (String) map.get("productName"));
        yaopingObject.put("approval_num", (String) map.get("approvalNum"));
        yaopingObject.put("manuf", (String) map.get("manufacturer"));

        yaopingObject.put("companyName", offlinecooperate);
        yaopingObject.put("dosage_form", (String) map.get("dosageForm"));
        exchangeProject.setThemeInfo(yaopingObject.toJSONString());
        exchangeJob.setDrugsNumber(1);
        exchangeJob.setDataDigest((String) map.get("productName"));
        exchangeProject.setThemeType(2);


        exchangeJobMapper.insertSelective(exchangeJob);
        Integer useJobId = 0;

        useJobId = exchangeJob.getId();
        List<Map<String, Object>> checkReports = mapper.queryTransmitItemsInfo(args);
        Integer jobId = useJobId;
        exchangeProject.setJobId(jobId);
        exchangeProject.setThemeDocNum(checkReports.size());
        exchangeProject.setCreateTime(date);
        exchangeProject.setUpateTime(date);
        exchangeProject.setCreateAccountId(accountId);
        exchangeProjectMapper.insertSelective(exchangeProject);


        ExchangeJobReceiveCompany exchangeJobReceiveCompany = new ExchangeJobReceiveCompany();
        exchangeJobReceiveCompany.setJobId(jobId);
        exchangeJobReceiveCompany.setReceivedStatus(2);
        exchangeJobReceiveCompany.setCreateAccountId(accountId);
        exchangeJobReceiveCompany.setReceiveCompanyId(receiveId);
        exchangeJobReceiveCompany.setCreateTime(date);
        exchangeJobReceiveCompany.setUpateTime(date);
        exchangeJobReceiveCompany.setNote("");

        exchangeJobReceiveCompany.setReceiveCompanyName(recevieName);
        exchangeJobReceiveCompanyMapper.insertSelective(exchangeJobReceiveCompany);
        checkReports.forEach(exchangeitem -> {
            ExchangeFileItem exchangeFileItem = new ExchangeFileItem();
            exchangeFileItem.setJobId(jobId);
            exchangeFileItem.setProjectId(exchangeProject.getId());
            exchangeFileItem.setCompanyId(companyId);
            exchangeFileItem.setDestSignInfo("");
            exchangeFileItem.setSignInfo("");
            exchangeFileItem.setDocumentId((Integer) exchangeitem.get("inspectionDocumentID"));
            exchangeFileItem.setCreateTime(date);
            exchangeFileItem.setUpateTime(date);
            Integer itemStatus = 3;
            exchangeFileItem.setStatus(itemStatus);
            exchangeFileItem.setJobId(jobId);
            exchangeFileItemMapper.insertSelective(exchangeFileItem);
        });

        return jobId;
    }

}
