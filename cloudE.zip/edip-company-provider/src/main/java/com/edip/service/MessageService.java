package com.edip.service;

import com.edip.entity.Message;

import java.util.List;
import java.util.Map;

public interface MessageService {

    List<Message> messageList(Integer accountID, Map<String, Object> params);

    int countMessageList(Integer accountID, Map<String, Object> params);
}
