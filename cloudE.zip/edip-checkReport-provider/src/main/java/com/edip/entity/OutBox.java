package com.edip.entity;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OutBox implements Serializable{
    private static final long serialVersionUID = 8222311846891803728L;
    /**
     * job id
     */
    private Integer id;
    /**
     *
     */
    private String type;
    /**
     * 发件人
     */
    private String sender;
    /**
     * 接收公司名称
     */
    private String receiveCompanyName;
    /**
     * 发送的产品清单
     */
    private String dataDigest;
    /**
     * 发送时间
     */
    private Date sendTime;
    /**
     * 接收公司数量
     */
    private String compCount;
    /**
     * 药品种类数量
     */
    private String drugCount;
    /**
     * 器械总数
     */
    private String apparatusCount;
    /**
     * 保健品总数
     */
    private String healthCount;
    /**
     * 拒收状态
     */
    private Integer status;
    /**
     * 公司数
     */
    private Integer companyCount;
    /**
     * 回传状态
     */
    private Integer returnStatus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getReceiveCompanyName() {
        return receiveCompanyName;
    }

    public void setReceiveCompanyName(String receiveCompanyName) {
        this.receiveCompanyName = receiveCompanyName;
    }

    public String getDataDigest() {
        return dataDigest;
    }

    public void setDataDigest(String dataDigest) {
        this.dataDigest = dataDigest;
    }



    public String getCompCount() {
        return compCount;
    }

    public void setCompCount(String compCount) {
        this.compCount = compCount;
    }

    public String getDrugCount() {
        return drugCount;
    }

    public void setDrugCount(String drugCount) {
        this.drugCount = drugCount;
    }

    public String getApparatusCount() {
        return apparatusCount;
    }

    public void setApparatusCount(String apparatusCount) {
        this.apparatusCount = apparatusCount;
    }

    public String getHealthCount() {
        return healthCount;
    }

    public void setHealthCount(String healthCount) {
        this.healthCount = healthCount;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getCompanyCount() {
        return companyCount;
    }

    public void setCompanyCount(Integer companyCount) {
        this.companyCount = companyCount;
    }

    public Integer getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(Integer returnStatus) {
        this.returnStatus = returnStatus;
    }
}
