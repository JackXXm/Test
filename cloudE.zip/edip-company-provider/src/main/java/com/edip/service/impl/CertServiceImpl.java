package com.edip.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.edip.Servant.CAClient;
import com.edip.Servant.CertServant;
import com.edip.dto.ServerResponse;
import com.edip.entity.CertVoConvert;
import com.edip.feign.CompanyFeign;
import com.edip.service.StampService;
import com.edip.util.CertConvert;
import com.edip.util.CertificateProperty;
import com.edip.vo.*;
import com.edip.entity.Cert;
import com.edip.entity.CertExample;
import com.edip.entity.CertWithBLOBs;

import com.edip.feign.AccountFeign;
import com.edip.mapper.CertMapper;
import com.edip.mapper.CertMapperVo;
import com.edip.service.CertService;
import com.edip.util.CertInfo;
//import org.dom4j.DocumentException;
import com.itextpdf.text.DocumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.util.*;

@Service
public class CertServiceImpl implements CertService {
    private static final Logger logger = LoggerFactory.getLogger(CertServiceImpl.class);
    @Autowired
    private CertMapper certMapper;
    @Autowired
    private CertMapperVo certMapperVo;
    @Autowired
    private AccountFeign accountFeign;
    @Autowired
    private CertServant certServant;
    @Autowired
    private CompanyFeign companyFeign;
    @Autowired
    private StampService stampService;

    @Override
    public Cert getCert(int compmayId,int accountId) {
        List<Integer> stauts = new ArrayList<Integer>();
        stauts.add(4);
        CertExample example=new CertExample();
        CertExample.Criteria criteria=example.createCriteria();
        criteria.andCompidEqualTo(compmayId);
        criteria.andAccountidEqualTo(accountId);
        criteria.andStatusNotIn(stauts);
        return certMapper.selectByExampleWithBLOBs(example).get(0);
    }

    @Override
    public Cert queryCertByCompId(Integer compId, Integer userID){
        CertExample example = new CertExample();
        List<Integer> status = new ArrayList<Integer>();
        status.add(0);
        status.add(5);
        status.add(6);
        example.createCriteria().andCompidEqualTo(compId).andStatusIn(status)/*.andUseridEqualTo(userID)*/;
        List<CertWithBLOBs> certs = certMapper.selectByExampleWithBLOBs(example);
        return certs.get(0);
    }

    @Override
    @Transactional
    public Integer applyCert(CertVo certVo) throws Exception {
        if(certVo.getUserID() == null)
            throw new BaseException("使用人ID为空");
        Map<String,Object> result = JSONObject.parseObject(companyFeign.getCompanyByCompanyId(certVo.getCompID()).getData().toString(),HashMap.class);
        if (result.get("provinceID")!=null)
            certVo.setProvinceID(Integer.valueOf(result.get("provinceID").toString()));
        if (result.get("cityID")!=null)
            certVo.setCityID(Integer.valueOf(result.get("cityID").toString()));
        if (result.get("areaID")!=null)
            certVo.setAreaID(Integer.valueOf(result.get("areaID").toString()));
		/*if(certVo.getIDCardFace() != null && certVo.getIDCardBack() != null){
			Account account = accountManagerServant.findOneAccount(certVo.getUserID());
			account.setIdCardNoURL(FileUtil.fileMove(certVo.getIDCardFace(), "IDcard", certVo.getCompID().toString()));
			account.setIdCardNo2URL(FileUtil.fileMove(certVo.getIDCardBack(), "IDcard", certVo.getCompID().toString()));
			accountManagerServant.updateAccount(account);
		}*/
        //判断该账户当前是否已经升级权限,若没有则说明追加的Ukey账户，需升级权限
        //promoteAccount(certVo.getUserID());
        if(certVo.getUkStatus()!=2)
            certMapper.deleteCertBycompanyId(certVo.getCompID());
        return certMapperVo.insertSelectiveVo(certVo);
    }

    @Override
    public CertWithBLOBs activeCert(CertVo certVo) throws Exception {
        // 验签参数不能为空
        if (certVo.getAccountID() == null || certVo.getX509() == null || certVo.getX509().length == 0) {
            throw new Exception("激活时,证书和用户ID为空");
        }
        // 解析证书对象
        CertInfo certInfo = null;
        try {
            certInfo = new CertInfo(certVo.getX509());
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.toString());
            throw new Exception("激活时,解析证书失败");
        }
        byte[] pubKey = null;
        if (null != certVo.getPublicKey() && 0 != certVo.getPublicKey().length) {
            pubKey = certVo.getPublicKey();
        } else {
            try {
                pubKey = certInfo.getPublicKey();
            } catch (Exception e) {
                throw new Exception("激活时,获取公钥失败");
            }
        }
        //针对单Ukey
        ServerResponse ukeyResult = accountFeign.getUkeyManager(certVo.getCompID());
        Map<String,Integer> uKey =(Map)ukeyResult.getData();
        Integer ukey = null;
        if(uKey.get("ukeyManager")!= null){
            ukey = uKey.get("ukeyManager");
        }
        if(uKey.get("ukeyAdmin")!= null){
            ukey = uKey.get("ukeyAdmin");
        }
        // certVo.setPublicKey(pubKey);
        certVo.setCertSN(certInfo.getSerialNumber());
        // 先去数据库查询没有企业ID和公钥对应的证书信息
        CertWithBLOBs cert = new CertWithBLOBs();
        cert = certServant.selectCert(certVo);
        //2018-03-23 追加当前Ukey使用人ID校验
		/*if(!cert.getUserid().equals(certVo.getAccountID())) {
			throw new BaseException("不具备该Ukey激活权限!");
		}*/
        System.out.println("UK证书激活 "+cert.getCompID());
        // 如果能查到证书申请且有证书信息则直接返回激活成功信息
        if (null != cert) {
            cert.setValidDate(certInfo.getNotBeforeDate());
            cert.setInvalidDate(certInfo.getNotAfterDate());
            cert.setAccountID(ukey);
            cert.setX509(certVo.getX509());
            cert.setPublickey(pubKey);
            cert.setLupDate(new Date());
            cert.setActiveDate(new Date());
            // cert.setPublisher(certInfo.getIssuerDN()); //证书发行机构
            certMapper.updateByPrimaryKeySelective(cert);
            // cert.setUserName(certificate.getUserName());//userName用于同步cert信息到EPMS平台

            //查询是否有已激活的证书记录
            CertExample certExample=new CertExample();
            certExample.createCriteria().andCompidEqualTo(certVo.getCompID()).andActivedateIsNotNull();
            List<Cert> certList=certMapper.selectByExample(certExample);
            // 首次激活证书并没有激活记录就赠送免费月卡
            if (cert.getUkStatus() == 0&&(null!=certList&&certList.size()==1)) {
//                System.out.println("UK证书首次激活赠送月卡 "+cert.getCompid());
//                companyBenefitDetailServer.insertSelective(1, cert.getCompid(), 0);
//				CompanyRenewalDetailVo renewal = new CompanyRenewalDetailVo();
//				renewal.setBusinessType(3);
//				renewal.setIsGive("Y");
//				// 计费方式
//				renewal.setBillModeID(5);
//				// 来源方式为证书激活
//				renewal.setFromType(1);
//				renewal.setCompID(certVo.getCompID());
//				renewal.setCreateTime(new Date());
//				renewal.setCreateID(ukey);
//				companyRenewalDetailServer.insertSelective(renewal);
            }
        } else {// 如果查询到信息为空，直接插入新数据
            cert = new CertWithBLOBs();
            cert.setValidDate(certInfo.getNotBeforeDate());
            cert.setInvalidDate(certInfo.getNotAfterDate());
            cert.setCertSN(certInfo.getSerialNumber());// 证书序列号
            cert.setStatus(CertVo.CERT_OK);
            cert.setCreateDate(new Date());
            cert.setLupDate(new Date());
            cert.setActiveDate(new Date());
            cert.setPublickey(pubKey);
            cert.setX509(certVo.getX509());
            // cert.setTerminalType(Certificate.CERT_TERMINAL_TYPE_WEB);//终端类型
            // cert.setCertType(Certificate.CERT_TYPE_UKEY);//证书类型
            // cert.setPublisher(certInfo.getIssuerDN());//证书发行机构
            // certMapper.insertSelectiveByVo(cert);
            // certificate.setUserName(certificate.getUserName());
        }
        return cert;
    }

    @Override
    @Transactional
    public CertVo updateKeyCertificate(CertVo certVo) throws Exception {

        if (certVo.getCertID() == null) {
            // 现将原来的证书吊销
            CertExample example = new CertExample();
            CertExample.Criteria criteria = example.createCriteria();
            criteria.andCertsnEqualTo(certVo.getCertSN());
            List<Integer> status = new ArrayList<Integer>();
            status.add(0);
            status.add(5);
            status.add(3);
            criteria.andStatusIn(status);
            List<CertWithBLOBs> cert = certMapperVo.selectByExampleWithBLOBs(example);
            if (cert.size() < 1) {
                throw new Exception("更新证书失败，原来的证书未找到");
            }
            CertWithBLOBs certw = cert.get(0);
            certw.setStatus(CertVo.CERT_REVOKE);
            Integer userid = certw.getUserid();
            certw.setUserid(-1);
            certMapper.updateByPrimaryKeySelective(certw);//将原来存在的证书吊销
            // 往证书表里插入申请记录
            certVo.setCertSN(certw.getCertSN());
            certVo.setCreateDate(new Date());
            certVo.setLupDate(new Date());
            certVo.setAccountID(certw.getAccountID());
            certVo.setCompID(certw.getCompID());
            certVo.setUkStatus(1);
            certVo.setActiveDate(certw.getActiveDate());
            certVo.setPublicKey(certw.getPublickey());
            certVo.setUserID(userid);
            certVo.setStatus(CertVo.CERT_TOAUDIT);// 修改证书状态为待审批
            certVo.setProvinceID(certw.getProvinceID());
            certVo.setCityID(certw.getCityID());
            certVo.setAreaID(certw.getAreaID());
            certVo.setCompName(certw.getCompName());
            certMapperVo.insertSelectiveVo(certVo);
        }
        return certVo;
    }


    @Override
    public List<CertVo> queryCertificateOne(CertExample example) throws Exception {
        List<CertWithBLOBs> list = certMapperVo.selectByExampleWithBLOBs(example);
        return CertVoConvert.convert(list);
    }

    private static String PLATFORMID_SY;
    @Value("${PLATFORMID_SY}")
    public void setPLATFORMID_SY(String PLATFORMID_SY) {
        this.PLATFORMID_SY = PLATFORMID_SY;
    }
    @Override
    @Transactional
    public CertWithBLOBs downloadCert(CertWithBLOBs cert) throws Exception {
        try {
            BASE64Encoder encoder = new BASE64Encoder();
            String publickey = encoder.encode(cert.getPublickey());

            // downloadResponseVO = downloadCert(cert.getTxcode(),publickey,"");
            DownloadCertReqVO downloadCertReqVO = new DownloadCertReqVO();
            downloadCertReqVO.setPlatformid(PLATFORMID_SY);
            downloadCertReqVO.setTransactioncode(cert.getTxcode());
            downloadCertReqVO.setAuthcode("");
            downloadCertReqVO.setSubjectpubkey(publickey);

            CertResponseVO certResponseVO = CAClient.downloadCert(downloadCertReqVO);
            // 下载证书失败
            if (!"0".equals(certResponseVO.getResult())) {
                throw new Exception("下载证书失败,错误码=" + certResponseVO.getResult());
            }
            BASE64Decoder decoder = new BASE64Decoder();
            byte[] decodeBuffer = decoder.decodeBuffer(certResponseVO.getSigncert().toString());

            // downloadResponseVO.getSigncert()
            // 解析证书对象
            if (cert.getUkStatus().intValue() == 1) {
                CertExample example = new CertExample();
                List<Integer> status = new ArrayList<Integer>();
                status.add(0);
                status.add(5);
                example.createCriteria().andStatusIn(status).andCompidEqualTo(cert.getCompID())
                        .andCertsnEqualTo(cert.getCertSN());
                List<CertWithBLOBs> certs = certMapperVo.selectByExampleWithBLOBs(example);
                if (certs.size() > 0) {
                    CertWithBLOBs cert2 = certs.get(0);
                    cert2.setStatus(4);
                    certMapper.updateByPrimaryKeySelective(cert2);
                }
            }
            CertInfo certInfo = new CertInfo(decodeBuffer);
            cert.setX509(decodeBuffer);
            cert.setCertSN(certInfo.getSerialNumber());
            cert.setValidDate(certInfo.getNotBeforeDate());
            cert.setInvalidDate(certInfo.getNotAfterDate());
            cert.setStatus(CertVo.CERT_OK);
            cert.setActiveDate(new Date());
            // certificateDao.updateCertificate(certificate);
            certMapper.updateByPrimaryKeySelective(cert);
            logger.info("end=================" + new Date().getTime());
        } catch (CaCommunicationException e) {
            logger.error(e.toString());
            e.printStackTrace();
            throw new Exception("下载证书失败,连接CA服务器异常");
        } catch (DocumentException e) {
            logger.error(e.toString());
            e.printStackTrace();
            throw new Exception("下载证书失败,解析响应XML失败");
        } catch (Exception e) {
            logger.error(e.toString());
            e.printStackTrace();
            throw new Exception("下载证书失败,系统异常");
        }
        return cert;
    }

    @Override
    public void updateCertByCompanyId(Map<String,Object> param) {
        List<CertVo> cb= certServant.selectCertByCompId(Integer.valueOf(param.get("companyId").toString()));
        if(cb !=null && cb.size() >0){
            for(int i=0;i<cb.size();i++){
                CertVo cVo =cb.get(i);
                cVo.setCompName(param.get("companyName").toString());
                cVo.setProvinceID(Integer.valueOf(param.get("provinceId").toString()));
                cVo.setCityID(Integer.valueOf(param.get("cityId").toString()));
                cVo.setAreaID(Integer.valueOf(param.get("areaId").toString()));
                if(1 != cVo.getStatus()  &&  2 != cVo.getStatus()){
                    //certServant.revokeCertificate(cVo.getCertID());
                    cVo.setStatus(6);
                    cVo.setLupDate(new Date());
                    certServant.UpdateCert(CertConvert.convert(cVo));
                }else{
                    certMapperVo.deleteByPrimaryKey(cVo.getCertID());
                }
            }
        }
        //删除公章
//        stampService.deleteData2(Integer.valueOf(param.get("companyId").toString()));
    }

    @Override
    public long getCertValidity(Integer companyId) throws BaseException {
        long result = 0;
        CertExample example = new CertExample();
        List<Integer> status = new ArrayList<Integer>();
        status.add(0);
        status.add(5);
        example.createCriteria().andCompidEqualTo(companyId).andStatusIn(status);
        List<CertWithBLOBs> certs = certMapper.selectByExampleWithBLOBs(example);
        if (certs.size()!=0&&certs.size()>1){
            logger.error("CerServiceImpl.getCertValidity() : ======数据异常，请联系管理员======");
            throw new BaseException("数据异常，请联系管理员");
        }else if (certs.size()==1){
            CertWithBLOBs cert = certs.get(0);
            result = (cert.getInvalidDate().getTime()-new Date().getTime())/(1000*60*60*24);
        }
        return result;
    }


    @Override
    public Integer updateCertVo(CertVo certVo) throws Exception {
        // TODO Auto-generated method stub
        return certMapper.updateByPrimaryKeySelective(CertConvert.convert(certVo));
    }



}
