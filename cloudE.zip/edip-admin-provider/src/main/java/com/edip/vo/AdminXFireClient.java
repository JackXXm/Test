package com.edip.vo;



import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.xfire.client.Client;


import java.net.URL;
import java.util.HashMap;
import java.util.Map;


/**
 * XFireClient      2012-8-3
 *  xFire客户端，与CMCA的openAPI通信
 * @Description:
 * @Copyright: Copyright (c) 2012
 * @Company: Aspire Technologies
 * @version 1.0
 * @author: huangliang
 */
public class AdminXFireClient {
	private static final Log logger = LogFactory.getLog(AdminXFireClient.class);

	public AdminXFireClient() {

	}

	/**
	 * 
	 * @description: taac与openAPI通信（webService）
	 * @param operationName
	 *            操作类型名称
	 * @param url
	 *            请求url
	 * @param reqXml
	 *            请求内容（xml）
	 * @return String
	 * @throws CaCommunicationException
	 */
	@SuppressWarnings({ "unused", "unchecked" })
	public static String webServiceReq(String operationName, String url,
			String reqXml) throws Exception {
		logger.info("Enter into webServiceReq of XFireClient!******");
		logger.info("url=" + url);
		logger.info("operationName=" + operationName);
		logger.info("reqXML=" + reqXml);
		Client client;
		String result = "";
		
		Map<String, String> caRespMap = new HashMap<>();

		try {
			client = new Client(new URL(url));
			client.setTimeout(1000 * 10);
			result = (String) client.invoke(operationName, new Object[] { reqXml })[0];
			logger.info("Left webServiceReq of XFireClient! result is: 	"
					+ result);

//			caRespMap = HttpConnUtil.xml2DataMap(result.getBytes("UTF-8"));

			client.close();
		} catch (Exception e) {
			logger.error("error",e);
			throw new Exception(e.getMessage());
		}

		return result;
	}

	public static void main(String[] args) throws Exception {
//		 String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><request
//		 xcommand=\"AccountCertRequest\"><platformid>1</platformid><parameters><idtype>11</idtype><idvalue>15811008197</idvalue><certsort>11</certsort><certapptype>321</certapptype><subjectpubkey></subjectpubkey><username></username><usercardtype></usercardtype><usercardnum></usercardnum><usermobilephone></usermobilephone><useremail></useremail><unitname></unitname><unitlicensecode></unitlicensecode><certstoragetype>ccit_esy_client_p12</certstoragetype><notbefore></notbefore><notafter></notafter><extend1></extend1><extend2></extend2><extend3></extend3><extend4></extend4><extend5></extend5></parameters></request>";
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><request command=\"EntCertRequest\"><platformid>10000002</platformid><parameters><unitname><![CDATA[android123.apk 1.0 test mm]]></unitname><unitlicensecode>333344454</unitlicensecode><ipaddress></ipaddress><certsort>17</certsort><certapptype>341</certapptype><subjectpubkey>MIGJAoGBALj3ytP7bDGqiF9xsBE2Li2WMR2L7jQr2HZGsXqAFJaDHPUMjo7t60NRrsLNvf5B5NMSwCJsMWq6Ax5jKTSOKWVVK2y/awLcfC02toM5DYc2q/HlSpBVGXzusaJWa5hL8kPfxUF4gjDAbl4603g5NyAYYDw2xFs3w1QXgGz7G1XrAgMBAAE=</subjectpubkey><unitbusinesscode>43434343434</unitbusinesscode><province></province><city></city><unitemail></unitemail><unittelephone>01064413320</unittelephone><unitfax></unitfax><unitaddress></unitaddress><unitpostalcode></unitpostalcode><username><![CDATA[pengtao]]></username><cardtype>1</cardtype><cardnum>34010219720424051</cardnum><telephone></telephone><mobilephone>13956784901</mobilephone><email>peng@ccit.com.cn</email><certstoretype>ccit_esy_client_p12</certstoretype><notbefore></notbefore><notafter></notafter></parameters></request>";
		String re=AdminXFireClient.webServiceReq("entCertApply",
				"http://10.1.4.238:8083/openapi/services/EntCertApply?wsdl",
				xml);
		System.out.println(re);
	}
}
