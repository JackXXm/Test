package com.edip.service.impl;

import com.edip.entity.CompInfo;
import com.edip.mapper.CompanyMapperVo;
import com.edip.service.CompanyIfBiz;
import com.edip.vo.CompInfoVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("companyIfBiz")
public class CompanyIfBizImpl implements CompanyIfBiz {

    @Autowired
    @Qualifier("companyMapperVo")
    private CompanyMapperVo companyMapperVo;

    @Override
    public CompInfo searchCompInfo(String compID) {
        return companyMapperVo.searchCompInfo(Integer.parseInt(compID));
    }

    @Override
    public CompInfoVo searchCompByCompID(String compID) {
        return companyMapperVo.searchCompByCompID(compID);
    }

    @Override
    public void updateCompByCompID(CompInfoVo vo) {
        companyMapperVo.updateCompByCompID(vo);
    }

    @Override
    public void insertCompInfo(CompInfoVo vo) {
        companyMapperVo.insertCompInfo(vo);
    }
}
