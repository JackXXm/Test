package com.edip.feign;

import com.edip.dto.ServerResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(serviceId = "edip-company-provider")
public interface AddCdrFeign {
    /**
     * 插入短信账单
     * @param mobile 手机号
     * @param cdrType 0 话单类型 短信
     * @param cdrSubType 0 话单子类型 验证短信
     * @param companyId 公司id
     * @return
     */
    @RequestMapping("/cdr/addCdr.ajax")
    ServerResponse addCdr(@RequestParam("mobile")String mobile,@RequestParam("cdrType")Integer cdrType,
                          @RequestParam("cdrSubType")Integer cdrSubType,@RequestParam("companyId")Integer companyId);
}
