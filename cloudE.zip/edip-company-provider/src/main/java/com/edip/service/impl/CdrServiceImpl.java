package com.edip.service.impl;

import com.edip.entity.Cdr;
import com.edip.mapper.CdrMapper;
import com.edip.mapper.CertMapper;
import com.edip.service.CdrService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

//import org.dom4j.DocumentException;

@Service
public class CdrServiceImpl implements CdrService {
    private static final Logger logger = LoggerFactory.getLogger(CdrServiceImpl.class);
    @Autowired
    private CdrMapper cdrMapper;


    @Override
    public void addCdr(String mobile, Integer cdrType, Integer cdrSubType, Integer companyId) {
        Cdr cdr = new Cdr();
        if(companyId !=null ){
            cdr.setCompid(companyId);
        }else{
            cdr.setCompid(-2);
        }
        cdr.setCdrtype(cdrType);
        cdr.setCdrsubtype(cdrSubType);
        Date createDate = new Date();
        cdr.setCreatedate(createDate);
        cdr.setTargetid(cdr.getCompid());
        cdrMapper.insertSelective(cdr);
    }
}
