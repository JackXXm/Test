package com.edip.service.impl;

import com.edip.entity.Address;
import com.edip.entity.AddressExample;
import com.edip.mapper.AddressMapper;
import com.edip.mapper.CertMapper;
//import com.edip.servant.AccountManagerServant;
import com.edip.service.CertificateService;
import com.edip.util.AttachmentConfigUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.List;

@Service("certificateService")
public class CretificateSreviceImpl implements CertificateService {

	@Autowired
	private AddressMapper addressMapper;
	@Autowired
	private CertMapper certMapper;

	@Override
	public int addOrEditUkeyAdress(Address address) {
		Address ad = getAddressByCompId(address.getCompID());
		if(ad!=null){
			address.setAdrID(ad.getAdrID());
			addressMapper.updateByPrimaryKeySelective(address);
			return 1;
		}else{
			addressMapper.insertSelective(address);
			return 0;
		}
	}
	@Override
	public Address getAddressByCompId(Integer compId) {
		AddressExample addressExample = new AddressExample();
		AddressExample.Criteria criteria = addressExample.createCriteria();
		criteria.andCompIDEqualTo(compId);
		List<Address> addressList = addressMapper.selectByExample(addressExample);
		if(addressList!=null&&addressList.size()>0)
			return addressList.get(0);
		return null;
	}

	private static String rootPath;
	@Value("${ABSOLUTE_UPLOAD_PATH}")
	public void setABSOLUTE_UPLOAD_PATH(String ABSOLUTE_UPLOAD_PATH) {
		this.rootPath = ABSOLUTE_UPLOAD_PATH;
	}
	private String urlHandler(String path){
		String oldPath = path;
		if(path.indexOf(File.separator+"water")==-1){
			String waterPath = path.replace("data","data"+File.separator+"water");
			if(waterPath.endsWith("pdf"))
				waterPath = waterPath.replace(".pdf",".jpg");
			if(new File(rootPath+waterPath).exists())
				path = waterPath;
		}
		return path.equals(oldPath)?null:path;
	}

}
