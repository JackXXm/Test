package com.edip.service;

import java.util.List;
import com.edip.entity.AdminMessage;
import com.edip.entity.AdminMessageExample;
import com.edip.vo.AdminMessageVo;


/**
 * Created by qiaoxiaolong on 2017/5/9.
 */
public interface AdminMessageBiz {
    //按条件查询
    List<AdminMessageVo> selectByExample(List<Integer> listCompId, Integer accountID, List<Integer> msgTypeList,
                                         String domain);

    //插入
    int insert(AdminMessageVo messageVo);
//    List<AdminMessage>  selectMsgId(AdminMessageVo messageVo);
    //根据主键更新
    int updateByPrimaryKey(AdminMessageVo messageVo);
    
//    int updateStatus(AdminMessageVo messageVo);
//
//  //根据条件更新
//    int updateByExample(AdminMessageVo messageVo, AdminMessageExample messageExample);
    
    List<AdminMessage> selectByExample(AdminMessageExample messageExample);

//    AdminMessage searchMessageByMsgID(AdminMessageVo messageVo);
//
//	int editMessageByMsgID(AdminMessageVo messageVo);
//
//	int updateMessageByMsgID(AdminMessageVo messageVo);
//
//	int editMessageInfoByMsgID(AdminMessageVo messageVo);
//
//	Integer delMessageInfo(Integer msgID);
//
//
//	void messageUpdateRead(Integer msgId, Integer status);

}
