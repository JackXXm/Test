package com.edip.tree;

import java.util.*;

public class TreeBuilder {
    private Map<String, TreeNode> treeNodes = new LinkedHashMap();

    public TreeBuilder() {
    }

    public void addNode(TreeNode node) {
        if (this.treeNodes.containsKey(node.getId())) {
            throw new RuntimeException("存在相同id[" + node.getId() + "]的树节点");
        } else {
            this.treeNodes.put(node.getId(), node);
        }
    }

    public void markChecked(String id) {
        if (this.treeNodes.containsKey(id)) {
            TreeNode node = (TreeNode)this.treeNodes.get(id);
            if (node instanceof CheckTreeNode) {
                ((CheckTreeNode)node).setChecked(true);
                this.expandNode(node);
            }
        }

    }

    public void markDisabled(String id) {
        if (this.treeNodes.containsKey(id)) {
            TreeNode node = (TreeNode)this.treeNodes.get(id);
            if (node instanceof CheckTreeNode) {
                ((CheckTreeNode)node).setDisabled(true);
                this.expandNode(node);
            }
        }

    }

    private void createTree(TreeNode treeNode) {
        Iterator it = this.treeNodes.values().iterator();

        while(it.hasNext()) {
            TreeNode node = (TreeNode)it.next();
            if (node.getParentId() != null && !"".equals(node.getParentId()) && treeNode.getId().equals(node.getParentId())) {
                treeNode.addChild(node);
            }
        }

        Set<TreeNode> childrens = treeNode.getChildren();
        if (childrens != null && childrens.size() > 0) {
            it = childrens.iterator();

            while(it.hasNext()) {
                this.createTree((TreeNode)it.next());
            }
        }

    }

    public List<TreeNode> buildTree() {
        List<TreeNode> rootList = new ArrayList();
        Iterator var3 = this.treeNodes.values().iterator();

        while(true) {
            TreeNode node;
            do {
                if (!var3.hasNext()) {
                    return rootList;
                }

                node = (TreeNode)var3.next();
            } while(node.getParentId() != null && !"".equals(node.getParentId()));

            rootList.add(node);
            this.createTree(node);
        }
    }

    private void expandNode(TreeNode node) {
        if (this.treeNodes.containsKey(node.getParentId())) {
            this.expandNode((TreeNode)this.treeNodes.get(node.getParentId()));
        }

        node.setExpanded(true);
    }

    public List<TreeNode> buildTreeWithNoEmptyNode() {
        List<TreeNode> tempList = new ArrayList();

        TreeNode node;
        Iterator var3;
        for(var3 = this.treeNodes.values().iterator(); var3.hasNext(); tempList.add(node)) {
            node = (TreeNode)var3.next();
            if (node.getParentId() != null && !"".equals(node.getParentId()) && this.treeNodes.containsKey(node.getParentId())) {
                ((TreeNode)this.treeNodes.get(node.getParentId())).addChild(node);
            }
        }

        var3 = tempList.iterator();

        while(var3.hasNext()) {
            node = (TreeNode)var3.next();
            if (node.isLeaf() && !(node instanceof MenuTreeNode)) {
                this.removeNode(node);
            }
        }

        return this.buildTree();
    }

    private void removeNode(TreeNode node) {
        this.treeNodes.remove(node.getId());
        if (this.treeNodes.containsKey(node.getParentId())) {
            TreeNode parent = (TreeNode)this.treeNodes.get(node.getParentId());
            parent.removeChild(node);
            if (parent.isLeaf()) {
                this.removeNode(parent);
            }
        }

    }
}
