package com.edip.dto.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class RedisConfig {

	private static final Logger logger = LoggerFactory.getLogger(RedisConfig.class);

	private static Properties properties;

	static {
		try {
			properties = new Properties();
			String filePath = System.getProperty("user.dir") + "/config/redis.properties";
			InputStream is = new FileInputStream(filePath);
			properties.load(is);
			if (is != null) {
				is.close();
			}
		} catch (Exception e) {
			logger.error("系统初始化读取smsconfig.properties文件出错", e.getMessage(),e);
		}
	}

	public static String getProperty(String key) {
		return properties.getProperty(key);
	}

	public static int getPropertyInt(String key) {
		return Integer.parseInt(properties.getProperty(key));
	}

}
