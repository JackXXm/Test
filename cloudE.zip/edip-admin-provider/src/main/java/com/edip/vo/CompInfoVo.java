package com.edip.vo;

import java.util.Date;

public class CompInfoVo {

    private Integer compID;    //公司ID

    private String compName;	//公司名称

    private String regi_status;	//登记状态

    private String Legal_representative;	//法人代表

    private String registered_capital;		//注册资本

    private String EnterpriseCreditCode;	//企业信用代码

    private String registerNo;				//注册号


    private String regist_authority;		//登记机关

    private String createDate;				//成立时间


    private String business_term;			//营业期限

    private String businessType;			//企业类型

    private String adreess;					//企业地址

    private String businessScope;			//经营范围

    private Date creDate;

    public Date getCreDate() {
        return creDate;
    }

    public void setCreDate(Date creDate) {
        this.creDate = creDate;
    }

    public Integer getCompID() {
        return compID;
    }

    public void setCompID(Integer compID) {
        this.compID = compID;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getRegi_status() {
        return regi_status;
    }

    public void setRegi_status(String regi_status) {
        this.regi_status = regi_status;
    }

    public String getLegal_representative() {
        return Legal_representative;
    }

    public void setLegal_representative(String legal_representative) {
        Legal_representative = legal_representative;
    }

    public String getRegistered_capital() {
        return registered_capital;
    }

    public void setRegistered_capital(String registered_capital) {
        this.registered_capital = registered_capital;
    }

    public String getEnterpriseCreditCode() {
        return EnterpriseCreditCode;
    }

    public void setEnterpriseCreditCode(String enterpriseCreditCode) {
        EnterpriseCreditCode = enterpriseCreditCode;
    }

    public String getRegisterNo() {
        return registerNo;
    }

    public void setRegisterNo(String registerNo) {
        this.registerNo = registerNo;
    }

    public String getRegist_authority() {
        return regist_authority;
    }

    public void setRegist_authority(String regist_authority) {
        this.regist_authority = regist_authority;
    }



    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getBusiness_term() {
        return business_term;
    }

    public void setBusiness_term(String business_term) {
        this.business_term = business_term;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public String getAdreess() {
        return adreess;
    }

    public void setAdreess(String adreess) {
        this.adreess = adreess;
    }

    public String getBusinessScope() {
        return businessScope;
    }

    public void setBusinessScope(String businessScope) {
        this.businessScope = businessScope;
    }


}
