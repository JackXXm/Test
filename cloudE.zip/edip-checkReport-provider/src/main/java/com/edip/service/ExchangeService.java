package com.edip.service;


import com.edip.dto.ServerResponse;
import com.edip.dto.util.Page;
import com.edip.entity.ExchangeInfo;
import com.github.pagehelper.PageInfo;

import java.util.List;
import java.util.Map;

public interface ExchangeService {
    ServerResponse getCheckReportDetail(Map<String,Object> args);
    ServerResponse sendCheckExchangeInfo(ExchangeInfo exchangeInfo ,int compID,int accountID ,String accountName,String companyName) throws Exception;
    ServerResponse getSendReportDocDetail(Map<String,Object> args);
    /**
     * 查询发送接收企业
     * @param compID
     * @param searchKey
     * @param searchType
     * @return
     */
    PageInfo queryReceiveCompany(Integer compID, String compName, String searchKey, String searchType, int page, int rows);
}
