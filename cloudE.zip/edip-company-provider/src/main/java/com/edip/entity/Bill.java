package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class Bill implements Serializable {
    /**
     * 账单ID
     */
    private Integer billid;

    /**
     * 账单类型:
	                                                                       0:短信
  	                                                                     1:资质查询
  	                                                                     2:证书
                                                                         3:数据交换
     */
    private Integer cdrtype;

    /**
     * 账单类型:
                                     																		 00:验证短信
                                     																		 10:通知短信
                                     																		 10:企业资质
                                     																		 11:个人资质
                                     																		 20:个人证书
                                     																		 21:企业证书
                                                                         30:数据交换
     */
    private Float cdrsubtype;

    /**
     * 总次数
     */
    private Float totalcount;

    /**
     * 使用总次数
     */
    private Float usedcount;

    /**
     * 剩余总次数
     */
    private Float remaincount;

    /**
     * 每次冲值金额除billMode.unitPrice
     */
    private Integer remainder;

    /**
     * 冲值累计总金额
     */
    private Float totalamount;

    /**
     * 剩余总金额
     */
    private Float remainamount;

    /**
     * 归属公司
     */
    private Integer compid;

    /**
     * 创建时间
     */
    private Date createdate;

    /**
     * 计费策略ID
     */
    private Integer modeid;

    /**
     * 交换数据免费截止日期
     */
    private Date freedate;

    /**
     * 赠送总金额
     */
    private Float giveamount;

    /**
     * 剩余赠送金额
     */
    private Float remaingiveamount;

    private static final long serialVersionUID = 1L;

    public Integer getBillid() {
        return billid;
    }

    public void setBillid(Integer billid) {
        this.billid = billid;
    }

    public Integer getCdrtype() {
        return cdrtype;
    }

    public void setCdrtype(Integer cdrtype) {
        this.cdrtype = cdrtype;
    }

    public Float getCdrsubtype() {
        return cdrsubtype;
    }

    public void setCdrsubtype(Float cdrsubtype) {
        this.cdrsubtype = cdrsubtype;
    }

    public Float getTotalcount() {
        return totalcount;
    }

    public void setTotalcount(Float totalcount) {
        this.totalcount = totalcount;
    }

    public Float getUsedcount() {
        return usedcount;
    }

    public void setUsedcount(Float usedcount) {
        this.usedcount = usedcount;
    }

    public Float getRemaincount() {
        return remaincount;
    }

    public void setRemaincount(Float remaincount) {
        this.remaincount = remaincount;
    }

    public Integer getRemainder() {
        return remainder;
    }

    public void setRemainder(Integer remainder) {
        this.remainder = remainder;
    }

    public Float getTotalamount() {
        return totalamount;
    }

    public void setTotalamount(Float totalamount) {
        this.totalamount = totalamount;
    }

    public Float getRemainamount() {
        return remainamount;
    }

    public void setRemainamount(Float remainamount) {
        this.remainamount = remainamount;
    }

    public Integer getCompid() {
        return compid;
    }

    public void setCompid(Integer compid) {
        this.compid = compid;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Integer getModeid() {
        return modeid;
    }

    public void setModeid(Integer modeid) {
        this.modeid = modeid;
    }

    public Date getFreedate() {
        return freedate;
    }

    public void setFreedate(Date freedate) {
        this.freedate = freedate;
    }

    public Float getGiveamount() {
        return giveamount;
    }

    public void setGiveamount(Float giveamount) {
        this.giveamount = giveamount;
    }

    public Float getRemaingiveamount() {
        return remaingiveamount;
    }

    public void setRemaingiveamount(Float remaingiveamount) {
        this.remaingiveamount = remaingiveamount;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Bill other = (Bill) that;
        return (this.getBillid() == null ? other.getBillid() == null : this.getBillid().equals(other.getBillid()))
            && (this.getCdrtype() == null ? other.getCdrtype() == null : this.getCdrtype().equals(other.getCdrtype()))
            && (this.getCdrsubtype() == null ? other.getCdrsubtype() == null : this.getCdrsubtype().equals(other.getCdrsubtype()))
            && (this.getTotalcount() == null ? other.getTotalcount() == null : this.getTotalcount().equals(other.getTotalcount()))
            && (this.getUsedcount() == null ? other.getUsedcount() == null : this.getUsedcount().equals(other.getUsedcount()))
            && (this.getRemaincount() == null ? other.getRemaincount() == null : this.getRemaincount().equals(other.getRemaincount()))
            && (this.getRemainder() == null ? other.getRemainder() == null : this.getRemainder().equals(other.getRemainder()))
            && (this.getTotalamount() == null ? other.getTotalamount() == null : this.getTotalamount().equals(other.getTotalamount()))
            && (this.getRemainamount() == null ? other.getRemainamount() == null : this.getRemainamount().equals(other.getRemainamount()))
            && (this.getCompid() == null ? other.getCompid() == null : this.getCompid().equals(other.getCompid()))
            && (this.getCreatedate() == null ? other.getCreatedate() == null : this.getCreatedate().equals(other.getCreatedate()))
            && (this.getModeid() == null ? other.getModeid() == null : this.getModeid().equals(other.getModeid()))
            && (this.getFreedate() == null ? other.getFreedate() == null : this.getFreedate().equals(other.getFreedate()))
            && (this.getGiveamount() == null ? other.getGiveamount() == null : this.getGiveamount().equals(other.getGiveamount()))
            && (this.getRemaingiveamount() == null ? other.getRemaingiveamount() == null : this.getRemaingiveamount().equals(other.getRemaingiveamount()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getBillid() == null) ? 0 : getBillid().hashCode());
        result = prime * result + ((getCdrtype() == null) ? 0 : getCdrtype().hashCode());
        result = prime * result + ((getCdrsubtype() == null) ? 0 : getCdrsubtype().hashCode());
        result = prime * result + ((getTotalcount() == null) ? 0 : getTotalcount().hashCode());
        result = prime * result + ((getUsedcount() == null) ? 0 : getUsedcount().hashCode());
        result = prime * result + ((getRemaincount() == null) ? 0 : getRemaincount().hashCode());
        result = prime * result + ((getRemainder() == null) ? 0 : getRemainder().hashCode());
        result = prime * result + ((getTotalamount() == null) ? 0 : getTotalamount().hashCode());
        result = prime * result + ((getRemainamount() == null) ? 0 : getRemainamount().hashCode());
        result = prime * result + ((getCompid() == null) ? 0 : getCompid().hashCode());
        result = prime * result + ((getCreatedate() == null) ? 0 : getCreatedate().hashCode());
        result = prime * result + ((getModeid() == null) ? 0 : getModeid().hashCode());
        result = prime * result + ((getFreedate() == null) ? 0 : getFreedate().hashCode());
        result = prime * result + ((getGiveamount() == null) ? 0 : getGiveamount().hashCode());
        result = prime * result + ((getRemaingiveamount() == null) ? 0 : getRemaingiveamount().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", billid=").append(billid);
        sb.append(", cdrtype=").append(cdrtype);
        sb.append(", cdrsubtype=").append(cdrsubtype);
        sb.append(", totalcount=").append(totalcount);
        sb.append(", usedcount=").append(usedcount);
        sb.append(", remaincount=").append(remaincount);
        sb.append(", remainder=").append(remainder);
        sb.append(", totalamount=").append(totalamount);
        sb.append(", remainamount=").append(remainamount);
        sb.append(", compid=").append(compid);
        sb.append(", createdate=").append(createdate);
        sb.append(", modeid=").append(modeid);
        sb.append(", freedate=").append(freedate);
        sb.append(", giveamount=").append(giveamount);
        sb.append(", remaingiveamount=").append(remaingiveamount);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}