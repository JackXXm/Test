package com.edip.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.entity.Address;
import com.edip.entity.Cert;
import com.edip.entity.CertExample;
import com.edip.entity.CertWithBLOBs;
import com.edip.feign.AccountFeign;
import com.edip.feign.CompanyFeign;
import com.edip.mapper.CertMapper;
import com.edip.mapper.CertMapperVo;
//import com.edip.model.CompanyExample;
import com.edip.service.CertificateService;
import com.edip.vo.CertVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/certificate")
public class CertificateController{
	private static final Logger logger = LoggerFactory.getLogger(CertificateController.class);
	@Autowired
	private HttpServletRequest request;
	@Autowired
	private CertificateService certificateService;
	@Autowired
	private CertMapperVo certMappervo;
	@Autowired
	private CertMapper certMapper;
	@Autowired
	private AccountFeign accountFeign;
	@Autowired
	private CompanyFeign companyFeign;
	
	@RequestMapping(value = "/addOrEditUkeyAdress.ajax", method = RequestMethod.POST)
	@ResponseBody
	public ServerResponse addOrEditUkeyAdress(HttpServletRequest request,Address address) {
		HttpSession httpSession = SessionContext.getContext().getSession(request);
		Integer companyId= (Integer) httpSession.getAttribute("compID");
		Integer accountID= (Integer) httpSession.getAttribute("accountID");
		try {
			if(address == null){
				logger.debug("ukey邮寄地址信息为空");
				return ServerResponse.createByErrorMsg("ukey邮寄地址信息为空");
			}
			address.setCompID(companyId);
			int status = certificateService.addOrEditUkeyAdress(address);
			String message = "修改ukey邮寄地址信息成功";
			if(status == 0){
				message = "新增ukey邮寄地址信息成功";
			}
			logger.debug(message);
			return ServerResponse.createBySuccessMsg(message);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return ServerResponse.createByErrorMsg("新增或修改ukey邮寄地址信息失败");
		}
	}

	private<T>  Map<String, Object> success(T data) {
		Map<String, Object> modelMap = new HashMap(2);
		modelMap.put("data", data);
		modelMap.put("success", true);
		return modelMap;
	}

	private Map<String, Object> fail(String message) {
		Map<String, Object> modelMap = new HashMap(2);
		modelMap.put("message", message);
		modelMap.put("success", false);
		return modelMap;
	}

	@RequestMapping(value = "/getAdderss.ajax", method = RequestMethod.POST)
	@ResponseBody
	public ServerResponse getAdderss(HttpServletRequest request) {
		HttpSession httpSession = SessionContext.getContext().getSession(request);
		Integer companyId= (Integer) httpSession.getAttribute("compID");
		Integer accountID= (Integer) httpSession.getAttribute("accountID");
		try {
//			Address address = certificateService.getAddressByCompId(1);
			Address address = certificateService.getAddressByCompId(companyId);
			logger.debug("查询ukey地址成功！");
			return ServerResponse.createBySuccess(address);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return ServerResponse.createBySuccessMsg("查询ukey地址失败！");
		}
	}
	
	@RequestMapping(value="/getAdmin.ajax")
	@ResponseBody
	public ServerResponse getEnterInfo(HttpSession session){
		try {
			Map<String, Object> error=new HashMap<String, Object>();
			HttpSession httpSession = SessionContext.getContext().getSession(request);
			Integer companyId= (Integer) httpSession.getAttribute("compID");
			Integer accountID= (Integer) httpSession.getAttribute("accountID");
			if(companyId!=null){
				Map<String, Object> data = (Map<String, Object>)accountFeign.getCompanyAdmin(companyId).getData();
				return ServerResponse.createBySuccess(data);
			}else {
				logger.error("CertificateController.getEnterInfo: 获取管理员信息失败！");
				return ServerResponse.createByError(103,"获取管理员信息失败,用户未登录！");
			}
		}catch (Exception e){
			logger.error("获取管理员信息失败！"+e.getMessage(),e);
			return ServerResponse.createByError(103,"获取管理员信息失败！");
		}

	}
	@RequestMapping("/isUpdate.ajax")
	@ResponseBody
	public ServerResponse  isUpdate(HttpSession session){
		Map<String,Object> params = new HashMap<String,Object>();
		HttpSession httpSession = SessionContext.getContext().getSession(request);
		Integer companyId= (Integer) httpSession.getAttribute("compID");
		Integer accountID= (Integer) httpSession.getAttribute("accountID");
		try{
			ServerResponse ukeyResult = accountFeign.checkUkeyManager(companyId);
			Integer ukey = (Integer)ukeyResult.getData();
			if(ukey == null){
				params.put("success", false);
				params.put("message", "该公司没有ukey管理员");
				return ServerResponse.createByErrorMsg("该公司没有ukey管理员");
			}
			if(ukey.intValue() == accountID){
				params.put("ukeyFlag", true);
			}else{
				params.put("ukeyFlag", false);
			}
			List<Integer> status =new ArrayList<Integer>();
			status.add(1);
			status.add(2);
			CertExample example = new CertExample();
			example.createCriteria().andStatusEqualTo(CertVo.CERT_TODOWNLOAD).andCompidEqualTo(companyId)
			.andUkstatusIn(status);
			List<CertWithBLOBs> result = certMapper.selectByExampleWithBLOBs(example);
			/*CertVo cert = new CertVo();
			cert.setUkStatus(1);
			cert.setStatus(CertVo.CERT_TODOWNLOAD);
			cert.setAccountID(account.getAccountID());
			CertWithBLOBs result = certMappervo.selectByUkStauts(cert);*/
			if(result.size()>0 && result != null){
				params.put("success", true);
				params.put("result", result.get(0));
				return ServerResponse.createBySuccess(params);

			}else{
				params.put("success", false);
				return ServerResponse.createByError();
			}
		}catch(Exception e){
			logger.error(e.toString(),e);
			params.put("success", false);
			return ServerResponse.createByErrorMsg("该公司没有ukey管理员");
		}
	}
	
	
	@RequestMapping("/getCert.ajax")
	@ResponseBody
	public Map<String, ? extends Object>  getCert(HttpSession session){
		Map<String,Object> params = new HashMap<String,Object>();
		HttpSession httpSession = SessionContext.getContext().getSession(request);
		Integer companyId= (Integer) httpSession.getAttribute("compID");
		Integer accountID= (Integer) httpSession.getAttribute("accountID");
		List<Integer> stauts = new ArrayList<Integer>();
		stauts.add(4);
		//20180419注释，证书查询过滤去掉已过期    stauts.add(3);  
		try{
			CertExample certExample = new CertExample();
			certExample.createCriteria().andCompidEqualTo(companyId)
				.andStatusNotIn(stauts)/*.andUseridEqualTo(account.getAccountID())*/;
			List<Cert> certs = certMappervo.selectByExample(certExample);
			
			List<String> status1 =  new ArrayList<String>();
			status1.add("2");
			status1.add("3");
			ServerResponse result = companyFeign.checkCompanyStatus(companyId);
			if(certs != null){
				if(result.getData() != null && (Integer)result.getData() ==1){
					params.put("compFlag", true);
					for(Cert c:certs){
						if(c.getStatus() == 6){
							if(c.getCertSN() !=null || c.getActiveDate() !=null){
								params.put("compFlag", true);
							}else{
								params.put("compFlag", false);
							}
						}else{
							params.put("compFlag", false);
						}
					}
				}else{
					params.put("compFlag", false);
				}
				params.put("data", certs);
				params.put("success", true);
				return params;
				//return success(certs);
			}else{
				params.put("success", false);
			}
		}catch(Exception e){
			logger.error(e.toString());
			params.put("success", false);
		}
		return params;
	}
}
