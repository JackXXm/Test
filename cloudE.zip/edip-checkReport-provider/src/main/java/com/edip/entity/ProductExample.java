package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProductExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public ProductExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andProductidIsNull() {
            addCriterion("productID is null");
            return (Criteria) this;
        }

        public Criteria andProductidIsNotNull() {
            addCriterion("productID is not null");
            return (Criteria) this;
        }

        public Criteria andProductidEqualTo(Integer value) {
            addCriterion("productID =", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotEqualTo(Integer value) {
            addCriterion("productID <>", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidGreaterThan(Integer value) {
            addCriterion("productID >", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidGreaterThanOrEqualTo(Integer value) {
            addCriterion("productID >=", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidLessThan(Integer value) {
            addCriterion("productID <", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidLessThanOrEqualTo(Integer value) {
            addCriterion("productID <=", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidIn(List<Integer> values) {
            addCriterion("productID in", values, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotIn(List<Integer> values) {
            addCriterion("productID not in", values, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidBetween(Integer value1, Integer value2) {
            addCriterion("productID between", value1, value2, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotBetween(Integer value1, Integer value2) {
            addCriterion("productID not between", value1, value2, "productid");
            return (Criteria) this;
        }

        public Criteria andProtypeIsNull() {
            addCriterion("proType is null");
            return (Criteria) this;
        }

        public Criteria andProtypeIsNotNull() {
            addCriterion("proType is not null");
            return (Criteria) this;
        }

        public Criteria andProtypeEqualTo(String value) {
            addCriterion("proType =", value, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeNotEqualTo(String value) {
            addCriterion("proType <>", value, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeGreaterThan(String value) {
            addCriterion("proType >", value, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeGreaterThanOrEqualTo(String value) {
            addCriterion("proType >=", value, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeLessThan(String value) {
            addCriterion("proType <", value, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeLessThanOrEqualTo(String value) {
            addCriterion("proType <=", value, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeLike(String value) {
            addCriterion("proType like", value, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeNotLike(String value) {
            addCriterion("proType not like", value, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeIn(List<String> values) {
            addCriterion("proType in", values, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeNotIn(List<String> values) {
            addCriterion("proType not in", values, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeBetween(String value1, String value2) {
            addCriterion("proType between", value1, value2, "protype");
            return (Criteria) this;
        }

        public Criteria andProtypeNotBetween(String value1, String value2) {
            addCriterion("proType not between", value1, value2, "protype");
            return (Criteria) this;
        }

        public Criteria andCompidIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompidIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompidEqualTo(Integer value) {
            addCriterion("compID =", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThan(Integer value) {
            addCriterion("compID >", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThan(Integer value) {
            addCriterion("compID <", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidIn(List<Integer> values) {
            addCriterion("compID in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNull() {
            addCriterion("accountID is null");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNotNull() {
            addCriterion("accountID is not null");
            return (Criteria) this;
        }

        public Criteria andAccountidEqualTo(Integer value) {
            addCriterion("accountID =", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotEqualTo(Integer value) {
            addCriterion("accountID <>", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThan(Integer value) {
            addCriterion("accountID >", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThanOrEqualTo(Integer value) {
            addCriterion("accountID >=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThan(Integer value) {
            addCriterion("accountID <", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThanOrEqualTo(Integer value) {
            addCriterion("accountID <=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidIn(List<Integer> values) {
            addCriterion("accountID in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotIn(List<Integer> values) {
            addCriterion("accountID not in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidBetween(Integer value1, Integer value2) {
            addCriterion("accountID between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotBetween(Integer value1, Integer value2) {
            addCriterion("accountID not between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andExtidIsNull() {
            addCriterion("extID is null");
            return (Criteria) this;
        }

        public Criteria andExtidIsNotNull() {
            addCriterion("extID is not null");
            return (Criteria) this;
        }

        public Criteria andExtidEqualTo(String value) {
            addCriterion("extID =", value, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidNotEqualTo(String value) {
            addCriterion("extID <>", value, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidGreaterThan(String value) {
            addCriterion("extID >", value, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidGreaterThanOrEqualTo(String value) {
            addCriterion("extID >=", value, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidLessThan(String value) {
            addCriterion("extID <", value, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidLessThanOrEqualTo(String value) {
            addCriterion("extID <=", value, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidLike(String value) {
            addCriterion("extID like", value, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidNotLike(String value) {
            addCriterion("extID not like", value, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidIn(List<String> values) {
            addCriterion("extID in", values, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidNotIn(List<String> values) {
            addCriterion("extID not in", values, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidBetween(String value1, String value2) {
            addCriterion("extID between", value1, value2, "extid");
            return (Criteria) this;
        }

        public Criteria andExtidNotBetween(String value1, String value2) {
            addCriterion("extID not between", value1, value2, "extid");
            return (Criteria) this;
        }

        public Criteria andUninameIsNull() {
            addCriterion("uniName is null");
            return (Criteria) this;
        }

        public Criteria andUninameIsNotNull() {
            addCriterion("uniName is not null");
            return (Criteria) this;
        }

        public Criteria andUninameEqualTo(String value) {
            addCriterion("uniName =", value, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameNotEqualTo(String value) {
            addCriterion("uniName <>", value, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameGreaterThan(String value) {
            addCriterion("uniName >", value, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameGreaterThanOrEqualTo(String value) {
            addCriterion("uniName >=", value, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameLessThan(String value) {
            addCriterion("uniName <", value, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameLessThanOrEqualTo(String value) {
            addCriterion("uniName <=", value, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameLike(String value) {
            addCriterion("uniName like", value, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameNotLike(String value) {
            addCriterion("uniName not like", value, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameIn(List<String> values) {
            addCriterion("uniName in", values, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameNotIn(List<String> values) {
            addCriterion("uniName not in", values, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameBetween(String value1, String value2) {
            addCriterion("uniName between", value1, value2, "uniname");
            return (Criteria) this;
        }

        public Criteria andUninameNotBetween(String value1, String value2) {
            addCriterion("uniName not between", value1, value2, "uniname");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andPictureurlIsNull() {
            addCriterion("pictureURL is null");
            return (Criteria) this;
        }

        public Criteria andPictureurlIsNotNull() {
            addCriterion("pictureURL is not null");
            return (Criteria) this;
        }

        public Criteria andPictureurlEqualTo(String value) {
            addCriterion("pictureURL =", value, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlNotEqualTo(String value) {
            addCriterion("pictureURL <>", value, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlGreaterThan(String value) {
            addCriterion("pictureURL >", value, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlGreaterThanOrEqualTo(String value) {
            addCriterion("pictureURL >=", value, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlLessThan(String value) {
            addCriterion("pictureURL <", value, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlLessThanOrEqualTo(String value) {
            addCriterion("pictureURL <=", value, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlLike(String value) {
            addCriterion("pictureURL like", value, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlNotLike(String value) {
            addCriterion("pictureURL not like", value, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlIn(List<String> values) {
            addCriterion("pictureURL in", values, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlNotIn(List<String> values) {
            addCriterion("pictureURL not in", values, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlBetween(String value1, String value2) {
            addCriterion("pictureURL between", value1, value2, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andPictureurlNotBetween(String value1, String value2) {
            addCriterion("pictureURL not between", value1, value2, "pictureurl");
            return (Criteria) this;
        }

        public Criteria andProductdescIsNull() {
            addCriterion("productDesc is null");
            return (Criteria) this;
        }

        public Criteria andProductdescIsNotNull() {
            addCriterion("productDesc is not null");
            return (Criteria) this;
        }

        public Criteria andProductdescEqualTo(String value) {
            addCriterion("productDesc =", value, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescNotEqualTo(String value) {
            addCriterion("productDesc <>", value, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescGreaterThan(String value) {
            addCriterion("productDesc >", value, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescGreaterThanOrEqualTo(String value) {
            addCriterion("productDesc >=", value, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescLessThan(String value) {
            addCriterion("productDesc <", value, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescLessThanOrEqualTo(String value) {
            addCriterion("productDesc <=", value, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescLike(String value) {
            addCriterion("productDesc like", value, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescNotLike(String value) {
            addCriterion("productDesc not like", value, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescIn(List<String> values) {
            addCriterion("productDesc in", values, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescNotIn(List<String> values) {
            addCriterion("productDesc not in", values, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescBetween(String value1, String value2) {
            addCriterion("productDesc between", value1, value2, "productdesc");
            return (Criteria) this;
        }

        public Criteria andProductdescNotBetween(String value1, String value2) {
            addCriterion("productDesc not between", value1, value2, "productdesc");
            return (Criteria) this;
        }

        public Criteria andUnitIsNull() {
            addCriterion("unit is null");
            return (Criteria) this;
        }

        public Criteria andUnitIsNotNull() {
            addCriterion("unit is not null");
            return (Criteria) this;
        }

        public Criteria andUnitEqualTo(String value) {
            addCriterion("unit =", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitNotEqualTo(String value) {
            addCriterion("unit <>", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitGreaterThan(String value) {
            addCriterion("unit >", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitGreaterThanOrEqualTo(String value) {
            addCriterion("unit >=", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitLessThan(String value) {
            addCriterion("unit <", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitLessThanOrEqualTo(String value) {
            addCriterion("unit <=", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitLike(String value) {
            addCriterion("unit like", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitNotLike(String value) {
            addCriterion("unit not like", value, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitIn(List<String> values) {
            addCriterion("unit in", values, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitNotIn(List<String> values) {
            addCriterion("unit not in", values, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitBetween(String value1, String value2) {
            addCriterion("unit between", value1, value2, "unit");
            return (Criteria) this;
        }

        public Criteria andUnitNotBetween(String value1, String value2) {
            addCriterion("unit not between", value1, value2, "unit");
            return (Criteria) this;
        }

        public Criteria andAuditinfoIsNull() {
            addCriterion("auditInfo is null");
            return (Criteria) this;
        }

        public Criteria andAuditinfoIsNotNull() {
            addCriterion("auditInfo is not null");
            return (Criteria) this;
        }

        public Criteria andAuditinfoEqualTo(String value) {
            addCriterion("auditInfo =", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoNotEqualTo(String value) {
            addCriterion("auditInfo <>", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoGreaterThan(String value) {
            addCriterion("auditInfo >", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoGreaterThanOrEqualTo(String value) {
            addCriterion("auditInfo >=", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoLessThan(String value) {
            addCriterion("auditInfo <", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoLessThanOrEqualTo(String value) {
            addCriterion("auditInfo <=", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoLike(String value) {
            addCriterion("auditInfo like", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoNotLike(String value) {
            addCriterion("auditInfo not like", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoIn(List<String> values) {
            addCriterion("auditInfo in", values, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoNotIn(List<String> values) {
            addCriterion("auditInfo not in", values, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoBetween(String value1, String value2) {
            addCriterion("auditInfo between", value1, value2, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoNotBetween(String value1, String value2) {
            addCriterion("auditInfo not between", value1, value2, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreatedateEqualTo(Date value) {
            addCriterion("createDate =", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThan(Date value) {
            addCriterion("createDate <", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateIn(List<Date> values) {
            addCriterion("createDate in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andLupdateIsNull() {
            addCriterion("lupDate is null");
            return (Criteria) this;
        }

        public Criteria andLupdateIsNotNull() {
            addCriterion("lupDate is not null");
            return (Criteria) this;
        }

        public Criteria andLupdateEqualTo(Date value) {
            addCriterion("lupDate =", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotEqualTo(Date value) {
            addCriterion("lupDate <>", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateGreaterThan(Date value) {
            addCriterion("lupDate >", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateGreaterThanOrEqualTo(Date value) {
            addCriterion("lupDate >=", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateLessThan(Date value) {
            addCriterion("lupDate <", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateLessThanOrEqualTo(Date value) {
            addCriterion("lupDate <=", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateIn(List<Date> values) {
            addCriterion("lupDate in", values, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotIn(List<Date> values) {
            addCriterion("lupDate not in", values, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateBetween(Date value1, Date value2) {
            addCriterion("lupDate between", value1, value2, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotBetween(Date value1, Date value2) {
            addCriterion("lupDate not between", value1, value2, "lupdate");
            return (Criteria) this;
        }

        public Criteria andOperstatusIsNull() {
            addCriterion("operStatus is null");
            return (Criteria) this;
        }

        public Criteria andOperstatusIsNotNull() {
            addCriterion("operStatus is not null");
            return (Criteria) this;
        }

        public Criteria andOperstatusEqualTo(Integer value) {
            addCriterion("operStatus =", value, "operstatus");
            return (Criteria) this;
        }

        public Criteria andOperstatusNotEqualTo(Integer value) {
            addCriterion("operStatus <>", value, "operstatus");
            return (Criteria) this;
        }

        public Criteria andOperstatusGreaterThan(Integer value) {
            addCriterion("operStatus >", value, "operstatus");
            return (Criteria) this;
        }

        public Criteria andOperstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("operStatus >=", value, "operstatus");
            return (Criteria) this;
        }

        public Criteria andOperstatusLessThan(Integer value) {
            addCriterion("operStatus <", value, "operstatus");
            return (Criteria) this;
        }

        public Criteria andOperstatusLessThanOrEqualTo(Integer value) {
            addCriterion("operStatus <=", value, "operstatus");
            return (Criteria) this;
        }

        public Criteria andOperstatusIn(List<Integer> values) {
            addCriterion("operStatus in", values, "operstatus");
            return (Criteria) this;
        }

        public Criteria andOperstatusNotIn(List<Integer> values) {
            addCriterion("operStatus not in", values, "operstatus");
            return (Criteria) this;
        }

        public Criteria andOperstatusBetween(Integer value1, Integer value2) {
            addCriterion("operStatus between", value1, value2, "operstatus");
            return (Criteria) this;
        }

        public Criteria andOperstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("operStatus not between", value1, value2, "operstatus");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andDosageformIsNull() {
            addCriterion("dosageForm is null");
            return (Criteria) this;
        }

        public Criteria andDosageformIsNotNull() {
            addCriterion("dosageForm is not null");
            return (Criteria) this;
        }

        public Criteria andDosageformEqualTo(String value) {
            addCriterion("dosageForm =", value, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformNotEqualTo(String value) {
            addCriterion("dosageForm <>", value, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformGreaterThan(String value) {
            addCriterion("dosageForm >", value, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformGreaterThanOrEqualTo(String value) {
            addCriterion("dosageForm >=", value, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformLessThan(String value) {
            addCriterion("dosageForm <", value, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformLessThanOrEqualTo(String value) {
            addCriterion("dosageForm <=", value, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformLike(String value) {
            addCriterion("dosageForm like", value, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformNotLike(String value) {
            addCriterion("dosageForm not like", value, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformIn(List<String> values) {
            addCriterion("dosageForm in", values, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformNotIn(List<String> values) {
            addCriterion("dosageForm not in", values, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformBetween(String value1, String value2) {
            addCriterion("dosageForm between", value1, value2, "dosageform");
            return (Criteria) this;
        }

        public Criteria andDosageformNotBetween(String value1, String value2) {
            addCriterion("dosageForm not between", value1, value2, "dosageform");
            return (Criteria) this;
        }

        public Criteria andSpecificationsIsNull() {
            addCriterion("specifications is null");
            return (Criteria) this;
        }

        public Criteria andSpecificationsIsNotNull() {
            addCriterion("specifications is not null");
            return (Criteria) this;
        }

        public Criteria andSpecificationsEqualTo(String value) {
            addCriterion("specifications =", value, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsNotEqualTo(String value) {
            addCriterion("specifications <>", value, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsGreaterThan(String value) {
            addCriterion("specifications >", value, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsGreaterThanOrEqualTo(String value) {
            addCriterion("specifications >=", value, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsLessThan(String value) {
            addCriterion("specifications <", value, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsLessThanOrEqualTo(String value) {
            addCriterion("specifications <=", value, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsLike(String value) {
            addCriterion("specifications like", value, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsNotLike(String value) {
            addCriterion("specifications not like", value, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsIn(List<String> values) {
            addCriterion("specifications in", values, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsNotIn(List<String> values) {
            addCriterion("specifications not in", values, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsBetween(String value1, String value2) {
            addCriterion("specifications between", value1, value2, "specifications");
            return (Criteria) this;
        }

        public Criteria andSpecificationsNotBetween(String value1, String value2) {
            addCriterion("specifications not between", value1, value2, "specifications");
            return (Criteria) this;
        }

        public Criteria andUnitnounIsNull() {
            addCriterion("unitNoun is null");
            return (Criteria) this;
        }

        public Criteria andUnitnounIsNotNull() {
            addCriterion("unitNoun is not null");
            return (Criteria) this;
        }

        public Criteria andUnitnounEqualTo(String value) {
            addCriterion("unitNoun =", value, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounNotEqualTo(String value) {
            addCriterion("unitNoun <>", value, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounGreaterThan(String value) {
            addCriterion("unitNoun >", value, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounGreaterThanOrEqualTo(String value) {
            addCriterion("unitNoun >=", value, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounLessThan(String value) {
            addCriterion("unitNoun <", value, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounLessThanOrEqualTo(String value) {
            addCriterion("unitNoun <=", value, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounLike(String value) {
            addCriterion("unitNoun like", value, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounNotLike(String value) {
            addCriterion("unitNoun not like", value, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounIn(List<String> values) {
            addCriterion("unitNoun in", values, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounNotIn(List<String> values) {
            addCriterion("unitNoun not in", values, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounBetween(String value1, String value2) {
            addCriterion("unitNoun between", value1, value2, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andUnitnounNotBetween(String value1, String value2) {
            addCriterion("unitNoun not between", value1, value2, "unitnoun");
            return (Criteria) this;
        }

        public Criteria andAmountIsNull() {
            addCriterion("amount is null");
            return (Criteria) this;
        }

        public Criteria andAmountIsNotNull() {
            addCriterion("amount is not null");
            return (Criteria) this;
        }

        public Criteria andAmountEqualTo(String value) {
            addCriterion("amount =", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountNotEqualTo(String value) {
            addCriterion("amount <>", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountGreaterThan(String value) {
            addCriterion("amount >", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountGreaterThanOrEqualTo(String value) {
            addCriterion("amount >=", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountLessThan(String value) {
            addCriterion("amount <", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountLessThanOrEqualTo(String value) {
            addCriterion("amount <=", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountLike(String value) {
            addCriterion("amount like", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountNotLike(String value) {
            addCriterion("amount not like", value, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountIn(List<String> values) {
            addCriterion("amount in", values, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountNotIn(List<String> values) {
            addCriterion("amount not in", values, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountBetween(String value1, String value2) {
            addCriterion("amount between", value1, value2, "amount");
            return (Criteria) this;
        }

        public Criteria andAmountNotBetween(String value1, String value2) {
            addCriterion("amount not between", value1, value2, "amount");
            return (Criteria) this;
        }

        public Criteria andApprovalnumIsNull() {
            addCriterion("approvalNum is null");
            return (Criteria) this;
        }

        public Criteria andApprovalnumIsNotNull() {
            addCriterion("approvalNum is not null");
            return (Criteria) this;
        }

        public Criteria andApprovalnumEqualTo(String value) {
            addCriterion("approvalNum =", value, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumNotEqualTo(String value) {
            addCriterion("approvalNum <>", value, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumGreaterThan(String value) {
            addCriterion("approvalNum >", value, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumGreaterThanOrEqualTo(String value) {
            addCriterion("approvalNum >=", value, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumLessThan(String value) {
            addCriterion("approvalNum <", value, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumLessThanOrEqualTo(String value) {
            addCriterion("approvalNum <=", value, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumLike(String value) {
            addCriterion("approvalNum like", value, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumNotLike(String value) {
            addCriterion("approvalNum not like", value, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumIn(List<String> values) {
            addCriterion("approvalNum in", values, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumNotIn(List<String> values) {
            addCriterion("approvalNum not in", values, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumBetween(String value1, String value2) {
            addCriterion("approvalNum between", value1, value2, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andApprovalnumNotBetween(String value1, String value2) {
            addCriterion("approvalNum not between", value1, value2, "approvalnum");
            return (Criteria) this;
        }

        public Criteria andManufIsNull() {
            addCriterion("manuf is null");
            return (Criteria) this;
        }

        public Criteria andManufIsNotNull() {
            addCriterion("manuf is not null");
            return (Criteria) this;
        }

        public Criteria andManufEqualTo(String value) {
            addCriterion("manuf =", value, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufNotEqualTo(String value) {
            addCriterion("manuf <>", value, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufGreaterThan(String value) {
            addCriterion("manuf >", value, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufGreaterThanOrEqualTo(String value) {
            addCriterion("manuf >=", value, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufLessThan(String value) {
            addCriterion("manuf <", value, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufLessThanOrEqualTo(String value) {
            addCriterion("manuf <=", value, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufLike(String value) {
            addCriterion("manuf like", value, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufNotLike(String value) {
            addCriterion("manuf not like", value, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufIn(List<String> values) {
            addCriterion("manuf in", values, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufNotIn(List<String> values) {
            addCriterion("manuf not in", values, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufBetween(String value1, String value2) {
            addCriterion("manuf between", value1, value2, "manuf");
            return (Criteria) this;
        }

        public Criteria andManufNotBetween(String value1, String value2) {
            addCriterion("manuf not between", value1, value2, "manuf");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateIsNull() {
            addCriterion("offlineCooperate is null");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateIsNotNull() {
            addCriterion("offlineCooperate is not null");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateEqualTo(String value) {
            addCriterion("offlineCooperate =", value, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateNotEqualTo(String value) {
            addCriterion("offlineCooperate <>", value, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateGreaterThan(String value) {
            addCriterion("offlineCooperate >", value, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateGreaterThanOrEqualTo(String value) {
            addCriterion("offlineCooperate >=", value, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateLessThan(String value) {
            addCriterion("offlineCooperate <", value, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateLessThanOrEqualTo(String value) {
            addCriterion("offlineCooperate <=", value, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateLike(String value) {
            addCriterion("offlineCooperate like", value, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateNotLike(String value) {
            addCriterion("offlineCooperate not like", value, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateIn(List<String> values) {
            addCriterion("offlineCooperate in", values, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateNotIn(List<String> values) {
            addCriterion("offlineCooperate not in", values, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateBetween(String value1, String value2) {
            addCriterion("offlineCooperate between", value1, value2, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflinecooperateNotBetween(String value1, String value2) {
            addCriterion("offlineCooperate not between", value1, value2, "offlinecooperate");
            return (Criteria) this;
        }

        public Criteria andOfflineIsNull() {
            addCriterion("offline is null");
            return (Criteria) this;
        }

        public Criteria andOfflineIsNotNull() {
            addCriterion("offline is not null");
            return (Criteria) this;
        }

        public Criteria andOfflineEqualTo(Integer value) {
            addCriterion("offline =", value, "offline");
            return (Criteria) this;
        }

        public Criteria andOfflineNotEqualTo(Integer value) {
            addCriterion("offline <>", value, "offline");
            return (Criteria) this;
        }

        public Criteria andOfflineGreaterThan(Integer value) {
            addCriterion("offline >", value, "offline");
            return (Criteria) this;
        }

        public Criteria andOfflineGreaterThanOrEqualTo(Integer value) {
            addCriterion("offline >=", value, "offline");
            return (Criteria) this;
        }

        public Criteria andOfflineLessThan(Integer value) {
            addCriterion("offline <", value, "offline");
            return (Criteria) this;
        }

        public Criteria andOfflineLessThanOrEqualTo(Integer value) {
            addCriterion("offline <=", value, "offline");
            return (Criteria) this;
        }

        public Criteria andOfflineIn(List<Integer> values) {
            addCriterion("offline in", values, "offline");
            return (Criteria) this;
        }

        public Criteria andOfflineNotIn(List<Integer> values) {
            addCriterion("offline not in", values, "offline");
            return (Criteria) this;
        }

        public Criteria andOfflineBetween(Integer value1, Integer value2) {
            addCriterion("offline between", value1, value2, "offline");
            return (Criteria) this;
        }

        public Criteria andOfflineNotBetween(Integer value1, Integer value2) {
            addCriterion("offline not between", value1, value2, "offline");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateIsNull() {
            addCriterion("appliancesDate is null");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateIsNotNull() {
            addCriterion("appliancesDate is not null");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateEqualTo(Date value) {
            addCriterion("appliancesDate =", value, "appliancesdate");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateNotEqualTo(Date value) {
            addCriterion("appliancesDate <>", value, "appliancesdate");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateGreaterThan(Date value) {
            addCriterion("appliancesDate >", value, "appliancesdate");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateGreaterThanOrEqualTo(Date value) {
            addCriterion("appliancesDate >=", value, "appliancesdate");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateLessThan(Date value) {
            addCriterion("appliancesDate <", value, "appliancesdate");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateLessThanOrEqualTo(Date value) {
            addCriterion("appliancesDate <=", value, "appliancesdate");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateIn(List<Date> values) {
            addCriterion("appliancesDate in", values, "appliancesdate");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateNotIn(List<Date> values) {
            addCriterion("appliancesDate not in", values, "appliancesdate");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateBetween(Date value1, Date value2) {
            addCriterion("appliancesDate between", value1, value2, "appliancesdate");
            return (Criteria) this;
        }

        public Criteria andAppliancesdateNotBetween(Date value1, Date value2) {
            addCriterion("appliancesDate not between", value1, value2, "appliancesdate");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateIsNull() {
            addCriterion("appliancesEndDate is null");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateIsNotNull() {
            addCriterion("appliancesEndDate is not null");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateEqualTo(Date value) {
            addCriterion("appliancesEndDate =", value, "appliancesenddate");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateNotEqualTo(Date value) {
            addCriterion("appliancesEndDate <>", value, "appliancesenddate");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateGreaterThan(Date value) {
            addCriterion("appliancesEndDate >", value, "appliancesenddate");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateGreaterThanOrEqualTo(Date value) {
            addCriterion("appliancesEndDate >=", value, "appliancesenddate");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateLessThan(Date value) {
            addCriterion("appliancesEndDate <", value, "appliancesenddate");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateLessThanOrEqualTo(Date value) {
            addCriterion("appliancesEndDate <=", value, "appliancesenddate");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateIn(List<Date> values) {
            addCriterion("appliancesEndDate in", values, "appliancesenddate");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateNotIn(List<Date> values) {
            addCriterion("appliancesEndDate not in", values, "appliancesenddate");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateBetween(Date value1, Date value2) {
            addCriterion("appliancesEndDate between", value1, value2, "appliancesenddate");
            return (Criteria) this;
        }

        public Criteria andAppliancesenddateNotBetween(Date value1, Date value2) {
            addCriterion("appliancesEndDate not between", value1, value2, "appliancesenddate");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidIsNull() {
            addCriterion("cooperationcompID is null");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidIsNotNull() {
            addCriterion("cooperationcompID is not null");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidEqualTo(Integer value) {
            addCriterion("cooperationcompID =", value, "cooperationcompid");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidNotEqualTo(Integer value) {
            addCriterion("cooperationcompID <>", value, "cooperationcompid");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidGreaterThan(Integer value) {
            addCriterion("cooperationcompID >", value, "cooperationcompid");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("cooperationcompID >=", value, "cooperationcompid");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidLessThan(Integer value) {
            addCriterion("cooperationcompID <", value, "cooperationcompid");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidLessThanOrEqualTo(Integer value) {
            addCriterion("cooperationcompID <=", value, "cooperationcompid");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidIn(List<Integer> values) {
            addCriterion("cooperationcompID in", values, "cooperationcompid");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidNotIn(List<Integer> values) {
            addCriterion("cooperationcompID not in", values, "cooperationcompid");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidBetween(Integer value1, Integer value2) {
            addCriterion("cooperationcompID between", value1, value2, "cooperationcompid");
            return (Criteria) this;
        }

        public Criteria andCooperationcompidNotBetween(Integer value1, Integer value2) {
            addCriterion("cooperationcompID not between", value1, value2, "cooperationcompid");
            return (Criteria) this;
        }

        public Criteria andExpirationdateIsNull() {
            addCriterion("expirationDate is null");
            return (Criteria) this;
        }

        public Criteria andExpirationdateIsNotNull() {
            addCriterion("expirationDate is not null");
            return (Criteria) this;
        }

        public Criteria andExpirationdateEqualTo(String value) {
            addCriterion("expirationDate =", value, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateNotEqualTo(String value) {
            addCriterion("expirationDate <>", value, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateGreaterThan(String value) {
            addCriterion("expirationDate >", value, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateGreaterThanOrEqualTo(String value) {
            addCriterion("expirationDate >=", value, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateLessThan(String value) {
            addCriterion("expirationDate <", value, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateLessThanOrEqualTo(String value) {
            addCriterion("expirationDate <=", value, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateLike(String value) {
            addCriterion("expirationDate like", value, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateNotLike(String value) {
            addCriterion("expirationDate not like", value, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateIn(List<String> values) {
            addCriterion("expirationDate in", values, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateNotIn(List<String> values) {
            addCriterion("expirationDate not in", values, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateBetween(String value1, String value2) {
            addCriterion("expirationDate between", value1, value2, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andExpirationdateNotBetween(String value1, String value2) {
            addCriterion("expirationDate not between", value1, value2, "expirationdate");
            return (Criteria) this;
        }

        public Criteria andPronumberIsNull() {
            addCriterion("proNumber is null");
            return (Criteria) this;
        }

        public Criteria andPronumberIsNotNull() {
            addCriterion("proNumber is not null");
            return (Criteria) this;
        }

        public Criteria andPronumberEqualTo(String value) {
            addCriterion("proNumber =", value, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberNotEqualTo(String value) {
            addCriterion("proNumber <>", value, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberGreaterThan(String value) {
            addCriterion("proNumber >", value, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberGreaterThanOrEqualTo(String value) {
            addCriterion("proNumber >=", value, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberLessThan(String value) {
            addCriterion("proNumber <", value, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberLessThanOrEqualTo(String value) {
            addCriterion("proNumber <=", value, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberLike(String value) {
            addCriterion("proNumber like", value, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberNotLike(String value) {
            addCriterion("proNumber not like", value, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberIn(List<String> values) {
            addCriterion("proNumber in", values, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberNotIn(List<String> values) {
            addCriterion("proNumber not in", values, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberBetween(String value1, String value2) {
            addCriterion("proNumber between", value1, value2, "pronumber");
            return (Criteria) this;
        }

        public Criteria andPronumberNotBetween(String value1, String value2) {
            addCriterion("proNumber not between", value1, value2, "pronumber");
            return (Criteria) this;
        }

        public Criteria andIsuploadIsNull() {
            addCriterion("isUpload is null");
            return (Criteria) this;
        }

        public Criteria andIsuploadIsNotNull() {
            addCriterion("isUpload is not null");
            return (Criteria) this;
        }

        public Criteria andIsuploadEqualTo(String value) {
            addCriterion("isUpload =", value, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadNotEqualTo(String value) {
            addCriterion("isUpload <>", value, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadGreaterThan(String value) {
            addCriterion("isUpload >", value, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadGreaterThanOrEqualTo(String value) {
            addCriterion("isUpload >=", value, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadLessThan(String value) {
            addCriterion("isUpload <", value, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadLessThanOrEqualTo(String value) {
            addCriterion("isUpload <=", value, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadLike(String value) {
            addCriterion("isUpload like", value, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadNotLike(String value) {
            addCriterion("isUpload not like", value, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadIn(List<String> values) {
            addCriterion("isUpload in", values, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadNotIn(List<String> values) {
            addCriterion("isUpload not in", values, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadBetween(String value1, String value2) {
            addCriterion("isUpload between", value1, value2, "isupload");
            return (Criteria) this;
        }

        public Criteria andIsuploadNotBetween(String value1, String value2) {
            addCriterion("isUpload not between", value1, value2, "isupload");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNull() {
            addCriterion("createBy is null");
            return (Criteria) this;
        }

        public Criteria andCreatebyIsNotNull() {
            addCriterion("createBy is not null");
            return (Criteria) this;
        }

        public Criteria andCreatebyEqualTo(String value) {
            addCriterion("createBy =", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotEqualTo(String value) {
            addCriterion("createBy <>", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThan(String value) {
            addCriterion("createBy >", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyGreaterThanOrEqualTo(String value) {
            addCriterion("createBy >=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThan(String value) {
            addCriterion("createBy <", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLessThanOrEqualTo(String value) {
            addCriterion("createBy <=", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyLike(String value) {
            addCriterion("createBy like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotLike(String value) {
            addCriterion("createBy not like", value, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyIn(List<String> values) {
            addCriterion("createBy in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotIn(List<String> values) {
            addCriterion("createBy not in", values, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyBetween(String value1, String value2) {
            addCriterion("createBy between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andCreatebyNotBetween(String value1, String value2) {
            addCriterion("createBy not between", value1, value2, "createby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNull() {
            addCriterion("updateBy is null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIsNotNull() {
            addCriterion("updateBy is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatebyEqualTo(String value) {
            addCriterion("updateBy =", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotEqualTo(String value) {
            addCriterion("updateBy <>", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThan(String value) {
            addCriterion("updateBy >", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyGreaterThanOrEqualTo(String value) {
            addCriterion("updateBy >=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThan(String value) {
            addCriterion("updateBy <", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLessThanOrEqualTo(String value) {
            addCriterion("updateBy <=", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyLike(String value) {
            addCriterion("updateBy like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotLike(String value) {
            addCriterion("updateBy not like", value, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyIn(List<String> values) {
            addCriterion("updateBy in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotIn(List<String> values) {
            addCriterion("updateBy not in", values, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyBetween(String value1, String value2) {
            addCriterion("updateBy between", value1, value2, "updateby");
            return (Criteria) this;
        }

        public Criteria andUpdatebyNotBetween(String value1, String value2) {
            addCriterion("updateBy not between", value1, value2, "updateby");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidIsNull() {
            addCriterion("modifyAccountId is null");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidIsNotNull() {
            addCriterion("modifyAccountId is not null");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidEqualTo(Integer value) {
            addCriterion("modifyAccountId =", value, "modifyaccountid");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidNotEqualTo(Integer value) {
            addCriterion("modifyAccountId <>", value, "modifyaccountid");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidGreaterThan(Integer value) {
            addCriterion("modifyAccountId >", value, "modifyaccountid");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidGreaterThanOrEqualTo(Integer value) {
            addCriterion("modifyAccountId >=", value, "modifyaccountid");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidLessThan(Integer value) {
            addCriterion("modifyAccountId <", value, "modifyaccountid");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidLessThanOrEqualTo(Integer value) {
            addCriterion("modifyAccountId <=", value, "modifyaccountid");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidIn(List<Integer> values) {
            addCriterion("modifyAccountId in", values, "modifyaccountid");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidNotIn(List<Integer> values) {
            addCriterion("modifyAccountId not in", values, "modifyaccountid");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidBetween(Integer value1, Integer value2) {
            addCriterion("modifyAccountId between", value1, value2, "modifyaccountid");
            return (Criteria) this;
        }

        public Criteria andModifyaccountidNotBetween(Integer value1, Integer value2) {
            addCriterion("modifyAccountId not between", value1, value2, "modifyaccountid");
            return (Criteria) this;
        }

        public Criteria andUpdatedateIsNull() {
            addCriterion("updateDate is null");
            return (Criteria) this;
        }

        public Criteria andUpdatedateIsNotNull() {
            addCriterion("updateDate is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatedateEqualTo(Date value) {
            addCriterion("updateDate =", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateNotEqualTo(Date value) {
            addCriterion("updateDate <>", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateGreaterThan(Date value) {
            addCriterion("updateDate >", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateGreaterThanOrEqualTo(Date value) {
            addCriterion("updateDate >=", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateLessThan(Date value) {
            addCriterion("updateDate <", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateLessThanOrEqualTo(Date value) {
            addCriterion("updateDate <=", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateIn(List<Date> values) {
            addCriterion("updateDate in", values, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateNotIn(List<Date> values) {
            addCriterion("updateDate not in", values, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateBetween(Date value1, Date value2) {
            addCriterion("updateDate between", value1, value2, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateNotBetween(Date value1, Date value2) {
            addCriterion("updateDate not between", value1, value2, "updatedate");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}