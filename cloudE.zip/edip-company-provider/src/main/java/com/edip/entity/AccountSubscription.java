package com.edip.entity;
import java.io.Serializable;

/**
 * @author 
 */
public class AccountSubscription implements Serializable {
    /**
     * 帐号ID
     */
    private Integer accountid;

    /**
     * 公司ID
     */
    private Integer compid;

    /**
     * 系统通知订阅状态
     */
    private Boolean systemstatus;

    /**
     * 交易通知订阅状态
     */
    private Boolean exchangestatus;

    /**
     * 公告通知订阅状态
     */
    private Boolean announcementstatus;

    /**
     * 优惠通知订阅状态
     */
    private Boolean favourablestatus;

    /**
     * 到期提醒订阅状态
     */
    private Boolean timeremind;

    /**
     * 企业档案提醒
     */
    private Boolean companydocument;

    /**
     * 产品档案提醒
     */
    private Boolean productdocument;

    /**
     * 人员档案提醒
     */
    private Boolean memberdocument;

    /**
     * 合同档案提醒
     */
    private Boolean contractdocument;

    /**
     * UKey档案提醒
     */
    private Boolean ukeydocument;
    
    /**
     * 资质更新提醒
     */
    private Boolean replacedocument;

    private static final long serialVersionUID = 1L;

    public Integer getAccountid() {
        return accountid;
    }

    public void setAccountid(Integer accountid) {
        this.accountid = accountid;
    }

    public Integer getCompid() {
        return compid;
    }

    public void setCompid(Integer compid) {
        this.compid = compid;
    }

    public Boolean getSystemstatus() {
        return systemstatus;
    }

    public void setSystemstatus(Boolean systemstatus) {
        this.systemstatus = systemstatus;
    }

    public Boolean getExchangestatus() {
        return exchangestatus;
    }

    public void setExchangestatus(Boolean exchangestatus) {
        this.exchangestatus = exchangestatus;
    }

    public Boolean getAnnouncementstatus() {
        return announcementstatus;
    }

    public void setAnnouncementstatus(Boolean announcementstatus) {
        this.announcementstatus = announcementstatus;
    }

    public Boolean getFavourablestatus() {
        return favourablestatus;
    }

    public void setFavourablestatus(Boolean favourablestatus) {
        this.favourablestatus = favourablestatus;
    }

    public Boolean getTimeremind() {
        return timeremind;
    }

    public void setTimeremind(Boolean timeremind) {
        this.timeremind = timeremind;
    }

    public Boolean getCompanydocument() {
        return companydocument;
    }

    public void setCompanydocument(Boolean companydocument) {
        this.companydocument = companydocument;
    }

    public Boolean getProductdocument() {
        return productdocument;
    }

    public void setProductdocument(Boolean productdocument) {
        this.productdocument = productdocument;
    }

    public Boolean getMemberdocument() {
        return memberdocument;
    }

    public void setMemberdocument(Boolean memberdocument) {
        this.memberdocument = memberdocument;
    }

    public Boolean getContractdocument() {
        return contractdocument;
    }

    public void setContractdocument(Boolean contractdocument) {
        this.contractdocument = contractdocument;
    }

    public Boolean getUkeydocument() {
        return ukeydocument;
    }

    public void setUkeydocument(Boolean ukeydocument) {
        this.ukeydocument = ukeydocument;
    }

	public Boolean getReplacedocument() {
		return replacedocument;
	}

	public void setReplacedocument(Boolean replacedocument) {
		this.replacedocument = replacedocument;
	}

	@Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AccountSubscription other = (AccountSubscription) that;
        return (this.getAccountid() == null ? other.getAccountid() == null : this.getAccountid().equals(other.getAccountid()))
            && (this.getCompid() == null ? other.getCompid() == null : this.getCompid().equals(other.getCompid()))
            && (this.getSystemstatus() == null ? other.getSystemstatus() == null : this.getSystemstatus().equals(other.getSystemstatus()))
            && (this.getExchangestatus() == null ? other.getExchangestatus() == null : this.getExchangestatus().equals(other.getExchangestatus()))
            && (this.getAnnouncementstatus() == null ? other.getAnnouncementstatus() == null : this.getAnnouncementstatus().equals(other.getAnnouncementstatus()))
            && (this.getFavourablestatus() == null ? other.getFavourablestatus() == null : this.getFavourablestatus().equals(other.getFavourablestatus()))
            && (this.getTimeremind() == null ? other.getTimeremind() == null : this.getTimeremind().equals(other.getTimeremind()))
            && (this.getCompanydocument() == null ? other.getCompanydocument() == null : this.getCompanydocument().equals(other.getCompanydocument()))
            && (this.getProductdocument() == null ? other.getProductdocument() == null : this.getProductdocument().equals(other.getProductdocument()))
            && (this.getMemberdocument() == null ? other.getMemberdocument() == null : this.getMemberdocument().equals(other.getMemberdocument()))
            && (this.getContractdocument() == null ? other.getContractdocument() == null : this.getContractdocument().equals(other.getContractdocument()))
            && (this.getUkeydocument() == null ? other.getUkeydocument() == null : this.getUkeydocument().equals(other.getUkeydocument()))
        	&& (this.getReplacedocument() == null ? other.getReplacedocument() == null : this.getReplacedocument().equals(other.getReplacedocument()));
	}

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getAccountid() == null) ? 0 : getAccountid().hashCode());
        result = prime * result + ((getCompid() == null) ? 0 : getCompid().hashCode());
        result = prime * result + ((getSystemstatus() == null) ? 0 : getSystemstatus().hashCode());
        result = prime * result + ((getExchangestatus() == null) ? 0 : getExchangestatus().hashCode());
        result = prime * result + ((getAnnouncementstatus() == null) ? 0 : getAnnouncementstatus().hashCode());
        result = prime * result + ((getFavourablestatus() == null) ? 0 : getFavourablestatus().hashCode());
        result = prime * result + ((getTimeremind() == null) ? 0 : getTimeremind().hashCode());
        result = prime * result + ((getCompanydocument() == null) ? 0 : getCompanydocument().hashCode());
        result = prime * result + ((getProductdocument() == null) ? 0 : getProductdocument().hashCode());
        result = prime * result + ((getMemberdocument() == null) ? 0 : getMemberdocument().hashCode());
        result = prime * result + ((getContractdocument() == null) ? 0 : getContractdocument().hashCode());
        result = prime * result + ((getUkeydocument() == null) ? 0 : getUkeydocument().hashCode());
        result = prime * result + ((getReplacedocument() == null) ? 0 : getReplacedocument().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", accountid=").append(accountid);
        sb.append(", compid=").append(compid);
        sb.append(", systemstatus=").append(systemstatus);
        sb.append(", exchangestatus=").append(exchangestatus);
        sb.append(", announcementstatus=").append(announcementstatus);
        sb.append(", favourablestatus=").append(favourablestatus);
        sb.append(", timeremind=").append(timeremind);
        sb.append(", companydocument=").append(companydocument);
        sb.append(", productdocument=").append(productdocument);
        sb.append(", memberdocument=").append(memberdocument);
        sb.append(", contractdocument=").append(contractdocument);
        sb.append(", ukeydocument=").append(ukeydocument);
        sb.append(", replaceDocument=").append(replacedocument);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}