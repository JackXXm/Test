package com.edip.vo;

import org.apache.commons.lang.StringUtils;


/**
 * ApplyEntCertReqVO.java      2012-8-3
 * 申请企业证书请求VO
 * @System: CA 1.0
 * @Description:
 * @Copyright: Copyright (c) 2012
 * @Company: Aspire Technologies
 * @version 1.0
 * @author: huangliang
 */
public class AdminApplyEntCertReqVO {
	/** 平台标识 */
	private String platformid;
	/** 企业名称 */
	private String unitname;
	/** 企业组织结构代码 */
	private String unitlicensecode;
	/** 营业执照注册号 */
	private String unitbusinesscode;
	/** Ip地址或域名（如果是个人服务器证书，该项必填） */
	private String ipaddress;
	/** 所在省份 注：所在省份（由CA提供，业务系统根据实际情况填写） */
	private String province;
	/** 所在城市 */
	private String city;
	/** 企业邮箱地址 */
	private String unitemail;
	/** 企业电话 */
	private String unittelephone;
	/** 企业传真号 */
	private String unitfax;
	/** 企业地址 */
	private String unitaddress;
	/** 企业邮编 */
	private String unitpostalcode;
	/** 企业联系人姓名 */
	private String username;
	/** 企业联系人联系电话 */
	private String telephone;
	/** 企业联系人手机号 */
	private String mobilephone;
	/** 企业联系人email */
	private String email;
	/** 企业联系人证件类型（由CA提供，业务系统根据实际情况填写）,身份证（1）、军官证（2）、护照（3）、士兵证（4）、外交官证（5）、武警警官证（6）、其他（7） */
	private String cardtype;
	/** 企业联系人证件号码 */
	private String cardnum;
	/** 证书种类（由CA提供，见附录11.3） */
	private String certsort;
	/** 公钥 */
	private String subjectpubkey;
	/** 证书应用项目（由CA提供，业务系统根据实际情况填写） */
	private String certapptype;
	/** 证书存储介质（由CA提供，见附录11.4） */
	private String certstoragetype;
	/** 证书生效日期（格式：YYYY-MM-DD） */
	private String notbefore;
	/** 证书失效日期（格式：YYYY-MM-DD） */
	private String notafter;
	
	/**
	 * @description: 构造函数
	 */
	public AdminApplyEntCertReqVO(){
		
	}
	
	/**
	 * Copy Constructor
	 * 
	 * @param applyEntCertReqVO
	 *            a <code>ApplyEntCertReqVO</code> object
	 */
	public AdminApplyEntCertReqVO(AdminApplyEntCertReqVO applyEntCertReqVO) {
		this.platformid = applyEntCertReqVO.platformid;
		this.unitname = applyEntCertReqVO.unitname;
		this.unitlicensecode = applyEntCertReqVO.unitlicensecode;
		this.unitbusinesscode = applyEntCertReqVO.unitbusinesscode;
		this.ipaddress = applyEntCertReqVO.ipaddress;
		this.province = applyEntCertReqVO.province;
		this.city = applyEntCertReqVO.city;
		this.unitemail = applyEntCertReqVO.unitemail;
		this.unittelephone = applyEntCertReqVO.unittelephone;
		this.unitfax = applyEntCertReqVO.unitfax;
		this.unitaddress = applyEntCertReqVO.unitaddress;
		this.unitpostalcode = applyEntCertReqVO.unitpostalcode;
		this.username = applyEntCertReqVO.username;
		this.telephone = applyEntCertReqVO.telephone;
		this.mobilephone = applyEntCertReqVO.mobilephone;
		this.email = applyEntCertReqVO.email;
		this.cardtype = applyEntCertReqVO.cardtype;
		this.cardnum = applyEntCertReqVO.cardnum;
		this.certsort = applyEntCertReqVO.certsort;
		this.subjectpubkey = applyEntCertReqVO.subjectpubkey;
		this.certapptype = applyEntCertReqVO.certapptype;
		this.certstoragetype = applyEntCertReqVO.certstoragetype;
		this.notbefore = applyEntCertReqVO.notbefore;
		this.notafter = applyEntCertReqVO.notafter;
	}

	public String getPlatformid() {
		return platformid;
	}

	public void setPlatformid(String platformid) {
		this.platformid = platformid;
	}

	public String getUnitname() {
		return unitname;
	}

	public void setUnitname(String unitname) {
		this.unitname = unitname;
	}

	public String getUnitlicensecode() {
		return unitlicensecode;
	}

	public void setUnitlicensecode(String unitlicensecode) {
		this.unitlicensecode = unitlicensecode;
	}

	public String getUnitbusinesscode() {
		return unitbusinesscode;
	}

	public void setUnitbusinesscode(String unitbusinesscode) {
		this.unitbusinesscode = unitbusinesscode;
	}

	public String getIpaddress() {
		return ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getUnitemail() {
		return unitemail;
	}

	public void setUnitemail(String unitemail) {
		this.unitemail = unitemail;
	}

	public String getUnittelephone() {
		return unittelephone;
	}

	public void setUnittelephone(String unittelephone) {
		this.unittelephone = unittelephone;
	}

	public String getUnitfax() {
		return unitfax;
	}

	public void setUnitfax(String unitfax) {
		this.unitfax = unitfax;
	}

	public String getUnitaddress() {
		return unitaddress;
	}

	public void setUnitaddress(String unitaddress) {
		this.unitaddress = unitaddress;
	}

	public String getUnitpostalcode() {
		return unitpostalcode;
	}

	public void setUnitpostalcode(String unitpostalcode) {
		this.unitpostalcode = unitpostalcode;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getMobilephone() {
		return mobilephone;
	}

	public void setMobilephone(String mobilephone) {
		this.mobilephone = mobilephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCardtype() {
		return cardtype;
	}

	public void setCardtype(String cardtype) {
		this.cardtype = cardtype;
	}

	public String getCardnum() {
		return cardnum;
	}

	public void setCardnum(String cardnum) {
		this.cardnum = cardnum;
	}

	public String getCertsort() {
		return certsort;
	}

	public void setCertsort(String certsort) {
		this.certsort = certsort;
	}

	public String getSubjectpubkey() {
		return subjectpubkey;
	}

	public void setSubjectpubkey(String subjectpubkey) {
		this.subjectpubkey = subjectpubkey;
	}

	public String getCertapptype() {
		return certapptype;
	}

	public void setCertapptype(String certapptype) {
		this.certapptype = certapptype;
	}

	public String getCertstoragetype() {
		return certstoragetype;
	}

	public void setCertstoragetype(String certstoragetype) {
		this.certstoragetype = certstoragetype;
	}

	public String getNotbefore() {
		return notbefore;
	}

	public void setNotbefore(String notbefore) {
		this.notbefore = notbefore;
	}

	public String getNotafter() {
		return notafter;
	}

	public void setNotafter(String notafter) {
		this.notafter = notafter;
	}

	/**
	 * Constructs a <code>String</code> with all attributes in name = value
	 * format.
	 * 
	 * @return a <code>String</code> representation of this object.
	 */
	public String toString() {
		final String TAB = "    ";

		String retValue = "";

		retValue = "ApplyEntCertReqVO ( " + super.toString() + TAB
				+ "platformid = " + this.platformid + TAB + "unitname = "
				+ this.unitname + TAB + "unitlicensecode = "
				+ this.unitlicensecode + TAB + "unitbusinesscode = "
				+ this.unitbusinesscode + TAB + "ipaddress = " + this.ipaddress
				+ TAB + "province = " + this.province + TAB + "city = "
				+ this.city + TAB + "unitemail = " + this.unitemail + TAB
				+ "unittelephone = " + this.unittelephone + TAB + "unitfax = "
				+ this.unitfax + TAB + "unitaddress = " + this.unitaddress
				+ TAB + "unitpostalcode = " + this.unitpostalcode + TAB
				+ "username = " + this.username + TAB + "telephone = "
				+ this.telephone + TAB + "mobilephone = " + this.mobilephone
				+ TAB + "email = " + this.email + TAB + "cardtype = "
				+ this.cardtype + TAB + "cardnum = " + this.cardnum + TAB
				+ "certsort = " + this.certsort + TAB + "subjectpubkey = "
				+ this.subjectpubkey + TAB + "certapptype = "
				+ this.certapptype + TAB + "certstoragetype = "
				+ this.certstoragetype + TAB + "notbefore = " + this.notbefore
				+ TAB + "notafter = " + this.notafter + TAB + " )";

		return retValue;
	}

	/**
	 * 转为XML
	 * 
	 * @return
	 */
	public String toXML() {
		StringBuffer buffer = new StringBuffer(
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><request command=\"EntCertRequest\">");

		buffer.append("<platformid>");
		if (!StringUtils.isEmpty(this.platformid)) {
			buffer.append(this.platformid);
		}
		buffer.append("</platformid>");

		buffer.append("<parameters>");

		buffer.append("<unitname>");
		if (!StringUtils.isEmpty(this.unitname)) {
			buffer.append(this.unitname);
		}
		buffer.append("</unitname>");

		buffer.append("<unitlicensecode>");
		if (!StringUtils.isEmpty(this.unitlicensecode)) {
			buffer.append(this.unitlicensecode);
		}
		buffer.append("</unitlicensecode>");

		buffer.append("<ipaddress>");
		if (!StringUtils.isEmpty(this.ipaddress)) {
			buffer.append(this.ipaddress);
		}
		buffer.append("</ipaddress>");

		buffer.append("<certsort>");
		if (!StringUtils.isEmpty(this.certsort)) {
			buffer.append(this.certsort);
		}
		buffer.append("</certsort>");

		buffer.append("<certapptype>");
		if (!StringUtils.isEmpty(this.certapptype)) {
			buffer.append(this.certapptype);
		}
		buffer.append("</certapptype>");

		buffer.append("<subjectpubkey>");
		if (!StringUtils.isEmpty(this.subjectpubkey)) {
			buffer.append(this.subjectpubkey);
		}
		buffer.append("</subjectpubkey>");

		buffer.append("<unitbusinesscode>");
		if (!StringUtils.isEmpty(this.unitbusinesscode)) {
			buffer.append(this.unitbusinesscode);
		}
		buffer.append("</unitbusinesscode>");

		buffer.append("<province>");
		if (!StringUtils.isEmpty(this.province)) {
			buffer.append(this.province);
		}
		buffer.append("</province>");

		buffer.append("<city>");
		if (!StringUtils.isEmpty(this.city)) {
			buffer.append(this.city);
		}
		buffer.append("</city>");

		buffer.append("<unitemail>");
		if (!StringUtils.isEmpty(this.unitemail)) {
			buffer.append(this.unitemail);
		}
		buffer.append("</unitemail>");

		buffer.append("<unittelephone>");
		if (!StringUtils.isEmpty(this.unittelephone)) {
			buffer.append(this.unittelephone);
		}
		buffer.append("</unittelephone>");

		buffer.append("<unitfax>");
		if (!StringUtils.isEmpty(this.unitfax)) {
			buffer.append(this.unitfax);
		}
		buffer.append("</unitfax>");

		buffer.append("<unitaddress>");
		if (!StringUtils.isEmpty(this.unitaddress)) {
			buffer.append(this.unitaddress);
		}
		buffer.append("</unitaddress>");

		buffer.append("<unitpostalcode>");
		if (!StringUtils.isEmpty(this.unitpostalcode)) {
			buffer.append(this.unitpostalcode);
		}
		buffer.append("</unitpostalcode>");

		buffer.append("<username>");
		if (!StringUtils.isEmpty(this.username)) {
			buffer.append(this.username);
		}
		buffer.append("</username>");

		buffer.append("<cardtype>");
		if (!StringUtils.isEmpty(this.cardtype)) {
			buffer.append(this.cardtype);
		}
		buffer.append("</cardtype>");

		buffer.append("<cardnum>");
		if (!StringUtils.isEmpty(this.cardnum)) {
			buffer.append(this.cardnum);
		}
		buffer.append("</cardnum>");

		buffer.append("<telephone>");
		if (!StringUtils.isEmpty(this.telephone)) {
			buffer.append(this.telephone);
		}
		buffer.append("</telephone>");

		buffer.append("<mobilephone>");
		if (!StringUtils.isEmpty(this.mobilephone)) {
			buffer.append(this.mobilephone);
		}
		buffer.append("</mobilephone>");

		buffer.append("<email>");
		if (!StringUtils.isEmpty(this.email)) {
			buffer.append(this.email);
		}
		buffer.append("</email>");

		buffer.append("<certstoragetype>");
		if (!StringUtils.isEmpty(this.certstoragetype)) {
			buffer.append(this.certstoragetype);
		}
		buffer.append("</certstoragetype>");

		buffer.append("<notbefore>");
		if (!StringUtils.isEmpty(this.notbefore)) {
			buffer.append(this.notbefore);
		}
		buffer.append("</notbefore>");

		buffer.append("<notafter>");
		if (!StringUtils.isEmpty(this.notafter)) {
			buffer.append(this.notafter);
		}
		buffer.append("</notafter>");

		buffer.append("</parameters>");
		buffer.append("</request>");

		return buffer.toString();
	}

}
