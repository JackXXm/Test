package com.edip.service;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

public interface NoticeService {
    void addNotice(Map<String,Object> params, HttpServletRequest request);

    List<Map<String,Object>> getNotice(Map<String,Object> params);

    void editNotice(Map<String,Object> params,HttpServletRequest request);

    void deleteNotice(String ids);

    void sendNotice(Integer id);
}
