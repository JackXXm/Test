package com.edip.controller;
import com.alibaba.fastjson.JSONObject;
import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.dto.util.CacheKey;
import com.edip.dto.util.RedisUtil;
import com.edip.dto.util.RedisUtilForDiy;
import com.edip.feign.CompanyFeign;
import com.edip.service.StampService;
import com.edip.utils.AdminFileUtil;
import com.edip.utils.StringUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@RestController
@RequestMapping("/company")
public class AdminStampController {

    private Logger LOGGER = LoggerFactory.getLogger(AdminStampController.class);
    @Autowired
    private HttpServletRequest request;

    @Autowired
    private StampService stampService;

    @Autowired
    private CompanyFeign companyFeign;

    @Autowired
    private RedisUtil redisUtil;



    /**
     *获取印章审核列表
     * @param info
     * @return
     */
    @RequestMapping("/queryStampsList.ajax")
    public ServerResponse queryStampsList(@RequestBody Map<String,Object>info) {
        Map<String,Object> param = new HashMap<String,Object>();
        Integer provinceID = (Integer) SessionContext.getContext().getSession(request).getAttribute("province");
        try {
            Integer page = (int)info.get("page");
            Integer rows = (int)info.get("rows");
            List<Integer> compId =new ArrayList<Integer>();
            List<Map<String , Object>> resultList = new ArrayList<Map<String , Object>>();

            if(provinceID!=-1){
                List<Map<String , Object>> list  = (List<Map<String, Object>>) companyFeign.queryCompanyByProvinceID(provinceID);
                if(list.size()>0){
                    for(int i=0;i<list.size();i++) {
                        List<Map<String , Object>> result = new ArrayList<Map<String , Object>>();
                        //compId.add((Integer) list.get(i).get("compID"));
                        //info.put("compId",(Integer) list.get(i).get("compID"));
                        compId.add((Integer) list.get(i).get("compID"));
                        info.put("compId",compId);

                    }
                }

            }
            PageHelper.startPage(page, rows);
            resultList = stampService.queryStampList(info);


            PageInfo pageInfo = new PageInfo(resultList);
            return ServerResponse.createBySuccess("success", pageInfo);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取印章列表失败！");
        }
    }


    /**
     * 查看印章详情
     * @param info
     * @return
     */
    @RequestMapping("/queryStampsDetail.ajax")
    public ServerResponse queryStampsDetail(@RequestBody Map<String,Object>info) {
        Map<String,Object> param = new HashMap<String,Object>();
        try {
            String stampID = info.get("stampID").toString();
            List<Map<String , Object>> resultList1 = stampService.queryStampDetail(stampID);
            List<Map<String , Object>> resultList = AdminFileUtil.getFileUrl(resultList1,redisUtil);
            return ServerResponse.createBySuccess("success", resultList);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取印章列表失败！");
        }
    }



    /**
     * 审核印章
     * @param info
     * @return
     */
    //status,stampID,auditInfo
    @RequestMapping("/updateByCompanyId.ajax")
    public ServerResponse updateByCompanyId(@RequestBody Map<String,Object> info) {
        try {
           /* Map param = new HashMap();
            String stampID= info.get("stampID").toString();
            String status = info.get("status").toString();
            param.put("status",status);
            param.put("stampID",stampID);*/
            Integer accountID = (Integer) SessionContext.getContext().getSession(request).getAttribute("accountID");
            String accountName = (String) SessionContext.getContext().getSession(request).getAttribute("accountName");
            info.put("accountID",accountID);
            info.put("accountName",accountName);
            info.put("operDate",new Date());
            int updateNUms = stampService.auditStamp(info);
            return ServerResponse.createBySuccessMsg("审核成功");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("审核失败");
        }
    }


    /**
     * 印章审核历史
     * @param info
     * @return
     */
    //status,stampID,auditInfo
    @RequestMapping("/getStampHistory.ajax")
    public ServerResponse getStampHistory(@RequestBody Map<String,Object> info) {
        try {
            String stampID = info.get("stampID").toString();
            List<Map<String , Object>> stampHistory = stampService.stampHistory(stampID);
            return ServerResponse.createBySuccess(stampHistory);
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取印章审核历史失败！");
        }
    }

    /**
     * 获取审核公司列表
     * @param info 参数 name企业名称，provinceId省，管理员账户accountName
     *             手机号msisdn，startTime,endTime(注册始末时间)，审核人operator，状态status
     * @return
     */
    @RequestMapping("/AuditCompanyList.ajax")
    public ServerResponse AuditCompanyList(@RequestBody Map<String,Object> param) {
        Map<String, String> mapDic = RedisUtilForDiy.getMap(CacheKey.DIC);//查所有dic
        Integer provinceID = (Integer) SessionContext.getContext().getSession(request).getAttribute("province");
        try {
            Integer page = (int)param.get("page");
            Integer rows = (int)param.get("rows");
            if(provinceID!=-1){
                param.put("provinceId",provinceID);
            }
            ServerResponse resultList = companyFeign.queryAuditCompanyList(param);
            Map mapResult = (Map)resultList.getData();
            if(mapResult.get("listResult")!=null){
                List<Map> list = (List<Map>)mapResult.get("listResult");
                for(Map map : list){
                    Map<String , Object> addressKey = new HashMap<>();
                    if(map.containsKey("serveType")){
                        map.put("serveType" ,translateServeType((String)map.get("serveType"),mapDic));
                    }
                    if(map.containsKey("provinceID")){
                        addressKey.put("proid",map.get("provinceID").toString());
                    }
                    if(map.containsKey("cityID")){//控制审核按钮是否显示
                        map.put("showOrNot",true);
                        addressKey.put("cityid",map.get("cityID").toString());
                    }
                    if(map.containsKey("areaID")){
                        addressKey.put("areaid",map.get("areaID").toString());
                    }
                    if(map.containsKey("address")){
                        addressKey.put("address",map.get("address").toString());
                    }

                    map.put("addressDetail",stampService.getAddressName(addressKey));
                }
                mapResult.put("listResult",list);
            }
            return ServerResponse.createBySuccess("success", mapResult);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取审核公司列表失败！");
        }
    }

    /**
     * 审核某个公司
     * @param param
     * @return
     */

     //参数compId,accountName,accountId,status ,auditInfo(审核信息)
    @RequestMapping("/AuditByCompanyId.ajax")
    public ServerResponse AuditByCompanyId(@RequestBody Map<String,Object> param) {
        try {
            String operator = (String) SessionContext.getContext().getSession(request).getAttribute("accountName");
            param.put("operator" , operator);
            ServerResponse result = companyFeign.AuditCompanyByComId(param);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("审核公司失败！");
        }
    }


    /**
     *
     * @param info  compID公司id
     * @return
     */
    @RequestMapping("/getCompanyDetail.ajax")
    public ServerResponse getCompanyDetail(@RequestBody Map<String,Object> param) {
        try {
            ServerResponse result = companyFeign.queryCompanyDetail(param);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("公司详情查询失败！");
        }
    }

    /**
     * 获取公司审核记录
     * @param param
     * @return
     */
    @RequestMapping("/getCompanyAduitDetail.ajax")
    public ServerResponse getCompanyAduitDetail(@RequestBody Map<String,Object> param) {
        try {
            ServerResponse result = companyFeign.getAduitDetail(param);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取公司审核信息失败！");
        }
    }




    //参数delFlag 0正常1删除  compID
    @RequestMapping("/deleteCompanyById.ajax")
    public ServerResponse deleteCompanyById(@RequestBody Map<String,Object> param) {
        try {
            ServerResponse result = companyFeign.deleteCompanysById(param);
            stampService.deleteCertAndStamp(param);
            return ServerResponse.createBySuccess("删除成功！");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("删除公司失败！");
        }
    }


    public String translateServeType(String servType , Map<String,String> mapDic){
        StringBuilder sb = new StringBuilder();
        if(!StringUtil.isEmpty(servType)){
            String[] arr = servType.split(",");
            for(String s : arr){
                sb.append(getDicValue(s,mapDic)+" ");
            }
        }
        return sb.toString().trim();

    }

    //获取dicValue
    public String getDicValue(String docType, Map<String, String> mapDic) {
        Map<String, String> map = new HashMap<>();
        if (mapDic.containsKey(docType)) {
            map.put("name", mapDic.get(docType));
        } else {
            map.put("name", docType);
        }
        String docValue = (String) map.get("name");
        return docValue;
    }


    @RequestMapping("/getCompanyUrlHistory.ajax")
    public ServerResponse getCompanyUrlHistory(@RequestBody Map<String,Object> param) {
        //Integer compID = (Integer) SessionContext.getContext().getSession(request).getAttribute("compID");
        Integer compID = (int) param.get("compID");
        Map res = new HashMap();
        try {
            ServerResponse result = companyFeign.getCompanyUrlHistory(compID);
            List<Map<String , Object>> list = (List<Map<String, Object>>) result.getData();
            for(Map map : list){
                res.put(map.get("value"),map.get("docUrl"));
            }
            return ServerResponse.createBySuccess(res);
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取公司资质历史记录失败！");
        }
    }






}

