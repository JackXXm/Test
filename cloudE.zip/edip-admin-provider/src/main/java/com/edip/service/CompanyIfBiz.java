package com.edip.service;

import com.edip.entity.CompInfo;
import com.edip.vo.CompInfoVo;

public interface CompanyIfBiz {

    CompInfo searchCompInfo(String compID);

    CompInfoVo searchCompByCompID(String compID);

    void updateCompByCompID(CompInfoVo vo);

    void insertCompInfo(CompInfoVo vo);

}
