package com.edip.service;

import com.edip.entity.Cert;
import com.edip.entity.CertExample;
import com.edip.entity.CertWithBLOBs;
import com.edip.vo.BaseException;
import com.edip.vo.CertVo;

import java.util.List;
import java.util.Map;

public interface CertService {
    public Cert getCert(int compmayId,int accountId);
    public Cert queryCertByCompId(Integer compId, Integer userID);
    public Integer applyCert(CertVo certVo) throws Exception;
    public CertWithBLOBs activeCert(CertVo certVo) throws Exception;
    public CertVo updateKeyCertificate(CertVo certVo) throws Exception;
    public List<CertVo> queryCertificateOne(CertExample example) throws Exception;

    Integer updateCertVo (CertVo certVo) throws Exception;

    CertWithBLOBs downloadCert(CertWithBLOBs cert) throws Exception;

    void updateCertByCompanyId(Map<String,Object> param);

    long getCertValidity(Integer companyId) throws BaseException;
}
