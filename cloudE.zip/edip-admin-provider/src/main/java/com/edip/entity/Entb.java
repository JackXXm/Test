package com.edip.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class Entb {
    /**
     * 返回代码
     */
    private String code;
    /**
     * 调用结果描述
     */
    private String message;
    /**
     * 唯一标识
     */
    private String wybs;
    /**
     * 查询关键字
     */
    private String key;
    /**
     * 键值类型
     */
    private String reqKeytype;

    private A1Po a1Po;

    private String a7pos;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getWybs() {
        return wybs;
    }

    public void setWybs(String wybs) {
        this.wybs = wybs;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getReqKeytype() {
        return reqKeytype;
    }

    public void setReqKeytype(String reqKeytype) {
        this.reqKeytype = reqKeytype;
    }

    public A1Po getA1Po() {
        return a1Po;
    }

    public void setA1Po(A1Po a1Po) {
        this.a1Po = a1Po;
    }

    public String getA7pos() {
        return a7pos;
    }

    public void setA7pos(String a7pos) {
        this.a7pos = a7pos;
    }

}
