package com.edip.mapper;

import com.edip.entity.CompInfo;
import com.edip.vo.CompInfoVo;

public interface CompanyMapperVo {

    CompInfo searchCompInfo(Integer compID);

    void insertCompInfo(CompInfoVo vo);

    CompInfoVo searchCompByCompID(String compID);

    void updateCompByCompID(CompInfoVo vo);

}