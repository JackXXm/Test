package com.edip.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.edip.dto.ServerResponse;
import com.edip.entity.*;
import com.edip.feign.AccountFeign;
import com.edip.feign.CompanyFeign;
import com.edip.mapper.BillMapper;

import com.edip.mapper.CdrMapper;
import com.edip.mapper.CompanyBenefitDetailMapper;
import com.edip.mapper.RechargeMapperVo;
import com.edip.service.ManageRechargeService;
import com.edip.vo.BaseException;
import com.edip.vo.BillVo;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.*;
@Service
public class ManageRechargeServiceImpl implements ManageRechargeService {
    @Autowired
    private BillMapper billMapper;
    @Autowired
    private CompanyFeign companyFeign;
    @Autowired
    private AccountFeign accountFeign;
    @Autowired
    private RechargeMapperVo rechargeMapperVo;
    @Autowired
    private CdrMapper cdrMapper;
    @Autowired
    private CompanyBenefitDetailMapper companyBenefitDetailMapper;
    @Override
    public PageInfo queryAllBills(Map<String, Object> info) {
        Integer page = (Integer)info.get("page");
        Integer rows = (Integer)info.get("rows");
        String name=(String)info.get("name");
        List<BillVo>billVos=new ArrayList<>();
        PageHelper.startPage(page, rows);
        BillExample example=new BillExample();
        example.setOrderByClause(" createDate desc ");
        Integer provinceID = (Integer)info.get("provinceID");
        List<Integer> compId =new ArrayList<Integer>();
        BillExample.Criteria criteria=example.createCriteria();
        if(name!=null){
            ServerResponse result=companyFeign.queryCompIds(name);
            List<Integer>compIds= (List<Integer>) result.getData();

            if(compIds.size()==0){
                return new PageInfo();
            }
            criteria.andCompidIn(compIds);
        }
        if(provinceID!=null&&!provinceID.equals("")&&provinceID !=-1){
            List<Map<String , Object>> listInfo  = (List<Map<String, Object>>) companyFeign.queryCompanyByProvinceID(provinceID);
            if(listInfo.size()>0){
                for(int i=0;i<listInfo.size();i++) {
                    compId.add((Integer) listInfo.get(i).get("compID"));
                }
            }
            criteria.andCompidIn(compId);
        }

        Date date = new Date();
        Calendar rightNow = Calendar.getInstance();
        rightNow.setTime(date);
        Date dt1=rightNow.getTime();

            List<Bill>bills=billMapper.selectByExample(example);
           PageInfo pageInfo=new PageInfo();
          if(bills!=null){
              pageInfo= new PageInfo(bills);
            bills.forEach(bill -> {
                if (bill.getFreedate()!=null&&bill.getFreedate().getTime()<dt1.getTime()){
                    bill.setFreedate(null);
                }
                BillVo billVo=new BillVo();
                billVo.setBill(bill);
               ServerResponse result = companyFeign.getCompanyByCompanyId(bill.getCompid());

                JSONObject  companyInfo = JSONObject.parseObject((String) result.getData());
                billVo.setName(companyInfo.getString("name"));
                billVos.add(billVo);
            });
              pageInfo.setList(billVos);
          }

        return pageInfo;
    }

    @Override
    @Transactional
    public int recharge(Map<String, Object> info) {
        int result=0;
        JSONObject rechargeJson=new JSONObject(info);
         Recharge recharge=JSONObject.toJavaObject(rechargeJson,Recharge.class);
         recharge.setCreatedate(new Date());
        Float billNum=recharge.getBillnum();
        Float giveNum=recharge.getGivenum();
        Integer giveDate = recharge.getGiveDate();
        Date startDate = recharge.getStartTime();
        int compID=recharge.getCompid();

        BillExample exam = new BillExample();
        BillExample.Criteria cri =exam.createCriteria();
        cri.andCompidEqualTo(compID);
        List<Bill> bi =billMapper.selectByExample(exam);
        Bill record = new Bill();
        Calendar rightNow = Calendar.getInstance();
        if(bi!=null&&bi.size()>0){
            Bill b =bi.get(0);
            record.setCdrsubtype(30f);
            record.setCdrtype(3);
            record.setBillid(b.getBillid());
            record.setCreatedate(new Date());

            if(billNum!=null){
                record.setTotalamount(b.getTotalamount()==null?billNum:b.getTotalamount()+billNum);
                record.setRemainamount(b.getRemainamount()==null?billNum:b.getRemainamount()+billNum);
                if(b.getRemainamount()+billNum<0){
                    return -1;
                }
            }
            if(giveNum!=null){
                record.setGiveamount(b.getGiveamount()==null?giveNum:b.getGiveamount()+giveNum);
                record.setRemaingiveamount(b.getRemaingiveamount()==null?giveNum:b.getRemaingiveamount()+giveNum);
                if(b.getRemaingiveamount()+giveNum<0){
                    return -1;
                }
            }
            //免费日期
            if (giveDate!=null){
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date date = startDate;
                rightNow.setTime(date);
                rightNow.add(Calendar.DAY_OF_YEAR,giveDate-1);//免费日期修改
                /* if (b.getFreedate()!=null&&b.getFreedate().getTime()>date.getTime()){
                    return -2;
                } */
                CompanyBenefitDetailExample example = new CompanyBenefitDetailExample();
                example.createCriteria().andCompidEqualTo(compID).andBenefittypeEqualTo(2);
                List<CompanyBenefitDetail> lists = companyBenefitDetailMapper.selectByExample(example);
                for (CompanyBenefitDetail companyBenefitDetail:lists){
                    if(companyBenefitDetail.getEndTime()!=null&&companyBenefitDetail.getEndTime().getTime()>=startDate.getTime())
                        return -2;
                }
                if (b.getFreedate()!=null&&b.getFreedate().getTime()>=startDate.getTime()){
                    return -2;
                }
            }

            record.setModeid(5);
            billMapper.updateByPrimaryKeySelective(record);
        }else{

            Bill bil = new Bill();
            bil.setCdrsubtype(30f);
            bil.setCdrtype(3);
            bil.setCompid(compID);
            bil.setCreatedate(new Date());
            bil.setTotalamount(billNum);
            bil.setRemainamount(billNum);
            bil.setGiveamount(giveNum);
            bil.setRemaingiveamount(giveNum);
            bil.setModeid(5);
            billMapper.insertSelective(bil);
        }
        if(billNum!=null){
            rechargeMapperVo.insertSelective(recharge);
        }else if(giveNum!=null){
            CompanyBenefitDetail companyBenefitDetail=new CompanyBenefitDetail();
            companyBenefitDetail.setIsgive(1);
            companyBenefitDetail.setBenefittype(1);
            companyBenefitDetail.setBenefitdata(giveNum);
            companyBenefitDetail.setFromcontent(recharge.getNote());
            companyBenefitDetail.setCompid(compID);
            companyBenefitDetail.setCreateid(recharge.getOperid());
            companyBenefitDetail.setCreatetime(new Date());
            companyBenefitDetailMapper.insertSelective(companyBenefitDetail);
        }else if (giveDate!=null){
            CompanyBenefitDetail companyBenefitDetail=new CompanyBenefitDetail();
            companyBenefitDetail.setIsgive(1);
            companyBenefitDetail.setBenefittype(2);
            companyBenefitDetail.setBenefitdata(Float.parseFloat(giveDate.toString()));
            companyBenefitDetail.setFromcontent(recharge.getNote());
            companyBenefitDetail.setCompid(compID);
            companyBenefitDetail.setCreateid(recharge.getOperid());
            companyBenefitDetail.setCreatetime(new Date());
            companyBenefitDetail.setStartTime(startDate);
            companyBenefitDetail.setEndTime(rightNow.getTime());
            companyBenefitDetailMapper.insertSelective(companyBenefitDetail);
        }
        return result;

    }
    @Override
    public PageInfo queryRechargeDetail(Map<String, Object> info) {

        Integer page = (int)info.get("page");
        Integer rows = (int)info.get("rows");
        PageHelper.startPage(page, rows);
        List<RechargeVo>rechargeVos=new ArrayList<>();
        Map<String,Object>params=new HashMap<>();
        params.put("compid",info.get("compId"));
        List<Recharge>recharges=rechargeMapperVo.queryRechargeDetail(params);
        recharges.forEach(recharge -> {
            RechargeVo rechargeVo=new RechargeVo();
            rechargeVo.setRecharge(recharge);
            ServerResponse result =accountFeign.getAccountInfo(recharge.getOperid());
            JSONObject  accountInfo = JSONObject.parseObject((String) result.getData());
            if(accountInfo!=null)
                rechargeVo.setAccountName(accountInfo.getString("name"));
            rechargeVos.add(rechargeVo);

        });

        PageInfo pageInfo=new PageInfo(recharges);

        pageInfo.setList(rechargeVos);
        return  pageInfo;
    }

    public PageInfo queryRechargeDetailBak(Map<String, Object> info) {

        Integer page = (int)info.get("page");
        Integer rows = (int)info.get("rows");
        PageHelper.startPage(page, rows);
        List<RechargeVo>rechargeVos=new ArrayList<>();
        Map<String,Object>params=new HashMap<>();
        params.put("compid",info.get("compId"));
        List<Recharge>recharges=rechargeMapperVo.queryRecharge(params);

        PageInfo pageInfo=new PageInfo(recharges);
        recharges.forEach(recharge -> {
            RechargeVo rechargeVo=new RechargeVo();
            rechargeVo.setRecharge(recharge);
            ServerResponse result =accountFeign.getAccountInfo(recharge.getOperid());
            JSONObject  accountInfo = JSONObject.parseObject((String) result.getData());
            if(accountInfo!=null)
            rechargeVo.setAccountName(accountInfo.getString("name"));
            rechargeVos.add(rechargeVo);

        });
        pageInfo.setList(rechargeVos);
        return  pageInfo;
    }

    @Override
    public PageInfo querySendCost(Map<String, Object> info) {
        CdrExample cdrExample=new CdrExample();
        CdrExample.Criteria criteria=cdrExample.createCriteria();
        cdrExample.setOrderByClause(" createDate desc");
        Integer page = (Integer)info.get("page");
        Integer rows = (Integer)info.get("rows");
        PageHelper.startPage(page, rows);
        criteria.andCompidEqualTo((int)info.get("compId"));

        return new PageInfo(cdrMapper.selectByExample(cdrExample));
    }

    @Override
    public PageInfo queryPresentationDetails(Map<String, Object> info) {
        Integer page = (int)info.get("page");
        Integer rows = (int)info.get("rows");
        PageHelper.startPage(page, rows);
        List<RechargeVo>rechargeVos=new ArrayList<>();
        Map<String,Object>params=new HashMap<>();
        params.put("compid",info.get("compId"));
        List<Recharge>recharges=rechargeMapperVo.queryPresentationDetails(params);
        recharges.forEach(recharge -> {
            RechargeVo rechargeVo=new RechargeVo();
            rechargeVo.setRecharge(recharge);
            ServerResponse result =accountFeign.getAccountInfo(recharge.getOperid());
            JSONObject  accountInfo = JSONObject.parseObject((String) result.getData());
            if(accountInfo!=null)
                rechargeVo.setAccountName(accountInfo.getString("name"));
            rechargeVos.add(rechargeVo);

        });

        PageInfo pageInfo=new PageInfo(recharges);

        pageInfo.setList(rechargeVos);
        return  pageInfo;
    }

    @Override
    public List<CompanyBenefitDetail> getFreeDelivery(Integer companyID) {
        return companyBenefitDetailMapper.getFreeDelivery(companyID);
    }
}
