package com.edip.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.edip.dto.ServerResponse;
import com.edip.dto.util.CacheKey;
import com.edip.dto.util.RedisUtilForDiy;
import com.edip.utils.*;
import com.edip.dto.util.Page;
import com.edip.dto.util.RedisUtil;
import com.edip.entity.*;
import com.edip.exception.BaseException;
import com.edip.feign.AccountFeign;
import com.edip.feign.CompanyFeign;
import com.edip.feign.DocFeign;
import com.edip.mapper.*;
import com.edip.servant.AdminCAClient;
import com.edip.service.AdminCertService;
import com.edip.service.AdminMessageBiz;
import com.edip.vo.*;
import org.apache.commons.lang.StringUtils;
import org.dom4j.DocumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.text.Collator;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service("adminCertServiceImpl")
public class AdminCertServiceImpl implements AdminCertService {
    private static final Logger logger = LoggerFactory.getLogger(AdminCertServiceImpl.class);

    @Autowired
    private RedisUtil util;
    @Autowired
    private AdminCertMapper adminCertMapper;
    @Autowired
    private AdminAddressMapper adminAddressMapper;
    @Autowired
    private AdminProvinceMapper adminProvinceMapper;
    @Autowired
    private AdminCityAreaMapper adminCityAreaMapper;
    @Autowired
    private CompanyFeign companyFeign;
    @Autowired
    private AdminDicMapper adminDicMapper;
    @Autowired
    private DocFeign docFeign;
    @Autowired
    private AccountFeign accountFeign;
    @Autowired
    private AdminBillMapper adminBillMapper;
    @Autowired
    private AdminCertMapperVo adminCertMapperVo;
    @Autowired
    private AdminMessageBiz adminMessageBiz;
    @Autowired
    private AdminCdrMapper adminCdrMapper;

    @Override
    public Map<String, Object> checkCertDetil(Integer certId) {
        Map<String, Object> result = new HashMap<>();
        AdminCertVo cert = adminCertMapper.selectByPrimaryKey(certId);
        AdminAddressVo addressVo= new AdminAddressVo();
        if(cert.getBillFlag()!=null ){
            if(cert.getBillFlag() == 0)cert.setIsBill("是");
            else cert.setIsBill("否");
        }
        if(cert.getDeliverFlag() !=null){
            if(cert.getDeliverFlag() == 0)cert.setIsDeliver("是");
            else cert.setIsDeliver("否");
        }
        if(cert.getStatus() == AdminCertVo.CERT_OK)
            cert.setCertStatus("正常");
        else if(cert.getStatus() ==AdminCertVo.CERT_TOAUDIT )
            cert.setCertStatus("待审批");
        else if(cert.getStatus() ==AdminCertVo.CERT_EXPIRED)
            cert.setCertStatus("已过期");
        else if(cert.getStatus() ==AdminCertVo.CERT_TODOWNLOAD)
            cert.setCertStatus("待下载");
        else if(cert.getStatus() ==AdminCertVo.CERT_REVOKE)
            cert.setCertStatus("已吊销");
        else if(cert.getStatus() ==AdminCertVo.CERT_AUDITNOPASS)
            cert.setCertStatus("审核失败");
        else if(cert.getStatus() ==AdminCertVo.CERT_EXPIRING)
            cert.setCertStatus("即将过期");
        if(cert.getUkStatus()==0)cert.setApplyTypeC("新申请");
        if(cert.getUkStatus()==1)cert.setApplyTypeC("更新");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if(cert.getActiveDate()!=null){
            String format = sdf.format(cert.getActiveDate());
            cert.setActiveDateS(format);
        }
        if(cert.getBillTime()!=null){
            String format = sdf.format(cert.getBillTime());
            cert.setBillTimeS(format);
        }
        if(cert.getValidDate()!=null){
            String format = sdf.format(cert.getValidDate());
            cert.setValidDateS(format);
        }
        if(cert.getInvalidDate()!=null){
            String format = sdf.format(cert.getInvalidDate());
            cert.setInvalidDateS(format);
        }
        if(cert.getCreateDate()!=null){
            String format = sdf.format(cert.getCreateDate());
            cert.setCreateDateS(format);
        }
        if(cert.getLupDate()!=null){
            String format = sdf.format(cert.getLupDate());
            cert.setLupDateS(format);
        }



        AdminAddress address = adminAddressMapper.selectByCompId(cert.getCompID());
        if(address!=null&&address.getAreaID()!=null){
            Integer areaID = address.getAreaID();
            AdminArea area = adminCityAreaMapper.selectAreaByAreaId(areaID);
            addressVo.setArea(area.getAreaName());
        }
        if(address!=null && address.getCityID()!=null){
            Integer cityID = address.getCityID();
            AdminCity city = adminCityAreaMapper.selectByPrimaryKey(cityID);
            addressVo.setCity(city.getCITY_NAME());
        }
        if(address!=null && address.getProvinceID()!=null){
            AdminProvince prov = adminProvinceMapper.selectByPrimaryKey(address.getProvinceID());
            addressVo.setProvince(prov.getPROV_NAME());
        }
        ServerResponse companyResponse = companyFeign.getCompanyByCompanyId(address.getCompID());
        Object data = companyResponse.getData();
        AdminCompanyVo comp = JSONObject.parseObject(data.toString(),AdminCompanyVo.class);
        if("1".equals(comp.getCodeFlag())){
            comp.setCodeFlag("是");
        }else{
            comp.setCodeFlag("否");
        }
        String serveType = comp.getServeType();
        String compType = "";
        if(serveType.contains(",")){
            String[] split = serveType.split(",");
            for(int i=0;i<split.length;i++){
                AdminDic dic = adminDicMapper.selectByValue(split[i]);
                compType += dic.getName();
                if(split.length != (i+1)){
                    compType +=",";
                }
            }
        }else{
            AdminDic dic = adminDicMapper.selectByValue(serveType);
            compType = dic.getName();
        }

        if(comp!=null && comp.getProvinceID()!=null){
            AdminProvince prov = adminProvinceMapper.selectByPrimaryKey(comp.getProvinceID());
            if(comp!=null && comp.getCityID()!=null){
                Integer cityID = comp.getCityID();
                AdminCity city = adminCityAreaMapper.selectByPrimaryKey(cityID);
                comp.setPcStr(prov.getPROV_NAME()+"省"+city.getCITY_NAME());
            }

        }

        comp.setServeType(compType);
        addressVo.setCompName(comp.getName());
        addressVo.setSite(address.getSite());
        addressVo.setLinkMan(address.getLinkMan());
        addressVo.setMsisdn(address.getMsisdn());
        result.put("address", addressVo);
        result.put("company", comp);
        List<Map<String,Object>> documents =new ArrayList<>();
        List<String> companyType = new ArrayList<>();
        companyType.add("uniLic") ;
        companyType.add("license") ;
        documents = (List<Map<String,Object>>)docFeign.getDocumentByType(companyType,cert.getCompID()).getData();
        result.put("document", documents);
        Object param = accountFeign.getAccountInfo(comp.getAccountID()).getData();
        AdminAccount account = JSONObject.parseObject(param.toString(),AdminAccount.class);
        account.setDocUrl(com.edip.dto.util.StringUtils.getFilePath(account.getDocUrl(),util));
        account.setIdCardNoURL(com.edip.dto.util.StringUtils.getFilePath(account.getIdCardNoURL(),util));
        account.setIdCardNo2URL(com.edip.dto.util.StringUtils.getFilePath(account.getIdCardNo2URL(),util));
//        if(cert.getUserID()!=null){
//            Object user = accountFeign.getAccountInfo(comp.getAccountID()).getData();
//            AdminAccount acct = JSONObject.parseObject(user.toString(),AdminAccount.class);
//            result.put("acct", acct);
//        }
        result.put("account", account);

        result.put("cert",cert);
        return result;
    }

    @Override
    public AdminAddressVo getAddress(Integer compid){
        AdminAddressVo  addressVo= new AdminAddressVo();
        AdminAddress address = adminAddressMapper.selectByCompId(compid);
        if(address!=null && address.getCityID()!=null){
            Integer cityID = address.getCityID();
            AdminCity city = adminCityAreaMapper.selectByPrimaryKey(cityID);
            addressVo.setCity(city.getCITY_NAME());
        }
        if(address!=null && address.getProvinceID()!=null){
            AdminProvince prov = adminProvinceMapper.selectByPrimaryKey(address.getProvinceID());
            addressVo.setProvince(prov.getPROV_NAME());
        }
        ServerResponse companyResponse = companyFeign.getCompanyByCompanyId(address.getCompID());
        Object data = companyResponse.getData();
        AdminCompanyVo comp = JSONObject.parseObject(data.toString(),AdminCompanyVo.class);
        addressVo.setCompName(comp.getName());
        addressVo.setSite(address.getSite());
        addressVo.setLinkMan(address.getLinkMan());
        addressVo.setMsisdn(address.getMsisdn());
        List<AdminCertVo> certs = adminCertMapper.selelctCertCompId(compid);
        if (certs.size()>0){
            AdminCertVo cert = certs.get(0);
            String ukeySN = cert.getUkeyCode();
            addressVo.setUkeySN(ukeySN);
        }
        else
            throw new RuntimeException("证书数据异常！");
        return addressVo;
    }
    @Override
    @Transactional
    public Integer revokeCertificate(Integer certId) throws Exception {

        AdminCertVo cert = selectByPrimaryKey(certId);
        Integer result =null;
        RevokeCertRespVO revokeCertRespVO = revokeCert(cert.getCertSN());
        if(revokeCertRespVO.getResult().equals("0")){
            cert.setStatus(AdminCertVo.CERT_REVOKE);//设置为已吊销
            cert.setLupDate(new Date());
            cert.setUserID(-10);
            result = UpdateCert(AdminCertConvert.convert(cert));
            AdminCertExample example = new AdminCertExample();
            example.createCriteria().andCertsnEqualTo(cert.getCertSN()).andCertidNotEqualTo(certId);
            List<AdminCertWithBLOBs> certs = adminCertMapper.selectByExampleWithBLOBs(example);
            if(certs.size() > 0){
                AdminCertWithBLOBs cert2 = certs.get(0);
                cert2.setStatus(AdminCertVo.CERT_REVOKE);
                cert.setLupDate(new Date());
                cert2.setUserid(-10);
                result = UpdateCert(cert2);
            }
        }else{
            if(revokeCertRespVO.getErrormsg().indexOf("Cert already revoke") == -1){
                throw new Exception("吊销证书失败："+revokeCertRespVO.getErrormsg());
            }else{
                cert.setStatus(AdminCertVo.CERT_REVOKE);
                cert.setLupDate(new Date());
                cert.setUserID(-10);
                result =  UpdateCert(AdminCertConvert.convert(cert));
            }
        }
        return result;
    }


    /**
     * 修改证书信息
     */
    public Integer UpdateCert(AdminCertWithBLOBs record){
        return adminCertMapper.updateByPrimaryKeySelective(record);
    }

    private static String PLATFORMID_SY;
    @Value("${PLATFORMID_SY}")
    public void setPLATFORMID_SY(String PLATFORMID_SY) {
        this.PLATFORMID_SY = PLATFORMID_SY;
    }
    private RevokeCertRespVO revokeCert(String certNO)throws Exception{

        RevokeCertReqVO revokeCertReqVO = new RevokeCertReqVO();
        revokeCertReqVO.setPlatformid(PLATFORMID_SY);
        revokeCertReqVO.setCertsn(certNO);
        revokeCertReqVO.setOperationtype("2");
        revokeCertReqVO.setRevokeReason("0");

        RevokeCertRespVO revokeCertRespVO = AdminCAClient.revokeCert(revokeCertReqVO);

        return revokeCertRespVO;
    }

    public AdminCertVo selectByPrimaryKey(Integer certID){
        AdminCertVo cert = adminCertMapper.selectByPrimaryKey(certID);
        return cert;
    }

    @Override
    public List<Map<String,Object>> selectCertVo(Map<String, Object> params) {

        List<Map<String,Object>> certs = adminCertMapper.searchCert(params);
        certs.forEach(cert ->{
            ServerResponse serverResponse = companyFeign.getCompanyByCompanyId(Integer.valueOf(cert.get("compID").toString()));
            if (serverResponse.getData()!=null){
                AdminCompanyVo result = JSONObject.parseObject(serverResponse.getData().toString(),AdminCompanyVo.class);
                cert.put("provinceID",result.getProvinceID()==null?"数据丢失":result.getProvinceID());
                cert.put("companyName",result.getName()==null?"数据丢失":result.getName());
            }else {
                cert.put("provinceID","数据丢失");
                cert.put("companyName","数据丢失");
                cert.put("province","数据丢失");
            }
            if (Integer.parseInt(cert.get("STATUS").toString())==4){
                cert.put("STATUS",3);
            }else {
                cert.put("STATUS",cert.get("STATUS"));
            }
        });
        List<AdminProvince> provinces = adminProvinceMapper.getProvinces();
        certs.forEach(cert -> provinces.stream().filter(province ->
                        !cert.get("provinceID").toString().equals("数据丢失")&&
                                Integer.parseInt(cert.get("provinceID").toString())==province.getPROVINCE_ID()).forEach(province ->
                        cert.put("province",province.getPROV_NAME())));
        return certs;
    }

    @Override
    public Integer countCertNums(Map<String, Object> params) {
        return adminCertMapper.countCertTotal(params);
    }

    @Override
    @Transactional
    public Integer CertPayment(Map<String, Integer> params) {
        AdminCertVo cert = adminCertMapper.selectByPrimaryKey(params.get("certId"));
        if (cert ==null) {
            logger.error("-------------- 未存在证书记录-------------");
            return -3;
        }
        if(cert.getBillFlag()!=null&&cert.getBillFlag()==0) {
            logger.error("--------------该证书以扣费-------------");
            return -4;
        }
        AdminBillExample example = new AdminBillExample();
        example.createCriteria().andCompIDEqualTo(params.get("companyId"));
        List<AdminBill> list = adminBillMapper.selectByExample(example);
        AdminBill bill =null;
        if (list.size()==0){
            bill = new AdminBill();
            bill.setCompID(params.get("companyId"));
            bill.setCdrsubType(30f);
            bill.setCdrType(3);
            bill.setCreateDate(new Date());
            bill.setTotalAmount(0d);
            bill.setRemainAmount(0d);
            bill.setGiveAmount(0d);
            bill.setRemainGiveAmount(0d);
            bill.setModeID(5);
            adminBillMapper.insertSelective(bill);
            list.add(bill);
            if (params.get("pay")>0){
                logger.error("--------------用户未充值，请提醒用户充值后，在进行缴费！-------------");
                return -5;
            }
        }else
            bill = list.get(0);
        if(list.size()!=1){
            logger.error("--------------账户数据异常-------------");
            return -1;
        }
        if (bill.getRemainAmount()<params.get("pay")){
            logger.error("--------------账户余额不足-------------");
            return -2;
        }else {
            Double amout = bill.getRemainAmount()-params.get("pay");
            bill.setRemainAmount(amout);
            //修改账单
            adminBillMapper.updateByPrimaryKeySelective(bill);
            //修改证书状态
            cert.setBillNum(params.get("pay"));
            cert.setBillFlag(0);
            cert.setBillTime(new Date());
            if(cert.getUkStatus() == 1){// 说明是更新证书
                try {
                    BASE64Encoder b64e = new BASE64Encoder();
                    String publickey = b64e.encode(cert.getPublicKey());
                    updateCertVo(cert, publickey);
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new BaseException("扣费失败！");
                }
            }else {
                if (cert.getStatus().intValue() == 1) { //需要审核
                    try {
                        applyCert(cert);
//                        }
                    } catch (Exception e) {
                        logger.error("审核失败"+e.getMessage(),e);
                        e.printStackTrace();
                        throw new BaseException("审核失败！");
                    }
                }
            }
            //生成话单报表
            try {
                AdminCdr cdr = new AdminCdr();
                cdr.setCdrType(2);
                cdr.setCompID(params.get("companyId"));
                cdr.setDataID(cert.getCertID());
                cdr.setDataType(5);
                cdr.setCreateDate(new Date());
                cdr.setAccountCharging(Double.valueOf(params.get("pay")));
                cdr.setRemainGiveAmount(bill.getRemainGiveAmount());
                cdr.setRemainAmount(bill.getRemainAmount());
                cdr.setCdrsubType(21);
                adminCdrMapper.insertSelective(cdr);
            }catch (Exception e){
                logger.error("初始化话单记录失败！"+e.getMessage(),e);
                throw new BaseException("初始化话单记录失败！");
            }
        }
        return 0;
    }

    @Override
    @Transactional
    public AdminCertWithBLOBs downloadCert(AdminCertWithBLOBs certificate) throws Exception {
        // 如果某些信息没有传入则抛出异常
        if (certificate.getAccountID() == null
                || certificate.getPublickey() == null
                || StringUtils.isEmpty(certificate.getTxcode())) {
            throw new Exception("证书下载失败，用户账号ID或公钥或业务号为空");
        }
        logger.info("start================" + new Date().getTime());
        AdminCertResponseVO downloadResponseVO = null;
        try {
            BASE64Encoder encoder = new BASE64Encoder();
            String publickey = encoder.encode(certificate.getPublickey());

            downloadResponseVO = downloadCert(certificate.getTxcode(),publickey,"");
            // 下载证书失败
            if (!"0".equals(downloadResponseVO.getResult())) {
                throw new Exception("下载证书失败,错误码="
                        + downloadResponseVO.getResult());
            }
            BASE64Decoder decoder = new BASE64Decoder();
            byte[] decodeBuffer = decoder.decodeBuffer(downloadResponseVO.getSigncert().toString());

            //downloadResponseVO.getSigncert()
            // 解析证书对象
            AdminCertInfo certInfo = new AdminCertInfo(decodeBuffer);
            certificate.setX509(decodeBuffer);
            certificate.setCertSN(certInfo.getSerialNumber());
            certificate.setValidDate(certInfo.getNotBeforeDate());
            certificate.setInvalidDate(certInfo.getNotAfterDate());
            certificate.setStatus(AdminCertVo.CERT_OK);
            //certificateDao.updateCertificate(certificate);
            adminCertMapper.updateByPrimaryKeySelective(certificate);
            logger.info("end=================" + new Date().getTime());
        } catch (AdminCaCommunicationException e) {
            logger.error(e.toString(),e);
            e.printStackTrace();
            throw new Exception("下载证书失败,连接CA服务器异常");
        } catch (DocumentException e) {
            logger.error(e.toString(),e);
            e.printStackTrace();
            throw new Exception("下载证书失败,解析响应XML失败");
        }catch (Exception e) {
            logger.error(e.toString(),e);
            e.printStackTrace();
            throw new Exception("下载证书失败,系统异常");
        }
        return certificate;
    }

    @Override
    @Transactional
    public Integer isMill(Map<String,Object> params) {
        Integer certId = (Integer)params.get("certId");
        List<Integer> status = new ArrayList<>();
        status.add(1);
        status.add(2);
        AdminCertVo cert =new AdminCertVo();
        cert.setCertID(certId);
        AdminCertExample example = new AdminCertExample();
        example.createCriteria().andCertidEqualTo(certId).andStatusIn(status);

        List<AdminCertWithBLOBs> certs = adminCertMapper.selectByExampleWithBLOBs(example);
        if (certs!=null&&certs.size()>0&&certs.get(0).getBillFlag()==1)
            return -2;
        if (certs!=null&&certs.size()>0&&certs.get(0).getStatus()==2)
            return -3;
        cert.setDeliverFlag(0);
        if(certs!=null&&certs.size()>0&&certs.get(0).getDeliverFlag()==0){
            return -1;
        }
        cert.setMailName((String)params.get("mailName"));
        cert.setMailNum((String)params.get("mailNum"));
        Integer result = adminCertMapperVo.updateByPrimaryKeySelective(cert);
        AdminCertWithBLOBs certw = adminCertMapperVo.selectByPrimaryKey(certId);
        AdminMessageVo messageVo = new AdminMessageVo();
        messageVo.setCreateDate(new Date());
        messageVo.setStatus(AdminMessageStatusUtil.MESSAGE_SUCCESS_FLAG);
        messageVo.setCompID((Integer)params.get("companyId"));
        messageVo.setAccountID((Integer)params.get("addountId"));
        messageVo.setContent("-");
        messageVo.setDataID(certId);
        messageVo.setDataType(7);
        messageVo.setSender("通知:");
        messageVo.setTitle("您的ukey已寄出请注意查收");
        messageVo.setMsgType(AdminMessageStatusUtil.MESSAGESTATUS_MSGTYPE_FROMSP11);//操作
        messageVo.setReceiveCompID(null);
        messageVo.setReceiveID(certw.getAccountID());
        messageVo.setUrl("/modules/signetManage/uKeyCheck.shtml?certId="+certId);
        messageVo.setLupDate(new Date());
        adminMessageBiz.insert(messageVo);
        return result;
    }

    @Override
    public Map<String, Object> getMailInfo(Integer certId) {
        return adminCertMapper.getMailInfo(certId);
    }

    /**
     * @param transctioncode
     *            业务受理号
     * @param publicKey
     *            公钥（base64）
     * @return CertResponseVO
     * @throws org.dom4j.DocumentException
     * @throws CaCommunicationException
     * @description: 下载证书
     */
    private AdminCertResponseVO downloadCert(String transctioncode,
                                        String publicKey, String passcode) throws Exception {

        AdminDownloadCertReqVO downloadCertReqVO = new AdminDownloadCertReqVO();
        downloadCertReqVO.setPlatformid(PLATFORMID_SY);
        downloadCertReqVO.setTransactioncode(transctioncode);
        downloadCertReqVO.setAuthcode(passcode);
        downloadCertReqVO.setSubjectpubkey(publicKey);

        AdminCertResponseVO certResponseVO = AdminCAClient.downloadCert(downloadCertReqVO);
        return certResponseVO;
    }

    public AdminCertVo applyCert(AdminCertVo certVo) throws Exception {
        // 判断参数是否为空
        //下个版本可以去掉
        //查找用户
        ServerResponse responseCompany = companyFeign.getCompanyByCompanyId(certVo.getCompID());
        Object data = responseCompany.getData();
        AdminCompanyVo company = JSONObject.parseObject(data.toString(),AdminCompanyVo.class);
        ServerResponse responseAccount =  accountFeign.getAccountInfo(company.getAccountID());
        AdminAccount account = JSONObject.parseObject(responseAccount.getData().toString(),AdminAccount.class);
        if (account == null) {
            throw new Exception("通过账号ID查不到用户信息");
        }
        company.setAliasName(account.getAliasName());//企业管理员姓名
        company.setIdCardNo(account.getIdCardNo());//企业管理员身份证ID
        company.setMsisdn(account.getMsisdn());//企业管理员手机号
        company.setEmail(account.getEmail());//企业管理员邮箱
        AdminCertResponseVO certResponseVO = null;
        try {
            //如果有ID说明 已经申请   开始审核
            certResponseVO = applyEntPIDC(company,account.getName(), certVo.getPublicKey());
            if (!"0".equals(certResponseVO.getResult())) {
                throw new Exception("申请证书失败,错误码" + certResponseVO.getResult());
            }
            certVo.setTxcode(certResponseVO.getTransactioncode());
            certVo.setLupDate(new Date());
            certVo.setStatus(AdminCertVo.CERT_TODOWNLOAD);//证书状态更改为待下载
            adminCertMapperVo.updateByPrimaryKeySelective(certVo);
        } catch (Exception e) {
            logger.debug(e.toString());
            e.printStackTrace();
            throw new Exception("申请证书失败,系统异常");
        }
        return certVo;
    }

    /**
     * @description: 申请企业PIDC证书
     * @return 包含证书信息的VO
     * @throws DocumentException
     * @throws CaCommunicationException
     * @throws Exception
     * @throws MalformedURLException
     */
    private static String certsort;
    @Value("${certsort}")
    public void setCertsort(String certsort) {
        this.certsort = certsort;
    }
    private static String certapptype;
    @Value("${certapptype}")
    public void setCertapptype(String certapptype) {
        this.certapptype = certapptype;
    }
    private AdminCertResponseVO applyEntPIDC(AdminCompanyVo comp,String userName,
                                        byte[] pubKey) throws Exception{

        AdminApplyEntCertReqVO applyEntCertReqVO = new AdminApplyEntCertReqVO();
		/*Accounts accounts =new Accounts();//找到当前对象的证书申请类型
		accounts.setUserName(userName);
		accounts.setRoleType(2);
        accounts = accountsDao.findAccountsOne(accounts);*/
        applyEntCertReqVO.setPlatformid(PLATFORMID_SY);
        if (comp.getName()==null||comp.getName().equals(""))
            throw new BaseException("企业名为空！");
        applyEntCertReqVO.setUnitname(comp.getName());// 公司名
        if (comp.getOrgCode()==null||comp.getOrgCode().equals(""))
            throw new BaseException("组织机构代码为空！");
        applyEntCertReqVO.setUnitlicensecode(comp.getOrgCode());// 组织机构
        applyEntCertReqVO.setCertsort(certsort);// 证书种类
        applyEntCertReqVO.setCertapptype(certapptype);
        //applyEntCertReqVO.setUnitbusinesscode(comp.getUnitbusinesscode());//营业执照号
        //applyEntCertReqVO.setUnittelephone(comp.getLandline());//企业电话
        if (comp.getAliasName()==null||comp.getAliasName().equals(""))
            throw new BaseException("企业联系人姓名为空！");
        applyEntCertReqVO.setUsername(comp.getAliasName());// 企业联系人姓名
        applyEntCertReqVO.setCardtype(AdminCompanyVo.CARDTYPE);// 企业联系人证件类型
        if (comp.getIdCardNo()==null||comp.getIdCardNo().equals(""))
            throw new BaseException("企业联系人证件号码为空！");
        applyEntCertReqVO.setCardnum(comp.getIdCardNo());// 企业联系人证件号码
        if (comp.getMsisdn()==null||comp.getMsisdn().equals(""))
            throw new BaseException("企业联系人电话为空！");
        applyEntCertReqVO.setMobilephone(comp.getMsisdn());// 企业联系人电话
        if (comp.getEmail()==null||comp.getEmail().equals(""))
            throw new BaseException("企业联系人email！");
        applyEntCertReqVO.setEmail(comp.getEmail());// 企业联系人email
        //根据证书申请类型来处理申请请求
        //applyEntCertReqVO.setCertstoragetype(CertificateProperty.getProperty("certstoragetype_u"));// Ukey证书
        applyEntCertReqVO.setCertstoragetype(AdminCertVo.cert_storagetype);// Ukey证书
        applyEntCertReqVO.setSubjectpubkey(""); // 公钥
        // 申请企业PIDC证书
        AdminCertResponseVO certResponseVO = AdminCAClient.applyEntcert(applyEntCertReqVO);
        return certResponseVO;
    }

    private Integer updateCertVo(AdminCertVo certVo,String publickey) throws Exception {
        AdminUpdateCertRespVO response = updateCert(certVo.getCertSN(),publickey );
        if (!"0".equals(response.getResult())) {
            throw new Exception("更新证书失败,错误码" + response.getResult());
        }
        certVo.setTxcode(response.getTransactioncode());
        certVo.setStatus(AdminCertVo.CERT_TODOWNLOAD);//状态修改为待下载
        certVo.setLupDate(new Date());
        return adminCertMapperVo.updateByPrimaryKeySelective(certVo);
    }

    /**
     * 更新证书
     * @param certsn
     * @param subjectpubkey
     * @return
     * @throws CaCommunicationException
     * @throws DocumentException
     */
    private AdminUpdateCertRespVO updateCert(String certsn,String subjectpubkey)throws Exception {
        AdminUpdateCertRespVO updateCertRespVO = null;
        AdminUpdateCertReqVO updateCertReqVO = new AdminUpdateCertReqVO();
        updateCertReqVO.setPlatformid(PLATFORMID_SY);
        updateCertReqVO.setCertsn(certsn);
        updateCertReqVO.setSubjectpubkey(subjectpubkey);
        updateCertReqVO.setCertstoragetype(/*CertificateProperty.getProperty("certstoragetype_u")*/"1");
        updateCertRespVO = AdminCAClient.updateCert(updateCertReqVO);
        return updateCertRespVO;
    }


    @Override
    public Page getUkeyCountInfo(Page page, Map<String, Object> params) {
        Map<String, String> mapDic = RedisUtilForDiy.getMap(CacheKey.DIC);//查所有dic
        List<Map<String,Object>> result = new ArrayList<>();

        List<Map<String,Object>> ukeyInfos = adminCertMapperVo.getUkeyCountInfo(params);


        if (ukeyInfos.size()<1){
            page.setDatas(ukeyInfos);
            return page;
        }
        List<Integer> compIds = new ArrayList<>();
        ukeyInfos.forEach(map ->compIds.add((Integer)map.get("compID")));
        params.put("compIds",compIds);
        ServerResponse serverResponse = companyFeign.getCompServiceType(params);
        List<Map<String,Object>> compTypes = (List<Map<String,Object>>)serverResponse.getData();
//        if (compTypes.size()<=0)
//            throw new BaseException("获取企业信息失败！");
        List<Map<String,String>> compTypeStr = adminCertMapperVo.getCompTypeStr(params);
        compTypes.forEach(compType-> compType.put("compType",translateServeType(compType.get("serveType").toString(),mapDic)));
        if (compTypeStr.size()<=0)
            throw new BaseException("获取企业类型失败！");

        if (params.get("limitFlag")==null){
            compTypes.forEach(comptype ->ukeyInfos.forEach(res -> {
                if (comptype!=null&&Integer.parseInt(res.get("compID").toString()) == Integer.parseInt(comptype.get("compID").toString())) {
                    res.put("compType",comptype.get("compType"));
                    res.put("provinceID",comptype.get("provinceID"));
                    result.add(res);
                }
            }));
            ukeyInfos.clear();
            ukeyInfos.addAll(result.subList((page.getPage()-1)*page.getPageSize(),page.getPage()*page.getPageSize()>result.size()?result.size():page.getPage()*page.getPageSize()));
            page.setTotal(result.size());
        }else{
            Integer count = adminCertMapperVo.getUkeyCountInfoCount(params);

            compTypes.forEach(comptype -> ukeyInfos.forEach(res -> {
                if (Integer.parseInt(res.get("compID").toString()) == Integer.parseInt(comptype.get("compID").toString())) {
                    res.put("compType",comptype.get("compType"));
                    res.put("provinceID",comptype.get("provinceID"));
                }
            }));
            page.setTotal(count);
        }
        if (page.getTotal()<=0)
            return page;
        page.setDatas(initUKeyCountInfoVos(adminProvinceMapper.getProvinceName(ukeyInfos)));
        return page;
    }

    private static String export_path;
    @Value("${export_path}")
    public void setExport_path(String export_path) {
        this.export_path = export_path;
    }
    @Override
    public String writeExcelWithModel(Map<String,Object> params, HttpServletRequest request, HttpServletResponse response) {
        Map<String, String> mapDic = RedisUtilForDiy.getMap(CacheKey.DIC);//查所有dic

        List<Map<String,Object>> ukeysList = new ArrayList<>();
        Integer count = adminCertMapperVo.getUkeyCountInfoCount(params);
        if (count>10000)
            return "IsTooLong";
        params.put("limitFlag",true);
        params.put("from",0);
        params.put("to",10000);

        List<Map<String,Object>> ukeyInfos = adminCertMapperVo.getUkeyCountInfo(params);
        if (ukeyInfos.size()<1)
            throw new BaseException("无证书信息！");
        List<Integer> compIds = new ArrayList<>();
        ukeyInfos.forEach(map ->compIds.add((Integer)map.get("compID")));
        params.put("compIds",compIds);
        String compTypesStr= companyFeign.exportUkeyCountInfo(params);
        List<Map<String,Object>> compTypes = JSONObject.parseObject(compTypesStr,List.class);
//        List<Map<String,Object>> compTypes = (List<Map<String,Object>>)serverResponse.getData();
//        if (compTypes.size()<=0)
//            throw new BaseException("获取企业信息失败！");
        List<Map<String,String>> compTypeStr = adminCertMapperVo.getCompTypeStr(params);

        List<AdminProvince> provinces = adminProvinceMapper.getProvinces();

        compTypes.forEach(compType->  compType.put("compType",translateServeType(compType.get("serveType").toString(),mapDic)));
        if (compTypeStr.size()<=0)
            throw new BaseException("获取企业类型失败！");

        compTypes.forEach(comptype ->ukeyInfos.forEach(res ->{
            if (comptype!=null&&Integer.parseInt(res.get("compID").toString()) == Integer.parseInt(comptype.get("compID").toString())) {
                res.put("compType",comptype.get("compType"));
                res.put("provinceID",comptype.get("provinceID"));
                ukeysList.add(res);
            }
        }));
        ukeysList.forEach(ukey ->provinces.forEach(province ->{
            if (province.getPROVINCE_ID()==Integer.parseInt(ukey.get("provinceID").toString()))
                ukey.put("provinceName",province.getPROV_NAME());
        }));

        List<UKeyCountInfoVo> etuInfoList= initUKeyCountInfoVos(ukeyInfos);
        File file = new File(export_path);
        if(!file.exists()){
            file.mkdirs();
        }
        try {
            String path  = export_path+File.separator+etuInfoList.get(etuInfoList.size()-1).getCreateTime().substring(0,10)+
                    "-"+etuInfoList.get(0).getCreateTime().substring(0,10)+"_"+"UKEY数量"+".xlsx";
            EasyExcelUtil.writeExcelWithModel(path,etuInfoList,UKeyCountInfoVo.class);

            File  outFile = new File(path);
            String fileName = outFile.getName();

            request.setCharacterEncoding("UTF-8");

            BufferedOutputStream bos = null;
            BufferedInputStream bis = null;
            bis = new BufferedInputStream(new FileInputStream(path));
            response.setContentType("application/octet-stream");
            response.setHeader("Content-disposition", "attachment; filename="+ new String(fileName.getBytes("utf-8"), "ISO8859-1"));
            response.setHeader("Content-Length", String.valueOf(bis.available()));
            bos = new BufferedOutputStream(response.getOutputStream());
            byte[] buff = new byte[2048];
            int bytesRead;
            while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                bos.write(buff, 0, bytesRead);
            }
            bis.close();
            bos.close();

            return path;
        } catch (Exception e) {
            e.printStackTrace();
            throw new BaseException("导出失败！");
        }
    }
    private String translateServeType(String servType , Map<String,String> mapDic){
        StringBuilder sb = new StringBuilder();
        if(!StringUtil.isEmpty(servType)){
            String[] arr = servType.split(",");
            for(String s : arr){
                sb.append(getDicValue(s,mapDic)+" ");
            }
        }
        return sb.toString().trim();

    }
    //获取dicValue
    private String getDicValue(String docType, Map<String, String> mapDic) {
        Map<String, String> map = new HashMap<>();
        if (mapDic.containsKey(docType)) {
            map.put("name", mapDic.get(docType));
        } else {
            map.put("name", docType);
        }
        String docValue = (String) map.get("name");
        return docValue;
    }

    private List<UKeyCountInfoVo> initUKeyCountInfoVos(List<Map<String,Object>> ukeysList)  {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        List<UKeyCountInfoVo> etuInfoList = new ArrayList<>();
        ukeysList.forEach(ukey ->{
            UKeyCountInfoVo uKeyCountInfoVo = new UKeyCountInfoVo();
            try {
                uKeyCountInfoVo.setCertID(Integer.parseInt(ukey.get("certID").toString()));
                uKeyCountInfoVo.setActiveTime(ukey.get("activeDate")==null?null:ukey.get("activeDate").toString());
                uKeyCountInfoVo.setActiveDate(ukey.get("activeDate")==null?null:sdf.parse(ukey.get("activeDate").toString()));
                uKeyCountInfoVo.setCertSN(ukey.get("certSN")==null?null:ukey.get("certSN").toString());
                uKeyCountInfoVo.setCompanyName(ukey.get("companyName")==null?null:ukey.get("companyName").toString());
                uKeyCountInfoVo.setCompanyType(ukey.get("compType")==null?null:ukey.get("compType").toString());
                uKeyCountInfoVo.setProvince(ukey.get("provinceName")==null?null:ukey.get("provinceName").toString());

                Integer status = Integer.parseInt(ukey.get("status").toString());

                uKeyCountInfoVo.setStatus(status.toString());
                if (Integer.parseInt(ukey.get("status").toString())==1)
                    ukey.put("billFlag",1);
                if (ukey.get("billFlag")!=null&&Integer.parseInt(ukey.get("billFlag").toString())==1)
                    uKeyCountInfoVo.setStatusInfo("待扣费");
                else if (status==0){
                    if (ukey.get("activeDate")!=null)
                        uKeyCountInfoVo.setStatusInfo("正常");
                    else
                        uKeyCountInfoVo.setStatusInfo("待激活");
                }
                else if (status==2)
                    uKeyCountInfoVo.setStatusInfo("待下载");
                else if (status==3||status==4||status==6){
                    uKeyCountInfoVo.setStatusInfo("已失效");
                    uKeyCountInfoVo.setStatus("4");
                }
                else if (status==5){
                    if (ukey.get("activeDate")!=null)
                        uKeyCountInfoVo.setStatusInfo("即将过期");
                    else
                        uKeyCountInfoVo.setStatusInfo("待激活");
                }
                uKeyCountInfoVo.setBillFlag(ukey.get("billFlag")==null?"":ukey.get("billFlag").toString());
                uKeyCountInfoVo.setUkeyCode(ukey.get("ukeyCode")==null?"":ukey.get("ukeyCode").toString());

                Integer ukeuStatus = Integer.parseInt(ukey.get("ukStatus").toString());
                if (ukeuStatus==0)
                    uKeyCountInfoVo.setUKeyStatus("首次申请");
                if (ukeuStatus==1)
                    uKeyCountInfoVo.setUKeyStatus("到期更新");
                if (ukeuStatus==2)
                    uKeyCountInfoVo.setUKeyStatus("遗失补发");
                if (ukeuStatus==3)
                    uKeyCountInfoVo.setUKeyStatus("企业变更");
                uKeyCountInfoVo.setCreateTime(ukey.get("createDate").toString());
                uKeyCountInfoVo.setCreateDate(ukey.get("createDate")==null?null:simpleDateFormat.parse(ukey.get("createDate").toString()));
                if (uKeyCountInfoVo.getActiveTime()!=null){
                    uKeyCountInfoVo.setInvalidTime(ukey.get("invalidDate")==null?"数据丢失":ukey.get("invalidDate").toString());
                    uKeyCountInfoVo.setInvalidDate(ukey.get("invalidDate")==null?null:sdf.parse(ukey.get("invalidDate").toString()));
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
            etuInfoList.add(uKeyCountInfoVo);
        });
        return etuInfoList;
    }

}
