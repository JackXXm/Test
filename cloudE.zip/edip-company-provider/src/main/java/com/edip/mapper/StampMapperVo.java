package com.edip.mapper;

import com.edip.entity.Stamp;
import com.edip.entity.StampExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface StampMapperVo {
    int countByExample(StampExample example);

    int deleteByExample(StampExample example);

    int deleteByPrimaryKey(Integer stampID);

    int insert(Stamp record);

    int insertSelective(Stamp record);

    List<Stamp> selectByExampleWithBLOBsWithPage(@Param("example") StampExample example, @Param("from") Integer from, @Param("to") Integer to);

    List<Stamp> selectByExampleWithBLOBs(StampExample example);

    List<Stamp> selectByExampleWithPage(@Param("example") StampExample example, @Param("from") Integer from, @Param("to") Integer to);

    List<Stamp> selectByExample(StampExample example);

    Stamp selectByPrimaryKey(Integer stampID);

    int updateByExampleSelective(@Param("record") Stamp record, @Param("example") StampExample example);

    int updateByExampleWithBLOBs(@Param("record") Stamp record, @Param("example") StampExample example);

    int updateByExample(@Param("record") Stamp record, @Param("example") StampExample example);

    int updateByPrimaryKeySelective(Stamp record);

    int updateByPrimaryKeyWithBLOBs(Stamp record);

    int updateByPrimaryKey(Stamp record);
    
    List<Stamp> selectByStampId(Map<String, Object> params);

    List<Map<String,Object>>queryList(@Param("params") Map<String, Object> params);

    int auditTure(@Param("params") Map<String, Object> params);

    List<Map<String,Object>> queryPageList(Map<String, Object> params);

    List<Stamp> selectByParams(Map<String, Object> params);

    Stamp selectByCompId(Map params);

    List<Map<String,Object>> checkMessage(@Param("params") Map<String, Object> params);

    List<Map<String,Object>> checkphoto(@Param("params") Map<String, Object> params);
    Integer selectStampID(int compID);

	List<Map<String, Object>> searchphoto(@Param("params") Map<String, Object> params);

	void updateData(Stamp stamp);

	void insertData(Stamp stamp);
	
	//优化管理端印章查询
	int queryListNums(Map<String, Object> params);
}