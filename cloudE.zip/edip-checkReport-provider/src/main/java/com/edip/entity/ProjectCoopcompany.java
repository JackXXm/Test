package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class ProjectCoopcompany implements Serializable {
    /**
     * 条目ID
     */
    private Integer itemid;

    /**
     * 产品ID
     */
    private Integer productid;

    /**
     * 产品主题ID
     */
    private Integer productproid;

    /**
     * 关联企业主题ID
     */
    private Integer coopproid;

    /**
     * 0:线上   1:线下
     */
    private Integer businesstype;

    /**
     * 关联企业ID
     */
    private Integer businessid;

    /**
     * 创建时间
     */
    private Date createdate;

    /**
     * 状态 0： 正常  -1：删除
     */
    private Integer status;

    /**
     * 类型:1为直接供应商，2为生产企业
     */
    private Integer type;

    /**
     * 标识：0：品种关联供应商数据，1线上，线下数据
     */
    private Integer flag;

    /**
     * 品种关联供应商“创建人”“主题发送人
     */
    private String createby;

    private static final long serialVersionUID = 1L;

    public Integer getItemid() {
        return itemid;
    }

    public void setItemid(Integer itemid) {
        this.itemid = itemid;
    }

    public Integer getProductid() {
        return productid;
    }

    public void setProductid(Integer productid) {
        this.productid = productid;
    }

    public Integer getProductproid() {
        return productproid;
    }

    public void setProductproid(Integer productproid) {
        this.productproid = productproid;
    }

    public Integer getCoopproid() {
        return coopproid;
    }

    public void setCoopproid(Integer coopproid) {
        this.coopproid = coopproid;
    }

    public Integer getBusinesstype() {
        return businesstype;
    }

    public void setBusinesstype(Integer businesstype) {
        this.businesstype = businesstype;
    }

    public Integer getBusinessid() {
        return businessid;
    }

    public void setBusinessid(Integer businessid) {
        this.businessid = businessid;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        ProjectCoopcompany other = (ProjectCoopcompany) that;
        return (this.getItemid() == null ? other.getItemid() == null : this.getItemid().equals(other.getItemid()))
            && (this.getProductid() == null ? other.getProductid() == null : this.getProductid().equals(other.getProductid()))
            && (this.getProductproid() == null ? other.getProductproid() == null : this.getProductproid().equals(other.getProductproid()))
            && (this.getCoopproid() == null ? other.getCoopproid() == null : this.getCoopproid().equals(other.getCoopproid()))
            && (this.getBusinesstype() == null ? other.getBusinesstype() == null : this.getBusinesstype().equals(other.getBusinesstype()))
            && (this.getBusinessid() == null ? other.getBusinessid() == null : this.getBusinessid().equals(other.getBusinessid()))
            && (this.getCreatedate() == null ? other.getCreatedate() == null : this.getCreatedate().equals(other.getCreatedate()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getType() == null ? other.getType() == null : this.getType().equals(other.getType()))
            && (this.getFlag() == null ? other.getFlag() == null : this.getFlag().equals(other.getFlag()))
            && (this.getCreateby() == null ? other.getCreateby() == null : this.getCreateby().equals(other.getCreateby()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getItemid() == null) ? 0 : getItemid().hashCode());
        result = prime * result + ((getProductid() == null) ? 0 : getProductid().hashCode());
        result = prime * result + ((getProductproid() == null) ? 0 : getProductproid().hashCode());
        result = prime * result + ((getCoopproid() == null) ? 0 : getCoopproid().hashCode());
        result = prime * result + ((getBusinesstype() == null) ? 0 : getBusinesstype().hashCode());
        result = prime * result + ((getBusinessid() == null) ? 0 : getBusinessid().hashCode());
        result = prime * result + ((getCreatedate() == null) ? 0 : getCreatedate().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getType() == null) ? 0 : getType().hashCode());
        result = prime * result + ((getFlag() == null) ? 0 : getFlag().hashCode());
        result = prime * result + ((getCreateby() == null) ? 0 : getCreateby().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", itemid=").append(itemid);
        sb.append(", productid=").append(productid);
        sb.append(", productproid=").append(productproid);
        sb.append(", coopproid=").append(coopproid);
        sb.append(", businesstype=").append(businesstype);
        sb.append(", businessid=").append(businessid);
        sb.append(", createdate=").append(createdate);
        sb.append(", status=").append(status);
        sb.append(", type=").append(type);
        sb.append(", flag=").append(flag);
        sb.append(", createby=").append(createby);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}