package com.edip.service;


import com.edip.vo.CompanyVo;
import com.edip.vo.ProductVo;

import java.util.List;
import java.util.Map;

public interface ReceiveBoxService {
    List<Map<String , Object>> queryReceiveBox(Map<String, Object> params);

    int updateByJobId(Map<String,Object> info);

    Map<String , Object> queryReceiveInfomationBox(Map<String, Object> params);



    int receiveProduct(Map<String, Object> params) throws Exception;
}


