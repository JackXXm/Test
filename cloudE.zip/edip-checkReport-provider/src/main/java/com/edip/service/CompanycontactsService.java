package com.edip.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public interface CompanycontactsService {
	
	 List<Map<String,Object>> selectWithPage(Map<String, Object> params) throws Exception;

	 Map<String , Object> update(Map<String, Object> params, HttpServletRequest request);
	 
	 Integer deleteCompanycontacts(Map<String, Object> params);
	 
	 Map<String, Object> uploadCompanycontacts(HttpServletRequest request, HttpServletResponse response);
	 
	 
	 Map<String,Object> search(Map<String, Object> params) throws Exception;

	 Integer insertOneCompanyContracts(Map<String, Object> params);

	 //统计公司收发列表
	 Map<String , Object> getReSeNum(Integer compID);
	 //统计公司发送记录
    List<Map<String , Object>> queryCompanySendList(Integer compID);
    //统计公司接收记录
    List<Map<String , Object>> queryCompanyReceiveList(Integer compID);

}
