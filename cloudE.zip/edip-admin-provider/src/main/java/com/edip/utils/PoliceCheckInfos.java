package com.edip.utils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class PoliceCheckInfos {

    private PoliceCheckInfo[] policeCheckInfo;

    public PoliceCheckInfo[] getPoliceCheckInfo() {
        return policeCheckInfo;
    }

    public void setPoliceCheckInfo(PoliceCheckInfo[] policeCheckInfo) {
        this.policeCheckInfo = policeCheckInfo;
    }



}
