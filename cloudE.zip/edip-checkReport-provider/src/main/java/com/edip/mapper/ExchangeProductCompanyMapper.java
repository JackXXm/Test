package com.edip.mapper;

import com.edip.entity.ExchangeProductCompany;
import com.edip.entity.ExchangeProductCompanyExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ExchangeProductCompanyMapper {
    long countByExample(ExchangeProductCompanyExample example);

    int deleteByExample(ExchangeProductCompanyExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ExchangeProductCompany record);

    int insertSelective(ExchangeProductCompany record);

    List<ExchangeProductCompany> selectByExample(ExchangeProductCompanyExample example);

    ExchangeProductCompany selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ExchangeProductCompany record, @Param("example") ExchangeProductCompanyExample example);

    int updateByExample(@Param("record") ExchangeProductCompany record, @Param("example") ExchangeProductCompanyExample example);

    int updateByPrimaryKeySelective(ExchangeProductCompany record);

    int updateByPrimaryKey(ExchangeProductCompany record);
}