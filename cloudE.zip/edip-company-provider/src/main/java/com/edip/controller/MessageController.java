package com.edip.controller;

import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.entity.Message;
import com.edip.service.MessageService;
import com.github.pagehelper.PageHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/message")
public class MessageController {
	/** slf4j */
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageController.class);
	@Autowired
	private MessageService messageService;
	@Autowired
	private HttpServletRequest request;

	/**
	 * @Author mao
	 * 
	 * @createdDate 2018-03-14
	 * 
	 * @illustrate 获取消息分类列表页面(新版分页接口)
	 */
	@RequestMapping(value = "/getMessageListByClassifyForNew.ajax")
	@ResponseBody
	public ServerResponse messageListWithType(HttpServletRequest request, @RequestBody Map<String,Object> params) {

		HttpSession session = SessionContext.getContext().getSession(request);
		Integer accountID = (Integer)session.getAttribute("accountID");
		//测试数据
//		accountID = 3239;
		Map<String,Object> result = new HashMap<>();
		List<Message> list = new ArrayList<Message>();
		int number = 0;
		try {
			Integer page= (Integer) params.get("page");
			Integer rows= (Integer) params.get("rows");
			list = messageService.messageList(accountID, params);
			number = messageService.countMessageList(accountID, params);
			// return
			// jsonResultHelper.buildSuccessJsonResult(messageService.messageList(accountID,
			// messageType, from, to,type));
			result.put("records", number);//总条数
			result.put("rows",list);//数据
			result.put("page", page);//页数
			result.put("total",(number - 1) / rows + 1);//总页数
			return ServerResponse.createBySuccess(result);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(),e);
			return ServerResponse.createByErrorMsg("获取消息失败！");
		}
	}

}
