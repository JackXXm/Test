package com.edip.service;

import com.edip.dto.ServerResponse;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

public interface InspectReportService {
    ServerResponse changeInspectReport(String data, HttpSession session) throws Exception;

    List<Map<String, Object>> getInspectReportList(String batchNum, String startTime, String endTime, Integer compId, Integer informationFrom, Integer productId, int from, int i);

    int getInspectReportListCount(String batchNum, String startTime, String endTime, Integer compId, Integer informationFrom, Integer productInfoId);

    void delInspectReport(Integer inspectReportId);

    void delInspectDocument(String docId);

    Map getInspectReportDetail(Integer reportId);

    Integer checkBatchNum(Integer productInfoId, String batchNum, Integer compId);

    void changeReportProductId(Integer productId, Integer infoId);

    List<Map> getReceiveReport(Integer reportId);

    void updateReceiveReport(Integer reportId, Integer edition, Integer ascription);

    void reportTransfer() throws Exception;

    void transmitReportTransfer() throws Exception;
}
