package com.edip.controller;
import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.feign.CompanyFeign;
import com.edip.service.RechargeService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/recharge")
public class RechargeController {

    private Logger LOGGER = LoggerFactory.getLogger(RechargeController.class);
    @Autowired
    private HttpServletRequest request;

    @Autowired
    private RechargeService rechargeService;

    @Autowired
    private CompanyFeign companyFeign;

    @RequestMapping("/queryMoneyTime.ajax")
    public ServerResponse queryBillList(@RequestBody Map<String,Object>info) {
        try {
            Integer compID = (Integer) SessionContext.getContext().getSession(request).getAttribute("compID");
            Integer page = (int)info.get("page");
            Integer rows = (int)info.get("rows");
            PageHelper.startPage(page, rows);
            List<Map<String , Object>> resultList = rechargeService.queryBill(compID);
            PageInfo pageInfo = new PageInfo(resultList);
            return ServerResponse.createBySuccess("success", pageInfo);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取企业充值列表失败！");
        }
    }



    @RequestMapping("/queryAmount.ajax")
    public ServerResponse queryTopView() {
        try {
            Integer compID = (Integer) SessionContext.getContext().getSession(request).getAttribute("compID");
            List<Map<String , Object>> resultList = rechargeService.queryTopView(compID);
            return ServerResponse.createBySuccess("success", resultList);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取充值管理金额显示失败！");
        }
    }



    @RequestMapping("/getBenefitList.ajax")
    public ServerResponse queryBenefitList(@RequestBody Map<String,Object>info) {
        try {
            Integer compID = (Integer) SessionContext.getContext().getSession(request).getAttribute("compID");
            Integer page = (int)info.get("page");
            Integer rows = (int)info.get("rows");
            PageHelper.startPage(page, rows);
            List<Map<String , Object>> resultList = rechargeService.queryBenefit(compID);
            PageInfo pageInfo = new PageInfo(resultList);
            return ServerResponse.createBySuccess("success", pageInfo);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取赠送明细显示失败！");
        }
    }



    @RequestMapping("/querySend.ajax")
    public ServerResponse querySendList(@RequestBody Map<String,Object>info) {
        try {
            Integer compID = (Integer) SessionContext.getContext().getSession(request).getAttribute("compID");
            //Integer compID = 9988;
            Integer page = (int)info.get("page");
            Integer rows = (int)info.get("rows");
            PageHelper.startPage(page, rows);
            List<Map<String , Object>> resultList = rechargeService.queryExchangeList(compID);
            for(Map map : resultList){
                if(!map.containsKey("name") && map.containsKey("targetID")){
                    Integer receiveCompId = (int)map.get("targetID");
                    ServerResponse result = companyFeign.getCompanyNameByCompanyId(receiveCompId);
                    String companyName = (String) result.getData();
                    map.put("name",companyName);
                }else {
                    map.put("name",map.get("name")==null?null:map.get("name"));
                }
            }

            PageInfo pageInfo = new PageInfo(resultList);
            return ServerResponse.createBySuccess("success", pageInfo);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取消费明细显示失败！");
        }
    }
    @RequestMapping("/charging.ajax")
    public ServerResponse charging(@RequestBody  String info) {
        try {
            Integer compID = (Integer) SessionContext.getContext().getSession(request).getAttribute("compID");
            //Integer compID = 155;

            int status = rechargeService.charging(info,compID);
            if(status==0){
                return ServerResponse.createBySuccess("success");
            }else{
                return ServerResponse.createByErrorMsg("扣费失败");
            }

        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("扣费失败！");
        }
    }

    /**
     * 维护账单表
     * @param info
     * @return
     */
    @RequestMapping("/billMaintain.ajax")
    public ServerResponse billMaintain(@RequestBody String info){
        try {
            Integer compId = Integer.parseInt(info);
            return ServerResponse.createBySuccess(rechargeService.billMaintain(compId));
        }catch (Exception e){
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByError();
        }
    }


}
