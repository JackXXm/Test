package com.edip.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class Entbs {

    private Entb[] entb;

    public Entb[] getEntbs() {
        return entb;
    }

    public void setEntbs(Entb[] entb) {
        this.entb = entb;
    }

}
