package com.edip.controller;

import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.dto.util.Page;
import com.edip.service.InspectReportService;
import com.edip.utils.StringUtil;
import org.apache.commons.collections.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/inspect_report")
public class InspectReportController {
    private static final Logger logger = LoggerFactory.getLogger(InspectReportController.class);

    @Autowired
    private InspectReportService inspectReportService;
    @Autowired
    private HttpServletRequest request;

    @RequestMapping("/changeInspectReport.ajax")
    public ServerResponse changeInspectReport(@RequestBody String data ) {
        logger.debug("----------检验报告新增----------");

        HttpSession session = SessionContext.getContext().getSession(request);
        try {
            return inspectReportService.changeInspectReport(data,session);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage(), e);
            return ServerResponse.createByErrorMsg("检验报告新增失败，请联系系统管理员");
        }
    }

    @RequestMapping("/getInspectReportList.ajax")
    public ServerResponse getInspectReportList(String batchNum, String startTime, String endTime, Integer informationFrom,Integer productId,Page page){
        logger.debug("------------检验报告列表查询----------");
        HttpSession session = SessionContext.getContext().getSession(request);
        Integer compId = (Integer)session.getAttribute("compID");
        List<Map<String, Object>> list = new ArrayList<>();
        int number = 0;
        try {
            int from = (page.getPage() - 1) * page.getPageSize();
            int to = page.getPage() * page.getPageSize();
            list = inspectReportService.getInspectReportList(batchNum,startTime,endTime,compId,informationFrom,productId,from,to-from);
            number = inspectReportService.getInspectReportListCount(batchNum,startTime,endTime,compId,informationFrom,productId);
        }catch (Exception e){
            e.printStackTrace();
            logger.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("检验报告列表查询失败，请联系系统管理员");
        }
        page.setDatas(list);
        page.setTotal(number);
        return ServerResponse.createBySuccess(page);
    }

    @RequestMapping("/delInspectReport.ajax")
    public ServerResponse delInspectReport(Integer inspectReportId){
        logger.debug("------------检验报告列表删除----------");
        try {
            inspectReportService.delInspectReport(inspectReportId);
        }catch (Exception e){
            e.printStackTrace();
            logger.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("检验报告列表删除失败，请联系系统管理员");
        }
        return ServerResponse.createBySuccess();
    }

    @RequestMapping("/delInspectDocument.ajax")
    public ServerResponse delInspectDocument(String docId){
        logger.debug("------------检验报告资质删除----------");
        try{
            if(StringUtil.isNotEmpty(docId))
                inspectReportService.delInspectDocument(docId);
        }catch (Exception e){
            e.printStackTrace();
            logger.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("检验报告资质删除失败，请联系系统管理员");
        }
        return ServerResponse.createBySuccess();
    }

    @RequestMapping("/getInspectReportDetail.ajax")
    public ServerResponse getInspectReportDetail(Integer reportId){
        logger.debug("------------检验报告详情查询----------");
        Map map = new HashedMap();
        try{
            map = inspectReportService.getInspectReportDetail(reportId);
        }catch (Exception e){
            e.printStackTrace();
            logger.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("检验报告详情查询失败，请联系系统管理员");
        }
        return ServerResponse.createBySuccess(map);
    }

    @RequestMapping("/checkBatchNum.ajax")
    public ServerResponse checkBatchNum(Integer productInfoId,String batchNum){
        logger.debug("------------校验批号----------");
        HttpSession session = SessionContext.getContext().getSession(request);
        Integer compId = (Integer)session.getAttribute("compID");
        try {
            Integer count = inspectReportService.checkBatchNum(productInfoId,batchNum,compId);
            if(count > 0)
                return ServerResponse.createByError(3,"批号已存在");
        }catch (Exception e){
            e.printStackTrace();
            logger.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("批号校验失败，请联系系统管理员");
        }
        return ServerResponse.createBySuccess();
    }

    @RequestMapping("/changeReportProductId.ajax")
    public void changeReportProductId(Integer productId ,Integer infoId){
        inspectReportService.changeReportProductId(productId,infoId);
    }

    @RequestMapping("/getReceiveReport.ajax")
    public ServerResponse getReceiveReport(Integer reportId){
        logger.debug("------------获取检验报告版本----------");
        List<Map> list = new ArrayList<>();
        try {
            list = inspectReportService.getReceiveReport(reportId);
        }catch (Exception e){
            e.printStackTrace();
            logger.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取检验报告版本失败，请联系系统管理员");
        }
        return ServerResponse.createBySuccess(list);
    }

    @RequestMapping("/updateReceiveReport.ajax")
    public ServerResponse updateReceiveReport(Integer reportId ,Integer edition,Integer ascription){
        logger.debug("------------更新检验报告版本----------");
        try {
            inspectReportService.updateReceiveReport(reportId,edition,ascription);
        }catch (Exception e){
            e.printStackTrace();
            logger.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("更新检验报告版本失败，请联系系统管理员");
        }
        return ServerResponse.createBySuccess();
    }

    @RequestMapping("/reportTransfer.ajax")
    public void reportTransfer(){
        logger.debug("------------检验报告数据迁移----------");
        try {
            inspectReportService.reportTransfer();

            inspectReportService.transmitReportTransfer();
        }catch (Exception e){
            e.printStackTrace();
            logger.error(e.getMessage(),e);
        }
    }
}
