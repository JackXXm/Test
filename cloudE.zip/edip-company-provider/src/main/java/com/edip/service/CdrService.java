package com.edip.service;

public interface CdrService {
    public void addCdr(String mobile,Integer cdrType,Integer cdrSubType,Integer companyId);

}
