package com.edip.utils;

import com.edip.controller.CompTypeCredentialsClient;
import com.edip.dto.util.CacheKey;
import com.edip.dto.util.RedisUtilForDiy;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Administrator
 * @description TODO
 * @DATE 2019/1/23 0023 18:53
 */
@Component
public class ExchangeUtil {
    @Autowired
    CompTypeCredentialsClient compTypeCredentialsClient;
    //组装人员资质
    public  List<Map<String, Object>> getMemberDocResult(List<Map<String, Object>> memberList, Map<String, Object> memberDocMap) {
        if (memberDocMap != null && !memberDocMap.isEmpty()) {
            List<Map<String, Object>> memberDocList = (List<Map<String, Object>>) memberDocMap.get("docList");
            if (!CollectionUtils.isEmpty(memberDocList) && !CollectionUtils.isEmpty(memberList)) {
                memberList.forEach(member -> {
                    List<Map<String, Object>> memberDocs = new ArrayList<>();
                    memberDocList.forEach(memberDoc -> {
                        String docMemberID = memberDoc.get("memberId") == null ? null : String.valueOf(memberDoc.get("memberId"));
                        String MemberID = member.get("id") == null ? null : String.valueOf(member.get("id"));
                        if (StringUtils.equalsIgnoreCase(docMemberID, MemberID)) {
                            memberDocs.add(memberDoc);
                        }
                        member.put("allAttribute", memberDocs);
                    });
                });
                memberList.forEach(member -> {
                    List<Map<String, Object>> docs = (List<Map<String, Object>>) member.get("allAttribute");
                    categorizeDoc(member, docs, "doc_type");
                });
            }
        }
        return memberList;
    }

    /**
     * doc分类
     *
     * @param compDocList
     * @return
     */
    public  Map<String, Object> categorizeDoc(Map<String, Object> docInfo, List<Map<String, Object>> compDocList, String typeKey) {
        if (docInfo != null) {
            List<Map<String, Object>> categorizeList = new ArrayList<>();
            if (!CollectionUtils.isEmpty(compDocList)) {
                Map<String, List<Map<String, Object>>> docMap = compDocList.stream().collect(Collectors.groupingBy(map -> (String) map.get(typeKey)));
                Iterator<String> iterator = docMap.keySet().iterator();
                while (iterator.hasNext()) {
                    Map<String, Object> doc = new HashMap<>();
                    String key = iterator.next();
                    List<Map<String, Object>> docTypeList;
                    Map <String,String >map=RedisUtilForDiy.getMap(CacheKey.DIC);
                    String typeName = null;
                    if(map!=null){
                        typeName=map.get(key);
                    }

                    if(typeName==null){
                        typeName =compTypeCredentialsClient.queryDicName(key);
                    }
                    doc.put("attributeName", typeName);
                    doc.put("attributeKey", key);
                    docTypeList = docMap.get(key);
                    doc.put("docList", docTypeList);
                    categorizeList.add(doc);
                }
                docInfo.put("allAttribute", categorizeList);
            }
        }
        return docInfo;
    }

    /**
     * 清除doc资质为零的数据
     *
     * @param dataList
     */
    public static List<Map<String, Object>> clearZeroDocData(List<Map<String, Object>> dataList) {
        List<Map<String, Object>> resultList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(dataList)) {
            for (Map dataMap:dataList){
                if(!CollectionUtils.isEmpty((List<Map<String, Object>>) dataMap.get("docList"))
                        || !CollectionUtils.isEmpty((List<Map<String, Object>>) dataMap.get("allAttribute"))){
                    resultList.add(dataMap);
                }
            }

        }
        if (!CollectionUtils.isEmpty(resultList)) {
            resultList.stream().filter(map -> !CollectionUtils.isEmpty((List<Map<String, Object>>) map.get("allAttribute"))).forEach(filterMap -> {
                List<Map<String, Object>> memberList = (List<Map<String, Object>>) filterMap.get("allAttribute");
                memberList.forEach(member -> {
                    List<Map<String, Object>> memberDocList = (List<Map<String, Object>>) member.get("docList");
                    memberDocList.forEach(memberDoc -> {
                        memberDoc.put("dataType", memberDoc.get("data_type"));
                    });
                });
            });
        }
        return resultList;
    }
}
