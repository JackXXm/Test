package com.edip.entity;

import com.edip.utils.Message;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "data")
public class ComapnyResponse {
    private Message message;
    private Entbs entbs;

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public Entbs getEntbs() {
        return entbs;
    }

    public void setEntbs(Entbs entbs) {
        this.entbs = entbs;
    }

}
