package com.edip.service;

import java.util.List;
import java.util.Map;

public interface StampService {

    List<Map<String , Object>> queryStampList(Map<String , Object> params);

    Integer auditStamp(Map param);

    List<Map<String , Object>> queryStampDetail(String stampID);

    String getAddressName(Map<String , Object> params);

    List<Map<String , Object>> stampHistory(String stampID);

    void deleteCertAndStamp(Map param) throws Exception;

}