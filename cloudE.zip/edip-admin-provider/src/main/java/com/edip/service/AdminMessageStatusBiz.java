package com.edip.service;

import java.util.List;

import com.edip.entity.AdminMessagestatus;
import com.edip.entity.AdminMessagestatusExample;
import com.edip.vo.AdminMessagestatusVo;

/**
 * Created by qiaoxiaolong on 2017/6/4.
 */
public interface AdminMessageStatusBiz {
    List<AdminMessagestatusVo> selectByExample(AdminMessagestatusExample example);
    
    int insert(AdminMessagestatus record);
    
    int countIs(AdminMessagestatus record);

    int insert(AdminMessagestatusVo messagestatusVo);

    int insertIfNo(AdminMessagestatusVo messagestatusVo);
}
