package com.edip.dto.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
    /**
     * 获取两日期相差的天数
     *
     * @param bDate
     *            减数
     * @param sDate
     *            被减数
     * @return
     * @throws ParseException
     */
    public static long getDaysBetween(Date Date) {
        long between_days = 0;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd");
        try {
            Date d1 = sdf.parse(sdf.format(Date));
            Date d2 = sdf.parse(sdf.format(new Date()));
            long time1 = d1.getTime();
            long time2 = d2.getTime();
            between_days = (time1 - time2) / (1000 * 3600 * 24);
        } catch (ParseException e) {

        }
        return between_days;

    }

    public static Date transferStandardFormat(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.parse(dateString);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }

    }

    /**
     * 日期字符串 yyyy-MM-dd 转化为Date
     *
     * @param dateString
     * @return
     */
    public static Date trasnferDateFormat(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return sdf.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getDateString(Date date) {
        if (date == null) {
            return "";
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
    }

    public static String getStandardString(Date date){
        if (date == null) {
            return "";
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(date);
    }

}
