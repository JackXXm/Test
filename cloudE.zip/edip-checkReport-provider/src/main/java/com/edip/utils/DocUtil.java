package com.edip.utils;

import com.edip.dto.util.CacheKey;
import com.edip.dto.util.RedisUtilForDiy;

/**
 * @author lilin
 * @description doc工具类
 * @DATE 2019/1/10
 */
public class DocUtil {

    /**
     *
     * 获取doc类型的名称
     * @param
     * @return
     */
    public static String getDocTypeName(String docType){
        return RedisUtilForDiy.getMap(CacheKey.DIC).get(docType);
    }
}
