package com.edip.mapper;

import com.edip.entity.Exchangeitem;
import com.edip.entity.ExchangeitemExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface ExchangeitemMapper {
    long countByExample(ExchangeitemExample example);

    int deleteByExample(ExchangeitemExample example);

    int deleteByPrimaryKey(Integer itemid);

    int insert(Exchangeitem record);

    int insertSelective(Exchangeitem record);

    List<Exchangeitem> selectByExample(ExchangeitemExample example);

    Exchangeitem selectByPrimaryKey(Integer itemid);

    int updateByExampleSelective(@Param("record") Exchangeitem record, @Param("example") ExchangeitemExample example);

    int updateByExample(@Param("record") Exchangeitem record, @Param("example") ExchangeitemExample example);

    int updateByPrimaryKeySelective(Exchangeitem record);

    int updateByPrimaryKey(Exchangeitem record);
    List<Exchangeitem> selectByProjectID(@Param("projectId") Integer projectId);
    String getCompanyName(@Param("companyId") Integer companyId);
    String getAccountName(@Param("accountId") Integer accountId);
    List<Exchangeitem> getItems(Map<String, Object> args);
    String querySenderName(@Param("companyId") Integer companyId);
    void updateDocument(Map<String, Object> args);
}