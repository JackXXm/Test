package com.edip.controller;

import com.edip.dto.ServerResponse;
import com.edip.util.VersionConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping("/version")
public class VersionController {

    private static String VERSION;
    @Value("${VERSION}")
    public void setVERSION(String VERSION) {
        this.VERSION = VERSION;
    }

    @RequestMapping("/getVersion.ajax")
    @ResponseBody
    public ServerResponse getVersion() {
        return ServerResponse.createBySuccess(VERSION);
    }

}

