package com.edip.exception;
import com.edip.utils.StringUtils;

public class BaseException extends RuntimeException {
    private static final long serialVersionUID = -2758906151035670666L;
    private int statusCode;
    private String msg;
    private String errorCode;
    private static final String CODE_MSG_SEPARATOR = ",";
    private static final int RESULT_FAILT = 500;
    private static final String SYSTEM_ERROR_MSG = "系统错误异常";

    public int getStatusCode() {
        return this.statusCode;
    }

    public String getErrorMessage() {
        return this.msg;
    }

    public BaseException() {
        this.parseErrorStr("");
    }

    public BaseException(Throwable cause) {
        super(cause);
        this.parseErrorStr(cause.getMessage());
    }

    public BaseException(String message) {
        super(message);
        this.parseErrorStr(message);
    }

    public BaseException(int statusCode, String msg, String errorCode) {
        this.statusCode = statusCode;
        this.msg = msg;
        this.errorCode = errorCode;
    }

    public BaseException(int statusCode, String errorCode) {
        this.statusCode = statusCode;
        this.errorCode = errorCode;
    }

    public BaseException(String message, Throwable cause) {
        super(message, cause);
        this.parseErrorStr(message);
    }

    public BaseException(ResultCode resultCode) {
        this.statusCode = resultCode.getStatusCode();
        this.errorCode = resultCode.getErrorCode();
    }

    protected void parseErrorStr(String errorStr) {
        if (StringUtils.isBlank(errorStr)) {
            this.statusCode = 500;
            this.msg = "系统错误异常";
        } else {
            int index = errorStr.indexOf(",");
            if (index >= 0 && StringUtils.isNumeric(errorStr.substring(0, index))) {
                this.statusCode = Integer.parseInt(errorStr.substring(0, index));
                this.msg = errorStr.substring(index + 1);
            } else {
                this.statusCode = 500;
                this.msg = errorStr;
            }

        }
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
