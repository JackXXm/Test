package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class Product implements Serializable {
    /**
     * 产品ID
     */
    private Integer productid;

    /**
     * 参考dic的type:productType
     */
    private String protype;

    /**
     * 归属公司
     */
    private Integer compid;

    /**
     * 帐号ID
     */
    private Integer accountid;

    /**
     * 外部系统产品编码，比如商品码
     */
    private String extid;

    /**
     * 产品通用名
     */
    private String uniname;

    /**
     * 产品名称
     */
    private String name;

    /**
     * 产品图片
     */
    private String pictureurl;

    /**
     * 产品描述
     */
    private String productdesc;

    /**
     * 产品指导价格
     */
    private String unit;

    /**
     * 产品审核意见
     */
    private String auditinfo;

    /**
     * 创建时间
     */
    private Date createdate;

    /**
     * 更新时间
     */
    private Date lupdate;

    /**
     * 操作状态:
                                                                     0:新增
                                                                     1:修改
                                                                     2:删除
                                                                     
     */
    private Integer operstatus;

    /**
     * 状态  -1:逻辑删除0:正常1:待审批9:审批失败  8下线 10归档
     */
    private Integer status;

    /**
     * 剂型
     */
    private String dosageform;

    /**
     * 规格
     */
    private String specifications;

    /**
     * 数量单位
     */
    private String unitnoun;

    /**
     * 数量
     */
    private String amount;

    /**
     * 批准文号
     */
    private String approvalnum;

    /**
     * 生产厂商
     */
    private String manuf;

    /**
     * 线下合作公司名称
     */
    private String offlinecooperate;

    /**
     * 线下状态    1-线下    0-非线下
     */
    private Integer offline;

    private Date appliancesdate;

    private Date appliancesenddate;

    /**
     * 其他公司ID
     */
    private Integer cooperationcompid;

    /**
     * 保质期
     */
    private String expirationdate;

    /**
     * 产品编号
     */
    private String pronumber;

    /**
     * 是否是oportal集成过来的数据（或者是oportal修改了edipdb当前的数据）Y：是，N：否
     */
    private String isupload;

    /**
     * 创建人
     */
    private String createby;

    /**
     * 更新人
     */
    private String updateby;

    /**
     * 更新人ID
     */
    private Integer modifyaccountid;

    /**
     * 更新时间
     */
    private Date updatedate;

    private static final long serialVersionUID = 1L;

    public Integer getProductid() {
        return productid;
    }

    public void setProductid(Integer productid) {
        this.productid = productid;
    }

    public String getProtype() {
        return protype;
    }

    public void setProtype(String protype) {
        this.protype = protype;
    }

    public Integer getCompid() {
        return compid;
    }

    public void setCompid(Integer compid) {
        this.compid = compid;
    }

    public Integer getAccountid() {
        return accountid;
    }

    public void setAccountid(Integer accountid) {
        this.accountid = accountid;
    }

    public String getExtid() {
        return extid;
    }

    public void setExtid(String extid) {
        this.extid = extid;
    }

    public String getUniname() {
        return uniname;
    }

    public void setUniname(String uniname) {
        this.uniname = uniname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPictureurl() {
        return pictureurl;
    }

    public void setPictureurl(String pictureurl) {
        this.pictureurl = pictureurl;
    }

    public String getProductdesc() {
        return productdesc;
    }

    public void setProductdesc(String productdesc) {
        this.productdesc = productdesc;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getAuditinfo() {
        return auditinfo;
    }

    public void setAuditinfo(String auditinfo) {
        this.auditinfo = auditinfo;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getLupdate() {
        return lupdate;
    }

    public void setLupdate(Date lupdate) {
        this.lupdate = lupdate;
    }

    public Integer getOperstatus() {
        return operstatus;
    }

    public void setOperstatus(Integer operstatus) {
        this.operstatus = operstatus;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getDosageform() {
        return dosageform;
    }

    public void setDosageform(String dosageform) {
        this.dosageform = dosageform;
    }

    public String getSpecifications() {
        return specifications;
    }

    public void setSpecifications(String specifications) {
        this.specifications = specifications;
    }

    public String getUnitnoun() {
        return unitnoun;
    }

    public void setUnitnoun(String unitnoun) {
        this.unitnoun = unitnoun;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getApprovalnum() {
        return approvalnum;
    }

    public void setApprovalnum(String approvalnum) {
        this.approvalnum = approvalnum;
    }

    public String getManuf() {
        return manuf;
    }

    public void setManuf(String manuf) {
        this.manuf = manuf;
    }

    public String getOfflinecooperate() {
        return offlinecooperate;
    }

    public void setOfflinecooperate(String offlinecooperate) {
        this.offlinecooperate = offlinecooperate;
    }

    public Integer getOffline() {
        return offline;
    }

    public void setOffline(Integer offline) {
        this.offline = offline;
    }

    public Date getAppliancesdate() {
        return appliancesdate;
    }

    public void setAppliancesdate(Date appliancesdate) {
        this.appliancesdate = appliancesdate;
    }

    public Date getAppliancesenddate() {
        return appliancesenddate;
    }

    public void setAppliancesenddate(Date appliancesenddate) {
        this.appliancesenddate = appliancesenddate;
    }

    public Integer getCooperationcompid() {
        return cooperationcompid;
    }

    public void setCooperationcompid(Integer cooperationcompid) {
        this.cooperationcompid = cooperationcompid;
    }

    public String getExpirationdate() {
        return expirationdate;
    }

    public void setExpirationdate(String expirationdate) {
        this.expirationdate = expirationdate;
    }

    public String getPronumber() {
        return pronumber;
    }

    public void setPronumber(String pronumber) {
        this.pronumber = pronumber;
    }

    public String getIsupload() {
        return isupload;
    }

    public void setIsupload(String isupload) {
        this.isupload = isupload;
    }

    public String getCreateby() {
        return createby;
    }

    public void setCreateby(String createby) {
        this.createby = createby;
    }

    public String getUpdateby() {
        return updateby;
    }

    public void setUpdateby(String updateby) {
        this.updateby = updateby;
    }

    public Integer getModifyaccountid() {
        return modifyaccountid;
    }

    public void setModifyaccountid(Integer modifyaccountid) {
        this.modifyaccountid = modifyaccountid;
    }

    public Date getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(Date updatedate) {
        this.updatedate = updatedate;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Product other = (Product) that;
        return (this.getProductid() == null ? other.getProductid() == null : this.getProductid().equals(other.getProductid()))
            && (this.getProtype() == null ? other.getProtype() == null : this.getProtype().equals(other.getProtype()))
            && (this.getCompid() == null ? other.getCompid() == null : this.getCompid().equals(other.getCompid()))
            && (this.getAccountid() == null ? other.getAccountid() == null : this.getAccountid().equals(other.getAccountid()))
            && (this.getExtid() == null ? other.getExtid() == null : this.getExtid().equals(other.getExtid()))
            && (this.getUniname() == null ? other.getUniname() == null : this.getUniname().equals(other.getUniname()))
            && (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getPictureurl() == null ? other.getPictureurl() == null : this.getPictureurl().equals(other.getPictureurl()))
            && (this.getProductdesc() == null ? other.getProductdesc() == null : this.getProductdesc().equals(other.getProductdesc()))
            && (this.getUnit() == null ? other.getUnit() == null : this.getUnit().equals(other.getUnit()))
            && (this.getAuditinfo() == null ? other.getAuditinfo() == null : this.getAuditinfo().equals(other.getAuditinfo()))
            && (this.getCreatedate() == null ? other.getCreatedate() == null : this.getCreatedate().equals(other.getCreatedate()))
            && (this.getLupdate() == null ? other.getLupdate() == null : this.getLupdate().equals(other.getLupdate()))
            && (this.getOperstatus() == null ? other.getOperstatus() == null : this.getOperstatus().equals(other.getOperstatus()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getDosageform() == null ? other.getDosageform() == null : this.getDosageform().equals(other.getDosageform()))
            && (this.getSpecifications() == null ? other.getSpecifications() == null : this.getSpecifications().equals(other.getSpecifications()))
            && (this.getUnitnoun() == null ? other.getUnitnoun() == null : this.getUnitnoun().equals(other.getUnitnoun()))
            && (this.getAmount() == null ? other.getAmount() == null : this.getAmount().equals(other.getAmount()))
            && (this.getApprovalnum() == null ? other.getApprovalnum() == null : this.getApprovalnum().equals(other.getApprovalnum()))
            && (this.getManuf() == null ? other.getManuf() == null : this.getManuf().equals(other.getManuf()))
            && (this.getOfflinecooperate() == null ? other.getOfflinecooperate() == null : this.getOfflinecooperate().equals(other.getOfflinecooperate()))
            && (this.getOffline() == null ? other.getOffline() == null : this.getOffline().equals(other.getOffline()))
            && (this.getAppliancesdate() == null ? other.getAppliancesdate() == null : this.getAppliancesdate().equals(other.getAppliancesdate()))
            && (this.getAppliancesenddate() == null ? other.getAppliancesenddate() == null : this.getAppliancesenddate().equals(other.getAppliancesenddate()))
            && (this.getCooperationcompid() == null ? other.getCooperationcompid() == null : this.getCooperationcompid().equals(other.getCooperationcompid()))
            && (this.getExpirationdate() == null ? other.getExpirationdate() == null : this.getExpirationdate().equals(other.getExpirationdate()))
            && (this.getPronumber() == null ? other.getPronumber() == null : this.getPronumber().equals(other.getPronumber()))
            && (this.getIsupload() == null ? other.getIsupload() == null : this.getIsupload().equals(other.getIsupload()))
            && (this.getCreateby() == null ? other.getCreateby() == null : this.getCreateby().equals(other.getCreateby()))
            && (this.getUpdateby() == null ? other.getUpdateby() == null : this.getUpdateby().equals(other.getUpdateby()))
            && (this.getModifyaccountid() == null ? other.getModifyaccountid() == null : this.getModifyaccountid().equals(other.getModifyaccountid()))
            && (this.getUpdatedate() == null ? other.getUpdatedate() == null : this.getUpdatedate().equals(other.getUpdatedate()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getProductid() == null) ? 0 : getProductid().hashCode());
        result = prime * result + ((getProtype() == null) ? 0 : getProtype().hashCode());
        result = prime * result + ((getCompid() == null) ? 0 : getCompid().hashCode());
        result = prime * result + ((getAccountid() == null) ? 0 : getAccountid().hashCode());
        result = prime * result + ((getExtid() == null) ? 0 : getExtid().hashCode());
        result = prime * result + ((getUniname() == null) ? 0 : getUniname().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getPictureurl() == null) ? 0 : getPictureurl().hashCode());
        result = prime * result + ((getProductdesc() == null) ? 0 : getProductdesc().hashCode());
        result = prime * result + ((getUnit() == null) ? 0 : getUnit().hashCode());
        result = prime * result + ((getAuditinfo() == null) ? 0 : getAuditinfo().hashCode());
        result = prime * result + ((getCreatedate() == null) ? 0 : getCreatedate().hashCode());
        result = prime * result + ((getLupdate() == null) ? 0 : getLupdate().hashCode());
        result = prime * result + ((getOperstatus() == null) ? 0 : getOperstatus().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getDosageform() == null) ? 0 : getDosageform().hashCode());
        result = prime * result + ((getSpecifications() == null) ? 0 : getSpecifications().hashCode());
        result = prime * result + ((getUnitnoun() == null) ? 0 : getUnitnoun().hashCode());
        result = prime * result + ((getAmount() == null) ? 0 : getAmount().hashCode());
        result = prime * result + ((getApprovalnum() == null) ? 0 : getApprovalnum().hashCode());
        result = prime * result + ((getManuf() == null) ? 0 : getManuf().hashCode());
        result = prime * result + ((getOfflinecooperate() == null) ? 0 : getOfflinecooperate().hashCode());
        result = prime * result + ((getOffline() == null) ? 0 : getOffline().hashCode());
        result = prime * result + ((getAppliancesdate() == null) ? 0 : getAppliancesdate().hashCode());
        result = prime * result + ((getAppliancesenddate() == null) ? 0 : getAppliancesenddate().hashCode());
        result = prime * result + ((getCooperationcompid() == null) ? 0 : getCooperationcompid().hashCode());
        result = prime * result + ((getExpirationdate() == null) ? 0 : getExpirationdate().hashCode());
        result = prime * result + ((getPronumber() == null) ? 0 : getPronumber().hashCode());
        result = prime * result + ((getIsupload() == null) ? 0 : getIsupload().hashCode());
        result = prime * result + ((getCreateby() == null) ? 0 : getCreateby().hashCode());
        result = prime * result + ((getUpdateby() == null) ? 0 : getUpdateby().hashCode());
        result = prime * result + ((getModifyaccountid() == null) ? 0 : getModifyaccountid().hashCode());
        result = prime * result + ((getUpdatedate() == null) ? 0 : getUpdatedate().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", productid=").append(productid);
        sb.append(", protype=").append(protype);
        sb.append(", compid=").append(compid);
        sb.append(", accountid=").append(accountid);
        sb.append(", extid=").append(extid);
        sb.append(", uniname=").append(uniname);
        sb.append(", name=").append(name);
        sb.append(", pictureurl=").append(pictureurl);
        sb.append(", productdesc=").append(productdesc);
        sb.append(", unit=").append(unit);
        sb.append(", auditinfo=").append(auditinfo);
        sb.append(", createdate=").append(createdate);
        sb.append(", lupdate=").append(lupdate);
        sb.append(", operstatus=").append(operstatus);
        sb.append(", status=").append(status);
        sb.append(", dosageform=").append(dosageform);
        sb.append(", specifications=").append(specifications);
        sb.append(", unitnoun=").append(unitnoun);
        sb.append(", amount=").append(amount);
        sb.append(", approvalnum=").append(approvalnum);
        sb.append(", manuf=").append(manuf);
        sb.append(", offlinecooperate=").append(offlinecooperate);
        sb.append(", offline=").append(offline);
        sb.append(", appliancesdate=").append(appliancesdate);
        sb.append(", appliancesenddate=").append(appliancesenddate);
        sb.append(", cooperationcompid=").append(cooperationcompid);
        sb.append(", expirationdate=").append(expirationdate);
        sb.append(", pronumber=").append(pronumber);
        sb.append(", isupload=").append(isupload);
        sb.append(", createby=").append(createby);
        sb.append(", updateby=").append(updateby);
        sb.append(", modifyaccountid=").append(modifyaccountid);
        sb.append(", updatedate=").append(updatedate);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}