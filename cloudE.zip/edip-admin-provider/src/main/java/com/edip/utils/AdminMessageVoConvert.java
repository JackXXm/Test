package com.edip.utils;

import java.util.List;

import com.edip.entity.AdminMessage;
import com.edip.vo.AdminMessageVo;
import com.google.common.collect.Lists;

/**
 * Created by qiaoxiaolong on 2017/5/9.
 */
public class AdminMessageVoConvert {
    private AdminMessageVoConvert() {

    }

    public static final AdminMessageVo convert(AdminMessage message) {
        if (null == message) {
            return null;
        }
        AdminMessageVo messageVo = new AdminMessageVo();
        messageVo.setMsgID(message.getMsgID());
        messageVo.setMsgType(message.getMsgType());
        messageVo.setDataID(message.getDataID());
        messageVo.setDataType(message.getDataType());
        messageVo.setAccountID(message.getAccountID());
        messageVo.setCompID(message.getCompID());
        messageVo.setReceiveID(message.getReceiveID());
        messageVo.setReceiveCompID(message.getReceiveCompID());
        messageVo.setSender(message.getSender());
        messageVo.setTitle(message.getTitle());
        messageVo.setUrl(message.getUrl());
        messageVo.setStatus(message.getStatus());
        messageVo.setCreateDate(message.getCreateDate());
        messageVo.setValidDay(message.getValidDay());
        messageVo.setLupDate(message.getLupDate());
        messageVo.setContent(message.getContent());
        messageVo.setPage(message.getPage());
        messageVo.setRows(message.getRows());
        messageVo.setFrom(message.getFrom());
        messageVo.setTo(message.getTo());
        messageVo.setSendTime(message.getSendTime());
        messageVo.setCreateBy(message.getCreateBy());
        messageVo.setClassify(message.getClassify());
        
        return messageVo;
    }

    public static final List<AdminMessageVo> convert(List<AdminMessage> listMessage) {
        if (listMessage == null) {
            return Lists.newArrayList();
        }
        List<AdminMessageVo> listMessageVo = Lists.newArrayList();
        for (AdminMessage message : listMessage) {
            listMessageVo.add(AdminMessageVoConvert.convert(message));
        }
        return listMessageVo;
    }
}
