package com.edip.mapper;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface RechargeMapper {
    //充值列表
    List<Map<String , Object>> queryBillList(@Param("compID") Integer compID);

    //顶部显示
    List<Map<String , Object>> queryBillAmount(@Param("compID") Integer compID);

    //充值优惠
    List<Map<String , Object>> queryBenefit(@Param("compID") Integer compID);

    //查交换记录
    List<Map<String , Object>> querySendList(@Param("compID") Integer compID);


}