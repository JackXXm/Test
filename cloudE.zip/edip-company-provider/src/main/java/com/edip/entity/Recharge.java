package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class Recharge implements Serializable {
    /**
     * 充值ID
     */
    private Integer rechargeid;

    /**
     * 归属公司
     */
    private Integer compid;

    /**
     * 付款账户
     */
    private String billaccount;

    /**
     * 付费金额
     */
    private Float billnum;

    /**
     * 管理端帐号ID
     */
    private Integer operid;

    /**
     * 计费策略ID
     */
    private Integer modeid;

    /**
     * 创建时间
     */
    private Date createdate;

    /**
     * 备注
     */
    private String note;

    /**
     * 赠送金额
     */
    private Float givenum;

    /**
     * 充值时间
     */
    private Date chargeDate;

    /**
     * 赠送天数
     */
    private Integer giveDate;

    /**
     * 免费开始时间
     * @return
     */
    private Date startTime;

    /**
     * 免费结束时间
     * @return
     */
    private Date endTime;

    /**
     * 赠送类型
     */
    private Integer benefitType;

    public Integer getBenefitType() {
        return benefitType;
    }

    public void setBenefitType(Integer benefitType) {
        this.benefitType = benefitType;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getGiveDate() {
        return giveDate;
    }

    public void setGiveDate(Integer giveDate) {
        this.giveDate = giveDate;
    }

    private static final long serialVersionUID = 1L;

    public Integer getRechargeid() {
        return rechargeid;
    }

    public void setRechargeid(Integer rechargeid) {
        this.rechargeid = rechargeid;
    }

    public Integer getCompid() {
        return compid;
    }

    public void setCompid(Integer compid) {
        this.compid = compid;
    }

    public String getBillaccount() {
        return billaccount;
    }

    public void setBillaccount(String billaccount) {
        this.billaccount = billaccount;
    }

    public Float getBillnum() {
        return billnum;
    }

    public void setBillnum(Float billnum) {
        this.billnum = billnum;
    }

    public Integer getOperid() {
        return operid;
    }

    public void setOperid(Integer operid) {
        this.operid = operid;
    }

    public Integer getModeid() {
        return modeid;
    }

    public void setModeid(Integer modeid) {
        this.modeid = modeid;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Float getGivenum() {
        return givenum;
    }

    public void setGivenum(Float givenum) {
        this.givenum = givenum;
    }

    public Date getChargeDate() {
        return chargeDate;
    }

    public void setChargeDate(Date chargeDate) {
        this.chargeDate = chargeDate;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Recharge other = (Recharge) that;
        return (this.getRechargeid() == null ? other.getRechargeid() == null : this.getRechargeid().equals(other.getRechargeid()))
            && (this.getCompid() == null ? other.getCompid() == null : this.getCompid().equals(other.getCompid()))
            && (this.getBillaccount() == null ? other.getBillaccount() == null : this.getBillaccount().equals(other.getBillaccount()))
            && (this.getBillnum() == null ? other.getBillnum() == null : this.getBillnum().equals(other.getBillnum()))
            && (this.getOperid() == null ? other.getOperid() == null : this.getOperid().equals(other.getOperid()))
            && (this.getModeid() == null ? other.getModeid() == null : this.getModeid().equals(other.getModeid()))
            && (this.getCreatedate() == null ? other.getCreatedate() == null : this.getCreatedate().equals(other.getCreatedate()))
            && (this.getNote() == null ? other.getNote() == null : this.getNote().equals(other.getNote()))
            && (this.getGivenum() == null ? other.getGivenum() == null : this.getGivenum().equals(other.getGivenum()))
            && (this.getChargeDate() == null ? other.getChargeDate() == null : this.getChargeDate().equals(other.getChargeDate()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getRechargeid() == null) ? 0 : getRechargeid().hashCode());
        result = prime * result + ((getCompid() == null) ? 0 : getCompid().hashCode());
        result = prime * result + ((getBillaccount() == null) ? 0 : getBillaccount().hashCode());
        result = prime * result + ((getBillnum() == null) ? 0 : getBillnum().hashCode());
        result = prime * result + ((getOperid() == null) ? 0 : getOperid().hashCode());
        result = prime * result + ((getModeid() == null) ? 0 : getModeid().hashCode());
        result = prime * result + ((getCreatedate() == null) ? 0 : getCreatedate().hashCode());
        result = prime * result + ((getNote() == null) ? 0 : getNote().hashCode());
        result = prime * result + ((getGivenum() == null) ? 0 : getGivenum().hashCode());
        result = prime * result + ((getChargeDate() == null) ? 0 : getChargeDate().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", rechargeid=").append(rechargeid);
        sb.append(", compid=").append(compid);
        sb.append(", billaccount=").append(billaccount);
        sb.append(", billnum=").append(billnum);
        sb.append(", operid=").append(operid);
        sb.append(", modeid=").append(modeid);
        sb.append(", createdate=").append(createdate);
        sb.append(", note=").append(note);
        sb.append(", givenum=").append(givenum);
        sb.append(", chargeDate=").append(chargeDate);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}