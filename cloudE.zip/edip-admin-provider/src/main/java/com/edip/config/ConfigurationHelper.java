package com.edip.config;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.apache.commons.configuration.reloading.ReloadingStrategy;
import org.apache.log4j.Logger;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

public final class ConfigurationHelper {
    private static final Logger logger = Logger.getLogger(ConfigurationHelper.class);
    private static final String XML = ".xml";
    private static final String PROPERTIES = ".properties";
    private static final String HTTP = "HTTP://";
    private static String basePath = null;
    private static String deployBasePath = null;

    private ConfigurationHelper() {
    }

    public static void setBasePath(String basePath) {
        basePath = basePath;
    }

    public static String getBasePath() {
        return basePath == null ? System.getProperty("user.dir") + "/config" : basePath;
    }

    public static InputStream readConfiguration(String configurationFileName) {
        String fileName = getFullFileName(configurationFileName);
        return readBaseConfiguration(fileName);
    }

    private static InputStream readBaseConfiguration(String fileName) {
        if (fileName == null) {
            return null;
        } else {
            boolean isUrl = isUrlFile(fileName);
            if (isUrl) {
                try {
                    URL url = new URL(fileName);
                    return url.openStream();
                } catch (MalformedURLException var4) {
                    logger.error("打开URL配置文件失败，URL=" + fileName, var4);
                } catch (IOException var5) {
                    logger.error("打开URL配置文件失败，URL=" + fileName, var5);
                }

                return null;
            } else {
                try {
                    File file = new File(fileName);
                    FileInputStream fileInputStream = new FileInputStream(file);
                    return fileInputStream;
                } catch (FileNotFoundException var6) {
                    logger.error("打开配置文件失败，filename=" + fileName, var6);
                    return null;
                }
            }
        }
    }

    public static Configuration getConfiguration(String configurationFileName) {
        return getConfiguration(configurationFileName, 0L, false);
    }

    public static Configuration getConfiguration(String configurationFileName, long refreshDelay) {
        return getConfiguration(configurationFileName, refreshDelay, false);
    }

    public static Configuration getConfiguration(String configurationFileName, long refreshDelay, boolean delimiterParsingDisabled) {
        String fileName = getFullFileName(configurationFileName);
        return getBaseConfiguration(fileName, refreshDelay, delimiterParsingDisabled);
    }

    private static Configuration getBaseConfiguration(String fileName, long refreshDelay, boolean delimiterParsingDisabled) {
        if (fileName == null) {
            return null;
        } else {
            boolean isXmlFile = false;
            if (fileName.endsWith(".xml")) {
                isXmlFile = true;
            } else {
                if (!fileName.endsWith(".properties")) {
                    return null;
                }

                isXmlFile = false;
            }

            boolean isUrl = isUrlFile(fileName);
            if (isXmlFile) {
                XMLConfiguration xmlConfiguration = new XMLConfiguration();
                xmlConfiguration.setDelimiterParsingDisabled(delimiterParsingDisabled);
                if (isUrl) {
                    try {
                        xmlConfiguration.load(new URL(fileName));
                    } catch (ConfigurationException var9) {
                        logger.error("打开URL配置文件失败，URL=" + fileName, var9);
                        return null;
                    } catch (MalformedURLException var10) {
                        logger.error("打开URL配置文件失败，URL=" + fileName, var10);
                        return null;
                    }
                } else {
                    try {
                        xmlConfiguration.load(fileName);
                    } catch (ConfigurationException var8) {
                        logger.error("打开配置文件失败，filename=" + fileName, var8);
                        return null;
                    }
                }

                if (refreshDelay > 0L) {
                    FileChangedReloadingStrategy fileChangedReloadingStrategy = new FileChangedReloadingStrategy();
                    fileChangedReloadingStrategy.setConfiguration(xmlConfiguration);
                    fileChangedReloadingStrategy.setRefreshDelay(refreshDelay);
                    xmlConfiguration.setReloadingStrategy(fileChangedReloadingStrategy);
                }

                return xmlConfiguration;
            } else {
                PropertiesConfiguration propertiesConfiguration = new PropertiesConfiguration();
                propertiesConfiguration.setDelimiterParsingDisabled(delimiterParsingDisabled);
                if (isUrl) {
                    try {
                        propertiesConfiguration.load(new URL(fileName));
                    } catch (ConfigurationException var12) {
                        logger.error("打开URL配置文件失败，URL=" + fileName, var12);
                        return null;
                    } catch (MalformedURLException var13) {
                        logger.error("打开URL配置文件失败，URL=" + fileName, var13);
                        return null;
                    }
                } else {
                    try {
                        propertiesConfiguration.load(fileName);
                    } catch (ConfigurationException var11) {
                        logger.error("打开配置文件失败，filename=" + fileName, var11);
                        return null;
                    }
                }

                if (refreshDelay > 0L) {
                    FileChangedReloadingStrategy reloadingStrategy = null;
                    if (isUrl) {
                        reloadingStrategy = new RemoteFileChangedReloadingStrategy();
                    } else {
                        reloadingStrategy = new FileChangedReloadingStrategy();
                    }

                    ((FileChangedReloadingStrategy)reloadingStrategy).setConfiguration(propertiesConfiguration);
                    ((FileChangedReloadingStrategy)reloadingStrategy).setRefreshDelay(refreshDelay);
                    propertiesConfiguration.setReloadingStrategy((ReloadingStrategy)reloadingStrategy);
                }

                return propertiesConfiguration;
            }
        }
    }

    public static void setDeployBasePath(String deployBasePath) {
        deployBasePath = deployBasePath;
    }

    public static String getDeployBasePath() {
        return deployBasePath == null ? System.getProperty("user.dir") : deployBasePath;
    }

    public static InputStream readDeployConfiguration(String configurationFileName) {
        String fileName = getDeployFullFileName(configurationFileName);
        return readBaseConfiguration(fileName);
    }

    public static Configuration getDeployConfiguration(String configurationFileName) {
        return getDeployConfiguration(configurationFileName, 0L, false);
    }

    public static Configuration getDeployConfiguration(String configurationFileName, long refreshDelay) {
        return getDeployConfiguration(configurationFileName, refreshDelay, false);
    }

    public static Configuration getDeployConfiguration(String configurationFileName, long refreshDelay, boolean delimiterParsingDisabled) {
        String fileName = getDeployFullFileName(configurationFileName);
        return getBaseConfiguration(fileName, refreshDelay, delimiterParsingDisabled);
    }

    public static String getFullFileName(String fileName) {
        if (fileName == null) {
            return null;
        } else {
            return getBasePath() != null ? getBasePath() + File.separator + fileName : fileName;
        }
    }

    public static String getDeployFullFileName(String fileName) {
        if (fileName == null) {
            return null;
        } else {
            return deployBasePath != null ? deployBasePath + File.separator + fileName : fileName;
        }
    }

    private static boolean isUrlFile(String fileName) {
        return fileName.toUpperCase().startsWith("HTTP://");
    }
}
