package com.edip.entity;

import java.util.Date;
import java.util.List;

/**
 * @author Administrator
 * @description TODO
 * @DATE 2019/1/23 0023 15:23
 */
public class ProductInfoVo {
    /**
     * 主键
     */
    private Integer id;

    /**
     * 产品id
     */
    private Integer productId;

    /**
     * 归属公司
     */
    private Integer compId;

    /**
     * 企业信息id
     */
    private Integer companyInfoId;

    /**
     * 创建人id
     */
    private Integer createAccountId;

    /**
     * 状态 0:正常1:待审批9:审批失败  8下线 10归档
     */
    private Integer status;

    /**
     * 线下合作公司名称
     */
    private String offlineCooperate;

    /**
     * 1-线下    0-非线下
     */
    private Integer offlineType;

    /**
     * 供应商公司ID
     */
    private Integer cooperationCompId;

    /**
     * 生产厂商
     */
    private String manuf;

    /**
     * 生产厂商id
     */
    private Integer manufId;

    /**
     * 保质期
     */
    private String expirationDate;

    /**
     * 归档文件数
     */
    private Integer documentNumber;

    /**
     * 文档资质总数
     */
    private Integer documentTotal;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 修改人id
     */
    private Integer updateAccountId;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 逻辑删除
     */
    private Integer deleteFlag;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 合并id
     */
    private Integer withId;

    /**
     * 0:本地上传1:在线接收
     */
    private Integer informationFrom;

    /**
     * 产地
     */
    private String place;

    /**
     * 执行标准
     */
    private String operativeNorm;

    /**
     * 单位
     */
    private String unit;

    /**
     * 产品编号
     */
    private String proNumber;

    /**
     * 产品指导价格
     */
    private String proGuidancePrice;

    /**
     * 批准日期
     */
    private Date appliancesDate;

    /**
     * 批准到期
     */
    private Date appliancesEndDate;

    /**
     * 流转码
     */
    private String exchangeCode;

    /**
     * 主题id
     */
    private Integer projectId;
    /**
     * 产品资质
     */
    private List<ProductInfoDocument> productInfoDocumentList;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getCompId() {
        return compId;
    }

    public void setCompId(Integer compId) {
        this.compId = compId;
    }

    public Integer getCompanyInfoId() {
        return companyInfoId;
    }

    public void setCompanyInfoId(Integer companyInfoId) {
        this.companyInfoId = companyInfoId;
    }

    public Integer getCreateAccountId() {
        return createAccountId;
    }

    public void setCreateAccountId(Integer createAccountId) {
        this.createAccountId = createAccountId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getOfflineCooperate() {
        return offlineCooperate;
    }

    public void setOfflineCooperate(String offlineCooperate) {
        this.offlineCooperate = offlineCooperate;
    }

    public Integer getOfflineType() {
        return offlineType;
    }

    public void setOfflineType(Integer offlineType) {
        this.offlineType = offlineType;
    }

    public Integer getCooperationCompId() {
        return cooperationCompId;
    }

    public void setCooperationCompId(Integer cooperationCompId) {
        this.cooperationCompId = cooperationCompId;
    }

    public String getManuf() {
        return manuf;
    }

    public void setManuf(String manuf) {
        this.manuf = manuf;
    }

    public Integer getManufId() {
        return manufId;
    }

    public void setManufId(Integer manufId) {
        this.manufId = manufId;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Integer getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(Integer documentNumber) {
        this.documentNumber = documentNumber;
    }

    public Integer getDocumentTotal() {
        return documentTotal;
    }

    public void setDocumentTotal(Integer documentTotal) {
        this.documentTotal = documentTotal;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateAccountId() {
        return updateAccountId;
    }

    public void setUpdateAccountId(Integer updateAccountId) {
        this.updateAccountId = updateAccountId;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Integer getWithId() {
        return withId;
    }

    public void setWithId(Integer withId) {
        this.withId = withId;
    }

    public Integer getInformationFrom() {
        return informationFrom;
    }

    public void setInformationFrom(Integer informationFrom) {
        this.informationFrom = informationFrom;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getOperativeNorm() {
        return operativeNorm;
    }

    public void setOperativeNorm(String operativeNorm) {
        this.operativeNorm = operativeNorm;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getProNumber() {
        return proNumber;
    }

    public void setProNumber(String proNumber) {
        this.proNumber = proNumber;
    }

    public String getProGuidancePrice() {
        return proGuidancePrice;
    }

    public void setProGuidancePrice(String proGuidancePrice) {
        this.proGuidancePrice = proGuidancePrice;
    }

    public Date getAppliancesDate() {
        return appliancesDate;
    }

    public void setAppliancesDate(Date appliancesDate) {
        this.appliancesDate = appliancesDate;
    }

    public Date getAppliancesEndDate() {
        return appliancesEndDate;
    }

    public void setAppliancesEndDate(Date appliancesEndDate) {
        this.appliancesEndDate = appliancesEndDate;
    }

    public String getExchangeCode() {
        return exchangeCode;
    }

    public void setExchangeCode(String exchangeCode) {
        this.exchangeCode = exchangeCode;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public List<ProductInfoDocument> getProductInfoDocumentList() {
        return productInfoDocumentList;
    }

    public void setProductInfoDocumentList(List<ProductInfoDocument> productInfoDocumentList) {
        this.productInfoDocumentList = productInfoDocumentList;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        ProductInfo other = (ProductInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
                && (this.getProductId() == null ? other.getProductId() == null : this.getProductId().equals(other.getProductId()))
                && (this.getCompId() == null ? other.getCompId() == null : this.getCompId().equals(other.getCompId()))
                && (this.getCompanyInfoId() == null ? other.getCompanyInfoId() == null : this.getCompanyInfoId().equals(other.getCompanyInfoId()))
                && (this.getCreateAccountId() == null ? other.getCreateAccountId() == null : this.getCreateAccountId().equals(other.getCreateAccountId()))
                && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
                && (this.getOfflineCooperate() == null ? other.getOfflineCooperate() == null : this.getOfflineCooperate().equals(other.getOfflineCooperate()))
                && (this.getOfflineType() == null ? other.getOfflineType() == null : this.getOfflineType().equals(other.getOfflineType()))
                && (this.getCooperationCompId() == null ? other.getCooperationCompId() == null : this.getCooperationCompId().equals(other.getCooperationCompId()))
                && (this.getManuf() == null ? other.getManuf() == null : this.getManuf().equals(other.getManuf()))
                && (this.getManufId() == null ? other.getManufId() == null : this.getManufId().equals(other.getManufId()))
                && (this.getExpirationDate() == null ? other.getExpirationDate() == null : this.getExpirationDate().equals(other.getExpirationDate()))
                && (this.getDocumentNumber() == null ? other.getDocumentNumber() == null : this.getDocumentNumber().equals(other.getDocumentNumber()))
                && (this.getDocumentTotal() == null ? other.getDocumentTotal() == null : this.getDocumentTotal().equals(other.getDocumentTotal()))
                && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
                && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
                && (this.getUpdateAccountId() == null ? other.getUpdateAccountId() == null : this.getUpdateAccountId().equals(other.getUpdateAccountId()))
                && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
                && (this.getDeleteFlag() == null ? other.getDeleteFlag() == null : this.getDeleteFlag().equals(other.getDeleteFlag()))
                && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
                && (this.getWithId() == null ? other.getWithId() == null : this.getWithId().equals(other.getWithId()))
                && (this.getInformationFrom() == null ? other.getInformationFrom() == null : this.getInformationFrom().equals(other.getInformationFrom()))
                && (this.getPlace() == null ? other.getPlace() == null : this.getPlace().equals(other.getPlace()))
                && (this.getOperativeNorm() == null ? other.getOperativeNorm() == null : this.getOperativeNorm().equals(other.getOperativeNorm()))
                && (this.getUnit() == null ? other.getUnit() == null : this.getUnit().equals(other.getUnit()))
                && (this.getProNumber() == null ? other.getProNumber() == null : this.getProNumber().equals(other.getProNumber()))
                && (this.getProGuidancePrice() == null ? other.getProGuidancePrice() == null : this.getProGuidancePrice().equals(other.getProGuidancePrice()))
                && (this.getAppliancesDate() == null ? other.getAppliancesDate() == null : this.getAppliancesDate().equals(other.getAppliancesDate()))
                && (this.getAppliancesEndDate() == null ? other.getAppliancesEndDate() == null : this.getAppliancesEndDate().equals(other.getAppliancesEndDate()))
                && (this.getExchangeCode() == null ? other.getExchangeCode() == null : this.getExchangeCode().equals(other.getExchangeCode()))
                && (this.getProjectId() == null ? other.getProjectId() == null : this.getProjectId().equals(other.getProjectId()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getProductId() == null) ? 0 : getProductId().hashCode());
        result = prime * result + ((getCompId() == null) ? 0 : getCompId().hashCode());
        result = prime * result + ((getCompanyInfoId() == null) ? 0 : getCompanyInfoId().hashCode());
        result = prime * result + ((getCreateAccountId() == null) ? 0 : getCreateAccountId().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getOfflineCooperate() == null) ? 0 : getOfflineCooperate().hashCode());
        result = prime * result + ((getOfflineType() == null) ? 0 : getOfflineType().hashCode());
        result = prime * result + ((getCooperationCompId() == null) ? 0 : getCooperationCompId().hashCode());
        result = prime * result + ((getManuf() == null) ? 0 : getManuf().hashCode());
        result = prime * result + ((getManufId() == null) ? 0 : getManufId().hashCode());
        result = prime * result + ((getExpirationDate() == null) ? 0 : getExpirationDate().hashCode());
        result = prime * result + ((getDocumentNumber() == null) ? 0 : getDocumentNumber().hashCode());
        result = prime * result + ((getDocumentTotal() == null) ? 0 : getDocumentTotal().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getUpdateAccountId() == null) ? 0 : getUpdateAccountId().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getDeleteFlag() == null) ? 0 : getDeleteFlag().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getWithId() == null) ? 0 : getWithId().hashCode());
        result = prime * result + ((getInformationFrom() == null) ? 0 : getInformationFrom().hashCode());
        result = prime * result + ((getPlace() == null) ? 0 : getPlace().hashCode());
        result = prime * result + ((getOperativeNorm() == null) ? 0 : getOperativeNorm().hashCode());
        result = prime * result + ((getUnit() == null) ? 0 : getUnit().hashCode());
        result = prime * result + ((getProNumber() == null) ? 0 : getProNumber().hashCode());
        result = prime * result + ((getProGuidancePrice() == null) ? 0 : getProGuidancePrice().hashCode());
        result = prime * result + ((getAppliancesDate() == null) ? 0 : getAppliancesDate().hashCode());
        result = prime * result + ((getAppliancesEndDate() == null) ? 0 : getAppliancesEndDate().hashCode());
        result = prime * result + ((getExchangeCode() == null) ? 0 : getExchangeCode().hashCode());
        result = prime * result + ((getProjectId() == null) ? 0 : getProjectId().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", productId=").append(productId);
        sb.append(", compId=").append(compId);
        sb.append(", companyInfoId=").append(companyInfoId);
        sb.append(", createAccountId=").append(createAccountId);
        sb.append(", status=").append(status);
        sb.append(", offlineCooperate=").append(offlineCooperate);
        sb.append(", offlineType=").append(offlineType);
        sb.append(", cooperationCompId=").append(cooperationCompId);
        sb.append(", manuf=").append(manuf);
        sb.append(", manufId=").append(manufId);
        sb.append(", expirationDate=").append(expirationDate);
        sb.append(", documentNumber=").append(documentNumber);
        sb.append(", documentTotal=").append(documentTotal);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateAccountId=").append(updateAccountId);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", deleteFlag=").append(deleteFlag);
        sb.append(", createBy=").append(createBy);
        sb.append(", withId=").append(withId);
        sb.append(", informationFrom=").append(informationFrom);
        sb.append(", place=").append(place);
        sb.append(", operativeNorm=").append(operativeNorm);
        sb.append(", unit=").append(unit);
        sb.append(", proNumber=").append(proNumber);
        sb.append(", proGuidancePrice=").append(proGuidancePrice);
        sb.append(", appliancesDate=").append(appliancesDate);
        sb.append(", appliancesEndDate=").append(appliancesEndDate);
        sb.append(", exchangeCode=").append(exchangeCode);
        sb.append(", projectId=").append(projectId);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}
