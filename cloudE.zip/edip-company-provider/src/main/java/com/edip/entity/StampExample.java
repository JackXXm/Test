package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class StampExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public StampExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andStampidIsNull() {
            addCriterion("stampID is null");
            return (Criteria) this;
        }

        public Criteria andStampidIsNotNull() {
            addCriterion("stampID is not null");
            return (Criteria) this;
        }

        public Criteria andStampidEqualTo(Integer value) {
            addCriterion("stampID =", value, "stampid");
            return (Criteria) this;
        }

        public Criteria andStampidNotEqualTo(Integer value) {
            addCriterion("stampID <>", value, "stampid");
            return (Criteria) this;
        }

        public Criteria andStampidGreaterThan(Integer value) {
            addCriterion("stampID >", value, "stampid");
            return (Criteria) this;
        }

        public Criteria andStampidGreaterThanOrEqualTo(Integer value) {
            addCriterion("stampID >=", value, "stampid");
            return (Criteria) this;
        }

        public Criteria andStampidLessThan(Integer value) {
            addCriterion("stampID <", value, "stampid");
            return (Criteria) this;
        }

        public Criteria andStampidLessThanOrEqualTo(Integer value) {
            addCriterion("stampID <=", value, "stampid");
            return (Criteria) this;
        }

        public Criteria andStampidIn(List<Integer> values) {
            addCriterion("stampID in", values, "stampid");
            return (Criteria) this;
        }

        public Criteria andStampidNotIn(List<Integer> values) {
            addCriterion("stampID not in", values, "stampid");
            return (Criteria) this;
        }

        public Criteria andStampidBetween(Integer value1, Integer value2) {
            addCriterion("stampID between", value1, value2, "stampid");
            return (Criteria) this;
        }

        public Criteria andStampidNotBetween(Integer value1, Integer value2) {
            addCriterion("stampID not between", value1, value2, "stampid");
            return (Criteria) this;
        }

        public Criteria andStampnameIsNull() {
            addCriterion("stampName is null");
            return (Criteria) this;
        }

        public Criteria andStampnameIsNotNull() {
            addCriterion("stampName is not null");
            return (Criteria) this;
        }

        public Criteria andStampnameEqualTo(String value) {
            addCriterion("stampName =", value, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameNotEqualTo(String value) {
            addCriterion("stampName <>", value, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameGreaterThan(String value) {
            addCriterion("stampName >", value, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameGreaterThanOrEqualTo(String value) {
            addCriterion("stampName >=", value, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameLessThan(String value) {
            addCriterion("stampName <", value, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameLessThanOrEqualTo(String value) {
            addCriterion("stampName <=", value, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameLike(String value) {
            addCriterion("stampName like", value, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameNotLike(String value) {
            addCriterion("stampName not like", value, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameIn(List<String> values) {
            addCriterion("stampName in", values, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameNotIn(List<String> values) {
            addCriterion("stampName not in", values, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameBetween(String value1, String value2) {
            addCriterion("stampName between", value1, value2, "stampname");
            return (Criteria) this;
        }

        public Criteria andStampnameNotBetween(String value1, String value2) {
            addCriterion("stampName not between", value1, value2, "stampname");
            return (Criteria) this;
        }

        public Criteria andStamptypeIsNull() {
            addCriterion("stampType is null");
            return (Criteria) this;
        }

        public Criteria andStamptypeIsNotNull() {
            addCriterion("stampType is not null");
            return (Criteria) this;
        }

        public Criteria andStamptypeEqualTo(String value) {
            addCriterion("stampType =", value, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeNotEqualTo(String value) {
            addCriterion("stampType <>", value, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeGreaterThan(String value) {
            addCriterion("stampType >", value, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeGreaterThanOrEqualTo(String value) {
            addCriterion("stampType >=", value, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeLessThan(String value) {
            addCriterion("stampType <", value, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeLessThanOrEqualTo(String value) {
            addCriterion("stampType <=", value, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeLike(String value) {
            addCriterion("stampType like", value, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeNotLike(String value) {
            addCriterion("stampType not like", value, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeIn(List<String> values) {
            addCriterion("stampType in", values, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeNotIn(List<String> values) {
            addCriterion("stampType not in", values, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeBetween(String value1, String value2) {
            addCriterion("stampType between", value1, value2, "stamptype");
            return (Criteria) this;
        }

        public Criteria andStamptypeNotBetween(String value1, String value2) {
            addCriterion("stampType not between", value1, value2, "stamptype");
            return (Criteria) this;
        }

        public Criteria andCompidIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompidIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompidEqualTo(Integer value) {
            addCriterion("compID =", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThan(Integer value) {
            addCriterion("compID >", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThan(Integer value) {
            addCriterion("compID <", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidIn(List<Integer> values) {
            addCriterion("compID in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNull() {
            addCriterion("accountID is null");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNotNull() {
            addCriterion("accountID is not null");
            return (Criteria) this;
        }

        public Criteria andAccountidEqualTo(Integer value) {
            addCriterion("accountID =", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotEqualTo(Integer value) {
            addCriterion("accountID <>", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThan(Integer value) {
            addCriterion("accountID >", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThanOrEqualTo(Integer value) {
            addCriterion("accountID >=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThan(Integer value) {
            addCriterion("accountID <", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThanOrEqualTo(Integer value) {
            addCriterion("accountID <=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidIn(List<Integer> values) {
            addCriterion("accountID in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotIn(List<Integer> values) {
            addCriterion("accountID not in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidBetween(Integer value1, Integer value2) {
            addCriterion("accountID between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotBetween(Integer value1, Integer value2) {
            addCriterion("accountID not between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andValiddateIsNull() {
            addCriterion("validDate is null");
            return (Criteria) this;
        }

        public Criteria andValiddateIsNotNull() {
            addCriterion("validDate is not null");
            return (Criteria) this;
        }

        public Criteria andValiddateEqualTo(Date value) {
            addCriterionForJDBCDate("validDate =", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateNotEqualTo(Date value) {
            addCriterionForJDBCDate("validDate <>", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateGreaterThan(Date value) {
            addCriterionForJDBCDate("validDate >", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("validDate >=", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateLessThan(Date value) {
            addCriterionForJDBCDate("validDate <", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("validDate <=", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateIn(List<Date> values) {
            addCriterionForJDBCDate("validDate in", values, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateNotIn(List<Date> values) {
            addCriterionForJDBCDate("validDate not in", values, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("validDate between", value1, value2, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("validDate not between", value1, value2, "validdate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateIsNull() {
            addCriterion("invalidDate is null");
            return (Criteria) this;
        }

        public Criteria andInvaliddateIsNotNull() {
            addCriterion("invalidDate is not null");
            return (Criteria) this;
        }

        public Criteria andInvaliddateEqualTo(Date value) {
            addCriterionForJDBCDate("invalidDate =", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateNotEqualTo(Date value) {
            addCriterionForJDBCDate("invalidDate <>", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateGreaterThan(Date value) {
            addCriterionForJDBCDate("invalidDate >", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("invalidDate >=", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateLessThan(Date value) {
            addCriterionForJDBCDate("invalidDate <", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("invalidDate <=", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateIn(List<Date> values) {
            addCriterionForJDBCDate("invalidDate in", values, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateNotIn(List<Date> values) {
            addCriterionForJDBCDate("invalidDate not in", values, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("invalidDate between", value1, value2, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("invalidDate not between", value1, value2, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andOperidIsNull() {
            addCriterion("operID is null");
            return (Criteria) this;
        }

        public Criteria andOperidIsNotNull() {
            addCriterion("operID is not null");
            return (Criteria) this;
        }

        public Criteria andOperidEqualTo(Integer value) {
            addCriterion("operID =", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidNotEqualTo(Integer value) {
            addCriterion("operID <>", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidGreaterThan(Integer value) {
            addCriterion("operID >", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidGreaterThanOrEqualTo(Integer value) {
            addCriterion("operID >=", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidLessThan(Integer value) {
            addCriterion("operID <", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidLessThanOrEqualTo(Integer value) {
            addCriterion("operID <=", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidIn(List<Integer> values) {
            addCriterion("operID in", values, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidNotIn(List<Integer> values) {
            addCriterion("operID not in", values, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidBetween(Integer value1, Integer value2) {
            addCriterion("operID between", value1, value2, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidNotBetween(Integer value1, Integer value2) {
            addCriterion("operID not between", value1, value2, "operid");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreatedateEqualTo(Date value) {
            addCriterion("createDate =", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThan(Date value) {
            addCriterion("createDate <", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateIn(List<Date> values) {
            addCriterion("createDate in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andLupdateIsNull() {
            addCriterion("lupDate is null");
            return (Criteria) this;
        }

        public Criteria andLupdateIsNotNull() {
            addCriterion("lupDate is not null");
            return (Criteria) this;
        }

        public Criteria andLupdateEqualTo(Date value) {
            addCriterion("lupDate =", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotEqualTo(Date value) {
            addCriterion("lupDate <>", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateGreaterThan(Date value) {
            addCriterion("lupDate >", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateGreaterThanOrEqualTo(Date value) {
            addCriterion("lupDate >=", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateLessThan(Date value) {
            addCriterion("lupDate <", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateLessThanOrEqualTo(Date value) {
            addCriterion("lupDate <=", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateIn(List<Date> values) {
            addCriterion("lupDate in", values, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotIn(List<Date> values) {
            addCriterion("lupDate not in", values, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateBetween(Date value1, Date value2) {
            addCriterion("lupDate between", value1, value2, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotBetween(Date value1, Date value2) {
            addCriterion("lupDate not between", value1, value2, "lupdate");
            return (Criteria) this;
        }

        public Criteria andAuditinfoIsNull() {
            addCriterion("auditInfo is null");
            return (Criteria) this;
        }

        public Criteria andAuditinfoIsNotNull() {
            addCriterion("auditInfo is not null");
            return (Criteria) this;
        }

        public Criteria andAuditinfoEqualTo(String value) {
            addCriterion("auditInfo =", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoNotEqualTo(String value) {
            addCriterion("auditInfo <>", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoGreaterThan(String value) {
            addCriterion("auditInfo >", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoGreaterThanOrEqualTo(String value) {
            addCriterion("auditInfo >=", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoLessThan(String value) {
            addCriterion("auditInfo <", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoLessThanOrEqualTo(String value) {
            addCriterion("auditInfo <=", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoLike(String value) {
            addCriterion("auditInfo like", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoNotLike(String value) {
            addCriterion("auditInfo not like", value, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoIn(List<String> values) {
            addCriterion("auditInfo in", values, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoNotIn(List<String> values) {
            addCriterion("auditInfo not in", values, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoBetween(String value1, String value2) {
            addCriterion("auditInfo between", value1, value2, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andAuditinfoNotBetween(String value1, String value2) {
            addCriterion("auditInfo not between", value1, value2, "auditinfo");
            return (Criteria) this;
        }

        public Criteria andDocurlIsNull() {
            addCriterion("docUrl is null");
            return (Criteria) this;
        }

        public Criteria andDocurlIsNotNull() {
            addCriterion("docUrl is not null");
            return (Criteria) this;
        }

        public Criteria andDocurlEqualTo(String value) {
            addCriterion("docUrl =", value, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlNotEqualTo(String value) {
            addCriterion("docUrl <>", value, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlGreaterThan(String value) {
            addCriterion("docUrl >", value, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlGreaterThanOrEqualTo(String value) {
            addCriterion("docUrl >=", value, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlLessThan(String value) {
            addCriterion("docUrl <", value, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlLessThanOrEqualTo(String value) {
            addCriterion("docUrl <=", value, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlLike(String value) {
            addCriterion("docUrl like", value, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlNotLike(String value) {
            addCriterion("docUrl not like", value, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlIn(List<String> values) {
            addCriterion("docUrl in", values, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlNotIn(List<String> values) {
            addCriterion("docUrl not in", values, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlBetween(String value1, String value2) {
            addCriterion("docUrl between", value1, value2, "docurl");
            return (Criteria) this;
        }

        public Criteria andDocurlNotBetween(String value1, String value2) {
            addCriterion("docUrl not between", value1, value2, "docurl");
            return (Criteria) this;
        }

        public Criteria andAccountNameIsNull() {
            addCriterion("account_name is null");
            return (Criteria) this;
        }

        public Criteria andAccountNameIsNotNull() {
            addCriterion("account_name is not null");
            return (Criteria) this;
        }

        public Criteria andAccountNameEqualTo(String value) {
            addCriterion("account_name =", value, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameNotEqualTo(String value) {
            addCriterion("account_name <>", value, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameGreaterThan(String value) {
            addCriterion("account_name >", value, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameGreaterThanOrEqualTo(String value) {
            addCriterion("account_name >=", value, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameLessThan(String value) {
            addCriterion("account_name <", value, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameLessThanOrEqualTo(String value) {
            addCriterion("account_name <=", value, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameLike(String value) {
            addCriterion("account_name like", value, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameNotLike(String value) {
            addCriterion("account_name not like", value, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameIn(List<String> values) {
            addCriterion("account_name in", values, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameNotIn(List<String> values) {
            addCriterion("account_name not in", values, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameBetween(String value1, String value2) {
            addCriterion("account_name between", value1, value2, "accountName");
            return (Criteria) this;
        }

        public Criteria andAccountNameNotBetween(String value1, String value2) {
            addCriterion("account_name not between", value1, value2, "accountName");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}