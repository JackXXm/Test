package com.edip.ucenter.provider;

//import com.alibaba.excel.ExcelReader;
//import com.alibaba.excel.read.context.AnalysisContext;
//import com.alibaba.excel.read.event.AnalysisEventListener;
//import com.alibaba.fastjson.JSON;
import com.edip.controller.ChinaAreaClient;
import com.edip.controller.CompTypeCredentialsClient;
import com.edip.dto.BaseResult;
import com.edip.dto.ServerResponse;
import com.edip.entity.User;
import com.edip.pay.client.ApplePayClient;
import com.edip.ucenter.manager.UserManager;
import com.edip.vo.ProvinceVo;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author vangao1989
 * @date 2017年7月26日
 */
@RestController
public class RechargeProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(RechargeProvider.class);

    @Resource
    private UserManager userManager;
    @Resource
    private ApplePayClient applePayClient;

    @Resource
    private CompTypeCredentialsClient compTypeCredentialsClient;

    @Resource
    private ChinaAreaClient chinaAreaClient;


    //    @HystrixCommand(fallbackMethod = "rechargeFallback")
//    @RequestMapping(value = "/recharge", method = RequestMethod.POST)
//    public BaseResult<Boolean> recharge(@RequestParam @ApiParam(name = "userId",value = "用户名") Long userId,
//                                        @RequestParam @ApiParam(name = "amount",value = "金额") Double amount,
//                                        @RequestParam @ApiParam(name = "type",value = "充值方式：1.支付宝|2.微信支付") String type) {
//        User user = userManager.getUserByUserId(userId);
//        LOGGER.info("user {} recharge {},type:{}", user.getUsername(), amount, type);
//        BaseResult<Boolean> baseResult = applePayClient.recharge(userId, amount);
//        LOGGER.info("user {} recharge  res:{}", user.getUsername(), JSON.toJSONString(baseResult));
//        return baseResult;
//
//    }
    @HystrixCommand(fallbackMethod = "rechargeFallback")
    @RequestMapping(value = "/recharge", method = RequestMethod.POST)
    public ServerResponse recharge(@RequestParam @ApiParam(name = "userId", value = "用户名") Long userId,
                                   @RequestParam @ApiParam(name = "amount", value = "金额") Double amount,
                                   @RequestParam @ApiParam(name = "type", value = "充值方式：1.支付宝|2.微信支付") String type) {
        User user = userManager.getUserByUserId(userId);
        applePayClient.recharge(userId, amount);
        ServerResponse result = compTypeCredentialsClient.queryAllCompanyTypeList();
        if (result.isSuccess()) {
            return ServerResponse.createBySuccess(result.getData());
        } else {
            return ServerResponse.createByErrorMsg("服务调用失败！");
        }


    }

    private ServerResponse rechargeFallback(Long useId, Double amount, String type, Throwable throwable) {
        LOGGER.error("user:{} recharge,amount:{},type:{}, fail:{}", useId, amount, type, throwable.getMessage(), throwable);
        return ServerResponse.createByErrorMsg(throwable.getMessage());
    }

    /*@RequestMapping(value = "/recharge/templates", method = RequestMethod.POST)
    public ServerResponse<List<ProvinceVo>> recharge() {
        // compTypeCredentialsClient.queryAllCompanyTypeList();
        //
        //ServerResponse aaa = compTypeCredentialsClient.transOneProductType(17);
        //ServerResponse aaa =  chinaAreaClient.searchArea(163);
        //return aaa;
    }*/


    @RequestMapping(value = "readExcel", method = RequestMethod.POST)
    public void readExcel(MultipartFile excel) {
        /*return ExcelUtil.readExcel(excel, new ImportInfo());*/

    }


}
