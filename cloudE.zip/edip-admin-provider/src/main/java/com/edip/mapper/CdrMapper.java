package com.edip.mapper;

import java.util.List;

import com.edip.entity.Cdr;
import com.edip.entity.CdrExample;
import org.apache.ibatis.annotations.Param;

public interface CdrMapper {
    int countByExample(CdrExample example);

    int deleteByExample(CdrExample example);

    int deleteByPrimaryKey(Integer cdrID);

    int insert(Cdr record);

    int insertSelective(Cdr record);

    List<Cdr> selectByExampleWithPage(@Param("example") CdrExample example, @Param("from") Integer from, @Param("to") Integer to);

    List<Cdr> selectByExample(CdrExample example);

    Cdr selectByPrimaryKey(Integer cdrID);

    int updateByExampleSelective(@Param("record") Cdr record, @Param("example") CdrExample example);

    int updateByExample(@Param("record") Cdr record, @Param("example") CdrExample example);

    int updateByPrimaryKeySelective(Cdr record);

    int updateByPrimaryKey(Cdr record);
}
