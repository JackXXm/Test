package com.edip;

import io.prometheus.client.spring.boot.EnableSpringBootMetricsCollector;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;


/**
 * @Description: 交换微服务
 * @date 2018年12月26日
 */
@SpringBootApplication
@EnableEurekaClient
@EnableHystrix
@EnableFeignClients
@EnableSpringBootMetricsCollector
@RefreshScope
@MapperScan("com.edip.mapper")
public class CheckReportProviderApplication {
    public static void main(String[] args) {
        SpringApplication.run(CheckReportProviderApplication.class, args);
    }
}