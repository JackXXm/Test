package com.edip.entity;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Scope("prototype")
public class Companycontacts {
	
	private String companyName;//合作企业名称

	private Integer upstreamSupplier;//上游供应商 0.不是 1.是
	
	private Integer downCustom;//下游客户 0.不是  1.是
	
	private String address;//合作公司所在省
	
	private String name;//合作公司联系人
	
	private String phone;
	
    private Integer ccid;

    private Integer compID;
    
    private Integer certification;//认证状态
   
    private Integer deleteFlag;// -1.删除  0.正常

    private Date createTime;//创建时间

    private  String supplier;

    private String customer;

    private Integer cocompID;

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }



	public Integer getCcid() {
		return ccid;
	}

	public void setCcid(Integer ccid) {
		this.ccid = ccid;
	}

	public Integer getCompID() {
		return compID;
	}

	public void setCompID(Integer compID) {
		this.compID = compID;
	}

	public Integer getCertification() {
		return certification;
	}

	public void setCertification(Integer certification) {
		this.certification = certification;
	}

	public Integer getDownCustom() {
		return downCustom;
	}

	public void setDownCustom(Integer downCustom) {
		this.downCustom = downCustom;
	}

	public Integer getUpstreamSupplier() {
		return upstreamSupplier;
	}

	public void setUpstreamSupplier(Integer upstreamSupplier) {
		this.upstreamSupplier = upstreamSupplier;
	}

	public Integer getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(Integer deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}


    public Integer getCocompID() {
        return cocompID;
    }

    public void setCocompID(Integer cocompID) {
        this.cocompID = cocompID;
    }
}