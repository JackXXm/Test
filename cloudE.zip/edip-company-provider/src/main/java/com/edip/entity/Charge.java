package com.edip.entity;

public class Charge {
    private Integer receiveID;
    private Integer sessionComId;
    private Integer comId;
    private boolean flag;
    private String name;
    private Integer jobId;
    private Integer costCount;
    private String firstFlag;

    public Integer getReceiveID() {
        return receiveID;
    }

    public void setReceiveID(Integer receiveID) {
        this.receiveID = receiveID;
    }

    public Integer getSessionComId() {
        return sessionComId;
    }

    public void setSessionComId(Integer sessionComId) {
        this.sessionComId = sessionComId;
    }

    public Integer getComId() {
        return comId;
    }

    public void setComId(Integer comId) {
        this.comId = comId;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getJobId() {
        return jobId;
    }

    public void setJobId(Integer jobId) {
        this.jobId = jobId;
    }

    public Integer getCostCount() {
        return costCount;
    }

    public void setCostCount(Integer costCount) {
        this.costCount = costCount;
    }

    public String getFirstFlag() {
        return firstFlag;
    }

    public void setFirstFlag(String firstFlag) {
        this.firstFlag = firstFlag;
    }
}
