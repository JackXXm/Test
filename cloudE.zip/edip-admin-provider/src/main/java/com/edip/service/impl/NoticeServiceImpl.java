package com.edip.service.impl;

import com.edip.dto.util.SessionAttributeUtil;
import com.edip.mapper.NoticeMapper;
import com.edip.service.NoticeService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Service
public class NoticeServiceImpl implements NoticeService {
    @Resource
    private NoticeMapper noticeMapper;

    @Override
    @Transactional
    public void addNotice(Map<String,Object> params, HttpServletRequest request) {
        String createBy = (String) SessionAttributeUtil.getAttribute(request).get("createBy");
        params.put("msgType",2);
        params.put("createDate",new Date());
        params.put("delFlag",1);
        if((Integer) params.get("type")==0) {
            params.put("send", 0);
        }else{
            params.put("send",1);
            params.put("sendDate",new Date());
        }
        params.put("createBy",createBy);
        noticeMapper.addNotice(params);
    }

    @Override
    public List<Map<String, Object>> getNotice(Map<String,Object> params) {
        return noticeMapper.getNotice(params);
    }

    @Override
    @Transactional
    public void editNotice(Map<String,Object> params, HttpServletRequest request) {
        String createBy = (String) SessionAttributeUtil.getAttribute(request).get("createBy");
        params.put("createBy",createBy);
        params.put("lupDate",new Date());
        if((Integer)params.get("type")==1){
            params.put("send",1);
            params.put("sendDate",new Date());
        }
        noticeMapper.editNotice(params);
    }

    @Override
    @Transactional
    public void deleteNotice(String ids) {
        String[] split = ids.split(",");
        noticeMapper.deleteNotice(Arrays.asList(split));
    }

    @Override
    @Transactional
    public void sendNotice(Integer id) {
        Map<String,Object> params = new HashMap<>();
        params.put("id",id);
        params.put("sendDate",new Date());
        noticeMapper.sendNotice(params);
    }
}
