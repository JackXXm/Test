package com.edip.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edip.controller.MessageClient;
import com.edip.dto.ServerResponse;
import com.edip.dto.util.RedisUtil;
import com.edip.entity.*;

import com.edip.feign.CompanyFeign;
import com.edip.mapper.*;
import com.edip.service.SignSendService;
import com.edip.utils.GetServerStatusUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Maps;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class SignSendServiceImpl implements SignSendService {
    @Autowired
    private ExchangeFileItemMapper exchangeFileItemMapper;
    @Autowired
    private ExchangeJobMapper exchangeJobMapper;
    @Autowired
    private ExchangeProjectMapper exchangeProjectMapper;
    @Autowired
    private ExchangeJobReceiveCompanyMapper exchangeJobReceiveCompanyMapper;
    @Autowired
    private ExchangeMapper exchangeMapper;
    @Autowired
    private ExchangeProductCompanyMapper exchangeProductCompanyMapper;
    @Autowired
    private MessageClient messageClient;
    @Autowired
    private CompanyFeign companyFeign;
    @Autowired
    RedisUtil util;
    private static final Logger log = LoggerFactory.getLogger(SignSendServiceImpl.class);

    @Override
    public JSONObject getSignatureProgress(Map<String, Object> signInfo) {


        List<SignInfo> signInfos=exchangeFileItemMapper.getSignDocInfo(signInfo);
        JSONObject result=new JSONObject();
        int docTotal=signInfos.size();
        int signTotal=0;
        int unSignTotal=0;
        for(SignInfo item:signInfos){
            int status=item.getStatus();
           //状态1标识签章成功
            if(status==1){
                signTotal++;
            }
        }
        unSignTotal=docTotal-signTotal;
        result.put("docTotal",docTotal);
        result.put("signTotal",signTotal);
        result.put("unSignTotal",unSignTotal);
        return result;
    }

    @Override
    public PageInfo getSendTaskList(Map<String, Object> signInfo) throws ParseException {
        ExchangeJobExample exchangeJobExample=new ExchangeJobExample();
        ExchangeJobExample.Criteria criteria=exchangeJobExample.createCriteria();
        criteria.andDeleteFlagNotEqualTo("-1");
        criteria.andCompanyIdEqualTo((Integer) signInfo.get("companyId"));
        criteria.andStatusNotEqualTo(6);
        if(StringUtils.isNotEmpty((String)signInfo.get("sender"))){
            criteria.andSenderLike("%"+(String)signInfo.get("sender")+"%");
        }
        if(StringUtils.isNotEmpty((String)signInfo.get("dataDigest"))){
            criteria.andDataDigestLike("%"+(String)signInfo.get("dataDigest")+"%");
        }
        if(StringUtils.isNotEmpty((String)signInfo.get("receiveCompany"))){
            criteria.andReceiveCompanyNameLike("%"+(String)signInfo.get("receiveCompany")+"%");
        }
        String status=(String)signInfo.get("status");
        if(StringUtils.isNotEmpty(status)){
            //查出待签章，失败的任务
            if("9".equals(status)){
                List<Integer>signStatus=new ArrayList<>();
                signStatus.add(1);
                signStatus.add(4);
                criteria.andStatusIn(signStatus);
            }else{
                criteria.andStatusEqualTo(Integer.parseInt((String)signInfo.get("status")));
            }


        }

        if(StringUtils.isNotEmpty((String)signInfo.get("startTime"))&&StringUtils.isNotEmpty((String)signInfo.get("endTime"))){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date stime=sdf.parse((String)signInfo.get("startTime")+" 00:00:00");
            Date etime=sdf.parse((String)signInfo.get("endTime")+" 23:59:59");
            criteria.andCreateTimeBetween(stime,etime);
        }
        exchangeJobExample.setOrderByClause("update_time desc");
        Integer pageNum= (Integer) signInfo.get("page");
        Integer pageSize= (Integer) signInfo.get("rows");

        PageHelper.startPage(pageNum,pageSize);

        PageInfo pageInfo=new PageInfo(exchangeJobMapper.selectByExample(exchangeJobExample));

        return pageInfo;
    }

    @Override
    public void deleteSendTask(Map<String, Object> signInfo) {
        ExchangeJobExample exchangeJobExample=new ExchangeJobExample();
        ExchangeJob job=new ExchangeJob();
        job.setDeleteFlag("-1");
        ExchangeJobExample.Criteria criteria=exchangeJobExample.createCriteria();
        JSONObject jsonObject=new JSONObject(signInfo);
        criteria.andIdIn(jsonObject.getObject("ids",List.class));
        Integer companyId=jsonObject.getInteger("companyId");
        criteria.andCompanyIdEqualTo(companyId);
        List<Integer>fisrtJobs=jsonObject.getObject("firstJobs",List.class);
        //需要删除回传对应资质记录
        if(fisrtJobs!=null&&fisrtJobs.size()>0){
            Map<String,Object>params=new HashMap<>();
            params.put("fisrtJobs",fisrtJobs);
            List<Map<String,Object>>jobInfos=exchangeFileItemMapper.queryDeleteDocs(params);
            Map<Integer,JSONObject>deleteInfos=new HashMap<>();
            jobInfos.forEach(map -> {
                JSONObject value=deleteInfos.get(map.get("job_id"));
                if(value!=null){
                    List<Integer>clonesIds=value.getObject("cloneIds",List.class);
                    clonesIds.add((Integer) map.get("clone_id"));
                }else{
                    value=new JSONObject();
                    Integer jobId= (Integer) map.get("job_id");
                    value.put("fisrtJobId",jobId);
                    List<Integer>clonesIds=new ArrayList<>();
                    clonesIds.add((Integer) map.get("clone_id"));
                    value.put("cloneIds",clonesIds);
                    deleteInfos.put(jobId,value);
                }
            });
            deleteInfos.values().forEach(jsonObject1 -> {
                updateReturnStatus(jsonObject1,companyId);
            });
        }

        exchangeJobMapper.updateByExampleSelective(job,exchangeJobExample);

        List idList = jsonObject.getObject("ids",List.class);
        for(int i = 0 ; i < idList.size() ; i++){
            Map map = messageClient.getMessageAccountIdByDataId(Integer.valueOf(idList.get(i).toString()),jsonObject.getInteger("companyId"));
            if(map != null && map.size() > 0){
                JSONObject json = new JSONObject();
                json.put("msgType",3);//消息类型:1 首营端消息 2 管理端消息 3 检验报告
                json.put("dataId",Integer.valueOf(idList.get(i).toString()));
                json.put("compId",jsonObject.getInteger("companyId"));
                json.put("accountId",jsonObject.getInteger("accountId"));
                json.put("receiveCompID",jsonObject.getInteger("companyId"));
                json.put("receiveID",map.get("accountId"));
                json.put("dataType",7);//实体类型 0:公司 1:人员 2:产品 3:合同 4:图章 5:证书 6:项目 7:检验报告
                json.put("sender","签章发送：");
                json.put("title","您于【" + map.get("createDate") + "】提交的发送任务被【" + jsonObject.getString("accountName") + "】已删除");
                json.put("content","您于【" + map.get("createDate") + "】提交的发送任务被【" + jsonObject.getString("accountName") + "】已删除");
                json.put("classify",0);//消息标识 0 系统消息，1 到期提醒，2 更新提醒，3 系统公告，4 优惠活动
                messageClient.changeMessageInvalid(Integer.valueOf(idList.get(i).toString()));
                messageClient.messageSend(json.toJSONString());
            }
        }
    }
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void sendTask(Map<String, Object> signInfo) throws Exception {
        ExchangeJobExample exchangeJobExample=new ExchangeJobExample();
        ExchangeJob job=new ExchangeJob();
        job.setStatus(6);
        ExchangeJobExample.Criteria criteria=exchangeJobExample.createCriteria();
        JSONObject jsonObject=new JSONObject(signInfo);
        List<Integer>ids=jsonObject.getObject("ids",List.class);
        criteria.andIdIn(ids);
        criteria.andCompanyIdEqualTo(jsonObject.getInteger("companyId"));
        job.setUpdateTime(new Date());
        job.setSender(jsonObject.getString("accountName"));
        job.setUpdateAccountId(jsonObject.getInteger("accountID"));
        exchangeJobMapper.updateByExampleSelective(job,exchangeJobExample);
        ExchangeFileItemExample exchangeFileItemExample=new ExchangeFileItemExample();
        ExchangeFileItemExample.Criteria exchangeFileItemExampleCriteria=exchangeFileItemExample.createCriteria();
        exchangeFileItemExampleCriteria.andJobIdIn(jsonObject.getObject("ids",List.class));
        exchangeFileItemExampleCriteria.andCompanyIdEqualTo(jsonObject.getInteger("companyId"));
        ExchangeFileItem exchangeFileItem=new ExchangeFileItem();
        exchangeFileItem.setStatus(3);
        exchangeFileItemMapper.updateByExampleSelective(exchangeFileItem,exchangeFileItemExample);
        ExchangeJobReceiveCompany exchangeJobReceiveCompany=new ExchangeJobReceiveCompany();
        exchangeJobReceiveCompany.setUpateTime(new Date());
        ExchangeJobReceiveCompanyExample exchangeJobReceiveCompanyExample=new ExchangeJobReceiveCompanyExample();
        ExchangeJobReceiveCompanyExample.Criteria comapnyCriteria=exchangeJobReceiveCompanyExample.createCriteria();
        comapnyCriteria.andJobIdIn(jsonObject.getObject("ids",List.class));
        exchangeJobReceiveCompanyMapper.updateByExampleSelective(exchangeJobReceiveCompany,exchangeJobReceiveCompanyExample);



        List idList = jsonObject.getObject("ids",List.class);
        sendMessageForUnRegisterCompany(idList,jsonObject.getString("companyName"));
        for(int i = 0 ; i < idList.size() ; i++){
            Map map = messageClient.getMessageAccountIdByDataId(Integer.valueOf(idList.get(i).toString()),jsonObject.getInteger("companyId"));
            if(map != null && map.size() > 0){
                JSONObject json = new JSONObject();
                json.put("msgType",3);//消息类型:1 首营端消息 2 管理端消息 3 检验报告消息
                json.put("dataId",Integer.valueOf(idList.get(i).toString()));
                json.put("compId",jsonObject.getInteger("companyId"));
                json.put("accountId",jsonObject.getInteger("accountId"));
                json.put("receiveCompID",jsonObject.getInteger("companyId"));
                json.put("receiveID",map.get("accountId"));
                json.put("dataType",7);//实体类型 0:公司 1:人员 2:产品 3:合同 4:图章 5:证书 6:项目 7:检验报告
                json.put("sender","通知：");
                json.put("title","您于【" + map.get("createDate") + "】提交的发送任务已签章发送成功");
                json.put("content","您于【" + map.get("createDate") + "】提交的发送任务已签章发送成功");
                json.put("classify",0);//消息标识 0 系统消息，1 到期提醒，2 更新提醒，3 系统公告，4 优惠活动
                messageClient.changeMessageInvalid(Integer.valueOf(idList.get(i).toString()));
                messageClient.messageSend(json.toJSONString());
            }
            ExchangeJobReceiveCompanyExample jobReceiveCompanyExample = new ExchangeJobReceiveCompanyExample();
            jobReceiveCompanyExample.createCriteria().andJobIdEqualTo(Integer.valueOf(idList.get(i).toString()));
            List<ExchangeJobReceiveCompany> list = exchangeJobReceiveCompanyMapper.selectByExample(jobReceiveCompanyExample);
            for (ExchangeJobReceiveCompany jobReceiveCompany : list){
                if(jobReceiveCompany.getReceiveCompanyId() != null) {
                    JSONObject json = new JSONObject();
                    json.put("msgType", 3);//消息类型:1 首营端消息 2 管理端消息 3 检验报告
                    json.put("dataId", Integer.valueOf(idList.get(i).toString()));
                    json.put("compId", jsonObject.getInteger("companyId"));
                    json.put("accountId", jsonObject.getInteger("accountId"));
                    json.put("receiveCompID", jobReceiveCompany.getReceiveCompanyId());
                    json.put("dataType", 7);//实体类型 0:公司 1:人员 2:产品 3:合同 4:图章 5:证书 6:项目 7:检验报告
                    json.put("sender", "收件箱");
                    json.put("title", "您有来自【" + jsonObject.getString("companyName") + "】公司的交换资料");
                    json.put("content", "您有来自【" + jsonObject.getString("companyName") + "】公司的交换资料");
                    json.put("classify", 0);//消息标识 0 系统消息，1 到期提醒，2 更新提醒，3 系统公告，4 优惠活动
                    json.put("newUrl","box/inbox/index?mid=243");
                    json.put("roleName", "");
                    messageClient.changeMessageInvalid(Integer.valueOf(idList.get(i).toString()));
                    messageClient.messageSend(json.toJSONString());
                }
            }
        }
       // charging(ids,jsonObject.getInteger("companyId"));
    }

    @Override
    public void saveCustomSign(Map<String, Object> signInfo) {
        ExchangeFileItem exchangeFileItem=new ExchangeFileItem();
        JSONObject jsonObject=new JSONObject(signInfo);
        JSONArray saveSignInfo=jsonObject.getJSONArray("signInfo");
        if(saveSignInfo!=null){
            exchangeFileItem.setSignInfo(saveSignInfo.toJSONString());
        }else{
            exchangeFileItem.setSignInfo("");
        }
        JSONArray destSignInfo=jsonObject.getJSONArray("destSignInfo");
        if(destSignInfo!=null){
            exchangeFileItem.setDestSignInfo(destSignInfo.toJSONString());
        }else{
            exchangeFileItem.setDestSignInfo("");
        }

        exchangeFileItem.setId(jsonObject.getInteger("id"));
        exchangeFileItemMapper.updateByPrimaryKeySelective(exchangeFileItem);
    }

    @Override
    public void deleteSendTaskDocs(Map<String, Object> signInfo) {
        ExchangeFileItemExample exchangeFileItemExample=new ExchangeFileItemExample();
        ExchangeFileItemExample.Criteria criteria=exchangeFileItemExample.createCriteria();
        JSONObject jsonObject=new JSONObject(signInfo);
        List ids=jsonObject.getObject("ids",List.class);
        criteria.andInspectIdIn(ids);
        Integer jobId=jsonObject.getInteger("jobId");
        int companyId=jsonObject.getInteger("companyId");
        criteria.andCompanyIdEqualTo(companyId);
        criteria.andJobIdEqualTo(jobId);
        ExchangeFileItem exchangeFileItem=new ExchangeFileItem();
        exchangeFileItem.setDeleteFlag("-1");

        exchangeFileItemMapper.updateByExampleSelective(exchangeFileItem,exchangeFileItemExample);
        ExchangeProjectExample exchangeProjectExample=new ExchangeProjectExample();
        ExchangeProjectExample.Criteria projectExampleCriteria=exchangeProjectExample.createCriteria();
        projectExampleCriteria.andJobIdEqualTo(jobId);
        projectExampleCriteria.andIdEqualTo(jsonObject.getInteger("projectId"));
        ExchangeProject exchangeProject=new ExchangeProject();
        exchangeProject.setThemeDocNum(jsonObject.getInteger("docNum"));
        exchangeProjectMapper.updateByExampleSelective(exchangeProject,exchangeProjectExample);

        //updateReturnStatus(jsonObject,companyId);

    }
    /**
     * create by: hym
     * description:更新回传资质状态
     * create time: 15:41 2019/2/26
     *
      * @Param: null
     * @return
     */
    private void updateReturnStatus(JSONObject jsonObject, int companyId){
        Integer fisrtJobId=jsonObject.getInteger("fisrtJobId");
        if(fisrtJobId!=null){

            List<Integer>cloneIds=jsonObject.getObject("cloneIds",List.class);
            Map<String,String>params=new HashMap<>();
            if(cloneIds!=null){

            params.put("jobId",fisrtJobId+"");
            params.put("companyID",companyId+"");
            String returnDocString= exchangeMapper.queryReturnDocStatus(params);
            JSONObject returnDocStatus=JSONObject.parseObject(returnDocString);
                if(returnDocStatus!=null){
                    cloneIds.forEach(id->{
                        returnDocStatus.remove(id+"");
                    });
                    params.put("returnDocStatus",returnDocStatus.toJSONString());
                }
            }

                params.put("status",2+"");
                exchangeMapper.updateReceiveCompany(params);

        }
    }

    @Override
    public void deleteSendTaskTheme(Map<String, Object> signInfo) {
        ExchangeProjectExample exchangeProjectExample=new ExchangeProjectExample();
        ExchangeProjectExample.Criteria criteria=exchangeProjectExample.createCriteria();
        JSONObject jsonObject=new JSONObject(signInfo);
        List ids=jsonObject.getObject("ids",List.class);


        ExchangeProject exchangeProject=new ExchangeProject();
        exchangeProject.setDeleteFlag("-1");
        int companyId=jsonObject.getInteger("companyId");

        ExchangeProductCompanyExample exchangeProductCompanyExample=new ExchangeProductCompanyExample();
        ExchangeProductCompanyExample.Criteria criteria1=exchangeProductCompanyExample.createCriteria();
        criteria1.andProductProjectIdIn(ids);
        List<ExchangeProductCompany>productCompanies=exchangeProductCompanyMapper.selectByExample(exchangeProductCompanyExample);
        List<Integer>produceId=new ArrayList<>();
        productCompanies.forEach(exchangeProductCompany -> {
            produceId.add(exchangeProductCompany.getProduceProjectId());
        });
        ids.addAll(produceId);
        criteria.andIdIn(ids);
        exchangeProjectMapper.updateByExampleSelective(exchangeProject,exchangeProjectExample);
        ExchangeJob exchangejob=new ExchangeJob();
        exchangejob.setDataDigest(jsonObject.getString("themeInfo"));

        ExchangeJobExample exchangeJobExample=new ExchangeJobExample();
        ExchangeJobExample.Criteria  criteriaJob=exchangeJobExample.createCriteria();
        Integer jobId=jsonObject.getInteger("jobId");
        criteriaJob.andIdEqualTo(jobId);
        criteriaJob.andCompanyIdEqualTo(companyId);
        exchangeJobMapper.updateByExampleSelective(exchangejob,exchangeJobExample);
        updateReturnStatus(jsonObject,companyId);

    }

    @Override
    public void changeTaskStatus(Map<String, Object> signInfo) {
        ExchangeJobExample exchangeJobExample=new ExchangeJobExample();
        ExchangeJob job=new ExchangeJob();

        ExchangeJobExample.Criteria criteria=exchangeJobExample.createCriteria();
        JSONObject jsonObject=new JSONObject(signInfo);
        Integer status=jsonObject.getInteger("status");
        List ids=jsonObject.getObject("ids",List.class);
        criteria.andCompanyIdEqualTo(jsonObject.getInteger("companyId"));
        Boolean closeReviewFlag=jsonObject.getBoolean("closeReviewFlag");
        if(closeReviewFlag!=null&&closeReviewFlag){
            criteria.andStatusGreaterThan(10);
            job.setStatus(1);
            exchangeJobMapper.updateByExampleSelective(job,exchangeJobExample);
            return ;
        }
        if(status==5) {

            Integer id = Integer.parseInt((String) ids.get(0)) ;
        Map<String,Object>objectMap=new HashMap<>();
            objectMap.put("jobId",id);
            List<ExchangeFileItem> list=exchangeFileItemMapper.getSendDocs(objectMap);
            for(ExchangeFileItem exchangeFileItem:list){
                if(exchangeFileItem.getStatus()!=1){
                    status=4;
                    break;
                }
            }
        }
        job.setStatus(status);
        criteria.andIdIn(ids);

        exchangeJobMapper.updateByExampleSelective(job,exchangeJobExample);

    }

    @Override
    public List<SignInfo> getSignatureDocList(Map<String, Object> signInfo) {
        signInfo.put("flag","need choose");
        List<SignInfo> signInfos=exchangeFileItemMapper.getSignDocInfo(signInfo);
        signInfos.forEach(signInfoMap ->{
            if(signInfoMap.getSignedPdfName()!=null){
                signInfoMap.setPdfName(signInfoMap.getSignedPdfName());
            }
        } );
        return signInfos;
    }

    @Override
    public List<SignInfo> getReturnSignatureDocList(Map<String, Object> signInfo) {
        List<SignInfo> signInfos=exchangeFileItemMapper.getReturnSignDocInfo(signInfo);
        signInfos.forEach(signInfoMap ->{
            if(signInfoMap.getSignedPdfName()!=null){
                signInfoMap.setPdfName(signInfoMap.getSignedPdfName());
            }
        } );
        return signInfos;
    }

    @Override
    public List<ReturnSignInfo> getReturnSignatureInfo(Map<String, Object> signInfo) {
        JSONObject result=new JSONObject(signInfo);
        JSONArray preSignArray=result.getJSONArray("signList");
        Map<String,Object> map= new HashMap<String,Object>();
        List<ReturnSignInfo> signInfos = new ArrayList<ReturnSignInfo>();

        for(int i=0;i<preSignArray.size();i++) {
            ReturnSignInfo sign = new ReturnSignInfo();
            JSONObject json=preSignArray.getJSONObject(i);
            String docID = json.get("docId").toString();
            map =  exchangeFileItemMapper.getReturnSignatureInfo(docID);
            sign.setPdfName(map.get("docURL").toString());
            String proID = map.get("proID").toString();
            sign.setTaskId(Integer.parseInt(proID));
            sign.setDocId(Integer.parseInt(docID));
           /* sign.setSignedPdfName(json.get("signedPdfName").toString());
            sign.setDestSignInfo(json.get("destSignInfo").toString());
            sign.setAliasName(json.get("aliasName").toString());*/
            sign.setCreateDate((Date) map.get("createDate"));
            //sign.setDocType(json.get("docType").toString());
            signInfos.add(sign);
        }
        return signInfos;
    }

    @Override
    public void updateTaskFail(Map<String, Object> signInfo) {
        ExchangeJobExample exchangeJobExample=new ExchangeJobExample();
        ExchangeJob job=new ExchangeJob();

        ExchangeJobExample.Criteria criteria=exchangeJobExample.createCriteria();
        JSONObject jsonObject=new JSONObject(signInfo);
        job.setStatus(4);
        List<Integer>status=new ArrayList<>();
        status.add(2);
        status.add(3);
        criteria.andStatusIn(status);
        criteria.andCompanyIdEqualTo(jsonObject.getInteger("companyId"));
        exchangeJobMapper.updateByExampleSelective(job,exchangeJobExample);
    }

    @Override
    public void deleteReceiveCompany(Map<String, Object> signInfo) {
        ExchangeJobReceiveCompany exchangeJobReceiveCompany=new ExchangeJobReceiveCompany();
        exchangeJobReceiveCompany.setDeleteFlag("-1");
        ExchangeJobReceiveCompanyExample exchangeJobReceiveCompanyExample=new ExchangeJobReceiveCompanyExample();
        ExchangeJobReceiveCompanyExample.Criteria criteria=exchangeJobReceiveCompanyExample.createCriteria();
        criteria.andReceiveCompanyNameEqualTo((String) signInfo.get("companyName"));
        int jobId=Integer.parseInt((String )signInfo.get("jobId"));
        criteria.andJobIdEqualTo(jobId);
        ExchangeJobExample exchangeJobExample=new ExchangeJobExample();
        ExchangeJob job=new ExchangeJob();
        job.setReceiveCompanyName((String )signInfo.get("receiveCompanyName"));
        ExchangeJobExample.Criteria criteria1=exchangeJobExample.createCriteria();
        criteria1.andIdEqualTo(jobId);
        exchangeJobMapper.updateByExampleSelective(job,exchangeJobExample);
        exchangeJobReceiveCompanyMapper.updateByExampleSelective(exchangeJobReceiveCompany,exchangeJobReceiveCompanyExample);
    }
    @Transactional(rollbackFor = Exception.class)
    @Override
    public int allSendTask(Map<String, Object> signInfo) throws Exception {
        int result =0;
        ExchangeJobExample exchangeJobExample=new ExchangeJobExample();
        ExchangeJob job=new ExchangeJob();
        job.setStatus(6);

        ExchangeJobExample.Criteria criteria=exchangeJobExample.createCriteria();
        JSONObject jsonObject=new JSONObject(signInfo);
        job.setSender(jsonObject.getString("accountName"));
        job.setUpdateAccountId(jsonObject.getInteger("accountID"));
        criteria.andCompanyIdEqualTo(jsonObject.getInteger("companyId"));
        criteria.andStatusEqualTo(5);
        criteria.andDeleteFlagNotEqualTo("-1");
        job.setUpdateTime(new Date());
        exchangeJobExample.setLimit(1000);
        List<ExchangeJob>jobs=exchangeJobMapper.selectByExample(exchangeJobExample);
        if (jobs!=null&&jobs.size()==0){
            result=1;
            return result;
        }
        List<Integer>ids=new ArrayList<>();
        int count=0;
        jobs.forEach(exchangeJob -> {
            ids.add(exchangeJob.getId());

        });
        sendMessageForUnRegisterCompany(ids,jsonObject.getString("companyName"));

        exchangeJobMapper.updateByExampleSelective(job,exchangeJobExample);
        ExchangeFileItemExample exchangeFileItemExample=new ExchangeFileItemExample();
        ExchangeFileItemExample.Criteria exchangeFileItemExampleCriteria=exchangeFileItemExample.createCriteria();
        exchangeFileItemExampleCriteria.andStatusEqualTo(1);
        exchangeFileItemExampleCriteria.andCompanyIdEqualTo(jsonObject.getInteger("companyId"));
        ExchangeFileItem exchangeFileItem=new ExchangeFileItem();
        exchangeFileItem.setStatus(3);
        exchangeFileItemMapper.updateByExampleSelective(exchangeFileItem,exchangeFileItemExample);

        ExchangeJobReceiveCompany exchangeJobReceiveCompany=new ExchangeJobReceiveCompany();
        exchangeJobReceiveCompany.setUpateTime(new Date());
        ExchangeJobReceiveCompanyExample exchangeJobReceiveCompanyExample=new ExchangeJobReceiveCompanyExample();
        ExchangeJobReceiveCompanyExample.Criteria comapnyCriteria=exchangeJobReceiveCompanyExample.createCriteria();
        comapnyCriteria.andJobIdIn(ids);
        exchangeJobReceiveCompanyMapper.updateByExampleSelective(exchangeJobReceiveCompany,exchangeJobReceiveCompanyExample);
        charging(ids,jsonObject.getInteger("companyId"));
        return result;
    }

    @Override
    public JSONObject sendSignInfo(Map<String, Object> signInfo) throws UnsupportedEncodingException, InterruptedException {
        Integer companyId= (Integer) signInfo.get("compID");
        //需要分配的服务数量
        int threadCount=0;
        JSONObject result=new JSONObject(signInfo);
        JSONArray preSignArray=result.getJSONArray("signList");
        for(int i=0;i<preSignArray.size();i++){
            JSONObject json=preSignArray.getJSONObject(i);

            if(json.getBoolean("first")){
                threadCount++;
            }
        }
        int size= GetServerStatusUtil.getAvailableServer(util,threadCount);
        String cert =(String)signInfo.get("cert");

        JSONArray resultSignArray=new JSONArray();
        Set<String> serviceIds=new HashSet<>();
        Map<String,JSONObject>preServiceJsons= Maps.newHashMap();
        for(int i=0;i<preSignArray.size();i++){
            JSONObject json=preSignArray.getJSONObject(i);
            json.put("cert",cert);
            json.put("companyId",companyId);

            //新可用的签章服务

            if(size>0&&json.getBoolean("first")){
                sendSignInfo(json,serviceIds,preServiceJsons,0);

                size--;
                continue;
                //已调用了签章服务的资质
            }else if(!json.getBoolean("first")){
                sendSignInfo(json,serviceIds,preServiceJsons,1);
                continue;
            }


            resultSignArray.add(json);
        }
        //需要等待结果的签章文件数
        size=serviceIds.size();
        Long startTime=System.currentTimeMillis();
        while(size>0){
            for(String serviceId:serviceIds){
                String retrunSignInfo= util.getSignInfo(serviceId);
                JSONObject sendTaskJson=preServiceJsons.get(serviceId);
                if(sendTaskJson!=null){
                    Long stayServerTime=sendTaskJson.getLong("stayServerTime");
                    if(stayServerTime!=null){
                        stayServerTime=(System.currentTimeMillis()-stayServerTime)/1000;
                        if(stayServerTime>60*2){
                            removeDieServer(sendTaskJson.getString("serverUrl"),serviceId);
                            size--;
                            preServiceJsons.remove(serviceId);
                        }
                    }
                }
                if(retrunSignInfo!=null&&!"".equals(retrunSignInfo)){
                    JSONObject resultInfo= JSONObject.parseObject(retrunSignInfo);
                    size--;
                    //清空此次缓存结果
                    util.delete(serviceId);
                    if(!resultInfo.getBoolean("sigleNeed")){
                        Map<String,Object>updateMap=new HashMap<>();
                        updateMap.put("docId",resultInfo.getLong("docId"));
                        updateMap.put("taskId",resultInfo.getLong("taskId"));
                        String signedPdfName=resultInfo.getString("signedPdfName");
                        if(resultInfo.getBoolean("hasError")||signedPdfName==null){
                            updateMap.put("status",2L);

                        }else {
                            updateMap.put("status",1L);

                            updateMap.put("documentUrl",signedPdfName);
                            int countStatus=exchangeFileItemMapper.updateSignDoc(updateMap);
                            if(countStatus>0&&StringUtils.isNotEmpty(signedPdfName)){
                                updateMap.put("status",1L);
                            }else {
                                updateMap.put("status",2L);
                            }

                        }
                        exchangeFileItemMapper.updateSignStatus(updateMap);
                    }else{
                        resultSignArray.add(resultInfo);
                    }



                    preServiceJsons.remove(serviceId);
                }

            }
            //不频繁刷新结果
            Thread.sleep(100);
            Long endTime=(System.currentTimeMillis()-startTime)/1000;
            //取结果超过10分钟退出
            if(endTime>60*3){
                break;
            }

        }
        for(JSONObject json :preServiceJsons.values()){
            resultSignArray.add(json);
        }
        result.put("signList",resultSignArray);

         return result;
    }

    @Override
    public JSONObject getCompnayInfo(Map<String, Object> signInfo) {
        List<Map<String,Object>>companyIDisNull=new ArrayList<>();
        JSONObject info=new JSONObject(signInfo);
        JSONArray compnays=info.getJSONArray("companyInfoList");
        for(int i=0;i<compnays.size();i++){
            Map<String,Object>map=new HashMap<>();
            JSONObject company=compnays.getJSONObject(i);
            if(company.getInteger("id")==null){
                map.put("companyName",company.getString("receiveCompanyName"));
                companyIDisNull.add(map);
            }

        }
        Map<String,Object>args=new HashMap<>();
        if(companyIDisNull.size()>0){
            args.put("merchantsList",companyIDisNull);
            ServerResponse response=companyFeign.queryMerchantCompany(args);
            Map<String,Integer>nameWithId=new HashMap<>();
            if(response.isSuccess()){
                List<Map<String, Object>>list= (List<Map<String, Object>>) response.getData();
                list.forEach(stringObjectMap -> {
                    nameWithId.put((String) stringObjectMap.get("companyName"),(Integer) stringObjectMap.get("companyNameId"));
                });
            }
            for(int i=0;i<compnays.size();i++){
                JSONObject company=compnays.getJSONObject(i);
                Integer id=nameWithId.get(company.getString("receiveCompanyName"));
                if(id!=null){
                    company.put("id",id);
                }
            }
            info.put("companyInfoList",compnays);
        }

        return info;
    }

    private void sendSignInfo(JSONObject json,  Set<String>serviceIds, Map<String,JSONObject> preServiceJsons,int type){

        String serviceId=json.getString("taskId")+"_"+json.getString("docId");



        String url=getServerUrl(serviceId,type);
        json.put("serverUrl",url);
        json.put("stayServerTime",System.currentTimeMillis());
        preServiceJsons.put(serviceId,json);
        if(url!=null){
            try{


                String[] serverInfo=url.split("#");
                Socket socket =new Socket(serverInfo[0],Integer.parseInt(serverInfo[1]));
                //2、获取输出流，向服务器端发送信息
                OutputStream os = socket.getOutputStream();//字节输出流
                PrintWriter pw =new PrintWriter(os);//将输出流包装成打印流
                pw.write(json.toJSONString());
                pw.flush();
                socket.shutdownOutput();
                pw.close();
                os.close();
                socket.close();
                log.info("send sign task taskid:"+serviceId+"==url==="+url);
                serviceIds.add(serviceId);
             }catch (Exception e){
                removeDieServer(url,serviceId);
            }
        }
        /*restTemplate.postForObject(REST_URL_PREFIX + "/sign", json.toJSONString()
                , String.class);*/

    }
    private void removeDieServer(String url,String serviceId){
        util.deleteListValue("SIGNSERVER",url);
        util.delete("service"+serviceId);
        util.delete(url);
        log.error("connect time out:"+url);
    }
    private String getServerUrl(String taskId,int type){
        List<String> upList = util.searchList("SIGNSERVER");

        Object serivceId=util.get("service"+taskId);
        if(serivceId!=null){
            if(type==0){
                //清除之前数据
               util.delete(taskId);
            }
            return (String) serivceId;
        }else{
            for(String chooseServer:upList){
                String instanceId= chooseServer;
                Integer status=(Integer)util.get(instanceId);
                //还未签章，找可用服务即可
                if(status==1){
                    util.set(instanceId,2);
                    util.delete("service"+taskId);
                    util.delete(taskId);
                    util.set("service"+taskId,instanceId);
                    return instanceId;
                }
            }
        }
        return null;
    }
    /**
     * create by: hym
     * description:发送任务扣费
     * create time: 15:42 2019/2/26
     *
      * @Param: null
     * @return
     */
    private void charging(List<Integer>jobIds,int compId) throws Exception {

        ExchangeProjectExample exchangeProjectExample=new ExchangeProjectExample();
        ExchangeProjectExample.Criteria exchangeProjectExampleCriteria=exchangeProjectExample.createCriteria();
        exchangeProjectExampleCriteria.andJobIdIn(jobIds);
        List<Integer>themeTypes=new ArrayList<>();
        themeTypes.add(1);
        themeTypes.add(2);
        themeTypes.add(3);
        themeTypes.add(4);

        exchangeProjectExampleCriteria.andThemeTypeIn(themeTypes);
        exchangeProjectExampleCriteria.andDeleteFlagEqualTo(0+"");
        List<ExchangeProject>exchangeProjects=exchangeProjectMapper.selectByExample(exchangeProjectExample);
        Map<Integer,Integer>projectCount=new HashMap<>();
        //统计一个任务下主题数目
        exchangeProjects.forEach(exchangeProject -> {
            Integer jobId=exchangeProject.getJobId();
            Integer count=projectCount.get(exchangeProject.getJobId());
            if(count!=null){
                projectCount.put(jobId,count+1);
            }else{
                projectCount.put(jobId,1);
            }
        });
        ExchangeJobReceiveCompanyExample exchangeJobReceiveCompanyExample=new ExchangeJobReceiveCompanyExample();
        ExchangeJobReceiveCompanyExample.Criteria criteria=exchangeJobReceiveCompanyExample.createCriteria();
        criteria.andDeleteFlagEqualTo(0+"");
        criteria.andJobIdIn(jobIds);
        List<ExchangeJobReceiveCompany>companies=exchangeJobReceiveCompanyMapper.selectByExample(exchangeJobReceiveCompanyExample);
        int count=exchangeProjects.size();
        JSONArray costInfos=new JSONArray();
        companies.forEach(exchangeJobReceiveCompany -> {
            JSONObject info=new JSONObject();

            info.put("costCount",count);
            info.put("jobId",exchangeJobReceiveCompany.getJobId());
            info.put("name",exchangeJobReceiveCompany.getReceiveCompanyName());
            info.put("flag",true);
            info.put("comId",compId);
            info.put("receiveID",exchangeJobReceiveCompany.getReceiveCompanyId());
            info.put("costCount",projectCount.get(exchangeJobReceiveCompany.getJobId()));
            costInfos.add(info);
        });


       /* ServerResponse serverResponse=chargeFeign.charging(costInfos.toJSONString());
       //扣费失败，回滚事物
        if(!serverResponse.isSuccess()){
            throw new Exception();
        }*/

    }
    /**
     * create by: hym
     * description:给未注册企业发消息
     * create time: 13:55 2019/4/13
     *
      * @Param: null
     * @return
     */
   private void sendMessageForUnRegisterCompany(List<Integer>jobIds,String companyName){
        new Thread(()->{
            ExchangeJobReceiveCompanyExample exchangeJobReceiveCompanyExample=new ExchangeJobReceiveCompanyExample();
            ExchangeJobReceiveCompanyExample.Criteria criteria=exchangeJobReceiveCompanyExample.createCriteria();
            criteria.andJobIdIn(jobIds);
            criteria.andReceiveCompanyIdIsNull();
            criteria.andTelIsNotNull();
            List<ExchangeJobReceiveCompany>compnays=exchangeJobReceiveCompanyMapper.selectByExample(exchangeJobReceiveCompanyExample);
            compnays.forEach(exchangeJobReceiveCompany -> {
                try {
                    String username="h2-zwsmsypt";
                    String password="h2-zwsmsypt";
                    Map<String,Object> baseMap = new HashMap<String, Object>();
                    baseMap.put("username", username);
                    baseMap.put("password", password);
                    JSONObject map=new JSONObject(baseMap);
                    String prefixUrl="http://180.76.110.67:5880";
                    String content = exchangeJobReceiveCompany.getTel()+"|"+companyName;
                    map.put("templateid", "10000902");
                    String url = prefixUrl.concat("/template/send");
                    List<String> list = new ArrayList<String>();
                    list.add(content);
                    map.put("extcode", "");
                    map.put("content", list);
                    RestTemplate restTemplate=new RestTemplate();
                    String json =map.toJSONString();
                    json= URLEncoder.encode(json, "UTF-8");
                    String result=restTemplate.postForObject(url,json,String.class);
                    log.info("url="+url+",info="+json+"result="+result);
                    //SMSUtil.smsSend(exchangeJobReceiveCompany.getReceiveCompanyName(),"fasongweizhuce",companyName);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        }).start();
   }


}
