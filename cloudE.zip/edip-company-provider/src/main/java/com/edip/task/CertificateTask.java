package com.edip.task;

import com.alibaba.fastjson.JSONObject;
import com.edip.controller.MessageClient;
import com.edip.mapper.CertMapperVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

@Lazy(false)
@Component
@EnableScheduling
public class CertificateTask implements SchedulingConfigurer {
    /**
     *  通过自动注入启动任务调度
     *
     *     @Autowired
     *    DynamicScheduledTask dynamicScheduledTask;
     *
     */

    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private static String CERTIFICATE_REMIND;
    @Value("${certificate_remind}")
    public void setCERTIFICATE_REMIND(String CERTIFICATE_REMIND) {
        this.CERTIFICATE_REMIND = CERTIFICATE_REMIND;
    }

    //   private static final String DEFAULT_CRON = "*/5 * * * * ? ";
    private String cron = CERTIFICATE_REMIND;
    @Autowired
    private CertMapperVo certMapperVo;
    @Autowired
    private MessageClient messageClient;
    /**
     * 获取任务执行规则
     * @return
     */
    public String getCron() {
        return cron;
    }

    /**
     * 设置任务执行规则
     * @param cron
     */
    public void setCron(String cron) {
        this.cron = cron;
    }

    //@Bean(destroyMethod = "shutdown")
    @Bean
    public Executor taskExecutor() {
        return Executors.newScheduledThreadPool(5);
    }

    @Override
    public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
        //用于设置定时任务线程数，默认不设置的话为单线程
        // taskRegistrar.setScheduler(taskExecutor());
        taskRegistrar.addTriggerTask(new Runnable() {
            @Override
            public void run() {
                // 任务逻辑
                logger.debug("dynamicCronTask is running....");
                List<Map> listMap = certMapperVo.getCertificateOverdueList();
                for(Map cert : listMap){
                    JSONObject json = new JSONObject();
                    json.put("msgType",1);//消息类型:1 首营端消息 2 管理端消息
                    json.put("dataId",cert.get("certID"));
                    json.put("receiveCompID",cert.get("compID"));
                    json.put("dataType",5);//实体类型 0:公司 1:人员 2:产品 3:合同 4:图章 5:证书 6:项目
                    json.put("sender","提醒：");
                    json.put("title","您的数字证书，即将到期，请尽快更新。若已处理，请忽略");
                    json.put("content","您的数字证书，即将到期，请尽快更新。若已处理，请忽略");
                    json.put("classify",1);//消息标识 0 系统消息，1 到期提醒，2 更新提醒，3 系统公告，4 优惠活动
                    json.put("newUrl","account/certificate/index?mid=39&tabIndex=1");
                    json.put("roleName","系统管理员");
                    messageClient.messageSend(json.toJSONString());
                }
                System.out.println("定时任务开始了。。。。。。。。。。。。。。。。。。。。。。。。。。。。");
            }
        }, new Trigger() {
            @Override
            public Date nextExecutionTime(TriggerContext triggerContext) {
                // 任务触发，可修改任务的执行周期
                CronTrigger trigger = new CronTrigger(CERTIFICATE_REMIND);
                Date nextExec = trigger.nextExecutionTime(triggerContext);
                return nextExec;
            }
        });
    }
}
