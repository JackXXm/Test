package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class StampChangeResore implements Serializable {
    /**
     * 主键ID
     */
    private Integer id;

    /**
     * 印章id
     */
    private Integer stampId;

    /**
     * 原印章路径
     */
    private String oldStampUrl;

    /**
     * 变更后印章路径
     */
    private String newStampUrl;

    /**
     * 变更审核状态：/0:未审核，1:审核已通过，2:审核未通过
     */
    private Integer status;

    /**
     * 变更时间
     */
    private Date createTime;

    /**
     * 变更发起人id
     */
    private Integer createAccountId;

    /**
     * 变更发起人名称
     */
    private String createAccountName;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStampId() {
        return stampId;
    }

    public void setStampId(Integer stampId) {
        this.stampId = stampId;
    }

    public String getOldStampUrl() {
        return oldStampUrl;
    }

    public void setOldStampUrl(String oldStampUrl) {
        this.oldStampUrl = oldStampUrl;
    }

    public String getNewStampUrl() {
        return newStampUrl;
    }

    public void setNewStampUrl(String newStampUrl) {
        this.newStampUrl = newStampUrl;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateAccountId() {
        return createAccountId;
    }

    public void setCreateAccountId(Integer createAccountId) {
        this.createAccountId = createAccountId;
    }

    public String getCreateAccountName() {
        return createAccountName;
    }

    public void setCreateAccountName(String createAccountName) {
        this.createAccountName = createAccountName;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        StampChangeResore other = (StampChangeResore) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getStampId() == null ? other.getStampId() == null : this.getStampId().equals(other.getStampId()))
            && (this.getOldStampUrl() == null ? other.getOldStampUrl() == null : this.getOldStampUrl().equals(other.getOldStampUrl()))
            && (this.getNewStampUrl() == null ? other.getNewStampUrl() == null : this.getNewStampUrl().equals(other.getNewStampUrl()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateAccountId() == null ? other.getCreateAccountId() == null : this.getCreateAccountId().equals(other.getCreateAccountId()))
            && (this.getCreateAccountName() == null ? other.getCreateAccountName() == null : this.getCreateAccountName().equals(other.getCreateAccountName()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getStampId() == null) ? 0 : getStampId().hashCode());
        result = prime * result + ((getOldStampUrl() == null) ? 0 : getOldStampUrl().hashCode());
        result = prime * result + ((getNewStampUrl() == null) ? 0 : getNewStampUrl().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateAccountId() == null) ? 0 : getCreateAccountId().hashCode());
        result = prime * result + ((getCreateAccountName() == null) ? 0 : getCreateAccountName().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", stampId=").append(stampId);
        sb.append(", oldStampUrl=").append(oldStampUrl);
        sb.append(", newStampUrl=").append(newStampUrl);
        sb.append(", status=").append(status);
        sb.append(", createTime=").append(createTime);
        sb.append(", createAccountId=").append(createAccountId);
        sb.append(", createAccountName=").append(createAccountName);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}