package com.edip.controller;

import com.alibaba.fastjson.JSONObject;
import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.dto.util.Page;
import com.edip.entity.ExchangeInfo;
import com.edip.service.ExchangeService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

/**
 * @author lilin
 * @description 我要发送
 * @DATE 2018/12/26 0026 19:13
 */
@RestController
public class ExchangeController {
    @Autowired
    private ExchangeService exchangeService;


    @RequestMapping("/receiveCompany.ajax")
    public ServerResponse queryReceiveCompany(HttpServletRequest request,
                                              String searchKey,
                                              @NotBlank(message = "搜索类型不能为空") String searchType,int page,int rows) throws Exception {
        HttpSession session = SessionContext.getContext().getSession(request);
        Integer compID = (Integer) session.getAttribute("compID");
        String companyName = (String) SessionContext.getContext().getSession(request).getAttribute("companyName");

        ;
        return ServerResponse.createBySuccess("success", exchangeService.queryReceiveCompany(compID, companyName, searchKey, searchType,page,rows));
    }




    /**
     * 获取产品详细信息
     * @return
     */
    @RequestMapping("/getCheckReportDetail.ajax")
    @ResponseBody
    public ServerResponse getCheckReportDetail(@RequestBody Map<String,Object>args) throws Exception{
        return exchangeService.getCheckReportDetail(args);
    }

    /**
     * 提交我要发送
     * @param exchangeInfo
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping("/sendCheckExchangeInfo.ajax")
    public ServerResponse sendCheckExchangeInfo(@RequestBody ExchangeInfo exchangeInfo, HttpServletRequest request) throws Exception{
        int compID = (int)SessionContext.getContext().getSession(request).getAttribute("compID");
        int accountID = (int)SessionContext.getContext().getSession(request).getAttribute("accountID");
        String accountName = (String) SessionContext.getContext().getSession(request).getAttribute("accountName");
        String companyName = (String) SessionContext.getContext().getSession(request).getAttribute("companyName");
        return exchangeService.sendCheckExchangeInfo(exchangeInfo,compID,accountID,accountName,companyName);
    }
    /**
     * 获取我要发送资质信息
     * @param exchangeInfo
     * @param request
     * @return
     * @throws Exception
     */
    @RequestMapping("/getSendReportDocDetail.ajax")
    public ServerResponse getSendReportDocDetail(@RequestBody Map<String,Object>args) throws Exception{

        return exchangeService.getSendReportDocDetail( args);
    }


}
