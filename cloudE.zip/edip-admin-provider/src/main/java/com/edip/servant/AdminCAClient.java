package com.edip.servant;

import com.edip.utils.AdminCertificateConstant;
import com.edip.vo.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.DocumentException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * CAClient.java 2012-8-3 CA客户端操作类
 * 
 * @System: CA 1.0
 * @Description:
 * @Copyright: Copyright (c) 2012
 * @Company: Aspire Technologies
 * @version 1.0
 * @author: zhangjie
 */
@Component
public class AdminCAClient {
	private static final Log logger = LogFactory.getLog(AdminCAClient.class);


	private static String DOWNLOADCERT_URL;
	@Value("${downloadCert_url}")
	public void setDOWNLOADCERT_URL(String DOWNLOADCERT_URL) {
		this.DOWNLOADCERT_URL = DOWNLOADCERT_URL;
	}
	private static String REVOKECERT_URL;
	@Value("${revokeCert_url}")
	public void setREVOKECERT_URL(String REVOKECERT_URL) {
		this.REVOKECERT_URL = REVOKECERT_URL;
	}
	private static String UPDATECERT_URL;
	@Value("${updateCert_url}")
	public void setUPDATECERT_URL(String UPDATECERT_URL) {
		this.UPDATECERT_URL = UPDATECERT_URL;
	}
	private static String APPLYENTCERT_URL;
	@Value("${applyEntCert_url}")
	public void setAPPLYENTCERT_URL(String APPLYENTCERT_URL) {
		this.APPLYENTCERT_URL = APPLYENTCERT_URL;
	}

	public AdminCAClient() {

	}

	/**
	 * @description: 申请企业证书
	 * @param applyEntCertReqVO
	 *            申请企业证书请求VO
	 * @return CertResponseVO
	 * @throws CaCommunicationException
	 * @throws DocumentException
	 */
	public static AdminCertResponseVO applyEntcert(
			AdminApplyEntCertReqVO applyEntCertReqVO)
			throws Exception{
		logger.debug("Enter into applyEntcert of CAClient!******");
		String reqXml = applyEntCertReqVO.toXML();
		String responseXml = AdminXFireClient.webServiceReq(
				AdminCertificateConstant.OPERATION_NAME_APPENTCERT, APPLYENTCERT_URL, reqXml);
		AdminCertResponseVO certResponseVO = new AdminCertResponseVO(responseXml);// 将响应xml转化为VO

		return certResponseVO;
	}

	/**
	 * @description: 下载证书
	 * @param downloadCertReqVO
	 *            证书下载请求VO
	 * @return CertResponseVO
	 * @throws CaCommunicationException
	 * @throws DocumentException
	 */
	public static AdminCertResponseVO downloadCert(
			AdminDownloadCertReqVO downloadCertReqVO)
			throws Exception {
		logger.debug("Enter into downloadCert of CAClient!******");
		String reqXml = null;
		String responseXml = null;
		AdminCertResponseVO certResponseVO = null;

		reqXml = downloadCertReqVO.toXML();
		responseXml = AdminXFireClient.webServiceReq(
				AdminCertificateConstant.OPERATION_NAME_DOWNLOADCERT, DOWNLOADCERT_URL, reqXml);
		certResponseVO = new AdminCertResponseVO(responseXml);// 将响应xml转化为VO

		return certResponseVO;
	}

	/**
	 * 吊销证书
	 * 
	 * @param revokeCertReqVO
	 * @return
	 * @throws CaCommunicationException
	 * @throws DocumentException
	 */
	public static RevokeCertRespVO revokeCert(RevokeCertReqVO revokeCertReqVO)
			throws Exception, DocumentException {
		logger.debug("Enter into revokeCert of CAClient!******");
		RevokeCertRespVO revokeCertRespVO = null;
		String reqXml = revokeCertReqVO.toXML();
		String responseXml = null;
		responseXml = AdminXFireClient.webServiceReq(
				AdminCertificateConstant.OPERATION_NAME_REVOKECERT, REVOKECERT_URL, reqXml);
		revokeCertRespVO = new RevokeCertRespVO(responseXml);
		return revokeCertRespVO;
	}
	public static AdminUpdateCertRespVO updateCert(AdminUpdateCertReqVO updateCertReqVO)
			throws Exception {
		logger.debug("Enter into revokeCert of CAClient!********");
		AdminUpdateCertRespVO updateCertRespVO = null;
		String reqXml = updateCertReqVO.toXML();
		String responseXml = null;
		responseXml = AdminXFireClient.webServiceReq(
				AdminCertificateConstant.OPERATION_NAME_UPDATECERT, UPDATECERT_URL, reqXml);
		updateCertRespVO = new AdminUpdateCertRespVO(responseXml);
		return updateCertRespVO;
	}

}
