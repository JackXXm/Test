package com.edip.mapper;

import java.util.List;

import com.edip.entity.AdminMessagestatus;
import com.edip.entity.AdminMessagestatusExample;
import org.apache.ibatis.annotations.Param;

public interface AdminMessagestatusMapper {
    int countByExample(AdminMessagestatusExample example);

    int deleteByExample(AdminMessagestatusExample example);

    int insert(AdminMessagestatus record);

    int insertSelective(AdminMessagestatus record);
    
    int  countIs(AdminMessagestatus record);

    List<AdminMessagestatus> selectByExampleWithPage(@Param("example") AdminMessagestatusExample example, @Param("from") Integer from, @Param("to") Integer to);

    List<AdminMessagestatus> selectByExample(AdminMessagestatusExample example);

    int updateByExampleSelective(@Param("record") AdminMessagestatus record, @Param("example") AdminMessagestatusExample example);

    int updateByExample(@Param("record") AdminMessagestatus record, @Param("example") AdminMessagestatusExample example);
}