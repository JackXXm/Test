package com.edip.vo;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.edip.entity.AccountExample;
import com.edip.entity.AccountExample.Criteria;
import org.springframework.util.StringUtils;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by qiaoxiaolong on 2017/5/9.
 */
public class AccountUtil {
    public static final Integer STATUS_NORMAL = 0;
    public static final Integer STATUS_DSH = 1; // 待审核
    public static final Integer STATUS_SH = 0; // 正常
    public static final Integer STATUS_PASS         = 9;                    //审核未通过
    public static final Integer STATUS_OPER = 0; // 新增
    public static final Integer DOMAIN_SP = 1; // 服务提供企业
    public static final Integer DOMAIN_MP           = 0;                    // 管理端0
    public static final Integer DOMAIN_AP           = 0;                    // 管理端0
    public static final Integer DOMAIN_RP = 2; // 监管机构
    public static final Integer MSISDN_LENGTH = 11; // 手机号码长度
    public static final Integer VERRIFY_SUCCESS = 0; // 短信验证码校验成功
    public static final Integer VERRIFY_NOTMATCH = 1; // 验证码不匹配
    public static final Integer VERRIFY_EXPIRED = 2; // 验证码超时
    public static final Integer VERRIFY_INVALIDPHONE = 3; // 手机号码无效
    public static final Integer VERRIFY_INVALIDCODE = 4; // 验证码无效
    public static final Integer GUAVACACHE_MAXSIZE = 5000; // guava缓存最大容量
    public static final Integer GUAVACACHE_EXPIRETIME = 15; // guava缓存失效时间（分钟）
    public static final Integer CDRTYPE_SMS = 0; // 话单类型 短信
    public static final Integer CDRTYPE_CREDQUERY = 1; // 话单类型  资质查询
    public static final Integer CDRTYPE_CERT = 2; // 话单类型 证书
    public static final Integer CDRTYPE_EXCHANGE = 4; // 话单类型  数据交换
    public static final Integer CDRSUBTYPE_VERIFYSMS = 0; // 话单子类型 验证短信
    public static final Integer CDRSUBTYPE_NOTIFYSMS = 10; // 话单子类型 通知短信
    public static final Integer CDRSUBTYPE_COMPCRED = 10; // 话单子类型 企业资质
    public static final Integer CDRSUBTYPE_INDIVCRED = 11; // 话单子类型 个人资质
    public static final Integer CDRSUBTYPE_INDIVCERT = 20; // 话单子类型 个人证书
    public static final Integer CDRSUBTYPE_COMPCERT = 21; // 话单子类型 企业证书
    public static final String DUAULT_NULL = "XXXXX";
    public static final String  BASE_ROLE_SP        = "sp_company_register";
    public static final String  BASE_ROLE_MP        = "mp_manager_system";  // 管理端的默认的账号
    public static final String  BASE_ROLE_AP        = "ap_manager_system";  // 管理端的默认的账号
    public static final String  BASE_ROLE_RP        = "rp_manager_system";  // 监管端的默认的账号
    public static final String BASE_ROLE_SP_REGISTER_EXIST = "sp_unformal_register";//非正式用户（注册已有公司的角色）
    public static final Integer MESSAGE_TYPE_USER = 0; // 消息类型 用户消息
    public static final Integer MESSAGE_DATA_TYPE = 0; // 实体类型 公司
    public static final String MESSAGE_SEND_TITTLE = "企业信息"; // 服务提供企业
    public static final String MESSAGE_URL = ""; // 对应管理端要打开的url界面
    public static final Integer MESSAGE_STATUS_DSH = 0; // 状态类型 待审核
    public static final Integer MESSAGE_VALIDDAY = 24; // 消息有效日期 单位小时
    public static final String  MANAGER_COUNTRY     = "manager-country";    //管理员角色 国际级
    public static final String  MANAGER_PROVINCE    = "manager-province";   //管理员角色 省级
    public static final String  MANAGER_CITY        = "manager-city";       //管理员角色 市级
    public static final String  MANAGER_SP           = "manager-sp";         //sp注册的管理员

    public static AccountExample getAccountExample(AccountVo accountVo) {
        AccountExample example = new AccountExample();
        if (accountVo == null) {
            return example;
        }
        Criteria cerit = example.createCriteria();
        if (accountVo.getCompID() != null) {
            cerit.andCompIDEqualTo(accountVo.getCompID());
        }
        if (StringUtils.hasText(accountVo.getAliasName())) {
            cerit.andAliasNameLike("%" + accountVo.getAliasName() + "%");
        }
        if (StringUtils.hasText(accountVo.getName())) {
            cerit.andNameLike("%" + accountVo.getName() + "%");
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            if (StringUtils.hasText(accountVo.getBeginDateString())) {
                cerit.andCreateDateGreaterThanOrEqualTo(sdf.parse(accountVo.getBeginDateString()));
            }
            if (StringUtils.hasText(accountVo.getEndDateString())) {
                cerit.andCreateDateLessThanOrEqualTo(sdf.parse(accountVo.getEndDateString()));
            }
        } catch (ParseException e) {

        }
        if (accountVo.getBeginDate() != null) {
            cerit.andCreateDateGreaterThanOrEqualTo(accountVo.getBeginDate());
        }
        if (accountVo.getEndDate() != null) {
            cerit.andCreateDateLessThanOrEqualTo(accountVo.getBeginDate());
        }
        if (accountVo.getStatus() == null) {
            cerit.andStatusNotEqualTo(-1);
        } else {
            cerit.andStatusEqualTo(accountVo.getStatus());
        }
        return example;

    }

    /**
     * 设置账户列表内查询条件
     *
     * @param param
     */
    public static void setQueryParam(AccountVo param) {
        if (param == null) {
            return;
        }
        if (StringUtils.hasText(param.getAliasName())) {
            param.setAliasName("%" + param.getAliasName() + "%");
        }
        if (StringUtils.hasText(param.getName())) {
            param.setName("%" + param.getName() + "%");
        }
        try {
            // 开始时间默认当天0点，结束时间默认当天24点
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            if (StringUtils.hasText(param.getBeginDateString())) {
                param.setBeginDate(sdf.parse(param.getBeginDateString() + " 00:00:00"));
            }
            if (StringUtils.hasText(param.getEndDateString())) {
                param.setEndDate(sdf.parse(param.getEndDateString() + " 23:59:59"));
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        List<String> accountTypes = new ArrayList<String>();
        if (StringUtils.hasText(param.getAccountType())) {
            if ("sp_ukey".equals(param.getAccountType())) {
                accountTypes.add(param.getAccountType());
                accountTypes.add("sp_company_ukey");
            }else{
                accountTypes.add(param.getAccountType());
            }

        }

        param.setAccountTypeList(accountTypes);
        int page = param.getPage();
        int pageSize = param.getRows();
        param.setFrom((page - 1) * pageSize);
        param.setTo(page * pageSize);
    }
}
