package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class AuditStampHistory implements Serializable {
    /**
     * 主键ID
     */
    private Integer id;

    /**
     * 印章id
     */
    private Integer stampid;

    /**
     * 审核人
     */
    private String opername;

    /**
     * 审核意见
     */
    private String auditinfo;

    /**
     *  审核状态：/0:审核通过，1:未审核  9:审核未通过
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 审核时间
     */
    private Date operdate;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStampid() {
        return stampid;
    }

    public void setStampid(Integer stampid) {
        this.stampid = stampid;
    }

    public String getOpername() {
        return opername;
    }

    public void setOpername(String opername) {
        this.opername = opername;
    }

    public String getAuditinfo() {
        return auditinfo;
    }

    public void setAuditinfo(String auditinfo) {
        this.auditinfo = auditinfo;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getOperdate() {
        return operdate;
    }

    public void setOperdate(Date operdate) {
        this.operdate = operdate;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AuditStampHistory other = (AuditStampHistory) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getStampid() == null ? other.getStampid() == null : this.getStampid().equals(other.getStampid()))
            && (this.getOpername() == null ? other.getOpername() == null : this.getOpername().equals(other.getOpername()))
            && (this.getAuditinfo() == null ? other.getAuditinfo() == null : this.getAuditinfo().equals(other.getAuditinfo()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getOperdate() == null ? other.getOperdate() == null : this.getOperdate().equals(other.getOperdate()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getStampid() == null) ? 0 : getStampid().hashCode());
        result = prime * result + ((getOpername() == null) ? 0 : getOpername().hashCode());
        result = prime * result + ((getAuditinfo() == null) ? 0 : getAuditinfo().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getOperdate() == null) ? 0 : getOperdate().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", stampid=").append(stampid);
        sb.append(", opername=").append(opername);
        sb.append(", auditinfo=").append(auditinfo);
        sb.append(", status=").append(status);
        sb.append(", createTime=").append(createTime);
        sb.append(", operdate=").append(operdate);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}