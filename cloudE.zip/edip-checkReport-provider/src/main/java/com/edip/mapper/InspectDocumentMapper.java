package com.edip.mapper;

import com.edip.entity.DocumentVo;
import com.edip.entity.InspectDocument;
import com.edip.entity.InspectDocumentExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InspectDocumentMapper {
    long countByExample(InspectDocumentExample example);

    int deleteByExample(InspectDocumentExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(InspectDocument record);

    int insertSelective(InspectDocument record);

    List<InspectDocument> selectByExample(InspectDocumentExample example);

    InspectDocument selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") InspectDocument record, @Param("example") InspectDocumentExample example);

    int updateByExample(@Param("record") InspectDocument record, @Param("example") InspectDocumentExample example);

    int updateByPrimaryKeySelective(InspectDocument record);

    int updateByPrimaryKey(InspectDocument record);

    void cloneCheckDoc(DocumentVo documentVo);
}