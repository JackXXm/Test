package com.edip.dto.util;

public class CacheKey {
	public static final String ALL_MENU = "ALL_MENU";
	public static final String USER_MENU = "USE_MENU_";
	
	public static final String ROLE_MENU = "ROLE_MENU_";
	
	public static final String UN_AUTH_MENU_DOMAIN = "UN_AUTH_MENU_DOMAIN_";
	
	
	public static final String AUTH = "AUTH";
	public static final String LOGIN_AUTH = "LOGIN_AUTH";
	public static final String UNAUTH = "UNAUTH";
	
	public static final String SUBSYSTEM = "SUBSYSTEM_";
	
	public static final String DICVALUE = "DICVALUE";

	public static final String DIC = "DIC";

	public static final String DICATTRIBUTE = "DICATTRIBUTE";

	public static final String DICLIST = "DICLIST";

    public static final String ALL_COMPANYTYPE_LIST = "ALL_COMPANYTYPE_LIST";

    public static final String ALL_PRODUCTTYPE_LIST = "ALL_PRODUCTTYPE_LIST";


}
