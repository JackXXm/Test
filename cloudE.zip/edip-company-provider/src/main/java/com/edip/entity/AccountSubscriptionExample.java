package com.edip.entity;

import java.util.ArrayList;
import java.util.List;

public class AccountSubscriptionExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public AccountSubscriptionExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAccountidIsNull() {
            addCriterion("accountID is null");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNotNull() {
            addCriterion("accountID is not null");
            return (Criteria) this;
        }

        public Criteria andAccountidEqualTo(Integer value) {
            addCriterion("accountID =", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotEqualTo(Integer value) {
            addCriterion("accountID <>", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThan(Integer value) {
            addCriterion("accountID >", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThanOrEqualTo(Integer value) {
            addCriterion("accountID >=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThan(Integer value) {
            addCriterion("accountID <", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThanOrEqualTo(Integer value) {
            addCriterion("accountID <=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidIn(List<Integer> values) {
            addCriterion("accountID in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotIn(List<Integer> values) {
            addCriterion("accountID not in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidBetween(Integer value1, Integer value2) {
            addCriterion("accountID between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotBetween(Integer value1, Integer value2) {
            addCriterion("accountID not between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andCompidIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompidIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompidEqualTo(Integer value) {
            addCriterion("compID =", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThan(Integer value) {
            addCriterion("compID >", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThan(Integer value) {
            addCriterion("compID <", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidIn(List<Integer> values) {
            addCriterion("compID in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andSystemstatusIsNull() {
            addCriterion("systemStatus is null");
            return (Criteria) this;
        }

        public Criteria andSystemstatusIsNotNull() {
            addCriterion("systemStatus is not null");
            return (Criteria) this;
        }

        public Criteria andSystemstatusEqualTo(Boolean value) {
            addCriterion("systemStatus =", value, "systemstatus");
            return (Criteria) this;
        }

        public Criteria andSystemstatusNotEqualTo(Boolean value) {
            addCriterion("systemStatus <>", value, "systemstatus");
            return (Criteria) this;
        }

        public Criteria andSystemstatusGreaterThan(Boolean value) {
            addCriterion("systemStatus >", value, "systemstatus");
            return (Criteria) this;
        }

        public Criteria andSystemstatusGreaterThanOrEqualTo(Boolean value) {
            addCriterion("systemStatus >=", value, "systemstatus");
            return (Criteria) this;
        }

        public Criteria andSystemstatusLessThan(Boolean value) {
            addCriterion("systemStatus <", value, "systemstatus");
            return (Criteria) this;
        }

        public Criteria andSystemstatusLessThanOrEqualTo(Boolean value) {
            addCriterion("systemStatus <=", value, "systemstatus");
            return (Criteria) this;
        }

        public Criteria andSystemstatusIn(List<Boolean> values) {
            addCriterion("systemStatus in", values, "systemstatus");
            return (Criteria) this;
        }

        public Criteria andSystemstatusNotIn(List<Boolean> values) {
            addCriterion("systemStatus not in", values, "systemstatus");
            return (Criteria) this;
        }

        public Criteria andSystemstatusBetween(Boolean value1, Boolean value2) {
            addCriterion("systemStatus between", value1, value2, "systemstatus");
            return (Criteria) this;
        }

        public Criteria andSystemstatusNotBetween(Boolean value1, Boolean value2) {
            addCriterion("systemStatus not between", value1, value2, "systemstatus");
            return (Criteria) this;
        }

        public Criteria andExchangestatusIsNull() {
            addCriterion("exchangeStatus is null");
            return (Criteria) this;
        }

        public Criteria andExchangestatusIsNotNull() {
            addCriterion("exchangeStatus is not null");
            return (Criteria) this;
        }

        public Criteria andExchangestatusEqualTo(Boolean value) {
            addCriterion("exchangeStatus =", value, "exchangestatus");
            return (Criteria) this;
        }

        public Criteria andExchangestatusNotEqualTo(Boolean value) {
            addCriterion("exchangeStatus <>", value, "exchangestatus");
            return (Criteria) this;
        }

        public Criteria andExchangestatusGreaterThan(Boolean value) {
            addCriterion("exchangeStatus >", value, "exchangestatus");
            return (Criteria) this;
        }

        public Criteria andExchangestatusGreaterThanOrEqualTo(Boolean value) {
            addCriterion("exchangeStatus >=", value, "exchangestatus");
            return (Criteria) this;
        }

        public Criteria andExchangestatusLessThan(Boolean value) {
            addCriterion("exchangeStatus <", value, "exchangestatus");
            return (Criteria) this;
        }

        public Criteria andExchangestatusLessThanOrEqualTo(Boolean value) {
            addCriterion("exchangeStatus <=", value, "exchangestatus");
            return (Criteria) this;
        }

        public Criteria andExchangestatusIn(List<Boolean> values) {
            addCriterion("exchangeStatus in", values, "exchangestatus");
            return (Criteria) this;
        }

        public Criteria andExchangestatusNotIn(List<Boolean> values) {
            addCriterion("exchangeStatus not in", values, "exchangestatus");
            return (Criteria) this;
        }

        public Criteria andExchangestatusBetween(Boolean value1, Boolean value2) {
            addCriterion("exchangeStatus between", value1, value2, "exchangestatus");
            return (Criteria) this;
        }

        public Criteria andExchangestatusNotBetween(Boolean value1, Boolean value2) {
            addCriterion("exchangeStatus not between", value1, value2, "exchangestatus");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusIsNull() {
            addCriterion("announcementStatus is null");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusIsNotNull() {
            addCriterion("announcementStatus is not null");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusEqualTo(Boolean value) {
            addCriterion("announcementStatus =", value, "announcementstatus");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusNotEqualTo(Boolean value) {
            addCriterion("announcementStatus <>", value, "announcementstatus");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusGreaterThan(Boolean value) {
            addCriterion("announcementStatus >", value, "announcementstatus");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusGreaterThanOrEqualTo(Boolean value) {
            addCriterion("announcementStatus >=", value, "announcementstatus");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusLessThan(Boolean value) {
            addCriterion("announcementStatus <", value, "announcementstatus");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusLessThanOrEqualTo(Boolean value) {
            addCriterion("announcementStatus <=", value, "announcementstatus");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusIn(List<Boolean> values) {
            addCriterion("announcementStatus in", values, "announcementstatus");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusNotIn(List<Boolean> values) {
            addCriterion("announcementStatus not in", values, "announcementstatus");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusBetween(Boolean value1, Boolean value2) {
            addCriterion("announcementStatus between", value1, value2, "announcementstatus");
            return (Criteria) this;
        }

        public Criteria andAnnouncementstatusNotBetween(Boolean value1, Boolean value2) {
            addCriterion("announcementStatus not between", value1, value2, "announcementstatus");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusIsNull() {
            addCriterion("favourableStatus is null");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusIsNotNull() {
            addCriterion("favourableStatus is not null");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusEqualTo(Boolean value) {
            addCriterion("favourableStatus =", value, "favourablestatus");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusNotEqualTo(Boolean value) {
            addCriterion("favourableStatus <>", value, "favourablestatus");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusGreaterThan(Boolean value) {
            addCriterion("favourableStatus >", value, "favourablestatus");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusGreaterThanOrEqualTo(Boolean value) {
            addCriterion("favourableStatus >=", value, "favourablestatus");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusLessThan(Boolean value) {
            addCriterion("favourableStatus <", value, "favourablestatus");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusLessThanOrEqualTo(Boolean value) {
            addCriterion("favourableStatus <=", value, "favourablestatus");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusIn(List<Boolean> values) {
            addCriterion("favourableStatus in", values, "favourablestatus");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusNotIn(List<Boolean> values) {
            addCriterion("favourableStatus not in", values, "favourablestatus");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusBetween(Boolean value1, Boolean value2) {
            addCriterion("favourableStatus between", value1, value2, "favourablestatus");
            return (Criteria) this;
        }

        public Criteria andFavourablestatusNotBetween(Boolean value1, Boolean value2) {
            addCriterion("favourableStatus not between", value1, value2, "favourablestatus");
            return (Criteria) this;
        }

        public Criteria andTimeremindIsNull() {
            addCriterion("timeRemind is null");
            return (Criteria) this;
        }

        public Criteria andTimeremindIsNotNull() {
            addCriterion("timeRemind is not null");
            return (Criteria) this;
        }

        public Criteria andTimeremindEqualTo(Boolean value) {
            addCriterion("timeRemind =", value, "timeremind");
            return (Criteria) this;
        }

        public Criteria andTimeremindNotEqualTo(Boolean value) {
            addCriterion("timeRemind <>", value, "timeremind");
            return (Criteria) this;
        }

        public Criteria andTimeremindGreaterThan(Boolean value) {
            addCriterion("timeRemind >", value, "timeremind");
            return (Criteria) this;
        }

        public Criteria andTimeremindGreaterThanOrEqualTo(Boolean value) {
            addCriterion("timeRemind >=", value, "timeremind");
            return (Criteria) this;
        }

        public Criteria andTimeremindLessThan(Boolean value) {
            addCriterion("timeRemind <", value, "timeremind");
            return (Criteria) this;
        }

        public Criteria andTimeremindLessThanOrEqualTo(Boolean value) {
            addCriterion("timeRemind <=", value, "timeremind");
            return (Criteria) this;
        }

        public Criteria andTimeremindIn(List<Boolean> values) {
            addCriterion("timeRemind in", values, "timeremind");
            return (Criteria) this;
        }

        public Criteria andTimeremindNotIn(List<Boolean> values) {
            addCriterion("timeRemind not in", values, "timeremind");
            return (Criteria) this;
        }

        public Criteria andTimeremindBetween(Boolean value1, Boolean value2) {
            addCriterion("timeRemind between", value1, value2, "timeremind");
            return (Criteria) this;
        }

        public Criteria andTimeremindNotBetween(Boolean value1, Boolean value2) {
            addCriterion("timeRemind not between", value1, value2, "timeremind");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentIsNull() {
            addCriterion("companyDocument is null");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentIsNotNull() {
            addCriterion("companyDocument is not null");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentEqualTo(Boolean value) {
            addCriterion("companyDocument =", value, "companydocument");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentNotEqualTo(Boolean value) {
            addCriterion("companyDocument <>", value, "companydocument");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentGreaterThan(Boolean value) {
            addCriterion("companyDocument >", value, "companydocument");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentGreaterThanOrEqualTo(Boolean value) {
            addCriterion("companyDocument >=", value, "companydocument");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentLessThan(Boolean value) {
            addCriterion("companyDocument <", value, "companydocument");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentLessThanOrEqualTo(Boolean value) {
            addCriterion("companyDocument <=", value, "companydocument");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentIn(List<Boolean> values) {
            addCriterion("companyDocument in", values, "companydocument");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentNotIn(List<Boolean> values) {
            addCriterion("companyDocument not in", values, "companydocument");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentBetween(Boolean value1, Boolean value2) {
            addCriterion("companyDocument between", value1, value2, "companydocument");
            return (Criteria) this;
        }

        public Criteria andCompanydocumentNotBetween(Boolean value1, Boolean value2) {
            addCriterion("companyDocument not between", value1, value2, "companydocument");
            return (Criteria) this;
        }

        public Criteria andProductdocumentIsNull() {
            addCriterion("productDocument is null");
            return (Criteria) this;
        }

        public Criteria andProductdocumentIsNotNull() {
            addCriterion("productDocument is not null");
            return (Criteria) this;
        }

        public Criteria andProductdocumentEqualTo(Boolean value) {
            addCriterion("productDocument =", value, "productdocument");
            return (Criteria) this;
        }

        public Criteria andProductdocumentNotEqualTo(Boolean value) {
            addCriterion("productDocument <>", value, "productdocument");
            return (Criteria) this;
        }

        public Criteria andProductdocumentGreaterThan(Boolean value) {
            addCriterion("productDocument >", value, "productdocument");
            return (Criteria) this;
        }

        public Criteria andProductdocumentGreaterThanOrEqualTo(Boolean value) {
            addCriterion("productDocument >=", value, "productdocument");
            return (Criteria) this;
        }

        public Criteria andProductdocumentLessThan(Boolean value) {
            addCriterion("productDocument <", value, "productdocument");
            return (Criteria) this;
        }

        public Criteria andProductdocumentLessThanOrEqualTo(Boolean value) {
            addCriterion("productDocument <=", value, "productdocument");
            return (Criteria) this;
        }

        public Criteria andProductdocumentIn(List<Boolean> values) {
            addCriterion("productDocument in", values, "productdocument");
            return (Criteria) this;
        }

        public Criteria andProductdocumentNotIn(List<Boolean> values) {
            addCriterion("productDocument not in", values, "productdocument");
            return (Criteria) this;
        }

        public Criteria andProductdocumentBetween(Boolean value1, Boolean value2) {
            addCriterion("productDocument between", value1, value2, "productdocument");
            return (Criteria) this;
        }

        public Criteria andProductdocumentNotBetween(Boolean value1, Boolean value2) {
            addCriterion("productDocument not between", value1, value2, "productdocument");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentIsNull() {
            addCriterion("memberDocument is null");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentIsNotNull() {
            addCriterion("memberDocument is not null");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentEqualTo(Boolean value) {
            addCriterion("memberDocument =", value, "memberdocument");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentNotEqualTo(Boolean value) {
            addCriterion("memberDocument <>", value, "memberdocument");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentGreaterThan(Boolean value) {
            addCriterion("memberDocument >", value, "memberdocument");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentGreaterThanOrEqualTo(Boolean value) {
            addCriterion("memberDocument >=", value, "memberdocument");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentLessThan(Boolean value) {
            addCriterion("memberDocument <", value, "memberdocument");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentLessThanOrEqualTo(Boolean value) {
            addCriterion("memberDocument <=", value, "memberdocument");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentIn(List<Boolean> values) {
            addCriterion("memberDocument in", values, "memberdocument");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentNotIn(List<Boolean> values) {
            addCriterion("memberDocument not in", values, "memberdocument");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentBetween(Boolean value1, Boolean value2) {
            addCriterion("memberDocument between", value1, value2, "memberdocument");
            return (Criteria) this;
        }

        public Criteria andMemberdocumentNotBetween(Boolean value1, Boolean value2) {
            addCriterion("memberDocument not between", value1, value2, "memberdocument");
            return (Criteria) this;
        }

        public Criteria andContractdocumentIsNull() {
            addCriterion("contractDocument is null");
            return (Criteria) this;
        }

        public Criteria andContractdocumentIsNotNull() {
            addCriterion("contractDocument is not null");
            return (Criteria) this;
        }

        public Criteria andContractdocumentEqualTo(Boolean value) {
            addCriterion("contractDocument =", value, "contractdocument");
            return (Criteria) this;
        }

        public Criteria andContractdocumentNotEqualTo(Boolean value) {
            addCriterion("contractDocument <>", value, "contractdocument");
            return (Criteria) this;
        }

        public Criteria andContractdocumentGreaterThan(Boolean value) {
            addCriterion("contractDocument >", value, "contractdocument");
            return (Criteria) this;
        }

        public Criteria andContractdocumentGreaterThanOrEqualTo(Boolean value) {
            addCriterion("contractDocument >=", value, "contractdocument");
            return (Criteria) this;
        }

        public Criteria andContractdocumentLessThan(Boolean value) {
            addCriterion("contractDocument <", value, "contractdocument");
            return (Criteria) this;
        }

        public Criteria andContractdocumentLessThanOrEqualTo(Boolean value) {
            addCriterion("contractDocument <=", value, "contractdocument");
            return (Criteria) this;
        }

        public Criteria andContractdocumentIn(List<Boolean> values) {
            addCriterion("contractDocument in", values, "contractdocument");
            return (Criteria) this;
        }

        public Criteria andContractdocumentNotIn(List<Boolean> values) {
            addCriterion("contractDocument not in", values, "contractdocument");
            return (Criteria) this;
        }

        public Criteria andContractdocumentBetween(Boolean value1, Boolean value2) {
            addCriterion("contractDocument between", value1, value2, "contractdocument");
            return (Criteria) this;
        }

        public Criteria andContractdocumentNotBetween(Boolean value1, Boolean value2) {
            addCriterion("contractDocument not between", value1, value2, "contractdocument");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentIsNull() {
            addCriterion("ukeyDocument is null");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentIsNotNull() {
            addCriterion("ukeyDocument is not null");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentEqualTo(Boolean value) {
            addCriterion("ukeyDocument =", value, "ukeydocument");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentNotEqualTo(Boolean value) {
            addCriterion("ukeyDocument <>", value, "ukeydocument");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentGreaterThan(Boolean value) {
            addCriterion("ukeyDocument >", value, "ukeydocument");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentGreaterThanOrEqualTo(Boolean value) {
            addCriterion("ukeyDocument >=", value, "ukeydocument");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentLessThan(Boolean value) {
            addCriterion("ukeyDocument <", value, "ukeydocument");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentLessThanOrEqualTo(Boolean value) {
            addCriterion("ukeyDocument <=", value, "ukeydocument");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentIn(List<Boolean> values) {
            addCriterion("ukeyDocument in", values, "ukeydocument");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentNotIn(List<Boolean> values) {
            addCriterion("ukeyDocument not in", values, "ukeydocument");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentBetween(Boolean value1, Boolean value2) {
            addCriterion("ukeyDocument between", value1, value2, "ukeydocument");
            return (Criteria) this;
        }

        public Criteria andUkeydocumentNotBetween(Boolean value1, Boolean value2) {
            addCriterion("ukeyDocument not between", value1, value2, "ukeydocument");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}