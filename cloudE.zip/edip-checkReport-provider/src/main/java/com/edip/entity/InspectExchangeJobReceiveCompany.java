package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class InspectExchangeJobReceiveCompany implements Serializable {
    private Integer id;

    /**
     * 任务id
     */
    private Integer jobId;

    /**
     * 接受公司id
     */
    private Integer receiveCompanyId;

    private Date createTime;

    private Date upateTime;

    private Integer createAccountId;

    private String deleteFlag;

    private String note;

    /**
     * 1不需要回传，2需要回传 3 全部合同回传完成
     */
    private Integer returnStatus;

    /**
     * 1未查收，2已查收 3拒收
     */
    private Integer receivedStatus;

    private String receiveCompanyName;

    private String returnDocStatus;

    private String tel;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getJobId() {
        return jobId;
    }

    public void setJobId(Integer jobId) {
        this.jobId = jobId;
    }

    public Integer getReceiveCompanyId() {
        return receiveCompanyId;
    }

    public void setReceiveCompanyId(Integer receiveCompanyId) {
        this.receiveCompanyId = receiveCompanyId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpateTime() {
        return upateTime;
    }

    public void setUpateTime(Date upateTime) {
        this.upateTime = upateTime;
    }

    public Integer getCreateAccountId() {
        return createAccountId;
    }

    public void setCreateAccountId(Integer createAccountId) {
        this.createAccountId = createAccountId;
    }

    public String getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Integer getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(Integer returnStatus) {
        this.returnStatus = returnStatus;
    }

    public Integer getReceivedStatus() {
        return receivedStatus;
    }

    public void setReceivedStatus(Integer receivedStatus) {
        this.receivedStatus = receivedStatus;
    }

    public String getReceiveCompanyName() {
        return receiveCompanyName;
    }

    public void setReceiveCompanyName(String receiveCompanyName) {
        this.receiveCompanyName = receiveCompanyName;
    }

    public String getReturnDocStatus() {
        return returnDocStatus;
    }

    public void setReturnDocStatus(String returnDocStatus) {
        this.returnDocStatus = returnDocStatus;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        InspectExchangeJobReceiveCompany other = (InspectExchangeJobReceiveCompany) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getJobId() == null ? other.getJobId() == null : this.getJobId().equals(other.getJobId()))
            && (this.getReceiveCompanyId() == null ? other.getReceiveCompanyId() == null : this.getReceiveCompanyId().equals(other.getReceiveCompanyId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpateTime() == null ? other.getUpateTime() == null : this.getUpateTime().equals(other.getUpateTime()))
            && (this.getCreateAccountId() == null ? other.getCreateAccountId() == null : this.getCreateAccountId().equals(other.getCreateAccountId()))
            && (this.getDeleteFlag() == null ? other.getDeleteFlag() == null : this.getDeleteFlag().equals(other.getDeleteFlag()))
            && (this.getNote() == null ? other.getNote() == null : this.getNote().equals(other.getNote()))
            && (this.getReturnStatus() == null ? other.getReturnStatus() == null : this.getReturnStatus().equals(other.getReturnStatus()))
            && (this.getReceivedStatus() == null ? other.getReceivedStatus() == null : this.getReceivedStatus().equals(other.getReceivedStatus()))
            && (this.getReceiveCompanyName() == null ? other.getReceiveCompanyName() == null : this.getReceiveCompanyName().equals(other.getReceiveCompanyName()))
            && (this.getReturnDocStatus() == null ? other.getReturnDocStatus() == null : this.getReturnDocStatus().equals(other.getReturnDocStatus()))
            && (this.getTel() == null ? other.getTel() == null : this.getTel().equals(other.getTel()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getJobId() == null) ? 0 : getJobId().hashCode());
        result = prime * result + ((getReceiveCompanyId() == null) ? 0 : getReceiveCompanyId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpateTime() == null) ? 0 : getUpateTime().hashCode());
        result = prime * result + ((getCreateAccountId() == null) ? 0 : getCreateAccountId().hashCode());
        result = prime * result + ((getDeleteFlag() == null) ? 0 : getDeleteFlag().hashCode());
        result = prime * result + ((getNote() == null) ? 0 : getNote().hashCode());
        result = prime * result + ((getReturnStatus() == null) ? 0 : getReturnStatus().hashCode());
        result = prime * result + ((getReceivedStatus() == null) ? 0 : getReceivedStatus().hashCode());
        result = prime * result + ((getReceiveCompanyName() == null) ? 0 : getReceiveCompanyName().hashCode());
        result = prime * result + ((getReturnDocStatus() == null) ? 0 : getReturnDocStatus().hashCode());
        result = prime * result + ((getTel() == null) ? 0 : getTel().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", jobId=").append(jobId);
        sb.append(", receiveCompanyId=").append(receiveCompanyId);
        sb.append(", createTime=").append(createTime);
        sb.append(", upateTime=").append(upateTime);
        sb.append(", createAccountId=").append(createAccountId);
        sb.append(", deleteFlag=").append(deleteFlag);
        sb.append(", note=").append(note);
        sb.append(", returnStatus=").append(returnStatus);
        sb.append(", receivedStatus=").append(receivedStatus);
        sb.append(", receiveCompanyName=").append(receiveCompanyName);
        sb.append(", returnDocStatus=").append(returnDocStatus);
        sb.append(", tel=").append(tel);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}