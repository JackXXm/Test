package com.edip.utils;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "data")
public class PersonResopnse {

    private Message message;

    private PoliceCheckInfos policeCheckInfos;

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }

    public PoliceCheckInfos getPoliceCheckInfos() {
        return policeCheckInfos;
    }

    public void setPoliceCheckInfos(PoliceCheckInfos policeCheckInfos) {
        this.policeCheckInfos = policeCheckInfos;
    }

}
