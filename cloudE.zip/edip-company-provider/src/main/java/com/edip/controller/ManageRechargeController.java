package com.edip.controller;

import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.service.ManageRechargeService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping("/manageRecharge")
public class ManageRechargeController {
    private Logger LOGGER = LoggerFactory.getLogger(ManageRechargeController.class);
    @Autowired
    private ManageRechargeService manageRechargeService;
    @Autowired
    private HttpServletRequest request;
    @RequestMapping("/queryAllBills.ajax")
    public ServerResponse queryAllBills(@RequestBody Map<String,Object> info) {
        try {
            Integer provinceID = (Integer) SessionContext.getContext().getSession(request).getAttribute("province");
            info.put("provinceID",provinceID);
            return ServerResponse.createBySuccess("success",manageRechargeService.queryAllBills(info));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取企业充值列表失败！");
        }
    }
    @RequestMapping("/recharge.ajax")
    public ServerResponse recharge(@RequestBody Map<String,Object> info) {
        try {
            int accountID = (int)SessionContext.getContext().getSession(request).getAttribute("accountID");
            info.put("operid",accountID);

            return ServerResponse.createBySuccess("success",  manageRechargeService.recharge(info));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("充值或赠送失败！");
        }
    }

    /**
     * 获取免费发送最新到期时间
     */
    @RequestMapping("/getFreeDelivery.ajax")
    public ServerResponse getFreeDelivery(Integer companyID){
        if (companyID==null)
            return ServerResponse.createByErrorMsg("参数异常！");
        try {
            return ServerResponse.createBySuccess(manageRechargeService.getFreeDelivery(companyID));
        }catch (Exception e){
            LOGGER.error("获取免费发送最新到期时间失败！"+e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取免费发送最新到期时间失败！");
        }
    }
    /**
     * 获取充值明细
     * @param info
     * @return
     */
    @RequestMapping("/queryRechargeDetail.ajax")
    public ServerResponse queryRechargeDetail(@RequestBody Map<String,Object> info) {
        try {
            return ServerResponse.createBySuccess("success", manageRechargeService.queryRechargeDetail(info));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取企业充值列表失败！");
        }
    }

    public ServerResponse queryRechargeDetailBAK(@RequestBody Map<String,Object> info) {
        try {
            return ServerResponse.createBySuccess("success", manageRechargeService.queryRechargeDetailBak(info));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取企业充值列表失败！");
        }
    }

    /**
     * 获取赠送明细
     * @param info
     * @return
     */
    @RequestMapping("/queryPresentationDetails.ajax")
    public ServerResponse queryPresentationDetails(@RequestBody Map<String,Object> info) {
        try {
            return ServerResponse.createBySuccess("success", manageRechargeService.queryPresentationDetails(info));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取企业充值列表失败！");
        }
    }
    @RequestMapping("/querySendCost.ajax")
    public ServerResponse querySendCost(@RequestBody Map<String,Object> info) {
        try {

            return ServerResponse.createBySuccess("success", manageRechargeService.querySendCost(info));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取企业充值列表失败！");
        }
    }

}
