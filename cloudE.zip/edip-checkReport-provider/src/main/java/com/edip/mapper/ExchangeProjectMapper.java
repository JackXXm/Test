package com.edip.mapper;

import com.edip.entity.ExchangeProject;
import com.edip.entity.ExchangeProjectExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ExchangeProjectMapper {
    long countByExample(ExchangeProjectExample example);

    int deleteByExample(ExchangeProjectExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ExchangeProject record);

    int insertSelective(ExchangeProject record);

    List<ExchangeProject> selectByExample(ExchangeProjectExample example);

    ExchangeProject selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ExchangeProject record, @Param("example") ExchangeProjectExample example);

    int updateByExample(@Param("record") ExchangeProject record, @Param("example") ExchangeProjectExample example);

    int updateByPrimaryKeySelective(ExchangeProject record);

    int updateByPrimaryKey(ExchangeProject record);
}