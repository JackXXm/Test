package com.edip.mapper;

import com.edip.entity.AdminDic;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface AdminDicMapper {
//    int countByExample(DicExample example);
//
//    int deleteByExample(DicExample example);

    int insert(AdminDic record);

    int insertSelective(AdminDic record);

    AdminDic selectByValue(String value);

    List<Map<String,Object>> selectMapAllValue();

    List<AdminDic> selectByAllValue();

//    List<Dic> selectByExampleWithPage(@Param("example") DicExample example, @Param("from") Integer from,
//                                      @Param("to") Integer to);

//    List<Dic> selectByExample(DicExample example);

    AdminDic selectGetName(String name);

    AdminDic selectByTypeAndName(Map map);

//    int updateByExampleSelective(@Param("record") Dic record, @Param("example") DicExample example);

//    int updateByExample(@Param("record") Dic record, @Param("example") DicExample example);

    List<AdminDic> selectByType(String type);

    List<Map<String ,Object>> selectByTypeForMap(String type);

//    int selectDicByTypeCount(@Param("compTypeDicVo") CompTypeDicVo compTypeDicVo);

//    List<CompTypeDicVo> selectDicByType(@Param("from") int from, @Param("to") int to, @Param("compTypeDicVo") CompTypeDicVo compTypeDicVo);

//    int addCompTypeDic(CompTypeDicVo compTypeDicVo);

//    List<CompTypeDicVo> getCompTypeDicListByName(CompTypeDicVo compTypeDicVo);

//    List<CompTypeDicVo> getCompTypeDicListByType(@Param("type") String type);

//    List<CompTypeDicVo> getCompTypeDicListByCompProductTypeId(@Param("compProductTypeId") Integer compProductTypeId);

//    CompTypeDicVo getCompTypeDicListByOrderNo(@Param("orderNo") Integer orderNo);

//    int updateAptitude(@Param("compTypeDicVo") CompTypeDicVo compTypeDicVo);

    int updateDic(AdminDic dic);


}