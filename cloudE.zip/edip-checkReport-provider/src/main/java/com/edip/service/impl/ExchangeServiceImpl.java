package com.edip.service.impl;

import com.alibaba.fastjson.JSONObject;

import com.edip.controller.MessageClient;
import com.edip.dto.ServerResponse;
import com.edip.dto.util.RedisUtil;
import com.edip.entity.*;
import com.edip.feign.CompanyFeign;
import com.edip.feign.DocFeign;
import com.edip.feign.MerchantsFeign;
import com.edip.mapper.CompanycontactsMapper;
import com.edip.mapper.ExchangeMapper;
import com.edip.mapper.InspectDocumentMapper;
import com.edip.service.CompanycontactsService;
import com.edip.service.ExchangeService;

import com.edip.utils.FileUtil;

import com.edip.utils.StringUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;


/**
 * @author lilin
 * @description 我要发送serviceImpl
 * @DATE 2018/12/26
 */
@Service
public class ExchangeServiceImpl implements ExchangeService {

    @Autowired
    private ExchangeMapper exchangeMapper;
    @Autowired
    private InspectDocumentMapper inspectDocumentMapper;
    @Autowired
    private RedisUtil util;
    @Autowired
    private CompanycontactsService companycontactsService;
    @Autowired
    private CompanycontactsMapper companycontactsMapper;
    @Autowired
    private MerchantsFeign merchantsFeign;
    @Autowired
    private CompanyFeign companyFeign;
    @Autowired
    private MessageClient messageClient;

    @Override
    public PageInfo queryReceiveCompany(Integer compID, String compName, String companyName, String searchType, int page, int rows) {
        PageHelper.startPage(page, rows);
        List<Map<String, Object>> resultList = new ArrayList<>(4);
        PageInfo pageInfo= null;
        try {
            if (StringUtils.equalsIgnoreCase("recent", searchType)) {
                //最近联系人
                List<Map<String, Object>> exchangeCompany = exchangeMapper.queryReceiveCompany(compID,companyName);
                resultList.addAll(exchangeCompany);
                pageInfo=new PageInfo(exchangeCompany);

            }
            else if(StringUtils.equalsIgnoreCase("contact", searchType)){//查通讯录
                Map<String , Object> params = new HashMap<>();
                params.put("companyName",companyName);
                params.put("ownCompanyName",compName);
                params.put("compID",compID);
                resultList = companycontactsService.selectWithPage(params);
                pageInfo=new PageInfo(resultList);

            } else if (StringUtils.equalsIgnoreCase("business", searchType)) {
                ServerResponse response = merchantsFeign.getMerchantsList("1", companyName,"Y", page, rows);
                Map<String, Object>map=(Map<String, Object>) response.getData();
                pageInfo=new PageInfo();
                Integer total= (Integer) map.get("total");
                pageInfo.setTotal(total);
                pageInfo.setPages(total/rows);
                pageInfo.setPageNum(page);
                pageInfo.setPageSize(rows);
                resultList=getMerchantsListResult(map, companyName);
            }



        } catch (Exception e) {
          e.printStackTrace();
        }
        pageInfo.setList(resultList);
        return pageInfo;
    }
    private List<Map<String, Object>> getMerchantsListResult(Map<String, Object> data, String searchKey) {
        List<Map<String, Object>> merchantsList = (List<Map<String, Object>>) data.get("datas");
        Map<String, Object> param = new HashMap<>(2);
        param.put("merchantsList", merchantsList);
        ServerResponse response = companyFeign.queryMerchantCompany(param);
        List<Map<String, Object>> merchantCompanyList = (List<Map<String, Object>>) response.getData();
        List<Map<String, Object>> resultList = new ArrayList<>();
        List<String> tempList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(merchantsList)) {
            merchantsList.stream().filter(merchant -> {
                boolean flag = !tempList.contains(merchant.get("companyName"));
                tempList.add((String) merchant.get("companyName"));
                return flag;
            }).forEach(merchant -> {
                String companyInfoName = (String) merchant.get("companyName");
                Map<String, Object> map = new HashMap<>();
                map.put("companyName", companyInfoName);
                map.put("companyNameId", null);
                if (!CollectionUtils.isEmpty(merchantCompanyList)) {
                    merchantCompanyList.stream().forEach(merchantCompany -> {
                        String companyName = (String) merchantCompany.get("companyName");
                        if (StringUtils.equals(companyInfoName, companyName)) {
                            map.put("companyNameId", merchantCompany.get("companyNameId"));
                        }
                    });
                }
                resultList.add(map);
            });
        }
        return resultList;
    }
    @Override
    public ServerResponse getCheckReportDetail(Map<String, Object> args) {

        try {
            List<Map<String,Object>>result=exchangeMapper.getCheckReportDetail(args);
            result=FileUtil.getFileUrl(result,util);
            Map map= result.stream().collect(Collectors.groupingBy(e ->e.get("batchNum")));
            return ServerResponse.createBySuccess(map);
        }catch (Exception e){
            e.printStackTrace();
        }

        return ServerResponse.createByError();
    }
    public void insetCompanyContacts(ExchangeInfo exchangeInfo, int compID, String companyName){
        List<ReceiveCompany> companyInfoList = exchangeInfo.getCompanyInfoList();
        for(ReceiveCompany rc : companyInfoList){
            if(!rc.getReceiveCompanyName().equals(companyName)){
                Companycontacts cc = new Companycontacts();
                if(rc.getId()==null){
                    String cocomp = this.getCompIdByName(rc.getReceiveCompanyName());
                    if(cocomp!=null){
                        cc.setCocompID(Integer.valueOf(cocomp));
                    }
                }
                cc.setCompID(compID);
                cc.setDeleteFlag(0);
                cc.setCompanyName(rc.getReceiveCompanyName());
                if(rc.getContacts()!=null && !"".equals(rc.getContacts())){//发送时通讯录不提供重置这两个值
                    cc.setName(rc.getContacts());
                }
                if(rc.getTel()!=null && !"".equals(rc.getTel())){
                    cc.setPhone(rc.getTel());
                }
                // 插入通讯录
                List<Companycontacts> list = companycontactsMapper.selectByEntity(cc);
                if (list.size() > 0) {
                    Integer ccid = list.get(0).getCcid();
                    cc.setCcid(ccid);
                    companycontactsMapper.updateImportSend(cc);
                } else {
                    cc.setCreateTime(new Date());
                    companycontactsMapper.insert(cc);
                }
            }
        }

    }

    public String getCompIdByName(String companyName){
        String compID = (String)companyFeign.getCompanyByName(companyName).getData();
        if (com.edip.utils.StringUtils.isNotEmpty(compID)){
            return compID;
        }
        return  null;
    }
    @Transactional
    @Override
    public ServerResponse sendCheckExchangeInfo(ExchangeInfo exchangeInfo, int compID, int accountID, String accountName, String companyName) throws Exception {



        insetCompanyContacts(exchangeInfo,compID, companyName);

        int jobId = insertExchangeJob(exchangeInfo, compID, accountID, accountName, companyName);

        //克隆doc
        this.cloneDoc(exchangeInfo);
        //更新project表
        insertProject(exchangeInfo, accountID, jobId, compID);
        //更新receiveCompany表
        insertReceiveCompany(exchangeInfo, accountID, jobId);

        JSONObject json = new JSONObject();
        json.put("msgType",3);//消息类型:1 首营端消息 2 管理端消息 3 检验报告
        json.put("dataId",jobId);
        json.put("compId",compID);
        json.put("accountId",accountID);
        json.put("receiveCompID",compID);
        json.put("dataType",7);//实体类型 0:公司 1:人员 2:产品 3:合同 4:图章 5:证书 6:项目 7:检验报告
        json.put("sender","签章发送");
        json.put("title","您有来自【" + accountName + "】的待签章发送文件，请处理。若已处理，请忽略");
        json.put("content","您有来自【" + accountName + "】的待签章发送文件，请处理。若已处理，请忽略");
        json.put("classify",0);//消息标识 0 系统消息，1 到期提醒，2 更新提醒，3 系统公告，4 优惠活动
        json.put("newUrl","exchange/signature/index?mid=237");
        json.put("menu","sign");
        messageClient.messageSend(json.toJSONString());

        return ServerResponse.createBySuccess();
    }

    @Override
    public ServerResponse getSendReportDocDetail(Map<String, Object> args) {
        try {
            List<Map<String,Object>>result=exchangeMapper.getSendReportDocDetail(args);
            result=FileUtil.getFileUrl(result,util);
            Map map= result.stream().collect(Collectors.groupingBy(e ->e.get("batchNum")));
            return ServerResponse.createBySuccess(map);
        }catch (Exception e){
            e.printStackTrace();
        }

        return ServerResponse.createByError();
    }

    /**
     * 更新Job表
     *
     * @param exchangeInfo
     * @param compID
     * @param accountID
     * @param accountName
     * @param companyName
     * @return
     */
    private int insertExchangeJob(ExchangeInfo exchangeInfo, int compID, int accountID, String accountName, String companyName) {
        ExchangeJob exchangeJob = exchangeInfo.getExchangeJob();
        String jobId = exchangeInfo.getJobId();
        if(jobId!=null){
            exchangeJob.setFristJobId(Integer.parseInt(jobId));
        }
        exchangeJob.setCompanyId(compID);
        exchangeJob.setAccountID(accountID);
        exchangeJob.setAccountName(accountName);
        exchangeJob.setCompanyName(companyName);
        if(exchangeJob.getType()==null){
            exchangeJob.setType(0+"");
        }
        if(exchangeJob.getReturnStatus()==null){
            exchangeJob.setReturnStatus(1);
        }
        exchangeJob.setStatus(1);

        exchangeMapper.insertExchangeJob(exchangeJob);
        return exchangeJob.getId();
    }
    //克隆doc
    private void cloneDoc(ExchangeInfo exchangeInfo) throws Exception {
        if (exchangeInfo != null) {
            String type=exchangeInfo.getExchangeJob().getType();
            List<List<ExchangeProject>> productInfoList = exchangeInfo.getProductInfoList();
            if (!CollectionUtils.isEmpty(productInfoList)) {

                List<DocumentVo> documentList = new ArrayList<>();
                List<Integer>productIds=new ArrayList<>();
                List<Integer>companyIds=new ArrayList<>();
                productInfoList.forEach(projectList -> {


                    projectList.forEach(project -> {
                        List<DocumentVo>documentVos=project.getDocList();
                        if(project.isFlag()){
                            documentVos.forEach(doc -> {
                                documentList.add(doc);
                            });
                        }else {

                                productIds.add(project.getInfoId());

                        }
                    });
                });
                Map<String,Object>params=new HashMap<>();

                if(productIds.size()==0){
                    productIds.add(-1);
                }

                params.put("productIds",productIds);
                List<DocumentVo>docIds=exchangeMapper.queryAllDocByIds(params);
                Map<Integer,List<DocumentVo>>docIdsByGroup=new HashMap<>();
                if(docIds!=null){
                    documentList.addAll(docIds);
                    docIdsByGroup= docIds.stream().collect(Collectors.groupingBy(e->e.getInfoId()));

                }

                cloneCheckDoc(documentList);
                for (List<ExchangeProject> projectList : productInfoList) {
                    if (!CollectionUtils.isEmpty(projectList)) {
                        for (ExchangeProject project : projectList) {
                            List<DocumentVo>documents= project.getDocList();
                            if(documents.size()==0&&docIdsByGroup.size()>0){
                                List<DocumentVo>groupDocIds=docIdsByGroup.get(project.getInfoId());
                                if(groupDocIds!=null){
                                    documents.addAll(groupDocIds);
                                }

                            }
                            for (DocumentVo document :documents) {
                                if (!CollectionUtils.isEmpty(documentList)) {
                                    documentList.forEach(cloneDoc -> {
                                        int cloneId = cloneDoc.getId();
                                        if (cloneId == document.getId()) {
                                            document.setId(cloneDoc.getId());
                                        }
                                    });
                                }
                            }
                        }
                    }
                }

            }
        }
        return;
    }
    private void cloneCheckDoc(List<DocumentVo>docIds){
        docIds.forEach(documentVo -> {
            documentVo.setCloneId(documentVo.getId());
            documentVo.setCloneStatus(1);
            inspectDocumentMapper.cloneCheckDoc(documentVo);

        });


    }

    //更新file附件表
    private void insertFile(ExchangeProject project, int jobId, int accountID, int compID,String type) {
        List<DocumentVo> docIdList = project.getDocList();
        if (!CollectionUtils.isEmpty(docIdList)) {
            docIdList.forEach(doc -> {
                ExchangeFileItem fileItem = new ExchangeFileItem();
                fileItem.setJobId(jobId);
                fileItem.setProjectId(project.getId());
                fileItem.setCompanyId(compID);
                fileItem.setCreateAccountId(accountID);
                fileItem.setDocumentId(doc.getId());
                fileItem.setInspectId(doc.getInspectId());
                exchangeMapper.insertFileItem(fileItem);
            });
        }
    }
    //更新project表和product_company
    private void insertProject(ExchangeInfo exchangeInfo, int accountID, int jobId, int compID) {
        List<List<ExchangeProject>> productInfoList = exchangeInfo.getProductInfoList();
        String type=exchangeInfo.getExchangeJob().getType();
        if (!CollectionUtils.isEmpty(productInfoList)) {
            List<Map<String, Object>> projectIdList = new ArrayList<>();
            productInfoList.forEach(projectList -> {

                ExchangeProject projectProduct=new ExchangeProject();
                projectProduct.setThemeDocNum(0);

                projectList.forEach(project -> {
                    project.setCreateAccountId(accountID);
                    project.setUpdateAccountId(accountID);
                    project.setJobId(jobId);
                    project.setThemeDocNum( project.getDocList().size());
                   //更新file附件表
                    exchangeMapper.insertProject(project);
                    this.insertFile(project, jobId, accountID, compID,type);



                });

            });

        }
    }
    private void insertReceiveCompany(ExchangeInfo exchangeInfo, int accountID, int jobId) {
        List<ReceiveCompany> companyInfoList = exchangeInfo.getCompanyInfoList();
        ExchangeJob job = exchangeInfo.getExchangeJob();
        Integer status = job.getReturnStatus();
        if (!CollectionUtils.isEmpty(companyInfoList)) {
            companyInfoList.forEach(companyInfo -> {
                companyInfo.setUpdateAccountId(accountID);
                companyInfo.setProjectId(jobId);
                if (status != null){
                    companyInfo.setReturnStatus(status + "");
                }
                if(StringUtil.isEmpty(companyInfo.getTel())){
                    companyInfo.setTel(-1+"");
                }

                int receiveId = exchangeMapper.insertReceiveCompany(companyInfo);
            });
        }

    }
}
