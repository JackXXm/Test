package com.edip.mapper;

import com.edip.entity.Stamp;
import com.edip.entity.StampExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface StampMapper {
    long countByExample(StampExample example);

    int deleteByExample(StampExample example);

    int deleteByPrimaryKey(Integer stampid);

    int insert(Stamp record);

    int insertSelective(Stamp record);

    List<Stamp> selectByExampleWithBLOBs(StampExample example);

    List<Stamp> selectByExample(StampExample example);

    Stamp selectByPrimaryKey(Integer stampid);

    int updateByExampleSelective(@Param("record") Stamp record, @Param("example") StampExample example);

    int updateByExampleWithBLOBs(@Param("record") Stamp record, @Param("example") StampExample example);

    int updateByExample(@Param("record") Stamp record, @Param("example") StampExample example);

    int updateByPrimaryKeySelective(Stamp record);

    int updateByPrimaryKeyWithBLOBs(Stamp record);

    int updateByPrimaryKey(Stamp record);
}