package com.edip.mapper;

import com.edip.entity.Billmode;
import com.edip.entity.BillmodeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BillmodeMapper {
    long countByExample(BillmodeExample example);

    int deleteByExample(BillmodeExample example);

    int deleteByPrimaryKey(Integer modeid);

    int insert(Billmode record);

    int insertSelective(Billmode record);

    List<Billmode> selectByExample(BillmodeExample example);

    Billmode selectByPrimaryKey(Integer modeid);

    int updateByExampleSelective(@Param("record") Billmode record, @Param("example") BillmodeExample example);

    int updateByExample(@Param("record") Billmode record, @Param("example") BillmodeExample example);

    int updateByPrimaryKeySelective(Billmode record);

    int updateByPrimaryKey(Billmode record);
}