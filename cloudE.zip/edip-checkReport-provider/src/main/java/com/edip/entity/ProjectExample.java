package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProjectExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public ProjectExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andProidIsNull() {
            addCriterion("proID is null");
            return (Criteria) this;
        }

        public Criteria andProidIsNotNull() {
            addCriterion("proID is not null");
            return (Criteria) this;
        }

        public Criteria andProidEqualTo(Integer value) {
            addCriterion("proID =", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidNotEqualTo(Integer value) {
            addCriterion("proID <>", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidGreaterThan(Integer value) {
            addCriterion("proID >", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidGreaterThanOrEqualTo(Integer value) {
            addCriterion("proID >=", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidLessThan(Integer value) {
            addCriterion("proID <", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidLessThanOrEqualTo(Integer value) {
            addCriterion("proID <=", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidIn(List<Integer> values) {
            addCriterion("proID in", values, "proid");
            return (Criteria) this;
        }

        public Criteria andProidNotIn(List<Integer> values) {
            addCriterion("proID not in", values, "proid");
            return (Criteria) this;
        }

        public Criteria andProidBetween(Integer value1, Integer value2) {
            addCriterion("proID between", value1, value2, "proid");
            return (Criteria) this;
        }

        public Criteria andProidNotBetween(Integer value1, Integer value2) {
            addCriterion("proID not between", value1, value2, "proid");
            return (Criteria) this;
        }

        public Criteria andPronameIsNull() {
            addCriterion("proName is null");
            return (Criteria) this;
        }

        public Criteria andPronameIsNotNull() {
            addCriterion("proName is not null");
            return (Criteria) this;
        }

        public Criteria andPronameEqualTo(String value) {
            addCriterion("proName =", value, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameNotEqualTo(String value) {
            addCriterion("proName <>", value, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameGreaterThan(String value) {
            addCriterion("proName >", value, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameGreaterThanOrEqualTo(String value) {
            addCriterion("proName >=", value, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameLessThan(String value) {
            addCriterion("proName <", value, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameLessThanOrEqualTo(String value) {
            addCriterion("proName <=", value, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameLike(String value) {
            addCriterion("proName like", value, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameNotLike(String value) {
            addCriterion("proName not like", value, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameIn(List<String> values) {
            addCriterion("proName in", values, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameNotIn(List<String> values) {
            addCriterion("proName not in", values, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameBetween(String value1, String value2) {
            addCriterion("proName between", value1, value2, "proname");
            return (Criteria) this;
        }

        public Criteria andPronameNotBetween(String value1, String value2) {
            addCriterion("proName not between", value1, value2, "proname");
            return (Criteria) this;
        }

        public Criteria andCompidIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompidIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompidEqualTo(Integer value) {
            addCriterion("compID =", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThan(Integer value) {
            addCriterion("compID >", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThan(Integer value) {
            addCriterion("compID <", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidIn(List<Integer> values) {
            addCriterion("compID in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andProductidIsNull() {
            addCriterion("productID is null");
            return (Criteria) this;
        }

        public Criteria andProductidIsNotNull() {
            addCriterion("productID is not null");
            return (Criteria) this;
        }

        public Criteria andProductidEqualTo(Integer value) {
            addCriterion("productID =", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotEqualTo(Integer value) {
            addCriterion("productID <>", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidGreaterThan(Integer value) {
            addCriterion("productID >", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidGreaterThanOrEqualTo(Integer value) {
            addCriterion("productID >=", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidLessThan(Integer value) {
            addCriterion("productID <", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidLessThanOrEqualTo(Integer value) {
            addCriterion("productID <=", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidIn(List<Integer> values) {
            addCriterion("productID in", values, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotIn(List<Integer> values) {
            addCriterion("productID not in", values, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidBetween(Integer value1, Integer value2) {
            addCriterion("productID between", value1, value2, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotBetween(Integer value1, Integer value2) {
            addCriterion("productID not between", value1, value2, "productid");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNull() {
            addCriterion("accountID is null");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNotNull() {
            addCriterion("accountID is not null");
            return (Criteria) this;
        }

        public Criteria andAccountidEqualTo(Integer value) {
            addCriterion("accountID =", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotEqualTo(Integer value) {
            addCriterion("accountID <>", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThan(Integer value) {
            addCriterion("accountID >", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThanOrEqualTo(Integer value) {
            addCriterion("accountID >=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThan(Integer value) {
            addCriterion("accountID <", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThanOrEqualTo(Integer value) {
            addCriterion("accountID <=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidIn(List<Integer> values) {
            addCriterion("accountID in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotIn(List<Integer> values) {
            addCriterion("accountID not in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidBetween(Integer value1, Integer value2) {
            addCriterion("accountID between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotBetween(Integer value1, Integer value2) {
            addCriterion("accountID not between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andReceiveidIsNull() {
            addCriterion("receiveID is null");
            return (Criteria) this;
        }

        public Criteria andReceiveidIsNotNull() {
            addCriterion("receiveID is not null");
            return (Criteria) this;
        }

        public Criteria andReceiveidEqualTo(Integer value) {
            addCriterion("receiveID =", value, "receiveid");
            return (Criteria) this;
        }

        public Criteria andReceiveidNotEqualTo(Integer value) {
            addCriterion("receiveID <>", value, "receiveid");
            return (Criteria) this;
        }

        public Criteria andReceiveidGreaterThan(Integer value) {
            addCriterion("receiveID >", value, "receiveid");
            return (Criteria) this;
        }

        public Criteria andReceiveidGreaterThanOrEqualTo(Integer value) {
            addCriterion("receiveID >=", value, "receiveid");
            return (Criteria) this;
        }

        public Criteria andReceiveidLessThan(Integer value) {
            addCriterion("receiveID <", value, "receiveid");
            return (Criteria) this;
        }

        public Criteria andReceiveidLessThanOrEqualTo(Integer value) {
            addCriterion("receiveID <=", value, "receiveid");
            return (Criteria) this;
        }

        public Criteria andReceiveidIn(List<Integer> values) {
            addCriterion("receiveID in", values, "receiveid");
            return (Criteria) this;
        }

        public Criteria andReceiveidNotIn(List<Integer> values) {
            addCriterion("receiveID not in", values, "receiveid");
            return (Criteria) this;
        }

        public Criteria andReceiveidBetween(Integer value1, Integer value2) {
            addCriterion("receiveID between", value1, value2, "receiveid");
            return (Criteria) this;
        }

        public Criteria andReceiveidNotBetween(Integer value1, Integer value2) {
            addCriterion("receiveID not between", value1, value2, "receiveid");
            return (Criteria) this;
        }

        public Criteria andConsigneeidIsNull() {
            addCriterion("consigneeID is null");
            return (Criteria) this;
        }

        public Criteria andConsigneeidIsNotNull() {
            addCriterion("consigneeID is not null");
            return (Criteria) this;
        }

        public Criteria andConsigneeidEqualTo(Integer value) {
            addCriterion("consigneeID =", value, "consigneeid");
            return (Criteria) this;
        }

        public Criteria andConsigneeidNotEqualTo(Integer value) {
            addCriterion("consigneeID <>", value, "consigneeid");
            return (Criteria) this;
        }

        public Criteria andConsigneeidGreaterThan(Integer value) {
            addCriterion("consigneeID >", value, "consigneeid");
            return (Criteria) this;
        }

        public Criteria andConsigneeidGreaterThanOrEqualTo(Integer value) {
            addCriterion("consigneeID >=", value, "consigneeid");
            return (Criteria) this;
        }

        public Criteria andConsigneeidLessThan(Integer value) {
            addCriterion("consigneeID <", value, "consigneeid");
            return (Criteria) this;
        }

        public Criteria andConsigneeidLessThanOrEqualTo(Integer value) {
            addCriterion("consigneeID <=", value, "consigneeid");
            return (Criteria) this;
        }

        public Criteria andConsigneeidIn(List<Integer> values) {
            addCriterion("consigneeID in", values, "consigneeid");
            return (Criteria) this;
        }

        public Criteria andConsigneeidNotIn(List<Integer> values) {
            addCriterion("consigneeID not in", values, "consigneeid");
            return (Criteria) this;
        }

        public Criteria andConsigneeidBetween(Integer value1, Integer value2) {
            addCriterion("consigneeID between", value1, value2, "consigneeid");
            return (Criteria) this;
        }

        public Criteria andConsigneeidNotBetween(Integer value1, Integer value2) {
            addCriterion("consigneeID not between", value1, value2, "consigneeid");
            return (Criteria) this;
        }

        public Criteria andSenddateIsNull() {
            addCriterion("sendDate is null");
            return (Criteria) this;
        }

        public Criteria andSenddateIsNotNull() {
            addCriterion("sendDate is not null");
            return (Criteria) this;
        }

        public Criteria andSenddateEqualTo(Date value) {
            addCriterion("sendDate =", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateNotEqualTo(Date value) {
            addCriterion("sendDate <>", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateGreaterThan(Date value) {
            addCriterion("sendDate >", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateGreaterThanOrEqualTo(Date value) {
            addCriterion("sendDate >=", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateLessThan(Date value) {
            addCriterion("sendDate <", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateLessThanOrEqualTo(Date value) {
            addCriterion("sendDate <=", value, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateIn(List<Date> values) {
            addCriterion("sendDate in", values, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateNotIn(List<Date> values) {
            addCriterion("sendDate not in", values, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateBetween(Date value1, Date value2) {
            addCriterion("sendDate between", value1, value2, "senddate");
            return (Criteria) this;
        }

        public Criteria andSenddateNotBetween(Date value1, Date value2) {
            addCriterion("sendDate not between", value1, value2, "senddate");
            return (Criteria) this;
        }

        public Criteria andReceivedateIsNull() {
            addCriterion("receiveDate is null");
            return (Criteria) this;
        }

        public Criteria andReceivedateIsNotNull() {
            addCriterion("receiveDate is not null");
            return (Criteria) this;
        }

        public Criteria andReceivedateEqualTo(Date value) {
            addCriterion("receiveDate =", value, "receivedate");
            return (Criteria) this;
        }

        public Criteria andReceivedateNotEqualTo(Date value) {
            addCriterion("receiveDate <>", value, "receivedate");
            return (Criteria) this;
        }

        public Criteria andReceivedateGreaterThan(Date value) {
            addCriterion("receiveDate >", value, "receivedate");
            return (Criteria) this;
        }

        public Criteria andReceivedateGreaterThanOrEqualTo(Date value) {
            addCriterion("receiveDate >=", value, "receivedate");
            return (Criteria) this;
        }

        public Criteria andReceivedateLessThan(Date value) {
            addCriterion("receiveDate <", value, "receivedate");
            return (Criteria) this;
        }

        public Criteria andReceivedateLessThanOrEqualTo(Date value) {
            addCriterion("receiveDate <=", value, "receivedate");
            return (Criteria) this;
        }

        public Criteria andReceivedateIn(List<Date> values) {
            addCriterion("receiveDate in", values, "receivedate");
            return (Criteria) this;
        }

        public Criteria andReceivedateNotIn(List<Date> values) {
            addCriterion("receiveDate not in", values, "receivedate");
            return (Criteria) this;
        }

        public Criteria andReceivedateBetween(Date value1, Date value2) {
            addCriterion("receiveDate between", value1, value2, "receivedate");
            return (Criteria) this;
        }

        public Criteria andReceivedateNotBetween(Date value1, Date value2) {
            addCriterion("receiveDate not between", value1, value2, "receivedate");
            return (Criteria) this;
        }

        public Criteria andReissuedateIsNull() {
            addCriterion("reissueDate is null");
            return (Criteria) this;
        }

        public Criteria andReissuedateIsNotNull() {
            addCriterion("reissueDate is not null");
            return (Criteria) this;
        }

        public Criteria andReissuedateEqualTo(Date value) {
            addCriterion("reissueDate =", value, "reissuedate");
            return (Criteria) this;
        }

        public Criteria andReissuedateNotEqualTo(Date value) {
            addCriterion("reissueDate <>", value, "reissuedate");
            return (Criteria) this;
        }

        public Criteria andReissuedateGreaterThan(Date value) {
            addCriterion("reissueDate >", value, "reissuedate");
            return (Criteria) this;
        }

        public Criteria andReissuedateGreaterThanOrEqualTo(Date value) {
            addCriterion("reissueDate >=", value, "reissuedate");
            return (Criteria) this;
        }

        public Criteria andReissuedateLessThan(Date value) {
            addCriterion("reissueDate <", value, "reissuedate");
            return (Criteria) this;
        }

        public Criteria andReissuedateLessThanOrEqualTo(Date value) {
            addCriterion("reissueDate <=", value, "reissuedate");
            return (Criteria) this;
        }

        public Criteria andReissuedateIn(List<Date> values) {
            addCriterion("reissueDate in", values, "reissuedate");
            return (Criteria) this;
        }

        public Criteria andReissuedateNotIn(List<Date> values) {
            addCriterion("reissueDate not in", values, "reissuedate");
            return (Criteria) this;
        }

        public Criteria andReissuedateBetween(Date value1, Date value2) {
            addCriterion("reissueDate between", value1, value2, "reissuedate");
            return (Criteria) this;
        }

        public Criteria andReissuedateNotBetween(Date value1, Date value2) {
            addCriterion("reissueDate not between", value1, value2, "reissuedate");
            return (Criteria) this;
        }

        public Criteria andReissueflagIsNull() {
            addCriterion("reissueFlag is null");
            return (Criteria) this;
        }

        public Criteria andReissueflagIsNotNull() {
            addCriterion("reissueFlag is not null");
            return (Criteria) this;
        }

        public Criteria andReissueflagEqualTo(Integer value) {
            addCriterion("reissueFlag =", value, "reissueflag");
            return (Criteria) this;
        }

        public Criteria andReissueflagNotEqualTo(Integer value) {
            addCriterion("reissueFlag <>", value, "reissueflag");
            return (Criteria) this;
        }

        public Criteria andReissueflagGreaterThan(Integer value) {
            addCriterion("reissueFlag >", value, "reissueflag");
            return (Criteria) this;
        }

        public Criteria andReissueflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("reissueFlag >=", value, "reissueflag");
            return (Criteria) this;
        }

        public Criteria andReissueflagLessThan(Integer value) {
            addCriterion("reissueFlag <", value, "reissueflag");
            return (Criteria) this;
        }

        public Criteria andReissueflagLessThanOrEqualTo(Integer value) {
            addCriterion("reissueFlag <=", value, "reissueflag");
            return (Criteria) this;
        }

        public Criteria andReissueflagIn(List<Integer> values) {
            addCriterion("reissueFlag in", values, "reissueflag");
            return (Criteria) this;
        }

        public Criteria andReissueflagNotIn(List<Integer> values) {
            addCriterion("reissueFlag not in", values, "reissueflag");
            return (Criteria) this;
        }

        public Criteria andReissueflagBetween(Integer value1, Integer value2) {
            addCriterion("reissueFlag between", value1, value2, "reissueflag");
            return (Criteria) this;
        }

        public Criteria andReissueflagNotBetween(Integer value1, Integer value2) {
            addCriterion("reissueFlag not between", value1, value2, "reissueflag");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateIsNull() {
            addCriterion("reissueRecDate is null");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateIsNotNull() {
            addCriterion("reissueRecDate is not null");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateEqualTo(Date value) {
            addCriterion("reissueRecDate =", value, "reissuerecdate");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateNotEqualTo(Date value) {
            addCriterion("reissueRecDate <>", value, "reissuerecdate");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateGreaterThan(Date value) {
            addCriterion("reissueRecDate >", value, "reissuerecdate");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateGreaterThanOrEqualTo(Date value) {
            addCriterion("reissueRecDate >=", value, "reissuerecdate");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateLessThan(Date value) {
            addCriterion("reissueRecDate <", value, "reissuerecdate");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateLessThanOrEqualTo(Date value) {
            addCriterion("reissueRecDate <=", value, "reissuerecdate");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateIn(List<Date> values) {
            addCriterion("reissueRecDate in", values, "reissuerecdate");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateNotIn(List<Date> values) {
            addCriterion("reissueRecDate not in", values, "reissuerecdate");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateBetween(Date value1, Date value2) {
            addCriterion("reissueRecDate between", value1, value2, "reissuerecdate");
            return (Criteria) this;
        }

        public Criteria andReissuerecdateNotBetween(Date value1, Date value2) {
            addCriterion("reissueRecDate not between", value1, value2, "reissuerecdate");
            return (Criteria) this;
        }

        public Criteria andNoteIsNull() {
            addCriterion("note is null");
            return (Criteria) this;
        }

        public Criteria andNoteIsNotNull() {
            addCriterion("note is not null");
            return (Criteria) this;
        }

        public Criteria andNoteEqualTo(String value) {
            addCriterion("note =", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotEqualTo(String value) {
            addCriterion("note <>", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThan(String value) {
            addCriterion("note >", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThanOrEqualTo(String value) {
            addCriterion("note >=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThan(String value) {
            addCriterion("note <", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThanOrEqualTo(String value) {
            addCriterion("note <=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLike(String value) {
            addCriterion("note like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotLike(String value) {
            addCriterion("note not like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteIn(List<String> values) {
            addCriterion("note in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotIn(List<String> values) {
            addCriterion("note not in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteBetween(String value1, String value2) {
            addCriterion("note between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotBetween(String value1, String value2) {
            addCriterion("note not between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andFilecountIsNull() {
            addCriterion("fileCount is null");
            return (Criteria) this;
        }

        public Criteria andFilecountIsNotNull() {
            addCriterion("fileCount is not null");
            return (Criteria) this;
        }

        public Criteria andFilecountEqualTo(Integer value) {
            addCriterion("fileCount =", value, "filecount");
            return (Criteria) this;
        }

        public Criteria andFilecountNotEqualTo(Integer value) {
            addCriterion("fileCount <>", value, "filecount");
            return (Criteria) this;
        }

        public Criteria andFilecountGreaterThan(Integer value) {
            addCriterion("fileCount >", value, "filecount");
            return (Criteria) this;
        }

        public Criteria andFilecountGreaterThanOrEqualTo(Integer value) {
            addCriterion("fileCount >=", value, "filecount");
            return (Criteria) this;
        }

        public Criteria andFilecountLessThan(Integer value) {
            addCriterion("fileCount <", value, "filecount");
            return (Criteria) this;
        }

        public Criteria andFilecountLessThanOrEqualTo(Integer value) {
            addCriterion("fileCount <=", value, "filecount");
            return (Criteria) this;
        }

        public Criteria andFilecountIn(List<Integer> values) {
            addCriterion("fileCount in", values, "filecount");
            return (Criteria) this;
        }

        public Criteria andFilecountNotIn(List<Integer> values) {
            addCriterion("fileCount not in", values, "filecount");
            return (Criteria) this;
        }

        public Criteria andFilecountBetween(Integer value1, Integer value2) {
            addCriterion("fileCount between", value1, value2, "filecount");
            return (Criteria) this;
        }

        public Criteria andFilecountNotBetween(Integer value1, Integer value2) {
            addCriterion("fileCount not between", value1, value2, "filecount");
            return (Criteria) this;
        }

        public Criteria andCompleteflagIsNull() {
            addCriterion("completeFlag is null");
            return (Criteria) this;
        }

        public Criteria andCompleteflagIsNotNull() {
            addCriterion("completeFlag is not null");
            return (Criteria) this;
        }

        public Criteria andCompleteflagEqualTo(Integer value) {
            addCriterion("completeFlag =", value, "completeflag");
            return (Criteria) this;
        }

        public Criteria andCompleteflagNotEqualTo(Integer value) {
            addCriterion("completeFlag <>", value, "completeflag");
            return (Criteria) this;
        }

        public Criteria andCompleteflagGreaterThan(Integer value) {
            addCriterion("completeFlag >", value, "completeflag");
            return (Criteria) this;
        }

        public Criteria andCompleteflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("completeFlag >=", value, "completeflag");
            return (Criteria) this;
        }

        public Criteria andCompleteflagLessThan(Integer value) {
            addCriterion("completeFlag <", value, "completeflag");
            return (Criteria) this;
        }

        public Criteria andCompleteflagLessThanOrEqualTo(Integer value) {
            addCriterion("completeFlag <=", value, "completeflag");
            return (Criteria) this;
        }

        public Criteria andCompleteflagIn(List<Integer> values) {
            addCriterion("completeFlag in", values, "completeflag");
            return (Criteria) this;
        }

        public Criteria andCompleteflagNotIn(List<Integer> values) {
            addCriterion("completeFlag not in", values, "completeflag");
            return (Criteria) this;
        }

        public Criteria andCompleteflagBetween(Integer value1, Integer value2) {
            addCriterion("completeFlag between", value1, value2, "completeflag");
            return (Criteria) this;
        }

        public Criteria andCompleteflagNotBetween(Integer value1, Integer value2) {
            addCriterion("completeFlag not between", value1, value2, "completeflag");
            return (Criteria) this;
        }

        public Criteria andArchiveflagIsNull() {
            addCriterion("archiveFlag is null");
            return (Criteria) this;
        }

        public Criteria andArchiveflagIsNotNull() {
            addCriterion("archiveFlag is not null");
            return (Criteria) this;
        }

        public Criteria andArchiveflagEqualTo(Integer value) {
            addCriterion("archiveFlag =", value, "archiveflag");
            return (Criteria) this;
        }

        public Criteria andArchiveflagNotEqualTo(Integer value) {
            addCriterion("archiveFlag <>", value, "archiveflag");
            return (Criteria) this;
        }

        public Criteria andArchiveflagGreaterThan(Integer value) {
            addCriterion("archiveFlag >", value, "archiveflag");
            return (Criteria) this;
        }

        public Criteria andArchiveflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("archiveFlag >=", value, "archiveflag");
            return (Criteria) this;
        }

        public Criteria andArchiveflagLessThan(Integer value) {
            addCriterion("archiveFlag <", value, "archiveflag");
            return (Criteria) this;
        }

        public Criteria andArchiveflagLessThanOrEqualTo(Integer value) {
            addCriterion("archiveFlag <=", value, "archiveflag");
            return (Criteria) this;
        }

        public Criteria andArchiveflagIn(List<Integer> values) {
            addCriterion("archiveFlag in", values, "archiveflag");
            return (Criteria) this;
        }

        public Criteria andArchiveflagNotIn(List<Integer> values) {
            addCriterion("archiveFlag not in", values, "archiveflag");
            return (Criteria) this;
        }

        public Criteria andArchiveflagBetween(Integer value1, Integer value2) {
            addCriterion("archiveFlag between", value1, value2, "archiveflag");
            return (Criteria) this;
        }

        public Criteria andArchiveflagNotBetween(Integer value1, Integer value2) {
            addCriterion("archiveFlag not between", value1, value2, "archiveflag");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreatedateEqualTo(Date value) {
            addCriterion("createDate =", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThan(Date value) {
            addCriterion("createDate <", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateIn(List<Date> values) {
            addCriterion("createDate in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andLupdateIsNull() {
            addCriterion("lupDate is null");
            return (Criteria) this;
        }

        public Criteria andLupdateIsNotNull() {
            addCriterion("lupDate is not null");
            return (Criteria) this;
        }

        public Criteria andLupdateEqualTo(Date value) {
            addCriterion("lupDate =", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotEqualTo(Date value) {
            addCriterion("lupDate <>", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateGreaterThan(Date value) {
            addCriterion("lupDate >", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateGreaterThanOrEqualTo(Date value) {
            addCriterion("lupDate >=", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateLessThan(Date value) {
            addCriterion("lupDate <", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateLessThanOrEqualTo(Date value) {
            addCriterion("lupDate <=", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateIn(List<Date> values) {
            addCriterion("lupDate in", values, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotIn(List<Date> values) {
            addCriterion("lupDate not in", values, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateBetween(Date value1, Date value2) {
            addCriterion("lupDate between", value1, value2, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotBetween(Date value1, Date value2) {
            addCriterion("lupDate not between", value1, value2, "lupdate");
            return (Criteria) this;
        }

        public Criteria andArchivedateIsNull() {
            addCriterion("archiveDate is null");
            return (Criteria) this;
        }

        public Criteria andArchivedateIsNotNull() {
            addCriterion("archiveDate is not null");
            return (Criteria) this;
        }

        public Criteria andArchivedateEqualTo(Date value) {
            addCriterion("archiveDate =", value, "archivedate");
            return (Criteria) this;
        }

        public Criteria andArchivedateNotEqualTo(Date value) {
            addCriterion("archiveDate <>", value, "archivedate");
            return (Criteria) this;
        }

        public Criteria andArchivedateGreaterThan(Date value) {
            addCriterion("archiveDate >", value, "archivedate");
            return (Criteria) this;
        }

        public Criteria andArchivedateGreaterThanOrEqualTo(Date value) {
            addCriterion("archiveDate >=", value, "archivedate");
            return (Criteria) this;
        }

        public Criteria andArchivedateLessThan(Date value) {
            addCriterion("archiveDate <", value, "archivedate");
            return (Criteria) this;
        }

        public Criteria andArchivedateLessThanOrEqualTo(Date value) {
            addCriterion("archiveDate <=", value, "archivedate");
            return (Criteria) this;
        }

        public Criteria andArchivedateIn(List<Date> values) {
            addCriterion("archiveDate in", values, "archivedate");
            return (Criteria) this;
        }

        public Criteria andArchivedateNotIn(List<Date> values) {
            addCriterion("archiveDate not in", values, "archivedate");
            return (Criteria) this;
        }

        public Criteria andArchivedateBetween(Date value1, Date value2) {
            addCriterion("archiveDate between", value1, value2, "archivedate");
            return (Criteria) this;
        }

        public Criteria andArchivedateNotBetween(Date value1, Date value2) {
            addCriterion("archiveDate not between", value1, value2, "archivedate");
            return (Criteria) this;
        }

        public Criteria andReturnstatusIsNull() {
            addCriterion("returnStatus is null");
            return (Criteria) this;
        }

        public Criteria andReturnstatusIsNotNull() {
            addCriterion("returnStatus is not null");
            return (Criteria) this;
        }

        public Criteria andReturnstatusEqualTo(Integer value) {
            addCriterion("returnStatus =", value, "returnstatus");
            return (Criteria) this;
        }

        public Criteria andReturnstatusNotEqualTo(Integer value) {
            addCriterion("returnStatus <>", value, "returnstatus");
            return (Criteria) this;
        }

        public Criteria andReturnstatusGreaterThan(Integer value) {
            addCriterion("returnStatus >", value, "returnstatus");
            return (Criteria) this;
        }

        public Criteria andReturnstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("returnStatus >=", value, "returnstatus");
            return (Criteria) this;
        }

        public Criteria andReturnstatusLessThan(Integer value) {
            addCriterion("returnStatus <", value, "returnstatus");
            return (Criteria) this;
        }

        public Criteria andReturnstatusLessThanOrEqualTo(Integer value) {
            addCriterion("returnStatus <=", value, "returnstatus");
            return (Criteria) this;
        }

        public Criteria andReturnstatusIn(List<Integer> values) {
            addCriterion("returnStatus in", values, "returnstatus");
            return (Criteria) this;
        }

        public Criteria andReturnstatusNotIn(List<Integer> values) {
            addCriterion("returnStatus not in", values, "returnstatus");
            return (Criteria) this;
        }

        public Criteria andReturnstatusBetween(Integer value1, Integer value2) {
            addCriterion("returnStatus between", value1, value2, "returnstatus");
            return (Criteria) this;
        }

        public Criteria andReturnstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("returnStatus not between", value1, value2, "returnstatus");
            return (Criteria) this;
        }

        public Criteria andDocstatusIsNull() {
            addCriterion("docStatus is null");
            return (Criteria) this;
        }

        public Criteria andDocstatusIsNotNull() {
            addCriterion("docStatus is not null");
            return (Criteria) this;
        }

        public Criteria andDocstatusEqualTo(Integer value) {
            addCriterion("docStatus =", value, "docstatus");
            return (Criteria) this;
        }

        public Criteria andDocstatusNotEqualTo(Integer value) {
            addCriterion("docStatus <>", value, "docstatus");
            return (Criteria) this;
        }

        public Criteria andDocstatusGreaterThan(Integer value) {
            addCriterion("docStatus >", value, "docstatus");
            return (Criteria) this;
        }

        public Criteria andDocstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("docStatus >=", value, "docstatus");
            return (Criteria) this;
        }

        public Criteria andDocstatusLessThan(Integer value) {
            addCriterion("docStatus <", value, "docstatus");
            return (Criteria) this;
        }

        public Criteria andDocstatusLessThanOrEqualTo(Integer value) {
            addCriterion("docStatus <=", value, "docstatus");
            return (Criteria) this;
        }

        public Criteria andDocstatusIn(List<Integer> values) {
            addCriterion("docStatus in", values, "docstatus");
            return (Criteria) this;
        }

        public Criteria andDocstatusNotIn(List<Integer> values) {
            addCriterion("docStatus not in", values, "docstatus");
            return (Criteria) this;
        }

        public Criteria andDocstatusBetween(Integer value1, Integer value2) {
            addCriterion("docStatus between", value1, value2, "docstatus");
            return (Criteria) this;
        }

        public Criteria andDocstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("docStatus not between", value1, value2, "docstatus");
            return (Criteria) this;
        }

        public Criteria andReportnumberIsNull() {
            addCriterion("reportNumber is null");
            return (Criteria) this;
        }

        public Criteria andReportnumberIsNotNull() {
            addCriterion("reportNumber is not null");
            return (Criteria) this;
        }

        public Criteria andReportnumberEqualTo(String value) {
            addCriterion("reportNumber =", value, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberNotEqualTo(String value) {
            addCriterion("reportNumber <>", value, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberGreaterThan(String value) {
            addCriterion("reportNumber >", value, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberGreaterThanOrEqualTo(String value) {
            addCriterion("reportNumber >=", value, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberLessThan(String value) {
            addCriterion("reportNumber <", value, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberLessThanOrEqualTo(String value) {
            addCriterion("reportNumber <=", value, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberLike(String value) {
            addCriterion("reportNumber like", value, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberNotLike(String value) {
            addCriterion("reportNumber not like", value, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberIn(List<String> values) {
            addCriterion("reportNumber in", values, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberNotIn(List<String> values) {
            addCriterion("reportNumber not in", values, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberBetween(String value1, String value2) {
            addCriterion("reportNumber between", value1, value2, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andReportnumberNotBetween(String value1, String value2) {
            addCriterion("reportNumber not between", value1, value2, "reportnumber");
            return (Criteria) this;
        }

        public Criteria andIsnewIsNull() {
            addCriterion("isNew is null");
            return (Criteria) this;
        }

        public Criteria andIsnewIsNotNull() {
            addCriterion("isNew is not null");
            return (Criteria) this;
        }

        public Criteria andIsnewEqualTo(Integer value) {
            addCriterion("isNew =", value, "isnew");
            return (Criteria) this;
        }

        public Criteria andIsnewNotEqualTo(Integer value) {
            addCriterion("isNew <>", value, "isnew");
            return (Criteria) this;
        }

        public Criteria andIsnewGreaterThan(Integer value) {
            addCriterion("isNew >", value, "isnew");
            return (Criteria) this;
        }

        public Criteria andIsnewGreaterThanOrEqualTo(Integer value) {
            addCriterion("isNew >=", value, "isnew");
            return (Criteria) this;
        }

        public Criteria andIsnewLessThan(Integer value) {
            addCriterion("isNew <", value, "isnew");
            return (Criteria) this;
        }

        public Criteria andIsnewLessThanOrEqualTo(Integer value) {
            addCriterion("isNew <=", value, "isnew");
            return (Criteria) this;
        }

        public Criteria andIsnewIn(List<Integer> values) {
            addCriterion("isNew in", values, "isnew");
            return (Criteria) this;
        }

        public Criteria andIsnewNotIn(List<Integer> values) {
            addCriterion("isNew not in", values, "isnew");
            return (Criteria) this;
        }

        public Criteria andIsnewBetween(Integer value1, Integer value2) {
            addCriterion("isNew between", value1, value2, "isnew");
            return (Criteria) this;
        }

        public Criteria andIsnewNotBetween(Integer value1, Integer value2) {
            addCriterion("isNew not between", value1, value2, "isnew");
            return (Criteria) this;
        }

        public Criteria andIsvarietyIsNull() {
            addCriterion("isVariety is null");
            return (Criteria) this;
        }

        public Criteria andIsvarietyIsNotNull() {
            addCriterion("isVariety is not null");
            return (Criteria) this;
        }

        public Criteria andIsvarietyEqualTo(Integer value) {
            addCriterion("isVariety =", value, "isvariety");
            return (Criteria) this;
        }

        public Criteria andIsvarietyNotEqualTo(Integer value) {
            addCriterion("isVariety <>", value, "isvariety");
            return (Criteria) this;
        }

        public Criteria andIsvarietyGreaterThan(Integer value) {
            addCriterion("isVariety >", value, "isvariety");
            return (Criteria) this;
        }

        public Criteria andIsvarietyGreaterThanOrEqualTo(Integer value) {
            addCriterion("isVariety >=", value, "isvariety");
            return (Criteria) this;
        }

        public Criteria andIsvarietyLessThan(Integer value) {
            addCriterion("isVariety <", value, "isvariety");
            return (Criteria) this;
        }

        public Criteria andIsvarietyLessThanOrEqualTo(Integer value) {
            addCriterion("isVariety <=", value, "isvariety");
            return (Criteria) this;
        }

        public Criteria andIsvarietyIn(List<Integer> values) {
            addCriterion("isVariety in", values, "isvariety");
            return (Criteria) this;
        }

        public Criteria andIsvarietyNotIn(List<Integer> values) {
            addCriterion("isVariety not in", values, "isvariety");
            return (Criteria) this;
        }

        public Criteria andIsvarietyBetween(Integer value1, Integer value2) {
            addCriterion("isVariety between", value1, value2, "isvariety");
            return (Criteria) this;
        }

        public Criteria andIsvarietyNotBetween(Integer value1, Integer value2) {
            addCriterion("isVariety not between", value1, value2, "isvariety");
            return (Criteria) this;
        }

        public Criteria andHasexcIsNull() {
            addCriterion("hasExc is null");
            return (Criteria) this;
        }

        public Criteria andHasexcIsNotNull() {
            addCriterion("hasExc is not null");
            return (Criteria) this;
        }

        public Criteria andHasexcEqualTo(Integer value) {
            addCriterion("hasExc =", value, "hasexc");
            return (Criteria) this;
        }

        public Criteria andHasexcNotEqualTo(Integer value) {
            addCriterion("hasExc <>", value, "hasexc");
            return (Criteria) this;
        }

        public Criteria andHasexcGreaterThan(Integer value) {
            addCriterion("hasExc >", value, "hasexc");
            return (Criteria) this;
        }

        public Criteria andHasexcGreaterThanOrEqualTo(Integer value) {
            addCriterion("hasExc >=", value, "hasexc");
            return (Criteria) this;
        }

        public Criteria andHasexcLessThan(Integer value) {
            addCriterion("hasExc <", value, "hasexc");
            return (Criteria) this;
        }

        public Criteria andHasexcLessThanOrEqualTo(Integer value) {
            addCriterion("hasExc <=", value, "hasexc");
            return (Criteria) this;
        }

        public Criteria andHasexcIn(List<Integer> values) {
            addCriterion("hasExc in", values, "hasexc");
            return (Criteria) this;
        }

        public Criteria andHasexcNotIn(List<Integer> values) {
            addCriterion("hasExc not in", values, "hasexc");
            return (Criteria) this;
        }

        public Criteria andHasexcBetween(Integer value1, Integer value2) {
            addCriterion("hasExc between", value1, value2, "hasexc");
            return (Criteria) this;
        }

        public Criteria andHasexcNotBetween(Integer value1, Integer value2) {
            addCriterion("hasExc not between", value1, value2, "hasexc");
            return (Criteria) this;
        }

        public Criteria andBusinessidIsNull() {
            addCriterion("businessID is null");
            return (Criteria) this;
        }

        public Criteria andBusinessidIsNotNull() {
            addCriterion("businessID is not null");
            return (Criteria) this;
        }

        public Criteria andBusinessidEqualTo(Integer value) {
            addCriterion("businessID =", value, "businessid");
            return (Criteria) this;
        }

        public Criteria andBusinessidNotEqualTo(Integer value) {
            addCriterion("businessID <>", value, "businessid");
            return (Criteria) this;
        }

        public Criteria andBusinessidGreaterThan(Integer value) {
            addCriterion("businessID >", value, "businessid");
            return (Criteria) this;
        }

        public Criteria andBusinessidGreaterThanOrEqualTo(Integer value) {
            addCriterion("businessID >=", value, "businessid");
            return (Criteria) this;
        }

        public Criteria andBusinessidLessThan(Integer value) {
            addCriterion("businessID <", value, "businessid");
            return (Criteria) this;
        }

        public Criteria andBusinessidLessThanOrEqualTo(Integer value) {
            addCriterion("businessID <=", value, "businessid");
            return (Criteria) this;
        }

        public Criteria andBusinessidIn(List<Integer> values) {
            addCriterion("businessID in", values, "businessid");
            return (Criteria) this;
        }

        public Criteria andBusinessidNotIn(List<Integer> values) {
            addCriterion("businessID not in", values, "businessid");
            return (Criteria) this;
        }

        public Criteria andBusinessidBetween(Integer value1, Integer value2) {
            addCriterion("businessID between", value1, value2, "businessid");
            return (Criteria) this;
        }

        public Criteria andBusinessidNotBetween(Integer value1, Integer value2) {
            addCriterion("businessID not between", value1, value2, "businessid");
            return (Criteria) this;
        }

        public Criteria andUpdatedateIsNull() {
            addCriterion("updateDate is null");
            return (Criteria) this;
        }

        public Criteria andUpdatedateIsNotNull() {
            addCriterion("updateDate is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatedateEqualTo(Date value) {
            addCriterion("updateDate =", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateNotEqualTo(Date value) {
            addCriterion("updateDate <>", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateGreaterThan(Date value) {
            addCriterion("updateDate >", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateGreaterThanOrEqualTo(Date value) {
            addCriterion("updateDate >=", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateLessThan(Date value) {
            addCriterion("updateDate <", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateLessThanOrEqualTo(Date value) {
            addCriterion("updateDate <=", value, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateIn(List<Date> values) {
            addCriterion("updateDate in", values, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateNotIn(List<Date> values) {
            addCriterion("updateDate not in", values, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateBetween(Date value1, Date value2) {
            addCriterion("updateDate between", value1, value2, "updatedate");
            return (Criteria) this;
        }

        public Criteria andUpdatedateNotBetween(Date value1, Date value2) {
            addCriterion("updateDate not between", value1, value2, "updatedate");
            return (Criteria) this;
        }

        public Criteria andSourceIsNull() {
            addCriterion("source is null");
            return (Criteria) this;
        }

        public Criteria andSourceIsNotNull() {
            addCriterion("source is not null");
            return (Criteria) this;
        }

        public Criteria andSourceEqualTo(Integer value) {
            addCriterion("source =", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotEqualTo(Integer value) {
            addCriterion("source <>", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceGreaterThan(Integer value) {
            addCriterion("source >", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceGreaterThanOrEqualTo(Integer value) {
            addCriterion("source >=", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceLessThan(Integer value) {
            addCriterion("source <", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceLessThanOrEqualTo(Integer value) {
            addCriterion("source <=", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceIn(List<Integer> values) {
            addCriterion("source in", values, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotIn(List<Integer> values) {
            addCriterion("source not in", values, "source");
            return (Criteria) this;
        }

        public Criteria andSourceBetween(Integer value1, Integer value2) {
            addCriterion("source between", value1, value2, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotBetween(Integer value1, Integer value2) {
            addCriterion("source not between", value1, value2, "source");
            return (Criteria) this;
        }

        public Criteria andSourcecompidIsNull() {
            addCriterion("sourceCompID is null");
            return (Criteria) this;
        }

        public Criteria andSourcecompidIsNotNull() {
            addCriterion("sourceCompID is not null");
            return (Criteria) this;
        }

        public Criteria andSourcecompidEqualTo(Integer value) {
            addCriterion("sourceCompID =", value, "sourcecompid");
            return (Criteria) this;
        }

        public Criteria andSourcecompidNotEqualTo(Integer value) {
            addCriterion("sourceCompID <>", value, "sourcecompid");
            return (Criteria) this;
        }

        public Criteria andSourcecompidGreaterThan(Integer value) {
            addCriterion("sourceCompID >", value, "sourcecompid");
            return (Criteria) this;
        }

        public Criteria andSourcecompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("sourceCompID >=", value, "sourcecompid");
            return (Criteria) this;
        }

        public Criteria andSourcecompidLessThan(Integer value) {
            addCriterion("sourceCompID <", value, "sourcecompid");
            return (Criteria) this;
        }

        public Criteria andSourcecompidLessThanOrEqualTo(Integer value) {
            addCriterion("sourceCompID <=", value, "sourcecompid");
            return (Criteria) this;
        }

        public Criteria andSourcecompidIn(List<Integer> values) {
            addCriterion("sourceCompID in", values, "sourcecompid");
            return (Criteria) this;
        }

        public Criteria andSourcecompidNotIn(List<Integer> values) {
            addCriterion("sourceCompID not in", values, "sourcecompid");
            return (Criteria) this;
        }

        public Criteria andSourcecompidBetween(Integer value1, Integer value2) {
            addCriterion("sourceCompID between", value1, value2, "sourcecompid");
            return (Criteria) this;
        }

        public Criteria andSourcecompidNotBetween(Integer value1, Integer value2) {
            addCriterion("sourceCompID not between", value1, value2, "sourcecompid");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}