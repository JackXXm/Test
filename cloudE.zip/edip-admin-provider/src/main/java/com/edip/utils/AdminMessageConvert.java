package com.edip.utils;

import java.util.List;

import com.edip.entity.AdminMessage;
import com.edip.vo.AdminMessageVo;
import com.google.common.collect.Lists;

/**
 * Created by qiaoxiaolong on 2017/5/9.
 */
public class AdminMessageConvert {
    private AdminMessageConvert() {

    }

    public static final AdminMessage convert(AdminMessageVo messageVo) {
        if (null == messageVo) {
            return null;
        }
        AdminMessage message = new AdminMessage();
        message.setMsgID(messageVo.getMsgID());
        message.setMsgType(messageVo.getMsgType());
        message.setDataID(messageVo.getDataID());
        message.setDataType(messageVo.getDataType());
        message.setAccountID(messageVo.getAccountID());
        message.setCompID(messageVo.getCompID());
        message.setReceiveID(messageVo.getReceiveID());
        message.setReceiveCompID(messageVo.getReceiveCompID());
        message.setSender(messageVo.getSender());
        message.setTitle(messageVo.getTitle());
        message.setUrl(messageVo.getUrl());
        message.setStatus(messageVo.getStatus());
        message.setCreateDate(messageVo.getCreateDate());
        message.setValidDay(messageVo.getValidDay());
        message.setLupDate(messageVo.getLupDate());
        message.setContent(messageVo.getContent());
        message.setPage(messageVo.getPage());
        message.setRows(messageVo.getRows());
        message.setFrom(messageVo.getFrom());
        message.setTo(messageVo.getTo());
        message.setSendTime(messageVo.getSendTime());
        message.setClassify(messageVo.getClassify());
        return message;
    }

    public static final List<AdminMessage> convert(List<AdminMessageVo> listMessageVo) {
        if (listMessageVo == null) {
            return Lists.newArrayList();
        }
        List<AdminMessage> listMessage = Lists.newArrayList();
        for (AdminMessageVo messageVo : listMessageVo) {
            listMessage.add(AdminMessageConvert.convert(messageVo));
        }
        return listMessage;
    }
}
