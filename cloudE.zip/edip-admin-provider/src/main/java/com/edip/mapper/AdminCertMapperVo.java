package com.edip.mapper;

import com.edip.entity.AdminCert;
import com.edip.entity.AdminCertExample;
import com.edip.entity.AdminCertWithBLOBs;
import com.edip.vo.AdminCertVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface AdminCertMapperVo {
//    int countByExample(CertExample example);

//    int deleteByExample(CertExample example);

    int deleteByPrimaryKey(Integer certID);

//    int insert(CertWithBLOBs record);

//    int insertSelective(CertWithBLOBs record);
    
    int insertSelectiveVo(AdminCertVo record);

//    List<CertWithBLOBs> selectByExampleWithBLOBsWithPage(@Param("example") CertExample example, @Param("from") Integer from, @Param("to") Integer to);

//    List<CertVo> selectByExampleVoWithPage(@Param("example") CertExample example, @Param("from") Integer from, @Param("to") Integer to);

    List<AdminCertWithBLOBs> selectByExampleWithBLOBs(AdminCertExample example);

    List<AdminCert> selectByExampleWithPage(@Param("example") AdminCertExample example, @Param("from") Integer from, @Param("to") Integer to);

    List<AdminCert> selectByExample(AdminCertExample example);

    AdminCertWithBLOBs selectByPrimaryKey(Integer certID);

//    CertWithBLOBs selelctCertBySN(CertVo record);

//    int updateByExampleSelective(@Param("record") CertWithBLOBs record, @Param("example") CertExample example);

//    int updateByExampleWithBLOBs(@Param("record") CertWithBLOBs record, @Param("example") CertExample example);

    int updateByExample(@Param("record") AdminCert record, @Param("example") AdminCertExample example);

    int updateByPrimaryKeySelective(AdminCertVo record);
    
//    int updateByCompIdSelective(CertWithBLOBs record);

//    int updateByPrimaryKeyWithBLOBs(CertWithBLOBs record);

    int updateByPrimaryKey(AdminCert record);

    List<Map<String,Object>> getUkeyCountInfo(Map<String,Object> params);

    List<Map<String,String>> getCompTypeStr(Map<String,Object> params);

    Integer getUkeyCountInfoCount(Map<String,Object> params);

//    CertWithBLOBs selelctCertCompId(Integer compID);
//
//    CertWithBLOBs selectByUkStauts(CertVo record);
//
//
//    List<CertWithBLOBs> selelctCertCompIdStatus(Integer compID);
    
}