package com.edip.entity;

import java.util.ArrayList;
import java.util.List;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class AddressExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public AddressExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAdrIDIsNull() {
            addCriterion("adrID is null");
            return (Criteria) this;
        }

        public Criteria andAdrIDIsNotNull() {
            addCriterion("adrID is not null");
            return (Criteria) this;
        }

        public Criteria andAdrIDEqualTo(Integer value) {
            addCriterion("adrID =", value, "adrID");
            return (Criteria) this;
        }

        public Criteria andAdrIDNotEqualTo(Integer value) {
            addCriterion("adrID <>", value, "adrID");
            return (Criteria) this;
        }

        public Criteria andAdrIDGreaterThan(Integer value) {
            addCriterion("adrID >", value, "adrID");
            return (Criteria) this;
        }

        public Criteria andAdrIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("adrID >=", value, "adrID");
            return (Criteria) this;
        }

        public Criteria andAdrIDLessThan(Integer value) {
            addCriterion("adrID <", value, "adrID");
            return (Criteria) this;
        }

        public Criteria andAdrIDLessThanOrEqualTo(Integer value) {
            addCriterion("adrID <=", value, "adrID");
            return (Criteria) this;
        }

        public Criteria andAdrIDIn(List<Integer> values) {
            addCriterion("adrID in", values, "adrID");
            return (Criteria) this;
        }

        public Criteria andAdrIDNotIn(List<Integer> values) {
            addCriterion("adrID not in", values, "adrID");
            return (Criteria) this;
        }

        public Criteria andAdrIDBetween(Integer value1, Integer value2) {
            addCriterion("adrID between", value1, value2, "adrID");
            return (Criteria) this;
        }

        public Criteria andAdrIDNotBetween(Integer value1, Integer value2) {
            addCriterion("adrID not between", value1, value2, "adrID");
            return (Criteria) this;
        }

        public Criteria andCompIDIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompIDIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompIDEqualTo(Integer value) {
            addCriterion("compID =", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDGreaterThan(Integer value) {
            addCriterion("compID >", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDLessThan(Integer value) {
            addCriterion("compID <", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDIn(List<Integer> values) {
            addCriterion("compID in", values, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compID");
            return (Criteria) this;
        }

        public Criteria andProvinceIDIsNull() {
            addCriterion("provinceID is null");
            return (Criteria) this;
        }

        public Criteria andProvinceIDIsNotNull() {
            addCriterion("provinceID is not null");
            return (Criteria) this;
        }

        public Criteria andProvinceIDEqualTo(Integer value) {
            addCriterion("provinceID =", value, "provinceID");
            return (Criteria) this;
        }

        public Criteria andProvinceIDNotEqualTo(Integer value) {
            addCriterion("provinceID <>", value, "provinceID");
            return (Criteria) this;
        }

        public Criteria andProvinceIDGreaterThan(Integer value) {
            addCriterion("provinceID >", value, "provinceID");
            return (Criteria) this;
        }

        public Criteria andProvinceIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("provinceID >=", value, "provinceID");
            return (Criteria) this;
        }

        public Criteria andProvinceIDLessThan(Integer value) {
            addCriterion("provinceID <", value, "provinceID");
            return (Criteria) this;
        }

        public Criteria andProvinceIDLessThanOrEqualTo(Integer value) {
            addCriterion("provinceID <=", value, "provinceID");
            return (Criteria) this;
        }

        public Criteria andProvinceIDIn(List<Integer> values) {
            addCriterion("provinceID in", values, "provinceID");
            return (Criteria) this;
        }

        public Criteria andProvinceIDNotIn(List<Integer> values) {
            addCriterion("provinceID not in", values, "provinceID");
            return (Criteria) this;
        }

        public Criteria andProvinceIDBetween(Integer value1, Integer value2) {
            addCriterion("provinceID between", value1, value2, "provinceID");
            return (Criteria) this;
        }

        public Criteria andProvinceIDNotBetween(Integer value1, Integer value2) {
            addCriterion("provinceID not between", value1, value2, "provinceID");
            return (Criteria) this;
        }

        public Criteria andCityIDIsNull() {
            addCriterion("cityID is null");
            return (Criteria) this;
        }

        public Criteria andCityIDIsNotNull() {
            addCriterion("cityID is not null");
            return (Criteria) this;
        }

        public Criteria andCityIDEqualTo(Integer value) {
            addCriterion("cityID =", value, "cityID");
            return (Criteria) this;
        }

        public Criteria andCityIDNotEqualTo(Integer value) {
            addCriterion("cityID <>", value, "cityID");
            return (Criteria) this;
        }

        public Criteria andCityIDGreaterThan(Integer value) {
            addCriterion("cityID >", value, "cityID");
            return (Criteria) this;
        }

        public Criteria andCityIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("cityID >=", value, "cityID");
            return (Criteria) this;
        }

        public Criteria andCityIDLessThan(Integer value) {
            addCriterion("cityID <", value, "cityID");
            return (Criteria) this;
        }

        public Criteria andCityIDLessThanOrEqualTo(Integer value) {
            addCriterion("cityID <=", value, "cityID");
            return (Criteria) this;
        }

        public Criteria andCityIDIn(List<Integer> values) {
            addCriterion("cityID in", values, "cityID");
            return (Criteria) this;
        }

        public Criteria andCityIDNotIn(List<Integer> values) {
            addCriterion("cityID not in", values, "cityID");
            return (Criteria) this;
        }

        public Criteria andCityIDBetween(Integer value1, Integer value2) {
            addCriterion("cityID between", value1, value2, "cityID");
            return (Criteria) this;
        }

        public Criteria andCityIDNotBetween(Integer value1, Integer value2) {
            addCriterion("cityID not between", value1, value2, "cityID");
            return (Criteria) this;
        }

        public Criteria andSiteIsNull() {
            addCriterion("site is null");
            return (Criteria) this;
        }

        public Criteria andSiteIsNotNull() {
            addCriterion("site is not null");
            return (Criteria) this;
        }

        public Criteria andSiteEqualTo(String value) {
            addCriterion("site =", value, "site");
            return (Criteria) this;
        }

        public Criteria andSiteNotEqualTo(String value) {
            addCriterion("site <>", value, "site");
            return (Criteria) this;
        }

        public Criteria andSiteGreaterThan(String value) {
            addCriterion("site >", value, "site");
            return (Criteria) this;
        }

        public Criteria andSiteGreaterThanOrEqualTo(String value) {
            addCriterion("site >=", value, "site");
            return (Criteria) this;
        }

        public Criteria andSiteLessThan(String value) {
            addCriterion("site <", value, "site");
            return (Criteria) this;
        }

        public Criteria andSiteLessThanOrEqualTo(String value) {
            addCriterion("site <=", value, "site");
            return (Criteria) this;
        }

        public Criteria andSiteLike(String value) {
            addCriterion("site like", value, "site");
            return (Criteria) this;
        }

        public Criteria andSiteNotLike(String value) {
            addCriterion("site not like", value, "site");
            return (Criteria) this;
        }

        public Criteria andSiteIn(List<String> values) {
            addCriterion("site in", values, "site");
            return (Criteria) this;
        }

        public Criteria andSiteNotIn(List<String> values) {
            addCriterion("site not in", values, "site");
            return (Criteria) this;
        }

        public Criteria andSiteBetween(String value1, String value2) {
            addCriterion("site between", value1, value2, "site");
            return (Criteria) this;
        }

        public Criteria andSiteNotBetween(String value1, String value2) {
            addCriterion("site not between", value1, value2, "site");
            return (Criteria) this;
        }

        public Criteria andLinkManIsNull() {
            addCriterion("linkMan is null");
            return (Criteria) this;
        }

        public Criteria andLinkManIsNotNull() {
            addCriterion("linkMan is not null");
            return (Criteria) this;
        }

        public Criteria andLinkManEqualTo(String value) {
            addCriterion("linkMan =", value, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManNotEqualTo(String value) {
            addCriterion("linkMan <>", value, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManGreaterThan(String value) {
            addCriterion("linkMan >", value, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManGreaterThanOrEqualTo(String value) {
            addCriterion("linkMan >=", value, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManLessThan(String value) {
            addCriterion("linkMan <", value, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManLessThanOrEqualTo(String value) {
            addCriterion("linkMan <=", value, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManLike(String value) {
            addCriterion("linkMan like", value, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManNotLike(String value) {
            addCriterion("linkMan not like", value, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManIn(List<String> values) {
            addCriterion("linkMan in", values, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManNotIn(List<String> values) {
            addCriterion("linkMan not in", values, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManBetween(String value1, String value2) {
            addCriterion("linkMan between", value1, value2, "linkMan");
            return (Criteria) this;
        }

        public Criteria andLinkManNotBetween(String value1, String value2) {
            addCriterion("linkMan not between", value1, value2, "linkMan");
            return (Criteria) this;
        }

        public Criteria andMsisdnIsNull() {
            addCriterion("msisdn is null");
            return (Criteria) this;
        }

        public Criteria andMsisdnIsNotNull() {
            addCriterion("msisdn is not null");
            return (Criteria) this;
        }

        public Criteria andMsisdnEqualTo(String value) {
            addCriterion("msisdn =", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnNotEqualTo(String value) {
            addCriterion("msisdn <>", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnGreaterThan(String value) {
            addCriterion("msisdn >", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnGreaterThanOrEqualTo(String value) {
            addCriterion("msisdn >=", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnLessThan(String value) {
            addCriterion("msisdn <", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnLessThanOrEqualTo(String value) {
            addCriterion("msisdn <=", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnLike(String value) {
            addCriterion("msisdn like", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnNotLike(String value) {
            addCriterion("msisdn not like", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnIn(List<String> values) {
            addCriterion("msisdn in", values, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnNotIn(List<String> values) {
            addCriterion("msisdn not in", values, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnBetween(String value1, String value2) {
            addCriterion("msisdn between", value1, value2, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnNotBetween(String value1, String value2) {
            addCriterion("msisdn not between", value1, value2, "msisdn");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}