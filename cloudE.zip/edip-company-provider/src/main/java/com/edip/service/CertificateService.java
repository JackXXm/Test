package com.edip.service;

import com.edip.entity.Address;


public interface CertificateService {
	int addOrEditUkeyAdress(Address address);
	
	Address getAddressByCompId(Integer compId);
} 
