package com.edip.service;

import com.edip.vo.UKeyVo;

import java.util.List;
import java.util.Map;

public interface UKeyCertificateService {

	List<Map<String,Object>>checkMessage(UKeyVo uKeyVo, Map<String, Object> map);
	
	int  queryCert(Integer compID);

}
