package com.edip.vo;

import org.apache.commons.lang.StringUtils;

/**
 * 证书吊销接口请求消息类
 * @author zhangjie_d
 *
 */
public class RevokeCertReqVO {

	private String platformid;//平台标识
	
	private String certsn;//证书序列号
	
	private String operationtype="2";//证书操作类型4: 冻结  5: 解冻  2: 吊销
	
	private String revokeReason;//吊销原因

	public String toXML() {
		StringBuffer buffer = new StringBuffer(
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><request command=\"certRevokeRequest\">");

		buffer.append("<platformid>");
		if (!StringUtils.isEmpty(this.platformid)) {
			buffer.append(this.platformid);
		}
		buffer.append("</platformid>");

		buffer.append("<parameters>");

		buffer.append("<certsn>");
		if (!StringUtils.isEmpty(this.certsn)) {
			buffer.append(this.certsn);
		}
		buffer.append("</certsn>");

		buffer.append("<operationtype>");
		if (!StringUtils.isEmpty(this.operationtype)) {
			buffer.append(this.operationtype);
		}
		buffer.append("</operationtype>");

		buffer.append("<revokeReason>");
		if (!StringUtils.isEmpty(this.revokeReason)) {
			buffer.append(this.revokeReason);
		}
		buffer.append("</revokeReason>");

		buffer.append("</parameters>");
		buffer.append("</request>");

		return buffer.toString();
	}	
	
	public String getPlatformid() {
		return platformid;
	}

	public void setPlatformid(String platformid) {
		this.platformid = platformid;
	}

	public String getCertsn() {
		return certsn;
	}

	public void setCertsn(String certsn) {
		this.certsn = certsn;
	}

	public String getOperationtype() {
		return operationtype;
	}

	public void setOperationtype(String operationtype) {
		this.operationtype = operationtype;
	}

	public String getRevokeReason() {
		return revokeReason;
	}

	public void setRevokeReason(String revokeReason) {
		this.revokeReason = revokeReason;
	}
	
}
