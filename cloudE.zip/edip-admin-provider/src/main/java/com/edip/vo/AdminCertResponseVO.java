package com.edip.vo;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.StringReader;

/**
 * CertResponseVO.java      2012-8-3
 * 证书操作响应VO（包括证书（个人、企业、账号）申请、更新、下载等）
 * @System: CA 1.0
 * @Description:
 * @Copyright: Copyright (c) 2012
 * @Company: Aspire Technologies
 * @version 1.0
 * @author: huangliang
 */
public class AdminCertResponseVO {
	/** 返回结果： 0-申请处理成功;1-CA接收申请，但需要审核或用户确认;2-申请参数错误;3- 系统内部错误 */
	private String result;
	/** 表示异常的描述 */
	private String errormsg;
	/** 业务受理号 */
	private String transactioncode;
	/** 验证码 */
	private String authcode;
	/** 证书类型：1:单证书 2:双证书 */
	private String certtype;
	/** 证书格式（1：仅包含公钥的签名证书 2：包含公私钥p12证书） */
	private String certformat;
	/** 签名证书（对于CA生成密钥情况，这里是p12格式证书） */
	private String signcert;
	/** 加密证书 */
	private String enccert;
	/** 包装加密私钥的数字信封 */
	private String encprikey;
	
	/**
	 * @description: 构造函数
	 */
	public AdminCertResponseVO() {

	}

	public AdminCertResponseVO(String xml) throws DocumentException {
		toBean(xml);
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getErrormsg() {
		return errormsg;
	}

	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}

	public String getTransactioncode() {
		return transactioncode;
	}

	public void setTransactioncode(String transactioncode) {
		this.transactioncode = transactioncode;
	}

	public String getAuthcode() {
		return authcode;
	}

	public void setAuthcode(String authcode) {
		this.authcode = authcode;
	}

	public String getCerttype() {
		return certtype;
	}

	public void setCerttype(String certtype) {
		this.certtype = certtype;
	}

	public String getCertformat() {
		return certformat;
	}

	public void setCertformat(String certformat) {
		this.certformat = certformat;
	}

	public String getSigncert() {
		return signcert;
	}

	public void setSigncert(String signcert) {
		this.signcert = signcert;
	}

	public String getEnccert() {
		return enccert;
	}

	public void setEnccert(String enccert) {
		this.enccert = enccert;
	}

	public String getEncprikey() {
		return encprikey;
	}

	public void setEncprikey(String encprikey) {
		this.encprikey = encprikey;
	}

	/**
	 * Constructs a <code>String</code> with all attributes in name = value
	 * format.
	 * 
	 * @return a <code>String</code> representation of this object.
	 */
	public String toString() {
		final String TAB = "    ";

		StringBuffer retValue = new StringBuffer();

		retValue.append("CertResponseVO ( ").append(super.toString()).append(
				TAB).append("result = ").append(this.result).append(TAB)
				.append("errormsg = ").append(this.errormsg).append(TAB)
				.append("transactioncode = ").append(this.transactioncode)
				.append(TAB).append("authcode = ").append(this.authcode)
				.append(TAB).append("certtype = ").append(this.certtype)
				.append(TAB).append("certformat = ").append(this.certformat)
				.append(TAB).append("signcert = ").append(this.signcert)
				.append(TAB).append("enccert = ").append(this.enccert).append(
						TAB).append("encprikey = ").append(this.encprikey)
				.append(TAB).append(" )");

		return retValue.toString();
	}

	/**
	 * 解析XML转为BEAN
	 * 
	 * @param xml
	 * @throws DocumentException
	 */
	private void toBean(String xml) throws DocumentException {
		// 解析xml
		SAXReader reader = new SAXReader();
		Document document = reader.read(new StringReader(xml));
		Element body = document.getRootElement();
		this.result = body.element("result").getText();
		this.errormsg = body.element("errormsg").getText();
		this.transactioncode = body.element("transactioncode").getText();
		this.authcode = body.element("authcode").getText();
		this.certtype = body.element("certtype").getText();
		this.certformat = body.element("certformat").getText();
		this.signcert = body.element("signcert").getText();
		this.enccert = body.element("enccert").getText();
		this.encprikey = body.element("encprikey").getText();
	}

}
