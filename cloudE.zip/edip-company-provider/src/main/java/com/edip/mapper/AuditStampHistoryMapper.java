package com.edip.mapper;

import com.edip.entity.AuditStampHistory;
import com.edip.entity.AuditStampHistoryExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface AuditStampHistoryMapper {
    long countByExample(AuditStampHistoryExample example);

    int deleteByExample(AuditStampHistoryExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(AuditStampHistory record);

    int insertSelective(AuditStampHistory record);

    List<AuditStampHistory> selectByExample(AuditStampHistoryExample example);

    AuditStampHistory selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AuditStampHistory record, @Param("example") AuditStampHistoryExample example);

    int updateByExample(@Param("record") AuditStampHistory record, @Param("example") AuditStampHistoryExample example);

    int updateByPrimaryKeySelective(AuditStampHistory record);

    int updateByPrimaryKey(AuditStampHistory record);
}