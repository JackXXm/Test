package com.edip.entity;

public class CertWithBLOBs extends Cert {
    private byte[] x509;

    private byte[] publicKey;

    private Integer provinceID;

    private Integer cityID;

    private Integer areaID;
    private String compName;

    public Integer getProvinceID() {
        return provinceID;
    }

    public void setProvinceID(Integer provinceID) {
        this.provinceID = provinceID;
    }

    public Integer getCityID() {
        return cityID;
    }

    public void setCityID(Integer cityID) {
        this.cityID = cityID;
    }

    public Integer getAreaID() {
        return areaID;
    }

    public void setAreaID(Integer areaID) {
        this.areaID = areaID;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public byte[] getX509() {
        return x509;
    }

    public void setX509(byte[] x509) {
        this.x509 = x509;
    }

    public byte[] getPublickey() {
        return publicKey;
    }

    public void setPublickey(byte[] publickey) {
        this.publicKey = publickey;
    }
}