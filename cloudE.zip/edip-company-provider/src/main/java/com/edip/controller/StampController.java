package com.edip.controller;
import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.entity.Stamp;
import com.edip.service.StampService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


@RestController
//@RequestMapping("/stamp")
public class StampController {
    private static final Logger LOGGER = LoggerFactory.getLogger(StampController.class);
    @Autowired
    private StampService stampService;
    @Autowired
    private HttpServletRequest request;
    @RequestMapping(value="/getStampList.ajax")
    public ServerResponse getStampList(String stampName, boolean signList,Integer page,Integer rows,boolean checkReportFlag){
        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            if(!signList){
                PageHelper.startPage(page,rows);
                return ServerResponse.createBySuccess(new PageInfo(stampService.getStampList(stampName,companyId,signList,checkReportFlag)));
            }else
                return ServerResponse.createBySuccess(stampService.getStampList(stampName,companyId,signList,checkReportFlag));
        }catch (Exception e){
            LOGGER.error("getStampList error",e);
            return  ServerResponse.createByError();
        }
    }

    @RequestMapping(value="/addStamp.ajax")
    public ServerResponse addStamp( Stamp stamp){
        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            Integer accountId= (Integer) httpSession.getAttribute("accountID");
            String accountName = (String) httpSession.getAttribute("accountName");
            String companyName = (String)httpSession.getAttribute("companyName");

            //测试数据
//            companyId = 2317;
//            companyName = "北京欢迎你公司b";
//            accountId = 4689;
//            accountName = "欢迎";

            stamp.setCompid(companyId);
            stamp.setAccountid(accountId);
            stamp.setAccountName(accountName);
            stamp.setCompanyName(companyName);
            int flag=stampService.addStamp(stamp);
            if(flag>0){
                return ServerResponse.createBySuccess("添加成功！");
            }else{
                return ServerResponse.createByError(100,"同类型印章只能有一个");
            }

        }catch (Exception e){
            LOGGER.error("getStampList error",e);
            return  ServerResponse.createByError();
        }
    }

    /**
     * 印章管理点击修改
     */
    @SuppressWarnings("restriction")
    @RequestMapping(value = "/revise.ajax")
    public ServerResponse revise(HttpServletRequest request,@RequestParam(value = "stampID", required = false) Integer stampID,
                                          @RequestParam(value = "tempUrl", required = false) String tempUrl) {
        Integer companyID = (Integer)SessionContext.getContext().getSession(request).getAttribute("compID");
        String accountName = (String) SessionContext.getContext().getSession(request).getAttribute("accountName");
        Integer accountID = (Integer) SessionContext.getContext().getSession(request).getAttribute("accountID");
        try {

            int amount = stampService.updateStamp(stampID,tempUrl,companyID,accountName,accountID);
            if (amount > 0){
               return ServerResponse.createBySuccess();
            } else if(amount == -1) {
                return ServerResponse.createByError(100,"印章只能有一个");
            } else{
                return ServerResponse.createByErrorMsg("印章修改失败！");
            }
        } catch (Exception e) {
            LOGGER.error("修改印章失败"+e.getMessage(), e);
            return ServerResponse.createByErrorMsg("修改印章失败");
        }
    }

    /**
     * 印章管理点击删除
     */
    @RequestMapping(value = "/del.ajax")
    public ServerResponse deleteData(@RequestParam(value = "stampID", required = false) Integer stampID,HttpServletRequest request) {
        int compID = (Integer)SessionContext.getContext().getSession(request).getAttribute("compID");
        try {
          if(null != stampID){
                int amount = stampService.deleteData(stampID);
                if (amount > 0){
                    return ServerResponse.createBySuccess("删除成功！");
                }else{
                    return ServerResponse.createByErrorMsg("删除失败");
                }
            }else {
              return ServerResponse.createByErrorMsg("参数异常");
          }

        } catch (Exception e) {
            LOGGER.error("删除印章失败"+e.getMessage(), e);
            return ServerResponse.createByError();
        }

    }

}
