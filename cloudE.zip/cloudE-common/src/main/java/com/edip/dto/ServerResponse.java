package com.edip.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;

public class ServerResponse<T> implements Serializable {
    private  int status;

    private String msg;

    private T data;

    public  ServerResponse(){}

    private ServerResponse (int status){

        this.status=status;

    }

    public ServerResponse (int status, String msg){

        this.status=status;

        this.msg=msg;

    }

    private ServerResponse (int status,String  msg,T data){

        this.status=status;

        this.msg=msg;

        this.data=data;

    }

    private ServerResponse(int  status,T data){

        this.status=status;

        this.data=data;

    }

    @JsonIgnore

//忽略，使之不在json序列化当中

    public boolean  isSuccess(){

        return this.status==ResponseCode.SUCCESS.getCode();

    }

    public int  getStatus(){

        return status;

    }

    public T  getData(){

        return data;

    }

    public String  getMsg(){

        return msg;

    }

    public static  <T>ServerResponse  createBySuccess(){

        return new  ServerResponse(ResponseCode.SUCCESS.getCode());

    }

    public static <T>ServerResponse createBySuccessMsg(String msg ){

        return new ServerResponse(ResponseCode.SUCCESS.getCode(),msg);

    }

    public static <T>ServerResponse createBySuccess(T data){

        return new ServerResponse(ResponseCode.SUCCESS.getCode(),data);

    }

    public static <T>ServerResponse createBySuccess(String msg , T  data){

        return new ServerResponse(ResponseCode.SUCCESS.getCode(), msg, data);

    }

    public static <T>ServerResponse createByError(){

        return new ServerResponse(ResponseCode.ERROR.getCode(),ResponseCode.ERROR.getMsg());

    }

    public static <T>ServerResponse createByErrorMsg(String msg){

        return new ServerResponse(ResponseCode.ERROR.getCode(),msg);

    }

    public static <T>ServerResponse createByError(int  code,String  msg){

        return new ServerResponse( code,msg);

    }

    public static <T>ServerResponse createByError(int  code,String  msg,T data){

        return new ServerResponse( code,msg,data);

    }

}
