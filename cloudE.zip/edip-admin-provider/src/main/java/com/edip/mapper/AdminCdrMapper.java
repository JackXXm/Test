package com.edip.mapper;

import java.util.List;

import com.edip.entity.AdminCdr;
import com.edip.entity.AdminCdrExample;
import org.apache.ibatis.annotations.Param;

public interface AdminCdrMapper {
    int countByExample(AdminCdrExample example);

    int deleteByExample(AdminCdrExample example);

    int deleteByPrimaryKey(Integer cdrID);

    int insert(AdminCdr record);

    int insertSelective(AdminCdr record);

    List<AdminCdr> selectByExampleWithPage(@Param("example") AdminCdrExample example, @Param("from") Integer from, @Param("to") Integer to);

    List<AdminCdr> selectByExample(AdminCdrExample example);

    AdminCdr selectByPrimaryKey(Integer cdrID);

    int updateByExampleSelective(@Param("record") AdminCdr record, @Param("example") AdminCdrExample example);

    int updateByExample(@Param("record") AdminCdr record, @Param("example") AdminCdrExample example);

    int updateByPrimaryKeySelective(AdminCdr record);

    int updateByPrimaryKey(AdminCdr record);
}