package com.edip.utils;

import com.alibaba.fastjson.JSONObject;
import com.edip.dto.util.RedisUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class AdminFileUtil {

    private static String MESSAGE = "";
    private static String tempPath;
    @Value("${LOCAL_ABSOLUTE_TEMP_PATH}")
    public void setTEMP_ROOT_PATH(String TEMP_ROOT_PATH) {
        this.tempPath = TEMP_ROOT_PATH;
    }
    private static String rootPath;
    @Value("${ABSOLUTE_UPLOAD_PATH}")
    public void setABSOLUTE_UPLOAD_PATH(String ABSOLUTE_UPLOAD_PATH) {
        this.rootPath = ABSOLUTE_UPLOAD_PATH;
    }
    private static final Logger logger = LoggerFactory.getLogger(AdminFileUtil.class);
    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * 复制单个文件
     *
     * @param srcFileName  待复制的文件名
     * @param destFileName 目标文件名
     * @param overlay      如果目标文件存在，是否覆盖
     * @return 如果复制成功返回true，否则返回false
     */
    public static boolean copyFile(String srcFileName, String destFileName, boolean overlay) {
        File srcFile = new File(srcFileName);

        // 判断源文件是否存在
        if (!srcFile.exists()) {
            MESSAGE = "file：" + srcFileName + " does not exists！";
            logger.error(MESSAGE);
            return false;
        } else if (!srcFile.isFile()) {
            MESSAGE = "copy file fail，file：" + srcFileName + " is not a file！";
            logger.error(MESSAGE);
            return false;
        }

        // 判断目标文件是否存在
        File destFile = new File(destFileName);
        if (destFile.exists()) {
            // 如果目标文件存在并允许覆盖
            if (overlay) {
                // 删除已经存在的目标文件，无论目标文件是目录还是单个文件
                new File(destFileName).delete();
            }
        } else {
            // 如果目标文件所在目录不存在，则创建目录
            if (!destFile.getParentFile().exists()) {
                // 目标文件所在目录不存在
                if (!destFile.getParentFile().mkdirs()) {
                    // 复制文件失败：创建目标文件所在目录失败
                    return false;
                }
            }
        }

        // 复制文件
        int byteread = 0; // 读取的字节数
        InputStream in = null;
        OutputStream out = null;

        try {
            in = new FileInputStream(srcFile);
            out = new FileOutputStream(destFile);
            byte[] buffer = new byte[1024];

            while ((byteread = in.read(buffer)) != -1) {
                out.write(buffer, 0, byteread);
            }
            return true;
        } catch (FileNotFoundException e) {
            return false;
        } catch (IOException e) {
            return false;
        } finally {
            try {
                if (out != null)
                    out.close();
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 复制整个目录的内容
     *
     * @param srcDirName  待复制目录的目录名
     * @param destDirName 目标目录名
     * @param overlay     如果目标目录存在，是否覆盖
     * @return 如果复制成功返回true，否则返回false
     */
//    public static boolean copyDirectory(String srcDirName, String destDirName, boolean overlay) {
//        // 判断源目录是否存在
//        File srcDir = new File(srcDirName);
//        if (!srcDir.exists()) {
//            MESSAGE = "复制目录失败：源目录" + srcDirName + "不存在！";
//            logger.error(MESSAGE);
//            return false;
//        } else if (!srcDir.isDirectory()) {
//            MESSAGE = "复制目录失败：" + srcDirName + "不是目录！";
//            logger.error(MESSAGE);
//            return false;
//        }
//
//        // 如果目标目录名不是以文件分隔符结尾，则加上文件分隔符
//        if (!destDirName.endsWith(File.separator)) {
//            destDirName = destDirName + File.separator;
//        }
//        File destDir = new File(destDirName);
//        // 如果目标文件夹存在
//        if (destDir.exists()) {
//            // 如果允许覆盖则删除已存在的目标目录
//            if (overlay) {
//                new File(destDirName).delete();
//            } else {
//                MESSAGE = "复制目录失败：目的目录" + destDirName + "已存在！";
//                logger.error(MESSAGE);
//                return false;
//            }
//        } else {
//            // 创建目的目录
//            System.out.println("目的目录不存在，准备创建。。。");
//            if (!destDir.mkdirs()) {
//                System.out.println("复制目录失败：创建目的目录失败！");
//                return false;
//            }
//        }
//
//        boolean flag = true;
//        File[] files = srcDir.listFiles();
//        for (int i = 0; i < files.length; i++) {
//            // 复制文件
//            if (files[i].isFile()) {
//                flag = FileUtil.copyFile(files[i].getAbsolutePath(), destDirName + files[i].getName(), overlay);
//                if (!flag)
//                    break;
//            } else if (files[i].isDirectory()) {
//                flag = FileUtil.copyDirectory(files[i].getAbsolutePath(), destDirName + files[i].getName(), overlay);
//                if (!flag)
//                    break;
//            }
//        }
//        if (!flag) {
//            MESSAGE = "复制目录" + srcDirName + "至" + destDirName + "失败！";
//            logger.error(MESSAGE);
//            return false;
//        } else {
//            return true;
//        }
//    }

    public static void downloadFiles(HttpServletRequest request, HttpServletResponse response, String[] urlPaths)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        List<File> files = new ArrayList<File>();
        int index = 0;
        long fileLength = 0;
        for (String filePath : urlPaths) {
            File file = new File(rootPath + filePath);
            if (file.exists()) {
                files.add(file);
                fileLength += file.length();
                index++;
            }
        }
        String fileName = UUID.randomUUID().toString() + ".zip";
        // 在服务器端创建打包下载的临时文件
        // String outFilePath = rootPath + fileName;
        File file = null;
        try {

            file = new File(fileName);
            // 文件输出流
            FileOutputStream outStream = new FileOutputStream(file);
            // 压缩流
            ZipOutputStream toClient = new ZipOutputStream(outStream);
            toClient.setEncoding("utf-8");
            zipFile(files, toClient);
            toClient.close();
            outStream.close();
            downloadZip(file, response);
        } catch (Exception e) {
            logger.error("打包下载的文件失败", e);
        } finally {
            if (file != null)
                file.delete();
        }

    }

    /**
     * 下载有明确名字的压缩包及资质
     *
     * @param request
     * @param response
     * @param docMap
     * @param zipName
     * @throws ServletException
     * @throws IOException
     */
    public static void downloadFilesWithName(HttpServletRequest request, HttpServletResponse response,
                                             Map<String, Object> docMap, String zipName) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        List<File> files = new ArrayList<File>();
        int index = 0;
        long fileLength = 0;
        Map<String, Object> fileMap = new HashMap<String, Object>();
        Set<String> s = docMap.keySet();
        for (String key : s) {
            File file = new File(rootPath + docMap.get(key));
            if (file.exists()) {
                fileMap.put(key, file);
                fileLength += file.length();
                index++;
            }
        }
        String fileName = "";
        if (zipName.indexOf("(") > -1) {
            int inde = zipName.indexOf("(");
            fileName = zipName.substring(0, inde) + ".zip";
        } else {
            fileName = zipName + ".zip";
        }
        String newFileName = fileName.replaceAll("\\\\", ".").replaceAll("/", ".").replaceAll(" ", "-").replaceAll(";",
                "--");
        newFileName = java.net.URLEncoder.encode(newFileName, "gb2312");
        newFileName = java.net.URLDecoder.decode(newFileName, "ISO-8859-1");

        // String newFileName = java.net.URLEncoder.encode(fileName, "UTF-8");
        /*
         * .replaceAll("\\+", "%20").replaceAll("%28", "\\(") .replaceAll("%29",
         * "\\)").replaceAll("%3B", ";").replaceAll("%40", "@")
         * .replaceAll("%23", "\\#").replaceAll("%26", "\\&").replaceAll("%2C",
         * "\\,");
         */
        // 在服务器端创建打包下载的临时文件
        // String outFilePath = rootPath + fileName;
        File file = null;
        try {

            file = new File(newFileName);
            // 文件输出流
            FileOutputStream outStream = new FileOutputStream(file);
            // 压缩流
            ZipOutputStream toClient = new ZipOutputStream(outStream);
            toClient.setEncoding("UTF-8");
            zipFileForMap(fileMap, toClient);
            toClient.close();
            outStream.close();
            downloadZip(file, response);
        } catch (Exception e) {
            logger.error("打包下载的文件失败", e);
        } finally {
            if (file != null)
                file.delete();
        }

    }

    /**
     * 压缩文件列表中的文件
     *
     * @param files
     * @param outputStream
     * @throws IOException
     */
    public static void zipFile(List files, ZipOutputStream outputStream) throws IOException, ServletException {
        try {
            int size = files.size();
            // 压缩列表中的文件
            for (int i = 0; i < size; i++) {
                File file = (File) files.get(i);
                zipFile(file, outputStream);
            }
        } catch (IOException e) {
            logger.error("压缩文件列表中的文件失败！", e);
        }
    }

    /**
     * 压缩文件列表中的文件
     *
     * @param fileMap
     * @param outputStream
     * @throws IOException
     */
    public static void zipFileForMap(Map<String, Object> fileMap, ZipOutputStream outputStream)
            throws IOException, ServletException {
        try {
            Set<String> s = fileMap.keySet();
            for (String key : s) {
                zipFileForMap((File) fileMap.get(key), key, outputStream);
            }
        } catch (Exception e) {
            logger.error("压缩文件列表中的文件失败！", e);
        }
    }

    /**
     * 将文件写入到zip文件中
     *
     * @param inputFile
     * @param outputstream
     * @throws Exception
     */
    public static void zipFile(File inputFile, ZipOutputStream outputstream) throws IOException, ServletException {
        try {
            if (inputFile.exists()) {
                if (inputFile.isFile()) {
                    FileInputStream inStream = new FileInputStream(inputFile);
                    BufferedInputStream bInStream = new BufferedInputStream(inStream);
                    ZipEntry entry = new ZipEntry(inputFile.getName());
                    outputstream.putNextEntry(entry);

                    final int MAX_BYTE = 10 * 1024 * 1024; // 最大的流为10M
                    long streamTotal = 0; // 接受流的容量
                    int streamNum = 0; // 流需要分开的数量
                    int leaveByte = 0; // 文件剩下的字符数
                    byte[] inOutbyte; // byte数组接受文件的数据

                    streamTotal = bInStream.available(); // 通过available方法取得流的最大字符数
                    streamNum = (int) Math.floor(streamTotal / MAX_BYTE); // 取得流文件需要分开的数量
                    leaveByte = (int) streamTotal % MAX_BYTE; // 分开文件之后,剩余的数量

                    if (streamNum > 0) {
                        for (int j = 0; j < streamNum; ++j) {
                            inOutbyte = new byte[MAX_BYTE];
                            // 读入流,保存在byte数组
                            bInStream.read(inOutbyte, 0, MAX_BYTE);
                            outputstream.write(inOutbyte, 0, MAX_BYTE); // 写出流
                        }
                    }
                    // 写出剩下的流数据
                    inOutbyte = new byte[leaveByte];
                    bInStream.read(inOutbyte, 0, leaveByte);
                    outputstream.write(inOutbyte);
                    outputstream.closeEntry(); // Closes the current ZIP entry
                    // and positions the stream for
                    // writing the next entry
                    bInStream.close(); // 关闭
                    inStream.close();
                }
            } else {
                logger.error("文件不存在！");
            }
        } catch (IOException e) {
            logger.error("压缩文件出错", e);
        }
    }

    /**
     * 将文件写入到zip文件中
     *
     * @param inputFile
     * @param outputstream
     * @throws Exception
     */
    public static void zipFileForMap(File inputFile, String fileName, ZipOutputStream outputstream)
            throws IOException, ServletException {
        try {
            if (inputFile.exists()) {
                if (inputFile.isFile()) {
                    FileInputStream inStream = new FileInputStream(inputFile);
                    BufferedInputStream bInStream = new BufferedInputStream(inStream);
                    // ZipEntry entry = new ZipEntry(inputFile.getName());
                    ZipEntry entry = new ZipEntry(fileName);
                    outputstream.setEncoding(System.getProperty("sun.jnu.encoding"));
                    outputstream.putNextEntry(entry);

                    final int MAX_BYTE = 10 * 1024 * 1024; // 最大的流为10M
                    long streamTotal = 0; // 接受流的容量
                    int streamNum = 0; // 流需要分开的数量
                    int leaveByte = 0; // 文件剩下的字符数
                    byte[] inOutbyte; // byte数组接受文件的数据

                    streamTotal = bInStream.available(); // 通过available方法取得流的最大字符数
                    streamNum = (int) Math.floor(streamTotal / MAX_BYTE); // 取得流文件需要分开的数量
                    leaveByte = (int) streamTotal % MAX_BYTE; // 分开文件之后,剩余的数量

                    if (streamNum > 0) {
                        for (int j = 0; j < streamNum; ++j) {
                            inOutbyte = new byte[MAX_BYTE];
                            // 读入流,保存在byte数组
                            bInStream.read(inOutbyte, 0, MAX_BYTE);
                            outputstream.write(inOutbyte, 0, MAX_BYTE); // 写出流
                        }
                    }
                    // 写出剩下的流数据
                    inOutbyte = new byte[leaveByte];
                    bInStream.read(inOutbyte, 0, leaveByte);
                    outputstream.write(inOutbyte);
                    outputstream.closeEntry(); // Closes the current ZIP entry
                    // and positions the stream for
                    // writing the next entry
                    bInStream.close(); // 关闭
                    inStream.close();
                }
            } else {
                logger.error("文件不存在！");
            }
        } catch (IOException e) {
            logger.error("压缩文件出错", e);
        }
    }

    /**
     * 下载打包的文件
     *
     * @param file
     * @param response
     */
    public static void downloadZip(File file, HttpServletResponse response) {
        try {
            // response.reset();
            response.setHeader("Content-Length", String.valueOf(file.length()));
            response.setContentType("multipart/form-data");
            response.setHeader("Content-Disposition", "attachment;filename=" + file.getName());
            // 以流的形式下载文件。
            BufferedInputStream fis = new BufferedInputStream(new FileInputStream(file.getPath()));
            int len = 0;
            byte[] bb = new byte[1024];
            while ((len = fis.read(bb)) != -1) {
                response.getOutputStream().write(bb, 0, len);
            }
            fis.close();
            // 清空response

            response.getOutputStream().flush();
            response.getOutputStream().close();
            file.delete(); // 将生成的服务器端文件删除
        } catch (Exception ex) {
            logger.error("下载打包的文件出错", ex);
        }
    }

    /**
     * 移动文件
     *
     * @param from
     * @param type
     * @throws Exception
     */

//    public static String fileMove(String from, String type, String compId, RedisUtil util) throws Exception {// 移动指定文件夹内的全部文件
//
//        String separator = "/";
//        // 文件目录
//        String to = separator + "data" + separator + "doc" + separator + compId + separator + type;
//        if (from.startsWith("/temp")) {
//            from = from.substring(5);
//        }
//        if (from.endsWith(".pdf")) {
//            if (!check(tempPath + from)) {
//                throw new Exception("文件已损坏");
//            }
//            ;
//        }
//        File dir = new File(tempPath + from);
//
//        FileInputStream fis = null;
//        byte[] bytes = null;
//        fis = new FileInputStream(dir);
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        byte[] temp = new byte[1024];
//        int len = 0;
//
//        while ((len = fis.read(temp)) != -1) {
//            bos.write(temp, 0, len);
//        }
//
//        String fileName = dir.getName();
//        if (fileName.contains("\\")) {
//            fileName = fileName.substring(fileName.lastIndexOf("\\") + 1);
//        } else {
//            fileName = fileName.substring(fileName.lastIndexOf("/") + 1);
//        }
//
//
//        if (bos != null) {
//            bytes = bos.toByteArray();
//            bos.close();
//            FileInfo fileInfo = new FileInfo();
//            fileInfo.setFileContent(bytes);
//            fileInfo.setFileName(fileName);
//            fileInfo.setUtil(util);
//            fileInfo.setCompanyId(Integer.parseInt(compId));
//            fileName = FileLibUtil.uploadFileSigle(fileInfo);
//            if (fileName != null) {
//                return fileName;
//            } else {
//                throw new Exception("file upload fail");
//
//            }
//
//        }
//        return null;
//
//
//    }

    public static List<Map<String, Object>> getFileUrl(List<Map<String, Object>> documents, RedisUtil util) {
        for (Map<String, Object> map : documents) {
            String filePath = (String) map.get("docUrl");

            map.put("docUrl", getFilePath(filePath, util));
        }
        return documents;
    }

//    public static List<DocVo> getFileUrlByDocVo(List<DocVo> documents, RedisUtil util) {
//        for (DocVo map : documents) {
//            String filePath = map.getDocUrl();
//            map.setDocUrl(getFilePath(filePath, util));
//
//        }
//        return documents;
//    }

    public static String getFilePath(String docUrl, RedisUtil util) {
        return com.edip.dto.util.StringUtils.getFilePath(docUrl,util);
    }


//    public static boolean check(String file) {
//        boolean flag1 = false;
//        int n = 0;
//        try {
//            Document document = new Document(new PdfReader(file).getPageSize(1));
//            document.open();
//            PdfReader reader = new PdfReader(file);
//            n = reader.getNumberOfPages();
//            if (n != 0)
//                flag1 = true;
//            document.close();
//        } catch (IOException e) {
//            System.out.println(e.getMessage());
//        }
//        return flag1;
//
//    }

    /**
     * * 等比例压缩算法：
     * <p>
     * 算法思想：根据压缩基数和压缩比来压缩原图，生产一张图片效果最接近原图的缩略图
     *
     * @param srcURL  原图地址
     * @param deskURL 缩略图地址
     * @param width   压缩宽度 传0是等比例压缩
     * @param height
     */
    public static Boolean zipImageFile(String srcURL, String deskURL, int width, int height) {
        File srcFile = null;
        Image src = null;
        FileOutputStream deskImage = null;
        try {
            srcFile = new File(srcURL);
            src = ImageIO.read(srcFile);
            int srcHeight = src.getHeight(null);
            int srcWidth = src.getWidth(null);
            double bili;
            if (width > 0) {
                bili = width / (double) srcWidth;
                height = (int) (srcHeight * bili);
            } else {
                width = srcWidth;
                height = srcHeight;
            }
            BufferedImage tag = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
            tag.getGraphics().drawImage(src, 0, 0, width, height, null); // 绘制缩小后的图
            File toFilePath = new File(deskURL.substring(0, deskURL.lastIndexOf("/")));
            if (!toFilePath.exists()) {
                toFilePath.mkdirs();
            }
            // 输出到文件流
            deskImage = new FileOutputStream(deskURL);
			/*JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(deskImage);
			encoder.encode(tag); // 近JPEG编码
*/
            ImageIO.write(tag, "JPEG", deskImage);
            return true;
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            if (null != deskImage) {
                try {
                    deskImage.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
        return false;
    }

//    /**
//     * 解压文件到指定目录
//     *
//     * @param multipartFile 上传压缩文件
//     * @return FileHandleResponse 表示上传结果实体对象
//     */
//    @SuppressWarnings("rawtypes")
//    public static FileHandleResponse unZipFiles(MultipartFile multipartFile) throws IOException {
//        FileHandleResponse fileHandleResponse = new FileHandleResponse();
//        Charset gbk = Charset.forName("GBK");
//        String path = AttachmentConfigUtil.getProperty("LOCAL_ABSOLUTE_TEMP_PATH");
//        String separator = "/";
//        String unZipRealPath = path + separator + "zip" + separator + UUID.randomUUID().toString().replaceAll("-", "")
//                + separator;
//        List<String> fileList = new ArrayList<String>();
//        // 如果保存解压缩文件的目录不存在，则进行创建，并且解压缩后的文件总是放在以fileName命名的文件夹下
//        File unZipFile = new File(unZipRealPath);
//        if (!unZipFile.exists()) {
//            unZipFile.mkdirs();
//        }
//        ZipInputStream zipInputStream = new ZipInputStream(multipartFile.getInputStream(), Charset.forName("gbk"));
//        java.util.zip.ZipEntry zipEntry;
//        OutputStream outputStream = null;
//        try {
//            while ((zipEntry = zipInputStream.getNextEntry()) != null) {
//                String zipEntryName = zipEntry.getName();
//                // 将目录中的1个或者多个\置换为/，因为在windows目录下，以\或者\\为文件目录分隔符，linux却是/
//                String outPath = (unZipRealPath + zipEntryName).replaceAll("\\+", "/");
//                File file = new File(outPath);
//                // 如果是文件夹就创建文件夹
//                if (zipEntry.isDirectory()) {
//                    if (!file.exists()) {
//                        file.mkdirs();
//                    }
//                } else {
//                    File filePath = file.getParentFile();
//                    if (!filePath.exists()) {
//                        filePath.mkdirs();
//                    }
//                    outputStream = new FileOutputStream(outPath);
//                    byte[] bytes = new byte[4096];
//                    int len;
//                    // 当read的返回值为-1，表示碰到当前项的结尾，而不是碰到zip文件的末尾
//                    while ((len = zipInputStream.read(bytes)) > 0) {
//                        outputStream.write(bytes, 0, len);
//                    }
//                    outputStream.close();
//                    // 必须调用closeEntry()方法来读入下一项
//                    zipInputStream.closeEntry();
//                    fileList.add(outPath);
//                }
//            }
//            fileHandleResponse.setMessageCode(200);
//            fileHandleResponse.setFileList(fileList);
//            fileHandleResponse.setMessage("fail");
//            fileHandleResponse.setUrl((unZipRealPath).replaceAll("\\+", "/"));
//            System.out.println("******************解压完毕********************");
//        } catch (Exception e) {
//            e.printStackTrace();
//            logger.info("解压zip异常====================" + e.getMessage());
//            fileHandleResponse.setMessageCode(500);
//            fileHandleResponse.setMessage("service error!");
//            return fileHandleResponse;
//        } finally {
//            if (null != outputStream) {
//                outputStream.close();
//            }
//            if (null != zipInputStream) {
//                zipInputStream.close();
//            }
//        }
//        return fileHandleResponse;
//    }

//    /**
//     * 解压缩ZIP文件，将ZIP文件里的内容解压
//     *
//     * @param zipFileName 需要解压的ZIP文件
//     */
//    public static FileHandleResponse unZipFile(String zipFileName) {
//        FileHandleResponse fileHandleResponse = new FileHandleResponse();
//        List<String> fileList = new ArrayList<String>();
//        // 解压文件夹
//        String descFileNames = tempPath + File.separator + "zip" + File.separator
//                + UUID.randomUUID().toString().replaceAll("-", "") + File.separator;
//        try {
//            // 根据ZIP文件创建ZipFile对象
//            ZipFile zipFile = new ZipFile(zipFileName, "gbk");
//            ZipEntry entry = null;
//            String entryName = null;
//            String descFileDir = null;
//            byte[] buf = new byte[4096];
//            int readByte = 0;
//            // 获取ZIP文件里所有的entry
//            @SuppressWarnings("rawtypes")
//            Enumeration enums = zipFile.getEntries();
//            // 遍历所有entry
//            while (enums.hasMoreElements()) {
//                entry = (ZipEntry) enums.nextElement();
//                // 获得entry的名字
//                entryName = entry.getName();
//                descFileDir = descFileNames + entryName;
//                if (entry.isDirectory()) {
//                    // 如果entry是一个目录，则创建目录
//                    new File(descFileDir).mkdirs();
//                    continue;
//                } else {
//                    // 如果entry是一个文件，则创建父目录
//                    new File(descFileDir).getParentFile().mkdirs();
//                    fileList.add(descFileDir);
//                }
//                File file = new File(descFileDir);
//                // 打开文件输出流
//                OutputStream os = new FileOutputStream(file);
//                // 从ZipFile对象中打开entry的输入流
//                InputStream is = zipFile.getInputStream(entry);
//                while ((readByte = is.read(buf)) != -1) {
//                    os.write(buf, 0, readByte);
//                }
//                os.close();
//                is.close();
//            }
//            zipFile.close();
//            fileHandleResponse.setMessageCode(200);
//            fileHandleResponse.setFileList(fileList);
//            fileHandleResponse.setMessage("success");
//            fileHandleResponse.setUrl((descFileNames).replaceAll("\\+", "/"));
//            logger.debug("文件解压成功!");
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            logger.debug("文件解压失败：" + e.getMessage());
//            fileHandleResponse.setMessageCode(500);
//            fileHandleResponse.setMessage("service error!");
//            return fileHandleResponse;
//        }
//        return fileHandleResponse;
//    }
//
//    /**
//     * 解压缩ZIP文件，将ZIP文件里的内容解压到descFileName目录下
//     *
//     * @param zipFileName  需要解压的ZIP文件
//     * @param descFileName 目标文件
//     */
//    public static boolean unZipFiles(String zipFileName, String descFileName) {
//        String descFileNames = descFileName;
//        if (!descFileNames.endsWith(File.separator)) {
//            descFileNames = descFileNames + File.separator;
//        }
//        try {
//            // 根据ZIP文件创建ZipFile对象
//            ZipFile zipFile = new ZipFile(zipFileName);
//            ZipEntry entry = null;
//            String entryName = null;
//            String descFileDir = null;
//            byte[] buf = new byte[4096];
//            int readByte = 0;
//            // 获取ZIP文件里所有的entry
//            @SuppressWarnings("rawtypes")
//            Enumeration enums = zipFile.getEntries();
//            // 遍历所有entry
//            while (enums.hasMoreElements()) {
//                entry = (ZipEntry) enums.nextElement();
//                // 获得entry的名字
//                entryName = entry.getName();
//                descFileDir = descFileNames + entryName;
//                if (entry.isDirectory()) {
//                    // 如果entry是一个目录，则创建目录
//                    new File(descFileDir).mkdirs();
//                    continue;
//                } else {
//                    // 如果entry是一个文件，则创建父目录
//                    new File(descFileDir).getParentFile().mkdirs();
//                }
//                File file = new File(descFileDir);
//                // 打开文件输出流
//                OutputStream os = new FileOutputStream(file);
//                // 从ZipFile对象中打开entry的输入流
//                InputStream is = zipFile.getInputStream(entry);
//                while ((readByte = is.read(buf)) != -1) {
//                    os.write(buf, 0, readByte);
//                }
//                os.close();
//                is.close();
//            }
//            zipFile.close();
//            logger.debug("文件解压成功!");
//            return true;
//        } catch (Exception e) {
//            logger.debug("文件解压失败：" + e.getMessage());
//            return false;
//        }
//    }
//
//    /**
//     * 判断文件是否存在
//     *
//     * @param path 文件路径
//     * @return true/false
//     */
//    // 判断文件是否存在
//    public static boolean FileIsExists(String path) {
//        File file = new File(path);
//        if (file.exists()) {
//            return true;
//        } else {
//            return false;
//        }
//    }
//
//    /**
//     * 判断是否是需要转换的图片格式
//     *
//     * @param path 图片路径
//     * @return true/false
//     */
//    public static boolean FileIsImg(String path) {
//        String imgType = path.substring(path.lastIndexOf(".") + 1, path.length());
//        String[] imagType = {"jpg", "png", "bmp", "gif"};
//        List<String> imageTyepList = Arrays.asList(imagType);
//        if (StringUtils.isNotBlank(imgType)) {
//            if (imageTyepList.contains(imgType.toLowerCase())) {
//                return true;
//            }
//        }
//        return false;
//    }
//
//    /**
//     * 移动文件
//     *
//     * @param fromPath 从哪个目录移动
//     * @param toPath   目标目录
//     * @throws Exception
//     */
//    public static Boolean PdfFileMove(String fromPath, String toPath) throws Exception {// 移动指定文件夹内的全部文件
//        try {
//            File dir = new File(fromPath);
//            File moveFile = new File(toPath);
//            File path = new File(toPath.substring(0, toPath.lastIndexOf("/")));
//            if (!path.exists()) {// 判断目标目录是否存在
//                path.mkdirs();// 不存在则创建
//            }
//            if (moveFile.exists()) {// 目标文件夹下存在的话，删除
//                moveFile.delete();
//            }
//            // 移动文件
//            if (dir.renameTo(moveFile)) {
//                logger.debug("文件移动成功！");
//                return true;
//            } else {
//                logger.error("文件移动失败！文件名：《{}》 起始路径：{}", moveFile.getName(), fromPath);
//
//            }
//        } catch (Exception e) {
//            logger.error("文件移动异常！");
//        }
//        return false;
//    }
//
//    /**
//     * 分片文件上传合并
//     *
//     * @param file
//     * @param request
//     * @param filePath 文件存储路径 以 /结尾
//     * @return code 0 上传成功 1 单个文件拷贝失败 2 分片文件拷贝失败 3 合并文件失败 4 保存文件路径为空 5 guid为空
//     */
//    public static Map<String, String> sliceUpload(MultipartFile file, HttpServletRequest request, String filePath) {
//        Map<String, String> map = new HashMap<String, String>();
//        // 上传成功
//        map.put("code", "0");
//        String guid = request.getParameter("guid");
//        String chunk = request.getParameter("chunk"); // 当前分片
//        String chunks = request.getParameter("chunks"); // 分片总计
//        String fileName = file.getOriginalFilename();
//        String fileType = fileName.substring(fileName.lastIndexOf("."), fileName.length());
//        String copyFilePath = null;
//        File copyFile = null;
//        if (StringUtils.isBlank(filePath)) {
//            map.put("code", "4");
//        }
//        if (StringUtils.isBlank(guid)) {
//            map.put("code", "5");
//        }
//        // 分片为空就当做不分片上传文件
//        if (StringUtils.isBlank(chunk) || StringUtils.isBlank(chunks)) {
//            try {
//                copyFilePath = filePath + UUID.randomUUID() + File.separator + fileName;
//                copyFile = new File(copyFilePath);
//                // 先创建文件存储路径
//                if (!copyFile.getParentFile().exists()) {
//                    copyFile.getParentFile().mkdirs();
//                }
//                file.transferTo(copyFile);
//            } catch (IllegalStateException | IOException e) {
//                // TODO Auto-generated catch block
//                // 文件拷贝失败
//                map.put("code", "1");
//                e.printStackTrace();
//            }
//        } else {
//            // 分片存储路径
//            String slicePath = tempPath + File.separator + "slice" + File.separator + guid + File.separator;
//            File sliceFilePath = new File(slicePath + chunk + fileType);
//            if (!sliceFilePath.getParentFile().exists()) {
//                sliceFilePath.getParentFile().mkdirs();
//            }
//            try {
//                // 保存分片
//                file.transferTo(sliceFilePath);
//            } catch (Exception e) {
//                // 分片文件拷贝失败
//                map.put("code", "2");
//                e.printStackTrace();
//            }
//            // 如果当前是最后一个分片，则合并所有文件
//            if (Integer.parseInt(chunk) == (Integer.parseInt(chunks) - 1)) {
//                // try {
//                // Thread.sleep(5000);
//                // } catch (InterruptedException e1) {
//                // // TODO Auto-generated catch block
//                // e1.printStackTrace();
//                // }
//                FileOutputStream fileOutputStream = null;
//                BufferedOutputStream bufferedOutputStream = null;
//                BufferedInputStream inputStream = null;
//                File tempFiles = null;
//                File[] files = null;
//                try {
//                    copyFilePath = filePath + UUID.randomUUID() + File.separator + fileName;
//                    copyFile = new File(copyFilePath);
//                    // 先创建文件存储路径
//                    if (!copyFile.getParentFile().exists()) {
//                        copyFile.getParentFile().mkdirs();
//                    }
//                    // 创建流
//                    fileOutputStream = new FileOutputStream(copyFile, true);
//                    // 创建文件输入缓冲流
//                    bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
//                    byte[] buffer = new byte[1024];// 一次读取1024个字节
//                    // 分片文件
//                    tempFiles = new File(slicePath);
//                    files = tempFiles.listFiles();
//                    // 对这个文件数组进行排序
//                    Arrays.sort(files, new Comparator<File>() {
//                        @Override
//                        public int compare(File o1, File o2) {
//                            int o1Index = Integer.parseInt(o1.getName().split("\\.")[0]);
//                            int o2Index = Integer.parseInt(o2.getName().split("\\.")[0]);
//                            if (o1Index > o2Index) {
//                                return 1;
//                            } else if (o1Index == o2Index) {
//                                return 0;
//                            } else {
//                                return -1;
//                            }
//                        }
//                    });
//
//                    for (int i = 0; i < files.length; i++) {
//                        File fileTemp = files[i];
//                        inputStream = new BufferedInputStream(new FileInputStream(fileTemp));
//                        int readcount;
//                        while ((readcount = inputStream.read(buffer)) > 0) {
//                            bufferedOutputStream.write(buffer, 0, readcount);
//                            bufferedOutputStream.flush();
//                        }
//                        inputStream.close();
//                    }
//                    bufferedOutputStream.close();
//                } catch (IOException e) {
//                    // 分片文件合并失败
//                    map.put("code", "3");
//                    e.printStackTrace();
//                } finally {
//                    if (inputStream != null) {
//                        try {
//                            inputStream.close();
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                    if (fileOutputStream != null) {
//                        try {
//                            fileOutputStream.close();
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                    if (bufferedOutputStream != null) {
//                        try {
//                            bufferedOutputStream.close();
//                        } catch (IOException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                    // 删除分片文件
//                    for (File sfile : files) {
//                        if (sfile.exists()) {
//                            sfile.delete();
//                        }
//                    }
//                    // 删除分块文件
//                    tempFiles.delete();
//                }
//            }
//        }
//        if (null != copyFilePath && copyFile.exists()) {
//            map.put("filePath", copyFilePath);
//        }
//        return map;
//    }

    /**
     * 指定位置开始写入文件
     *
     * @param tempFile 输入文件
     * @param outPath  输出文件的路径(路径+文件名)
     * @throws IOException
     */
    public static void randomAccessFile(String outPath, File tempFile) throws IOException {
        RandomAccessFile raFile = null;
        BufferedInputStream inputStream = null;
        try {
            File dirFile = new File(outPath);
            // 以读写的方式打开目标文件
            raFile = new RandomAccessFile(dirFile, "rw");
            raFile.seek(raFile.length());
            inputStream = new BufferedInputStream(new FileInputStream(tempFile));
            byte[] buf = new byte[1024];
            int length = 0;
            while ((length = inputStream.read(buf)) != -1) {
                raFile.write(buf, 0, length);
            }
        } catch (Exception e) {
            throw new IOException(e.getMessage());
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (raFile != null) {
                    raFile.close();
                }
            } catch (Exception e) {
                throw new IOException(e.getMessage());
            }
        }
    }

    /**
     * 判断是否是压缩包
     *
     * @param fileName
     * @return
     */
    public static boolean isCompressionPackage(String fileName) {
        String imgType = fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length());
        // String[] imagType = { "zip", "rar", "7z" };
        String[] imagType = {"zip"};
        List<String> imageTyepList = Arrays.asList(imagType);
        if (StringUtils.isNotBlank(imgType)) {
            if (imageTyepList.contains(imgType.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 将异常内容写入到txt文件中
     *
     * @param Context
     * @return String 返回异常文件的路径
     */
    public static String getLogFileUrl(String Context) {
        logger.info("=================进入写日志的方法=================");
        String fileName = UUID.randomUUID().toString() + ".txt";
        String separator = "/";
        String filePath = rootPath + separator + "LOG";
        logger.info("=================LOGurl=================" + filePath);
        String filePathUrl = rootPath + separator + "LOG" + separator + fileName;
        logger.info("=================LOGurl1111=================" + filePathUrl);
        BufferedWriter bufferedWriter = null;
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                logger.info("=================是否存在LOG文件夹2222=================" + filePathUrl);
                file.mkdirs();
            }
            File fileCreatePath = new File(filePathUrl);
            if (!fileCreatePath.exists()) {
                logger.info("=================是否存在LOG文件夹=================" + filePathUrl);
                fileCreatePath.createNewFile();

            }
            bufferedWriter = new BufferedWriter(new FileWriter(filePathUrl));
            bufferedWriter.write(Context);
        } catch (IOException e) {
            logger.info("create File failure");
            e.printStackTrace();
        } finally {
            try {
                // bufferedWriter.flush();
                bufferedWriter.close();
            } catch (IOException e) {
                logger.info("writer File failure");
                e.printStackTrace();
            }
        }
        logger.info("=================返回LOG文件=================" + separator + "LOG" + separator + fileName);
        return separator + "LOG" + separator + fileName;
    }

    /**
     * @param fileRarPath rar file name
     * @param rarPath     output file path
     * @return success Or Failed
     * @throws Exception
     * @author zhuss
     */
//    public static FileHandleResponse unrarFile(String fileRarPath, String rarPath) throws Exception {
//        FileHandleResponse fileHandleResponse = new FileHandleResponse();
//        FileOutputStream fos = null;
//        Archive archive = null;
//        List<String> list = new ArrayList<String>();
//        File unZipFile = new File(rarPath);
//        if (!unZipFile.exists()) {
//            unZipFile.mkdirs();
//        }
//        try {
//            archive = new Archive(new File(fileRarPath));
//            if (archive == null) {
//                throw new FileNotFoundException(fileRarPath + "文件不存在!");
//            }
//            if (archive.isEncrypted()) {
//                throw new Exception(fileRarPath + " IS ENCRYPTED!");
//            }
//            List<FileHeader> files = archive.getFileHeaders();
//            File file = null;
//            for (FileHeader fh : files) {
//                if (fh.isEncrypted()) {
//                    throw new Exception(fileRarPath + " IS ENCRYPTED!");
//                }
//                String fileName = fh.getFileNameW().isEmpty() ? fh.getFileNameString() : fh.getFileNameW();
//                file = new File((rarPath + fileName).replaceAll("\\\\", "/"));
//                logger.info("rar  解压文件路径：" + (rarPath + fileName).replaceAll("\\\\", "/"));
//                if (fileName != null && fileName.trim().length() > 0) {
//                    if (fh.isDirectory()) {
//                        if (!file.exists()) {
//                            file.mkdirs();
//                        }
//                        continue;
//                    }
//                    try {
//                        if (!file.getParentFile().exists()) {
//                            file.getParentFile().mkdirs();
//                        }
//                        list.add((rarPath + fileName).replaceAll("\\\\", "/"));
//                        fos = new FileOutputStream(file);
//                        archive.extractFile(fh, fos);
//                        fos.flush();
//                        fos.close();
//                    } catch (RarException e) {
//                        e.printStackTrace();
//                        logger.error("文件解压失败：" + fileName);
//                        fileHandleResponse.setMessageCode(500);
//                        fileHandleResponse.setMessage("fail");
//                    }
//
//                }
//            }
//            fileHandleResponse.setMessageCode(200);
//            fileHandleResponse.setFileList(list);
//            fileHandleResponse.setMessage("success");
//            fileHandleResponse.setUrl((rarPath).replaceAll("\\\\", "/"));
//        } catch (Exception e) {
//            e.printStackTrace();
//            logger.error("文件解压失败：" + e.getMessage());
//            fileHandleResponse.setMessageCode(500);
//            fileHandleResponse.setMessage("解压rar失败！");
//        } finally {
//            if (null != fos) {
//                fos.close();
//            }
//            if (null != archive) {
//                archive.close();
//            }
//        }
//        return fileHandleResponse;
//    }

    public static void main(String[] args) {

        try {
            String regEx = "(.*-)-";
            Pattern p = Pattern.compile(regEx);
            String url = "public-10-10-fd289c36-dfea-419b-9cd7-61b6b58bf7e2.jpg";
            String paths[] = url.split("-");
            url = paths[0] + "-" + paths[1] + "-" + paths[2];
            System.out.print(url);
          /*  String path = fileMove("/20170803/73/2/17a8fe08-b733-4c76-aa7d-1a54afaf6729.jpg", "productStd", "73");
            System.out.println(path);*/
        } catch (Exception e) {
            e.printStackTrace();
        }
        // String destDirName =srcDirName.substring(0,
        // srcDirName.lastIndexOf("\\")) + "\\test2.txt";
        // FileUtil.copyFile(srcDirName, destDirName, true);
    }

    /*@SuppressWarnings({ "unchecked", "deprecation" })
    public static void downloadFilesClassify(HttpServletRequest request, HttpServletResponse response,
                                             List<Map<String, Object>> docMap, String zipName, String type, String varieties, Map<String, Object> map,
                                             Product product,String comyanyName) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String serverPath = request.getSession().getServletContext().getRealPath("/"); //获取服务器路径
        Map<String, Object> fileMap = new HashMap<String, Object>();
        Map<String, Object> filesMap = new HashMap<>(); //存放压缩文件的路径
        HSSFWorkbook wb = new HSSFWorkbook();
        HSSFSheet sheet = null;
        HSSFRow row = null;
        HSSFCellStyle style = null;
        HSSFCell cell = null;
        String title[] = null;
        String filePath = ""; //文件存放临时路径
        String fileName = ""; //临时文件名称
        String filesName = ""; //临时文件夹名称
        if("0".equals(type)){ // 首营企业下载时
            for (int i = 0; i < docMap.size(); i++) {
                if(docMap.get(i).get("dataType").equals("人员档案") || docMap.get(i).get("dataType").equals("关联人员档案"))
                    filesName = docMap.get(i).get("dataType")+"("+docMap.get(i).get("name")+")";
                else
                    filesName = docMap.get(i).get("dataType").toString();
                File file = new File(serverPath + filesName);
                if (!file.exists()) { //判断文件是否存在
                    filesMap.put(filesName, serverPath + filesName);
                    file.mkdir(); //创建文件夹
                }
                File files = new File(rootPath + docMap.get(i).get("url").toString());
                if(files.exists()){
                    String name = "";
                    //复制文件并修改文件名称
                    FileInputStream in = new FileInputStream(new File(rootPath + docMap.get(i).get("url").toString()));
                    if(docMap.get(i).get("docName").toString().split("/").length > 1){
                        name = docMap.get(i).get("docName").toString().split("/")[1];
                    }else{
                        name = docMap.get(i).get("docName").toString();
                    }
                    FileOutputStream out = new FileOutputStream(
                            new File(serverPath + filesName + "/" + name));
                    byte[] buff = new byte[10240]; // 限制大小
                    int n = 0;
                    while ((n = in.read(buff)) != -1) {
                        out.write(buff, 0, n);
                    }
                    out.flush();
                    in.close();
                    out.close();
                }
            }
        }
        //xls 文件标题栏
        title = new String[] { "资质类型", "资质名称", "资质文件名", "证书编号", "发证日期", "有效期", "材质说明" };
        fileName = "资质文件信息表.xls";
        filePath = serverPath + fileName;
        sheet = wb.createSheet("资质文件信息表");
        row = sheet.createRow((int) 0);
        style = wb.createCellStyle();
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
        for (int i = 0; i < title.length; i++) {
            cell = row.createCell((short) i);
            cell.setCellValue(title[i]);
            cell.setCellStyle(style);
        }
        for (int i = 0; i < docMap.size(); i++) { //给附件赋值
            String name = "";
            row = sheet.createRow((int) i + 1);
            if(docMap.get(i).get("dataType").equals("人员档案") || docMap.get(i).get("dataType").equals("关联人员档案"))
                row.createCell((short) 0).setCellValue(docMap.get(i).get("dataType") + "("+docMap.get(i).get("name")+")");
            else
                row.createCell((short) 0).setCellValue(docMap.get(i).get("dataType").toString());
            row.createCell((short) 1).setCellValue(docMap.get(i).get("dicName") == null ? "" : docMap.get(i).get("dicName").toString());
            if(docMap.get(i).get("docName").toString().split("/").length > 1){
                name = docMap.get(i).get("docName").toString().split("/")[1];
            }else{
                name = docMap.get(i).get("docName").toString();
            }
            row.createCell((short) 2).setCellValue(name);
            row.createCell((short) 3).setCellValue(docMap.get(i).get("certNo") == null ? "" : docMap.get(i).get("certNo").toString());
            row.createCell((short) 4).setCellValue(docMap.get(i).get("issueDate") == null ? "" : docMap.get(i).get("issueDate").toString());
            row.createCell((short) 5).setCellValue(docMap.get(i).get("invalidDate") == null ? "" : docMap.get(i).get("invalidDate").toString());
            row.createCell((short) 6).setCellValue(docMap.get(i).get("illustrate") == null ? "" : docMap.get(i).get("illustrate").toString());
        }
        try {
            //生成附件
            FileOutputStream fout = new FileOutputStream(filePath);
            wb.write(fout);
            fout.close();
            File files = new File(filePath);
            fileMap.put(fileName, files);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if ("1".equals(type)) { // 首营品种下载时
            String name = "";
            wb = new HSSFWorkbook();
            if ("medicine".equals(varieties)) { // 药品
                name = product.getUniName();
                //xls 药品文件标题栏
                title = new String[] { "产品通用名", "批准文号", "药品分类", "剂型", "规格", "包装规格", "生产厂家", "发送企业" };
                fileName = "药品基础信息表.xls";
                filePath = serverPath + fileName;
                sheet = wb.createSheet("药品基础信息表");
                row = sheet.createRow((int) 0);
                style = wb.createCellStyle();
                style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
                for (int i = 0; i < title.length; i++) {
                    cell = row.createCell((short) i);
                    cell.setCellValue(title[i]);
                    cell.setCellStyle(style);
                }
                row = sheet.createRow((int) 1);
                row.createCell((short) 0).setCellValue(product.getUniName());
                row.createCell((short) 1).setCellValue(product.getApprovalNum());
                row.createCell((short) 2).setCellValue(product.getAmount());
                row.createCell((short) 3).setCellValue(product.getDosageForm());
                row.createCell((short) 4).setCellValue(product.getSpecifications());
                row.createCell((short) 5).setCellValue(product.getUnitNoun());
                row.createCell((short) 6).setCellValue(product.getManuf());
                row.createCell((short) 7).setCellValue(comyanyName);
            } else if ("apparatus".equals(varieties)) { // 器械
                name = product.getName();
                //xls 器械文件标题栏
                title = new String[] { "产品商品名", "注册证编号/备案号", "型号规格", "生产厂家/注册人名称", "发送企业" };
                fileName = "器械基础信息表.xls";
                filePath = serverPath + fileName;
                sheet = wb.createSheet("器械基础信息表");
                row = sheet.createRow((int) 0);
                style = wb.createCellStyle();
                style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
                for (int i = 0; i < title.length; i++) {
                    cell = row.createCell((short) i);
                    cell.setCellValue(title[i]);
                    cell.setCellStyle(style);
                }
                row = sheet.createRow((int) 1);
                row.createCell((short) 0).setCellValue(product.getName());
                row.createCell((short) 1).setCellValue(product.getApprovalNum());
                row.createCell((short) 2).setCellValue(product.getSpecifications());
                row.createCell((short) 3).setCellValue(product.getManuf());
                row.createCell((short) 4).setCellValue(comyanyName);
            } else { // 保健品
                name = product.getName();
                //xls 器械文件标题栏
                title = new String[] { "产品通用名", "批准文号", "规格", "保质期", "生产厂家", "发送企业" };
                fileName = "保健品基础信息表.xls";
                filePath = serverPath + fileName;
                sheet = wb.createSheet("保健品基础信息表");
                row = sheet.createRow((int) 0);
                style = wb.createCellStyle();
                style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
                for (int i = 0; i < title.length; i++) {
                    cell = row.createCell((short) i);
                    cell.setCellValue(title[i]);
                    cell.setCellStyle(style);
                }
                row = sheet.createRow((int) 1);
                row.createCell((short) 0).setCellValue(product.getName());
                row.createCell((short) 1).setCellValue(product.getApprovalNum());
                row.createCell((short) 2).setCellValue(product.getSpecifications());
                row.createCell((short) 3).setCellValue(product.getExpirationDate());
                row.createCell((short) 4).setCellValue(product.getManuf());
                row.createCell((short) 5).setCellValue(comyanyName);
            }
            filesName = "产品档案("+name+")";
            File file = new File(serverPath + filesName);
            if (!file.exists()) {
                filesMap.put(filesName, serverPath + filesName);
                file.mkdir();
            }

            //解析首营品种 map
            Map<String, Object> maps = new HashMap<>();
            Map<String, Object> productMap = (Map<String, Object>) map.get("product");
            List<Map<String, Object>> productMaps = (List<Map<String, Object>>) productMap.get("data");
            for (int i = 0; i < productMaps.size(); i++) {
                JSONArray jsonArray = JSONArray.fromObject(productMaps.get(i).get("data"));
                List<Map<String, Object>> listMap = jsonArray;
                for (int k = 0; k < listMap.size(); k++) {
                    for (int j = 0; j < docMap.size(); j++) {
                        if(docMap.get(j).get("url").equals(listMap.get(k).get("documentURL"))){
                            String fileNames = "";
                            if(docMap.get(j).get("docName").toString().split("/").length > 1){
                                fileNames = docMap.get(j).get("docName").toString().split("/")[1];
                            }else{
                                fileNames = docMap.get(j).get("docName").toString();
                            }
                            maps.put(serverPath+filesName+"/"+fileNames,rootPath + listMap.get(k).get("documentURL"));
                            break;
                        }
                    }
                }
            }
            List<Map<String, Object>> companyMaps = (List<Map<String, Object>>) map.get("company");
            for (int i = 0; i < companyMaps.size(); i++) {
                JSONArray jsonArray = JSONArray.fromObject(companyMaps.get(i).get("company"));
                Map<String, Object> cMap = jsonArray.getJSONObject(0);
                filesName = "关联企业("+cMap.get("name")+")";
                File files = new File(serverPath + filesName);
                if (!files.exists()) {
                    filesMap.put(filesName, serverPath + filesName);
                    files.mkdir();
                }
                JSONArray dataJson = JSONArray.fromObject(companyMaps.get(i).get("data"));
                for (int j = 0; j < dataJson.size(); j++) {
                    Map<String, Object> dataMaps = dataJson.getJSONObject(j);
                    List<Map<String, Object>> dataList = (List<Map<String, Object>>) dataMaps.get("data");
                    String fileNames = "";
                    if("企业资质".equals(dataMaps.get("name"))){
                        fileNames = "企业档案";
                    }else if("人员资质".equals(dataMaps.get("name"))){
                        fileNames = "人员档案";
                    }else{
                        fileNames = "合同档案";
                    }
                    File f = new File(serverPath + filesName + "/" + fileNames);
                    if (!f.exists()) {
                        f.mkdir();
                    }
                    if("企业资质".equals(dataMaps.get("name"))){
                        for (int k = 0; k < dataList.size(); k++) {
                            List<Map<String, Object>> daMap = (List<Map<String, Object>>) dataList.get(k).get("data");
                            for (int l = 0; l < daMap.size(); l++) {
                                Map<String, Object> fMap = (Map<String, Object>) daMap.get(l);
                                for (int d = 0; d < docMap.size(); d++) {
                                    if(docMap.get(d).get("url").equals(fMap.get("documentURL"))){
                                        String names = "";
                                        if(docMap.get(d).get("docName").toString().split("/").length > 1){
                                            names = docMap.get(d).get("docName").toString().split("/")[1];
                                        }else{
                                            names = docMap.get(d).get("docName").toString();
                                        }
                                        maps.put(serverPath+filesName + "/" + fileNames + "/" + names,rootPath + fMap.get("documentURL"));
                                        break;
                                    }
                                }
                            }
                        }
                    }else if("人员资质".equals(dataMaps.get("name")) || "合同资质".equals(dataMaps.get("name"))){
                        for (int k = 0; k < dataList.size(); k++) {
                            List<Map<String, Object>> daMap = (List<Map<String, Object>>) dataList.get(k).get("data");
                            for (int l = 0; l < daMap.size(); l++) {
                                Map<String, Object> fMap = (Map<String, Object>) daMap.get(l);
                                List<Map<String, Object>> dataLists = (List<Map<String, Object>>) fMap.get("data");
                                for (int m = 0; m < dataLists.size(); m++) {
                                    for (int d = 0; d < docMap.size(); d++) {
                                        if(docMap.get(d).get("url").equals(dataLists.get(m).get("documentURL"))){
                                            String names = "";
                                            if(docMap.get(d).get("docName").toString().split("/").length > 1){
                                                names = docMap.get(d).get("docName").toString().split("/")[1];
                                            }else{
                                                names = docMap.get(d).get("docName").toString();
                                            }
                                            maps.put(serverPath + filesName + "/" + fileNames + "/" + names,rootPath + dataLists.get(m).get("documentURL"));
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            for (String key : maps.keySet()) {
                File f = new File(maps.get(key).toString());
                if(f.exists()){
                    FileInputStream in = new FileInputStream(f);
                    FileOutputStream out = new FileOutputStream(new File(key));
                    byte[] buff = new byte[10240]; // 限制大小
                    int n = 0;
                    while ((n = in.read(buff)) != -1) {
                        out.write(buff, 0, n);
                    }
                    out.flush();
                    in.close();
                    out.close();
                }
            }
        }
        try {
            FileOutputStream fout = new FileOutputStream(filePath);
            wb.write(fout);
            fout.close();
            File files = new File(filePath);
            fileMap.put(fileName, files);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (String key : filesMap.keySet()) {
            File file = new File(filesMap.get(key).toString());
            if (file.exists()) {
                fileMap.put(key, file);
            }
        }
        String fileNames = ""; //压缩文件的名称
        if (zipName.indexOf("(") > -1) {
            int inde = zipName.indexOf("(");
            fileNames = zipName.substring(0, inde) + ".zip";
        } else {
            fileNames = zipName + ".zip";
        }
        //设置编码格式
        String newFileName = fileNames.replaceAll("\\\\", ".").replaceAll("/", ".").replaceAll(" ", "-").replaceAll(";",
                "--");
        newFileName = java.net.URLEncoder.encode(newFileName, "gb2312");
        newFileName = java.net.URLDecoder.decode(newFileName, "ISO-8859-1");

        File file = null;
        try {
            file = new File(newFileName);
            // 文件输出流
            FileOutputStream outStream = new FileOutputStream(file);
            ZipOutputStream toClient = new ZipOutputStream(outStream);
            toClient.setEncoding("GBK");
            String baseDir = "";
            zipFileForMap(fileMap, toClient, baseDir);// 压缩文件
            toClient.close();
            outStream.close();
            downloadZip(file, response);
        } catch (Exception e) {
            logger.error("打包下载的文件失败", e);
        } finally {
            if (file != null)
                file.delete();
            deleteFiles(fileMap); // 删除临时文件
        }
    }*/

    // 文件压缩完毕后 清楚服务器上的临时文件
    public static void deleteFiles(Map<String, Object> fileMap) {
        for (String key : fileMap.keySet()) {
            Map<String, Object> maps = new HashMap<>();
            File file = new File(fileMap.get(key).toString());
            if (file != null) { //判断附件是否存在
                if (file.isDirectory()) { //判断是否为文件夹
                    File[] files = file.listFiles(); //获取文件夹下所有的文件/文件夹
                    for (int i = 0; i < files.length; i++) {
                        if (files[i].isDirectory()) { //判断是否为文件夹
                            maps.put(i + "", files[i]);
                            //递归删除文件目录下的文件
                            deleteFiles(maps);
                        } else {
                            files[i].delete(); //删除文件
                        }
                    }
                    file.delete();
                } else {
                    file.delete(); //删除文件
                }
            }
        }
    }

    /**
     * 压缩文件列表中的文件/文件夹
     *
     * @param fileMap      附件集合
     * @param outputStream 压缩
     * @param baseDir      文件路径
     * @throws IOException
     */
    public static void zipFileForMap(Map<String, Object> fileMap, ZipOutputStream outputStream, String baseDir)
            throws IOException, ServletException {
        try {
            Set<String> s = fileMap.keySet();
            for (String key : s) {
                File file = new File(fileMap.get(key).toString());
                if (file.isFile()) {// 判断文件是否是文件
                    zipFileForMap((File) fileMap.get(key), key, outputStream);
                } else {
                    compressDirectory(file, outputStream, baseDir);
                }
            }
        } catch (Exception e) {
            logger.error("压缩文件列表中的文件失败！", e);
        }
    }

    /**
     * 压缩一个目录
     */
    private static void compressDirectory(File dir, ZipOutputStream out, String basedir) {
        if (!dir.exists())//判断文件是否存在
            return;
        File[] files = dir.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                /* 递归 */
                compressFile(files[i], out, basedir + dir.getName() + "/");
            } else {
                /* 递归 */
                compressDirectory(files[i], out, basedir + dir.getName() + "/");
            }
        }
    }

    /**
     * 压缩一个文件
     */
    private static void compressFile(File file, ZipOutputStream out, String basedir) {
        if (!file.exists()) //判断文件是否存在
            return;
        try {
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
            ZipEntry entry = new ZipEntry(basedir + file.getName());
            out.putNextEntry(entry);
            int count;
            byte data[] = new byte[8192];
            while ((count = bis.read(data, 0, 8192)) != -1) {
                out.write(data, 0, count);
            }
            bis.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 凌晨
     *
     * @param date
     * @return
     * @flag 0 返回yyyy-MM-dd 00:00:00日期<br>
     * 1 返回yyyy-MM-dd 23:59:59日期
     */
    public static Date weeHours(Date date, int flag) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);
        int second = cal.get(Calendar.SECOND);
        //时分秒（毫秒数）
        long millisecond = hour * 60 * 60 * 1000 + minute * 60 * 1000 + second * 1000;
        //凌晨00:00:00
        cal.setTimeInMillis(cal.getTimeInMillis() - millisecond);

        if (flag == 0) {
            return cal.getTime();
        } else if (flag == 1) {
            //凌晨23:59:59
            cal.setTimeInMillis(cal.getTimeInMillis() + 23 * 60 * 60 * 1000 + 59 * 60 * 1000 + 59 * 1000);
        }
        return cal.getTime();
    }

    //正则表达式判断是否是数字或字母
    public static boolean isNumAndChar(String str) {
        Pattern pattern = Pattern.compile("^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]{2,20})$");
        Matcher isNum = pattern.matcher(str);
        if (!isNum.matches()) {
            return false;
        }
        return true;
    }

//    public static JSONObject handelFile(String type, String srcFileName, String destFileName, long srcFileSize, String returnpath, String destFileTemp) throws Exception {
//        byte[] fileData = null;
//        JSONObject fileInfo = new JSONObject();
//        RedisUtil redisUtil = new RedisUtil();
//        if ("pdf".equalsIgnoreCase(type)) {
//            fileData = toPdfPageA4(srcFileName, fileInfo).toByteArray();
//            if (fileData.length == 0) {
//                fileInfo.put("srcFileSize", srcFileSize);
//                fileInfo.put("needHandel", false);
//                String key = Base64.encodeBase64String(returnpath.getBytes());
//                //RedisUtil.setJson(key,fileInfo);
//                redisUtil.set(key, fileInfo);
//
//                return fileInfo;
//            }
//        } else if ("jpg".equalsIgnoreCase(type) || "bmp".equalsIgnoreCase(type)) {
//            type = type.toLowerCase();
//            fileData = getImagePdfBytes(srcFileName, fileInfo, type);
//            destFileName = destFileName.replace(type, "pdf");
//            destFileTemp = destFileTemp.replace(type, "pdf");
//        } else {
//            return fileInfo;
//        }
//        int destSize = 0;
//        if (fileData != null) {
//            destSize = fileData.length;
//        }
//
//        FileOutputStream fos = null;
//        try {
//            fos = new FileOutputStream(destFileName);
//            fos.write(fileData);
//            fos.flush();
//            fos.close();
//            fileInfo.put("needHandel", true);
//            fileInfo.put("srcFile", srcFileName);
//            fileInfo.put("destFile", destFileName);
//            fileInfo.put("srcFileSize", srcFileSize);
//            fileInfo.put("destFileTemp", destFileTemp);
//            File destFile = new File(destFileName);
//            fileInfo.put("destFileSize", destFile.length());
//            String key = Base64.encodeBase64String(returnpath.getBytes());
//            //RedisUtil.setJson(key,fileInfo);
//            redisUtil.set(key, fileInfo);
//        } catch (Exception e) {
//            e.printStackTrace();
//            fos.flush();
//            fos.close();
//        } finally {
//            if (fos != null) {
//                fos.close();
//            }
//        }
//        return fileInfo;
//    }

//    private static ByteArrayOutputStream toPdfPageA4(String PdfFileName, JSONObject fileInfo) throws IOException {
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//
//
//        PdfReader srcReader = new PdfReader(PdfFileName);
//        boolean pflag = false;
//        float height = srcReader.getPageSize(1).getHeight();
//        float width = srcReader.getPageSize(1).getWidth();
//        if (width > height) {
//            pflag = width < 850;
//        } else {
//            pflag = width < 550;
//        }
//        Map<String, AcroFields.Item> item = srcReader.getAcroFields().getFields();
//        pflag = pflag || (item != null && item.size() > 0);
//        if (pflag) {
//            fileInfo.put("pdfPages", srcReader.getNumberOfPages());
//            return bos;
//        }
//
//
//        com.itextpdf.kernel.pdf.PdfReader reader = new com.itextpdf.kernel.pdf.PdfReader(PdfFileName);
//
//        System.out.println("Encrypted?" + reader.isEncrypted());
//
//        System.out.println("是否有加密====================================");
//        reader.setUnethicalReading(true);
//
//        // Creating a PdfWriter object
//
//
//        com.itextpdf.kernel.pdf.PdfWriter writer = new com.itextpdf.kernel.pdf.PdfWriter(bos);
//
//        // Creating a PdfReader
//
//
//        // Creating a PdfDocument objects
//        com.itextpdf.kernel.pdf.PdfDocument destpdf = new com.itextpdf.kernel.pdf.PdfDocument(writer);
//
//        com.itextpdf.kernel.pdf.PdfDocument srcPdf = new com.itextpdf.kernel.pdf.PdfDocument(reader);
//
//        for (int i = 0; i < srcPdf.getNumberOfPages(); i++) {
//            // Opening a page from the existing PDF
//            com.itextpdf.kernel.pdf.PdfPage origPage = srcPdf.getPage(i + 1);
//
//            // Getting the page size
//            com.itextpdf.kernel.geom.Rectangle orig = origPage.getPageSize();
//
//            // Adding a page to destination Pdf
//            com.itextpdf.kernel.pdf.PdfPage page = null;
//            float flag = orig.getWidth() / orig.getHeight();
//            if (flag > 1) {
//
//                page = destpdf.addNewPage(com.itextpdf.kernel.geom.PageSize.A4.rotate());
//                if (origPage.getRotation() == 90) {
//                    page.setRotation(90);
//                } else {
//                    page.setRotation(-90);
//                }
//
//
//            } else {
//                page = destpdf.addNewPage(com.itextpdf.kernel.geom.PageSize.A4);
//            }
//
//            // Scaling the image in a Pdf page
//
//            com.itextpdf.kernel.geom.AffineTransform transformationMatrix = com.itextpdf.kernel.geom.AffineTransform.getScaleInstance(
//                    page.getPageSize().getWidth() / orig.getWidth(),
//                    page.getPageSize().getHeight() / orig.getHeight());
//
//            // Shrink original page content using transformation matrix
//            com.itextpdf.kernel.pdf.canvas.PdfCanvas canvas = new com.itextpdf.kernel.pdf.canvas.PdfCanvas(page);
//            canvas.concatMatrix(transformationMatrix);
//
//            // Add the object to the canvas
//            com.itextpdf.kernel.pdf.xobject.PdfFormXObject pageCopy = origPage.copyAsFormXObject(destpdf);
//            canvas.addXObject(pageCopy, 0, 0);
//        }
//        fileInfo.put("pdfPages", destpdf.getNumberOfPages());
//        destpdf.close();
//        srcPdf.close();
//        return bos;
//        // Creating a Document object
//    /*  Document doc = new Document(destpdf,PageSize.A4);
//
//      // Closing the document
//      doc.close();*/
//
//    }

    /**
     * 把图片生成pdf
     *
     * @param pdfName
     * @return
     * @throws Exception
     */
//    private static byte[] getImagePdfBytes(String pdfName, JSONObject fileInfo, String type) throws Exception {
//        Document document = new Document(PageSize.A4);
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        // 2.定义pdfWriter，指明文件输出流输出到一个文件
//        PdfWriter.getInstance(document, baos);
//        document.open();
//        document.add(new Paragraph("  "));
//        document.close();
//        PdfReader reader = new PdfReader(baos.toByteArray());// 选择需要写图片的pdf
//        //置PdfReader的静态属性unethicalreading为true, 无需设置加密密码20180516
//        System.out.println("Encrypted?" + reader.isEncrypted());
//        if (reader.isEncrypted()) {
//            System.out.println("是否有加密====================================");
//            reader.unethicalreading = true;
//        }
//
//        ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
//        PdfStamper stamp = new PdfStamper(reader, baos1);// 加完图片的pdf
//        PdfContentByte over = stamp.getOverContent(1);// 设置在第1页写图片
//
//
//        com.itextpdf.text.Image img = null;
//
//        try {
//            img = com.itextpdf.text.Image.getInstance(pdfName);
//
//            //;
//        } catch (Exception e) {
//            Image awtImage = Toolkit.getDefaultToolkit().createImage(pdfName);
//
//            img = com.itextpdf.text.Image.getInstance(awtImage, null);
//
//        } finally {
//            IOUtils.closeQuietly(baos1);
//        }
//        img.setAlignment(1);
//        float width = img.getPlainWidth();
//        float height = img.getPlainHeight();
//
//        float w = width > 590 ? 590 : width;
//        float h = height > 840 ? 840 : height;
//
//
//        if (width > 590 || height > 840) {
//            int realWidth = 590;
//            int realHeight = 840;
//            BufferedImage bufferedImage = Thumbnails.of(pdfName).size(realWidth, realHeight).outputFormat(type).asBufferedImage();
//            img = com.itextpdf.text.Image.getInstance(bufferedImage, null);
//            realWidth = (int) img.getWidth();
//            realHeight = (int) img.getHeight();
//            float x = realWidth > 590 ? 0 : (600 - realWidth) / 2;
//            float y = realHeight > 840 ? 0 : (realHeight > 740 ? (840 - realHeight) : (740 - realHeight));
//            img.setAbsolutePosition(x, y);// 控制图片位置
//        } else {
//            img.scaleAbsolute(w, h);// 控制图片大小
//            float x = width > 590 ? 0 : (600 - width) / 2;
//            float y = height > 840 ? 0 : (height > 740 ? (840 - height) : (740 - height));
//            img.setAbsolutePosition(x, y);// 控制图片位置
//        }
//
//
//        over.addImage(img);
//        stamp.close();
//        IOUtils.closeQuietly(baos);
//        reader.close();
//        stamp.close();
//        img = null;
//        fileInfo.put("pdfPages", 1);
//        return baos1.toByteArray();
//    }

//    public static void downloadFileList(HttpServletRequest request, HttpServletResponse response, List<Map> docMap, Map data, Integer dataType, Integer type, RedisUtil redisUtil) throws Exception {
//        request.setCharacterEncoding("UTF-8");
//        Map<String, Object> fileMap = new HashMap<String, Object>();
//        HSSFWorkbook wb = new HSSFWorkbook();
//        HSSFSheet sheet = null;
//        HSSFRow row = null;
//        HSSFCellStyle style = null;
//        HSSFCell cell = null;
//        String title[] = null;
//        String filePath = ""; //文件存放临时路径
//        String fileName = ""; //excel文件名称
//        String zipName = ""; //压缩包名称
//        try {
//            if (dataType == 0) {
//                Map dataMap = (Map) data.get("data");
//                if(type == 0) {
//                    //xls 我的企业标题栏
//                    title = new String[]{"企业名称", "企业类型 ", "业务范围","归属地"};
//                    fileName = "我的企业基本信息表.xls";
//                    filePath = tempPath + "/" + fileName;
//                    sheet = wb.createSheet("我的企业基本信息");
//                    row = sheet.createRow(0);
//                    style = wb.createCellStyle();
//                    style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
//                    for (int i = 0; i < title.length; i++) {
//                        cell = row.createCell((short) i);
//                        cell.setCellValue(title[i]);
//                        cell.setCellStyle(style);
//                    }
//                    row = sheet.createRow(1);
//                    row.createCell((short) 0).setCellValue(dataMap.get("companyName").toString());
//                    row.createCell((short) 1).setCellValue(dataMap.get("companyTypeName").toString());
//                    row.createCell((short) 2).setCellValue(dataMap.get("businessTypeName").toString());
//                    row.createCell((short) 3).setCellValue(dataMap.get("ascription").toString());
//                } else if (type == 1) {
//                    //xls 客商文件标题栏
//                    title = new String[]{"企业名称", "企业编号", "业务范围", "客户关系", "企业类别", "归属地", "获取方式"};
//                    fileName = "客商企业基本信息表.xls";
//                    filePath = tempPath + "/" + fileName;
//                    sheet = wb.createSheet("客商企业基本信息");
//                    row = sheet.createRow(0);
//                    style = wb.createCellStyle();
//                    style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
//                    for (int i = 0; i < title.length; i++) {
//                        cell = row.createCell((short) i);
//                        cell.setCellValue(title[i]);
//                        cell.setCellStyle(style);
//                    }
//                    row = sheet.createRow(1);
//                    row.createCell((short) 0).setCellValue(dataMap.get("companyName").toString());
//                    row.createCell((short) 1).setCellValue(dataMap.get("companySerialNumber").toString());
//                    row.createCell((short) 2).setCellValue(dataMap.get("businessTypeName").toString());
//                    row.createCell((short) 3).setCellValue(dataMap.get("relationship").toString());
//                    row.createCell((short) 4).setCellValue(dataMap.get("companyTypeName").toString());
//                    row.createCell((short) 5).setCellValue(dataMap.get("ascription").toString());
//                    row.createCell((short) 6).setCellValue(dataMap.get("informationType").toString());
//                } else {
//                    //xls 厂家文件标题栏
//                    title = new String[]{"企业名称", "企业类别", "业务范围", "归属地", "资料来源", "获取方式"};
//                    fileName = "厂家企业基本信息表.xls";
//                    filePath = tempPath + "/" + fileName;
//                    sheet = wb.createSheet("厂家企业基本信息");
//                    row = sheet.createRow(0);
//                    style = wb.createCellStyle();
//                    style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
//                    for (int i = 0; i < title.length; i++) {
//                        cell = row.createCell((short) i);
//                        cell.setCellValue(title[i]);
//                        cell.setCellStyle(style);
//                    }
//                    row = sheet.createRow(1);
//                    row.createCell((short) 0).setCellValue(dataMap.get("companyName").toString());
//                    row.createCell((short) 1).setCellValue(dataMap.get("companyTypeName").toString());
//                    row.createCell((short) 2).setCellValue(dataMap.get("businessTypeName").toString());
//                    row.createCell((short) 3).setCellValue(dataMap.get("ascription").toString());
//                    row.createCell((short) 4).setCellValue(dataMap.get("informationFrom").toString());
//                    row.createCell((short) 5).setCellValue(dataMap.get("informationType").toString());
//                }
//                zipName = dataMap.get("companyName") + ".zip";
//            } else if (dataType == 1) {
//                Map dataMap = (Map) data.get("data");
//                //xls 人员文件标题栏
//                title = new String[]{"姓名", "身份证号码", "联系方式", "部门", "职位", "备注", "获取方式"};
//                fileName = "人员基本信息表.xls";
//                filePath = tempPath + "/" + fileName;
//                sheet = wb.createSheet("人员基本信息");
//                row = sheet.createRow(0);
//                style = wb.createCellStyle();
//                style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
//                for (int i = 0; i < title.length; i++) {
//                    cell = row.createCell((short) i);
//                    cell.setCellValue(title[i]);
//                    cell.setCellStyle(style);
//                }
//                row = sheet.createRow(1);
//                row.createCell((short) 0).setCellValue(dataMap.get("name").toString());
//                row.createCell((short) 1).setCellValue(dataMap.get("memberId").toString());
//                row.createCell((short) 2).setCellValue(dataMap.get("contact").toString());
//                row.createCell((short) 3).setCellValue(dataMap.get("department").toString());
//                row.createCell((short) 4).setCellValue(dataMap.get("position").toString());
//                row.createCell((short) 5).setCellValue(dataMap.get("note").toString());
//                row.createCell((short) 6).setCellValue(dataMap.get("informationFrom") == "0" ? "本地上传" : "在线接收");
//                zipName = dataMap.get("name") + ".zip";
//            } else if (dataType == 2) {
//                Map dataMap = (Map) data.get("data");
//
//                //xls 产品文件标题栏
//                title = new String[]{"产品名称", "剂型", "单位", "药品分类", "规格", "执行标准", "批准文号", "包装规格", "获取方式", "产品编号", "药品本位码", "生产厂家", "产品商品名", "产地", "供应商"};
//                fileName = "产品基本信息表.xls";
//                filePath = tempPath + "/" + fileName;
//                sheet = wb.createSheet("产品基本信息");
//                row = sheet.createRow(0);
//                style = wb.createCellStyle();
//                style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
//                for (int i = 0; i < title.length; i++) {
//                    cell = row.createCell((short) i);
//                    cell.setCellValue(title[i]);
//                    cell.setCellStyle(style);
//                }
//                row = sheet.createRow(1);
//                ProductCard productCard =  (ProductCard)dataMap.get("productCard");
//                ProductInfo productInfo= (ProductInfo) dataMap.get("productInfo");
//                row.createCell((short) 0).setCellValue(productCard.getUniName());
//                row.createCell((short) 1).setCellValue(productCard.getDosageForm());
//                row.createCell((short) 2).setCellValue(productInfo.getUnit());
//                row.createCell((short) 3).setCellValue(productCard.getAmount());
//                row.createCell((short) 4).setCellValue(productCard.getSpecifications());
//                row.createCell((short) 5).setCellValue(productInfo.getOperativeNorm());
//                row.createCell((short) 6).setCellValue(productCard.getApprovalNum());
//                row.createCell((short) 7).setCellValue(productCard.getUnitNoun());
//                row.createCell((short) 8).setCellValue(productInfo.getInformationFrom() == 0 ? "本地上传" : "在线接收");
//                row.createCell((short) 9).setCellValue(productInfo.getProNumber());
//                row.createCell((short) 10).setCellValue(productCard.getProIndex());
//                row.createCell((short) 11).setCellValue(productCard.getManuf());
//                row.createCell((short) 12).setCellValue(productCard.getName());
//                row.createCell((short) 13).setCellValue(productInfo.getPlace());
//                row.createCell((short) 14).setCellValue(productInfo.getOfflineCooperate());
//                zipName = productCard.getUniName() + ".zip";
//            } else if (dataType == 3) {
//                ContractVo contractVo = (ContractVo) data.get("data");
//                //xls 合同文件标题栏
//                title = new String[]{"合同名称", "合同类型", "合同编号", "生效时间", "失效时间"};
//                fileName = "合同基本信息表.xls";
//                filePath = tempPath + "/" + fileName;
//                sheet = wb.createSheet("合同基本信息");
//                row = sheet.createRow(0);
//                style = wb.createCellStyle();
//                style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
//                for (int i = 0; i < title.length; i++) {
//                    cell = row.createCell((short) i);
//                    cell.setCellValue(title[i]);
//                    cell.setCellStyle(style);
//                }
//                row = sheet.createRow(1);
//                row.createCell((short) 0).setCellValue(contractVo.getContractName());
//                row.createCell((short) 1).setCellValue(contractVo.getContractType());
//                row.createCell((short) 2).setCellValue(contractVo.getContractNumber());
//                row.createCell((short) 3).setCellValue(contractVo.getStartTime());
//                row.createCell((short) 4).setCellValue(contractVo.getEndTime());
//                zipName = contractVo.getContractName() + ".zip";
//            }
//            fileMap = fileGenerate(wb, fileMap, filePath, fileName);
//
//            wb = new HSSFWorkbook();
//            //xls 资质文件标题栏
//            title = new String[]{"资质类型", "证书编号", "有效期至", "文件名称"};
//            fileName = "资质信息表.xls";
//            filePath = tempPath + "/" + fileName;
//            sheet = wb.createSheet("资质信息");
//            row = sheet.createRow(0);
//            style = wb.createCellStyle();
//            style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
//            for (int i = 0; i < title.length; i++) {
//                cell = row.createCell((short) i);
//                cell.setCellValue(title[i]);
//                cell.setCellStyle(style);
//            }
//
//            StringBuilder builder = new StringBuilder();
//            int i = 0;
//            for (Map document : docMap) {
//                SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmssSSS");//设置日期格式
//                String keyName = "";
//                for (Object key : document.keySet()) {
//                    keyName = (String) key;
//                }
//                com.edip.entity.Document doc = (com.edip.entity.Document) document.get(keyName);
//                String docName = "";
//                if (builder.indexOf(doc.getAliasName() + ",") > -1) {
//                    String[] docNames = doc.getAliasName().split("\\.");
//                    docName = docNames[0] + df.format(new Date()) + "." + docNames[1];
//                    builder.append(docName).append(",");
//                } else {
//                    docName = doc.getAliasName();
//                    builder.append(docName).append(",");
//                }
//                row = sheet.createRow(i + 1);
//                row.createCell((short) 0).setCellValue(keyName);
//                row.createCell((short) 1).setCellValue(doc.getCertNo());
//                row.createCell((short) 2).setCellValue(doc.getInvalidDate() == null?"":sdf.format(doc.getInvalidDate()));
//                row.createCell((short) 3).setCellValue(docName);
//                File folder = new File(tempPath + "/" + keyName);
//                if (!folder.exists()) {
//                    fileMap.put(keyName, folder.getPath());
//                    folder.mkdir();
//                }
//                FileOutputStream fileOut = null;
//                HttpURLConnection conn = null;
//                InputStream inputStream = null;
//                String path = com.edip.dto.util.StringUtils.getReadFilePath(doc.getDocUrl(), redisUtil);
//                URL httpUrl = new URL(path);
//                conn = (HttpURLConnection) httpUrl.openConnection();
//                //以Post方式提交表单，默认get方式
//                conn.setRequestMethod("GET");
//                conn.setDoInput(true);
//                conn.setDoOutput(true);
//                // post方式不能使用缓存 
//                conn.setUseCaches(false);
//                //连接指定的资源 
//                conn.connect();
//                //获取网络输入流
//                inputStream = conn.getInputStream();
//                BufferedInputStream bis = new BufferedInputStream(inputStream);
//                //写入到文件（注意文件保存路径的后面一定要加上文件的名称）
//                fileOut = new FileOutputStream(tempPath + "/" +keyName + "/" + docName);
//                BufferedOutputStream bos = new BufferedOutputStream(fileOut);
//                byte[] buf = new byte[4096];
//                int length = bis.read(buf);
//                //保存文件
//                while (length != -1) {
//                    bos.write(buf, 0, length);
//                    length = bis.read(buf);
//                }
//                bos.close();
//                bis.close();
//                conn.disconnect();
//                i++;
//            }
//            fileMap = fileGenerate(wb, fileMap, filePath, fileName);
//
//            //设置编码格式
//            String newFileName = zipName.replaceAll("\\\\", ".").replaceAll("/", ".").replaceAll(" ", "-").replaceAll(";",
//                    "--");
//            newFileName = java.net.URLEncoder.encode(newFileName, "gb2312");
//            newFileName = java.net.URLDecoder.decode(newFileName, "ISO-8859-1");
//
//            File file = new File(newFileName);
//            // 文件输出流
//            FileOutputStream outStream = new FileOutputStream(file);
//            ZipOutputStream toClient = new ZipOutputStream(outStream);
//            toClient.setEncoding("GBK");
//            String baseDir = "";
//            zipFileForMap(fileMap, toClient, baseDir);// 压缩文件
//            toClient.close();
//            outStream.close();
//            downloadZip(file, response);
//        }catch (Exception e){
//           logger.error("下载失败",e);
//        }finally {
//                deleteFiles(fileMap);
//        }
//    }

    /**
     * excel文件生成
     *
     * @param wb
     * @param fileMap
     * @param filePath
     * @param fileName
     * @throws Exception
     */
    public static Map fileGenerate(HSSFWorkbook wb, Map<String, Object> fileMap, String filePath, String fileName) throws Exception {
        FileOutputStream fout = new FileOutputStream(filePath);
        wb.write(fout);
        fout.close();
        File files = new File(filePath);
        fileMap.put(fileName, files);
        return fileMap;
    }

}


