package com.edip.controller;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.HashMap;

import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import com.edip.entity.*;
import com.edip.service.AccountCdrBiz;
import com.edip.service.CompanyIfBiz;
import com.edip.service.QueryValidatorServices;
import com.edip.service.impl.QueryValidatorServicesProxy;
import com.edip.utils.HttpClientUtil;
import com.edip.utils.PersonResopnse;
import com.edip.utils.PoliceCheckInfo;
import com.edip.utils.XmlUtil;
import com.edip.vo.AccountUtil;
import com.edip.vo.CompInfoVo;
import com.edip.vo.CompanyVo;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 企业信息管理
 * @author chenxiaoguang_a
 *
 */
@Controller
@RequestMapping("/companyIf")
public class CompanyIfController {
    /** slf4j*/
    private static final Logger LOGGER = LoggerFactory.getLogger(CompanyIfController.class);

    @Autowired
    @Qualifier("companyIfBiz")
    protected CompanyIfBiz companyIfBiz;
    /* @Autowired
     protected ComAuthService  comAuthService;
     @Autowired
     protected MessageBiz messageBiz;
     @Autowired
     protected MessageStatusBiz messageStatusBiz;*/
    @Autowired
    private AccountCdrBiz accountCdrBiz;

    private static String USERNAME;
    @Value("${USER_NAME}")
    public void setUSERNAME(String USERNAME) {
        this.USERNAME = USERNAME;
    }

    private static String PASSWORD;
    @Value("${PASSWORD}")
    public void setPASSWORD(String PASSWORD) {
        this.PASSWORD = PASSWORD;
    }
    private static final String QUERY_TYPE_ID = "1A020201";
    //公司校验
    private static final String QUERY_TYPE_ID_COMPANY = "5E010101";
    private static final String KEY = "12345678";

    /*private static String url;
    @Value("${IDCard_URL}")
    public void setUrl(String url) {
        this.url = url;
    }*/

    private static String id5Url;
    @Value("${WEBSERVICE_ID5_URL}")
    public void setId5Url(String id5Url) {
        this.id5Url = id5Url;
    }
    /**
     * 企业信息列表查询
     */
    /*@RequestMapping(value = "/companyIfList.ajax")
    @ResponseBody
    public Map<String, Object> companyIfList(@ModelAttribute("companyVo") CompanyVo companyVo,
                                             @RequestParam(value = "startTime", required = false) String startTime,
                                             @RequestParam(value = "endTime", required = false) String endTime,
                                             @RequestParam(value = "page", required = false) int page,
                                             @RequestParam(value = "rows", required = false) int rows,
                                             HttpServletRequest request) {
        Map<String,Object> params = new HashMap<String,Object>();
        List<Map<String,Object>> result=new ArrayList<Map<String,Object>>();
        Map<String, Object> modelMap = new HashMap<String, Object>();
        params.put("name", companyVo.getName());
        params.put("status",companyVo.getStatus());
        HttpSession session = request.getSession();
        String role = (String) session.getAttribute("ROLE");
        if (!AccountUtil.MANAGER_COUNTRY.equals(role)) {// 不是全国账号，根据省份来过滤
            String provinceID = session.getAttribute("PROVINCEID") + "";
            params.put("provinceID", provinceID);
        }else{//全国账号，保留页面按省份查询功能
            params.put("provinceID", companyVo.getProvinceID());
        }
        	*//*params.put("provinceID", companyVo.getProvinceID());
        	Integer a = 0;
        	Integer b =companyVo.getStatus();
        	if(a == b){
        		params.put("status1","dd");
        	}*//*
        if(!StringUtils.isEmpty(startTime)){
            params.put("startTime",startTime + " 00:00:00");
        }if(!StringUtils.isEmpty(endTime)){
            params.put("endTime", endTime +" 23:59:59");
        }
        int start =(page - 1) * rows;
        params.put("start",start);
        params.put("limit",rows);
        params.put("orderByClause","c.createDate  DESC");
        try {
        	*//*List<Integer> list =comAuthService.getSpPendAndNormallList(request);
        	List<Integer> list1 =comAuthService.getSpNoPasslList(request);
        	for(int i=0;i<list1.size();i++){
        		list.add(list1.get(i));
        	}
        	if(null == list || list.size() ==0 ){
        		list.add(-999);
        	}
        	params.put("companyIds",list);*//*
            // 如果请求路径中有双斜杠转为单斜杠
            int count = companyService.queryCompanyNums(params);
            //result = companyIfBiz.selectByExample(params);
            result = companyService.queryCompanyList(params);
            Iterator<Map<String,Object>> it=result.iterator();
            while(it.hasNext()){
                Map<String,Object> map=it.next();
                map.put("severTypeName", companyService.selectServeTypeName(map.get("serveType").toString()));
            }
            modelMap.put("records", count);//总条数
            modelMap.put("rows",result);//数据
            modelMap.put("page", page);//页数
            modelMap.put("total",(count - 1) / rows + 1);//总页数
            modelMap.put("success", true);
        } catch (BaseException be) {
            LOGGER.error(be.getErrorMessage());
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return modelMap;
    }*/


    /**
     * 企业信息详情
     */
    /*@RequestMapping(value = "/companyIfDetail.ajax")
    @ResponseBody
    public Map<String, Object> companyIfDetail(@ModelAttribute("companyVo")CompanyVo companyVo,@RequestParam(value = "codeFlag", required = false) String codeFlag,
                                               HttpServletRequest request){
        HttpSession session = request.getSession();
        Staff staff = (Staff) session.getAttribute("LOGIN_STAFF");
        Map<String, Object> modelMap = new HashMap<String, Object>();
        Map<String, Object> parem = new HashMap<String, Object>();
        parem.put("compID", companyVo.getCompID());
        CompanyVo cvResult = new CompanyVo();
        CompanyVo cv4 = companyIfBiz.queryDocUrl(parem);
        //parem.put("status", companyVo.getStatus());
        if("1".equals(codeFlag)){
            parem.put("docType", "uniLic");
            CompanyVo cv1 =companyIfBiz.selectByPrimaryKey(parem);
            cv1.setDocUrl(cv4.getDocUrl());
            cvResult = cv1;
        }if("0".equals(codeFlag)){

            parem.put("docType", "license");
            CompanyVo cv =companyIfBiz.selectByPrimaryKey(parem);
            cvResult =cv;
            parem.put("docType", "orgLic");
            CompanyVo cv2 =companyIfBiz.selectByPrimaryKey(parem);
            parem.put("docType", "taxLic");
            CompanyVo cv3 =companyIfBiz.selectByPrimaryKey(parem);
            cvResult.setBusinessLicenseUrl(cv.getYinyePic());
            cvResult.setBusinessLicenseDocName(cv.getDocName());
            cvResult.setBusinessLicenseDocExpireTime(cv.getUsCodeDocExpireTime());
            cvResult.setTaxNumberUrl(cv3.getYinyePic());
            cvResult.setTaxNumberDocName(cv3.getDocName());
            cvResult.setTaxNumberDocExpireTime(cv3.getUsCodeDocExpireTime());


            cvResult.setOrgCodeUrl(cv2.getYinyePic());
            cvResult.setOrgCodeDocName(cv2.getDocName());
            cvResult.setOrgCodeDocExpireTime(cv2.getUsCodeDocExpireTime());
            cvResult.setDocUrl(cv4.getDocUrl());

        }
        cvResult.setSeverTypeName(companyService.selectServeTypeName(cvResult.getServeType()));
        modelMap.put("records", "");
        modelMap.put("rows",cvResult);
        modelMap.put("page", "");
        modelMap.put("total","");
        modelMap.put("success", true);

        return modelMap;
    }*/

    /**
     * 企业账号删除（逻辑删除）
     * @throws Exception
     */
    /*@RequestMapping(value = "/deleteAcct.ajax")
    @ResponseBody
    public Integer deleteAcct(Integer compID,
                              HttpServletRequest request) throws Exception{
        Integer number =0;
        List<AccountCompanyVo> acct= accountService.selectByCompID(compID.toString());
        AccountCompanyVo vo = new AccountCompanyVo();
        if(acct.size() >0){
            for(int k=0;k<acct.size();k++){


                //将手机号码首位改为一位随机字母
                String str = "abcdefghijklmnopqrstuvwxyz";
                String strNew = "";
                char[] b = str.toCharArray();
                for(int i=0;i<1;i++){
                    int index =(int) (Math.random()*b.length);
                    strNew += b[index];

                }
                String msisdn = acct.get(k).getMsisdn().replaceFirst("^1", strNew);
                vo.setMsisdn(msisdn);
                vo.setDelFlag(1);
                vo.setAccountID(acct.get(k).getAccountID());
                vo.setCompID(acct.get(k).getCompID());
                vo.setStaffID(acct.get(k).getStaffID());
                accountService.updateAccounts(vo);
                staffDao.deleteStaff(vo.getStaffID().longValue());
                vo.setMsisdn(acct.get(0).getMsisdn());
            }

            number= companyService.updateDelFlag(vo);

        }
        return number;


    }*/

    /*<?xml version="1.0" encoding="UTF-8"?>
    <data>
      <message>
        <status>0</status>
        <value>处理成功</value>
      </message>
      <policeCheckInfos>
        <policeCheckInfo name="陈晓光" id="430626******107117">
          <message>
            <status>0</status>
            <value>查询成功</value>
          </message>
          <name desc="姓名">陈晓光</name>
          <identitycard desc="身份证号">430626******7117</identitycard>
          <compStatus desc="比对状态">3</compStatus>
          <compResult desc="比对结果">一致</compResult>
          <checkPhoto desc="照片" />
          <no desc="唯一标识" />
        </policeCheckInfo>
      </policeCheckInfos>
    </data>
*/
    //身份验证
    /*@RequestMapping(value = "/personVerification.ajax")
    @ResponseBody
    public Map<String, Object> personVerification(@ModelAttribute("companyVo")CompanyVo companyVo,
                                                  @RequestParam(value = "idCard", required = false) String idCard,
                                                  @RequestParam(value = "idName", required = false) String idName,
                                                  @RequestParam(value = "compID", required = false) String compID,
                                                  HttpServletRequest request,HttpSession session){
        Map<String, Object> modelMap = new HashMap<String, Object>();
        String resultStr ="";
        //从配置文件中获取edipApiURL
        String url = "http://192.168.123.56:8111/IdCard/attestation.ajax";
        //String url = AttachmentConfigUtil.getProperty("IDCard_URL");
        LOGGER.debug("人员身份证认证: "+ url);
        Map<String,Object> params = new HashMap<String,Object>();
        try {
            params.put("idCard",idCard);
            params.put("idName",idName);
            //身份证
            params.put("flag",2);
    		String idNameStr  = java.net.URLDecoder.decode(idName,"UTF-8");
    		//String id5Url = AttachmentConfigUtil.getProperty("WEBSERVICE_ID5_URL");
    		QueryValidatorServicesProxy proxy = new QueryValidatorServicesProxy();
    		proxy.setEndpoint(id5Url);
            //换成获取对应的serice
            //QueryValidatorServices service =  proxy.getQueryValidatorServices();
            //调用web service提供的方法
            //调用edipApi
            String result = HttpClientUtil.doPost(url, params, "UTF-8", false);
            LOGGER.debug("人员身份证认证结果: "+ result);
          //String result = service.querySingle(encode(KEY, USERNAME), encode(KEY, PASSWORD),
			//		encode(KEY, QUERY_TYPE_ID), encode(KEY, idNameStr + "," + idCard));
			System.out.println(decode(KEY,result));
			LOGGER.info(decode(KEY,result));
            System.out.println(result);
            LOGGER.info(result);
            //String response =decode(KEY,result);
            String response =result;
            PersonResopnse person = XmlUtil.xmlToBean(response,  PersonResopnse.class);
            if("0".equals(person.getMessage().getStatus())){
                PoliceCheckInfo[] a   =person.getPoliceCheckInfos().getPoliceCheckInfo();
                String status = person.getMessage().getStatus();
                resultStr =a[0].getCompResult();
                if(!"".equals(status) || null != status){
                    accountCdrBiz.insertCdrs( AccountUtil.CDRTYPE_CREDQUERY, AccountUtil.CDRSUBTYPE_INDIVCRED,compID,session);
                }
            }

            System.out.println(resultStr);
        }catch (RemoteException e) {
			e.printStackTrace();
		} catch (Exception e) {
            e.printStackTrace();
        }

        modelMap.put("records", "");
        modelMap.put("rows",resultStr);
        modelMap.put("page", "");
        modelMap.put("total","");
        modelMap.put("success", true);

        return modelMap;
    }*/
    @RequestMapping(value = "/personVerification.ajax")//旧版直接调用
    @ResponseBody
    public Map<String, Object> personVerification(@ModelAttribute("companyVo")CompanyVo companyVo,
                                                  @RequestParam(value = "idCard", required = false) String idCard,
                                                  @RequestParam(value = "idName", required = false) String idName,
                                                  @RequestParam(value = "compID", required = false) String compID,
                                                  HttpServletRequest request,HttpSession session){
        Map<String, Object> modelMap = new HashMap<String, Object>();
        String resultStr ="";
        try {
            String idNameStr  = java.net.URLEncoder.encode(idName,"GB18030");
            //String id5Url = AttachmentConfigUtil.getProperty("WEBSERVICE_ID5_URL");
            QueryValidatorServicesProxy proxy = new QueryValidatorServicesProxy();
            proxy.setEndpoint(id5Url);
            //换成获取对应的serice
            QueryValidatorServices service =  proxy.getQueryValidatorServices();
            //调用web service提供的方法
            String result = service.querySingle(encode(KEY, USERNAME), encode(KEY, PASSWORD),
                    encode(KEY, QUERY_TYPE_ID), encode(KEY, idName + "," + idCard));
            System.out.println(decode(KEY,result));
            LOGGER.info(decode(KEY,result));
            String response =decode(KEY,result);
            PersonResopnse person = XmlUtil.xmlToBean(response,  PersonResopnse.class);
            if("0".equals(person.getMessage().getStatus())){
                PoliceCheckInfo[] a   =person.getPoliceCheckInfos().getPoliceCheckInfo();
                String status = person.getMessage().getStatus();
                resultStr =a[0].getCompResult();
                if(!"".equals(status) || null != status){
                    accountCdrBiz.insertCdrs( AccountUtil.CDRTYPE_CREDQUERY, AccountUtil.CDRSUBTYPE_INDIVCRED,compID,session,request);
                }
            }

            System.out.println(resultStr);
        }catch (RemoteException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        modelMap.put("records", "");
        modelMap.put("rows",resultStr);
        modelMap.put("page", "");
        modelMap.put("total","");
        modelMap.put("success", true);

        return modelMap;
    }
    /*@RequestMapping(value = "/personVerification.ajax")
    @ResponseBody
    public Map<String, Object> personVerification(@ModelAttribute("companyVo")CompanyVo companyVo,
                                                  @RequestParam(value = "idCard", required = false) String idCard,
                                                  @RequestParam(value = "idName", required = false) String idName,
                                                  @RequestParam(value = "compID", required = false) String compID,
                                                  HttpServletRequest request,HttpSession session){
        Map<String, Object> modelMap = new HashMap<String, Object>();
        String resultStr ="";
        //从配置文件中获取edipApiURL
        //String url = AttachmentConfigUtil.getProperty("IDCard_URL");
        //LOGGER.debug("人员身份证认证: "+ url);
        Map<String,Object> params = new HashMap<String,Object>();
        try {
            params.put("idCard",idCard);
            params.put("idName",idName);
            //身份证
            params.put("flag",2);
    		String idNameStr  = java.net.URLDecoder.decode(idName,"UTF-8");
    		//String id5Url = AttachmentConfigUtil.getProperty("WEBSERVICE_ID5_URL");
    		QueryValidatorServicesProxy proxy = new QueryValidatorServicesProxy();
    		proxy.setEndpoint(id5Url);
            //换成获取对应的serice
            QueryValidatorServices service =  proxy.getQueryValidatorServices();
            //调用web service提供的方法
            //调用edipApi
            //String result = HttpClientUtil.doPost(url, params, "UTF-8", false);
            //LOGGER.debug("人员身份证认证结果: "+ result);
          String result = service.querySingle(encode(KEY, USERNAME), encode(KEY, PASSWORD),
					encode(KEY, QUERY_TYPE_ID), encode(KEY, idNameStr + "," + idCard));
			System.out.println(decode(KEY,result));
			LOGGER.info(decode(KEY,result));
            System.out.println(result);
            LOGGER.info(result);
            String response =decode(KEY,result);
            //String response =result;
            PersonResopnse person = XmlUtil.xmlToBean(response,  PersonResopnse.class);
            if("0".equals(person.getMessage().getStatus())){
                PoliceCheckInfo[] a   =person.getPoliceCheckInfos().getPoliceCheckInfo();
                String status = person.getMessage().getStatus();
                resultStr =a[0].getCompResult();
                if(!"".equals(status) || null != status){
                    accountCdrBiz.insertCdrs( AccountUtil.CDRTYPE_CREDQUERY, AccountUtil.CDRSUBTYPE_INDIVCRED,compID,session);
                }
            }

            System.out.println(resultStr);
        }catch (RemoteException e) {
			e.printStackTrace();
		} catch (Exception e) {
            e.printStackTrace();
        }

        modelMap.put("records", "");
        modelMap.put("rows",resultStr);
        modelMap.put("page", "");
        modelMap.put("total","");
        modelMap.put("success", true);

        return modelMap;
    }*/

    @RequestMapping(value = "/companyVerification.ajax")
    @ResponseBody
    public Map<String, Object> companyVerification(@ModelAttribute("companyVo")CompanyVo companyVo,
                                                   @RequestParam(value = "usCode", required = false) String usCode,
                                                   @RequestParam(value = "license", required = false) String license,
                                                   @RequestParam(value = "codeFlag", required = false) String codeFlag,
                                                   @RequestParam(value = "compID", required = false) String compID,
                                                   HttpSession session,
                                                   HttpServletRequest request){

        Map<String, Object> modelMap = new HashMap<String, Object>();
        CompInfo info = companyIfBiz.searchCompInfo(compID);
        if(info !=null){
            modelMap.put("records", "");
            modelMap.put("rows",info);
            modelMap.put("page", "");
            modelMap.put("total","");
            modelMap.put("success", true);

            return modelMap;

        }
        Item item = null;
        String code ="";
        try {
            //String idNameStr  = java.net.URLDecoder.decode(idName,"UTF-8");
            if("0".equals(codeFlag)){
                code = license;
            }else{
                code = usCode;
            }
            //String id5Url = AttachmentConfigUtil.getProperty("WEBSERVICE_ID5_URL");
            QueryValidatorServicesProxy proxy = new QueryValidatorServicesProxy();
            proxy.setEndpoint(id5Url);
            //换成获取对应的serice
            QueryValidatorServices service =  proxy.getQueryValidatorServices();
            //调用web service提供的方法
            String result = service.querySingle(encode(KEY, USERNAME), encode(KEY, PASSWORD),
                    encode(KEY, QUERY_TYPE_ID_COMPANY), encode(KEY, code + "," + 3));
            System.out.println(decode(KEY,result));
            LOGGER.info(decode(KEY,result));
            String response =decode(KEY,result);
            ComapnyResponse company = XmlUtil.xmlToBean(response,  ComapnyResponse.class);
            if("0".equals(company.getMessage().getStatus())){
                item = new Item();
                Entb[] entbs=company.getEntbs().getEntbs();
                if (entbs == null || 0 == entbs.length) {
                    LOGGER.info("无数据");
                }else{
                    A1Po a1po = entbs[0].getA1Po();
                    if(a1po !=null){
                        item =a1po.getItem();
                    }
                }
                String codeStatus= 	entbs[0].getCode();
                if("1".equals(codeStatus)){
                    accountCdrBiz.insertCdrs( AccountUtil.CDRTYPE_CREDQUERY, AccountUtil.CDRSUBTYPE_COMPCRED,compID,session,request);
                }
            }else{

            }

        }catch (RemoteException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(item !=null){
            CompInfoVo list=companyIfBiz.searchCompByCompID(compID);
            CompInfoVo vo = new CompInfoVo();
            vo.setCompID(Integer.parseInt(compID));
            vo.setCompName(item.getA1Entname());
            vo.setBusiness_term(item.getA1Opfrom() +"至"+ item.getA1Opto());
            vo.setBusinessScope(item.getA1Zsopscope());
            vo.setBusinessType(item.getA1Enttype());
            vo.setCreateDate(item.getA1Esdate());
            vo.setEnterpriseCreditCode(item.getA1Creditcod());
            vo.setLegal_representative(item.getA1Frname());
            vo.setRegi_status(item.getA1Entstatus());
            vo.setRegist_authority(item.getA1Regorg());
            vo.setRegistered_capital(item.getA1Reccap()+item.getA1Regcapcur());
            vo.setRegisterNo(item.getA1Regno());
            vo.setAdreess(item.getA1Dom());
            if(list !=null){
                companyIfBiz.updateCompByCompID(vo);
            }else{

                companyIfBiz.insertCompInfo(vo);
            }
        }
        modelMap.put("records", "");
        modelMap.put("rows",item);
        modelMap.put("page", "");
        modelMap.put("total","");
        modelMap.put("success", true);

        return modelMap;

    }
    /*public Map<String, Object> companyVerification(@ModelAttribute("companyVo")CompanyVo companyVo,
                                                   @RequestParam(value = "usCode", required = false) String usCode,
                                                   @RequestParam(value = "license", required = false) String license,
                                                   @RequestParam(value = "codeFlag", required = false) String codeFlag,
                                                   @RequestParam(value = "compID", required = false) String compID,
                                                   HttpSession session,
                                                   HttpServletRequest request){

        Map<String, Object> modelMap = new HashMap<String, Object>();
        CompInfo info = companyIfBiz.searchCompInfo(compID);
        if(info !=null){
            modelMap.put("records", "");
            modelMap.put("rows",info);
            modelMap.put("page", "");
            modelMap.put("total","");
            modelMap.put("success", true);

            return modelMap;

        }
        Item item = null;
        String code ="";
        try {
            //String idNameStr  = java.net.URLDecoder.decode(idName,"UTF-8");
            if("0".equals(codeFlag)){
                code = license;
            }else{
                code = usCode;
            }
            Map<String,Object> params = new HashMap<String,Object>();
            params.put("code",code);
            //营业执照
            params.put("flag",1);
            //String url = AttachmentConfigUtil.getProperty("IDCard_URL");
    		*//*String id5Url = AttachmentConfigUtil.getProperty("WEBSERVICE_ID5_URL");*//*
    		QueryValidatorServicesProxy proxy = new QueryValidatorServicesProxy();
    		proxy.setEndpoint(id5Url);
            //换成获取对应的serice(原调用认证方法)
            QueryValidatorServices service =  proxy.getQueryValidatorServices();
            //调用web service提供的方法
          String result = service.querySingle(encode(KEY, USERNAME), encode(KEY, PASSWORD),
					encode(KEY, QUERY_TYPE_ID_COMPANY), encode(KEY, code + "," + 3));
            //调用edip-api
            //String result = HttpClientUtil.doPost(url, params, "UTF-8", false);
            //LOGGER.debug("营业执照认证: "+ result + "url: "+url);
			*//*System.out.println(decode(KEY,result));
			LOGGER.info(decode(KEY,result));*//*
			String response =decode(KEY,result);
            //String response =result;
            ComapnyResponse company = XmlUtil.xmlToBean(response,  ComapnyResponse.class);
            if("0".equals(company.getMessage().getStatus())){
                item = new Item();
                Entb[] entbs=company.getEntbs().getEntbs();
                if (entbs == null || 0 == entbs.length) {
                    LOGGER.info("无数据");
                }else{
                    A1Po a1po = entbs[0].getA1Po();
                    if(a1po !=null){
                        item =a1po.getItem();
                    }
                }
                String codeStatus= 	entbs[0].getCode();
                if("1".equals(codeStatus)){
                    accountCdrBiz.insertCdrs( AccountUtil.CDRTYPE_CREDQUERY, AccountUtil.CDRSUBTYPE_COMPCRED,compID,session,request);
                }
            }else{

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        if(item !=null){
            CompInfoVo list=companyIfBiz.searchCompByCompID(compID);
            CompInfoVo vo = new CompInfoVo();
            vo.setCompID(Integer.parseInt(compID));
            vo.setCompName(item.getA1Entname());
            vo.setBusiness_term(item.getA1Opfrom() +"至"+ item.getA1Opto());
            vo.setBusinessScope(item.getA1Opscope());
            vo.setBusinessType(item.getA1Enttype());
            vo.setCreateDate(item.getA1Esdate());
            vo.setEnterpriseCreditCode(item.getA1Creditcod());
            vo.setLegal_representative(item.getA1Frname());
            vo.setRegi_status(item.getA1Entstatus());
            vo.setRegist_authority(item.getA1Regorg());
            vo.setRegistered_capital(item.getA1Reccap()+item.getA1Regcapcur());
            vo.setRegisterNo(item.getA1Regno());
            vo.setAdreess(item.getA1Dom());
            Date date = new Date();
            vo.setCreDate(date);
            if(list !=null){
                companyIfBiz.updateCompByCompID(vo);
            }else{

                companyIfBiz.insertCompInfo(vo);
            }
        }
        modelMap.put("records", "");
        modelMap.put("rows",item);
        modelMap.put("page", "");
        modelMap.put("total","");
        modelMap.put("success", true);

        return modelMap;

    }*/

   /* @RequestMapping(value = "/companydetal.ajax")
    @ResponseBody
    public Map<String, Object> companyIfDetail(@ModelAttribute("companyVo")CompanyVo companyVo,
                                               HttpServletRequest request){
        HttpSession session = request.getSession();
        Staff staff = (Staff) session.getAttribute("LOGIN_STAFF");
        Map<String, Object> modelMap = new HashMap<String, Object>();
        Map<String, Object> parem = new HashMap<String, Object>();
        parem.put("compID", companyVo.getCompID());
        parem.put("staffId", staff.getStaffId());
        CompanyVo cv =companyIfBiz.selectByPrimaryKey(parem);
        cv.setSeverTypeName(companyService.selectServeTypeName(cv.getServeType()));

        modelMap.put("records", "");
        modelMap.put("rows",cv);
        modelMap.put("page", "");
        modelMap.put("total","");
        modelMap.put("success", true);

        return modelMap;
    }*/

    /**
     * 企业审核
     */
    /*@RequestMapping(value = "/updateStatus.ajax")
    @ResponseBody
    public Map<String, Object> updateStatus(@ModelAttribute("companyVo")CompanyVo companyVo,@RequestParam(value = "msgID", required = false) String msgID,
                                            HttpServletRequest request,HttpSession session){
        Map<String, Object> modelMap = new HashMap<String, Object>();
        AccountVo vo = (AccountVo) session.getAttribute("ACCOUNTVO");
        CompanyVo co = (CompanyVo) session.getAttribute("COMPANYVO");
        Staff staff1 = (Staff) session.getAttribute("LOGIN_STAFF");
        try {
            String msgIdStr="";
            if("null".equals(msgID)){
                MessageVo messageVo = new MessageVo();
                messageVo.setDataID(companyVo.getCompID());
                messageVo.setDataType(0);
                List<Message> listM =messageBiz.selectMsgId(messageVo);
                if(null != listM && listM.size() >0){
                    Message mess =listM.get(0);
                    msgIdStr = mess.getMsgID()+"";
                }
            }else{
                msgIdStr = msgID;
            }
            String auditStr  = java.net.URLDecoder.decode(companyVo.getAuditInfo(),"UTF-8");
            companyVo.setAuditInfo(auditStr);
            companyIfBiz.update(companyVo,request,msgIdStr);
            AcctStatus status = companyIfBiz.queryAcctStatus(companyVo.getCompID());
            AcctCreatByInfo createByInfo = companyIfBiz.queryAcctAliamsName(companyVo.getAccountID());
            if(status.getStatus()==0){
                RoleInfoVo ro = new RoleInfoVo();
                int staffid = Integer.parseInt(companyVo.getStaffId());


                //AcctAndCompInfoVo acct = companyIfBiz.searchRoleIdInfo(staffid);

                //List<AcctAndCompInfoVo> acctList = companyIfBiz.searchRoleIdInfo(staffid);

                CompanyTab info= companyIfBiz.searchName(companyVo.getCompID());
                List<Company> compList = companyIfBiz.searchCompIdByName(info.getName());
                //List<Company> compList1 = companyIfBiz.queryCompIdByName(info.getName());
                if(compList.size()>0){
                    for(int k=0;k<compList.size();k++){

                        Integer coid = compList.get(k).getCompID();
                        companyVo.setCoid(coid);
                        AcctAndStaff ac = companyIfBiz.searchAcctAndStaffInfo(coid);
                        if(ac !=null){
                            ro.setStaffid(ac.getStaffid());
                        }
                        ro.setRole_id(29);
                        companyIfBiz.updateRole(ro);
                        companyIfBiz.updateAcctByCompId(companyVo);
                        companyIfBiz.deleteCompInfo(coid);
                    }
                }
                if(info.getTab()!=null){


                }else{
                    String role_key ="sp_company_ukey";
                    AcctAndCompInfoVo acc =companyIfBiz.searchAcctAndCompInfo(role_key);
                    //int role_id = acc.getRole_id();
                    ro.setRole_id(acc.getRole_id());
                    ro.setStaffid(staffid);
                    Sec_Staff sec = new Sec_Staff();
                    sec.setFrist_login(1);//设置为首次登陆
                    sec.setStaffId(Long.valueOf(staffid));
                    //更新sec_staff表中的status信息
                    companyIfBiz.updateSecStaffInfo(sec);
                    companyIfBiz.updateRole(ro);
                    companyIfBiz.updateCreateBy(createByInfo);
                }


            }

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        modelMap.put("success", true);
        return modelMap;
    }

*/

    /*@RequestMapping(value = "/exportExcel.ajax")
    @ResponseBody
    public void exportExcel(@RequestParam(value = "param", required = false) String param,@RequestParam(value = "name", required = false) String name,@RequestParam(value = "status", required = false) String status,
                            @RequestParam(value = "provinceID", required = false) String provinceID,@RequestParam(value = "kssj", required = false) String kssj,@RequestParam(value = "zzsj", required = false) String zzsj,
                            HttpServletRequest request,
                            HttpServletResponse response) throws Exception{
        ExportExcel exportExcel = new ExportExcel();
        Map<String, Object> params = new HashMap<String, Object>();
        List<Integer> list = new ArrayList<Integer>();
        List<Map<String,Object>> result=new ArrayList<Map<String,Object>>();
        if( param !=null){
            String[] strs=param.split(",");

            for(int i=1,len=strs.length;i<len;i++){
                list.add(Integer.parseInt(strs[i]));
            }

            params.put("companyIds",list);
            result = companyIfBiz.selectExportList(params);
        }else{
            HttpSession session = request.getSession();
            CompanyExample example = new CompanyExample();
            List<Integer> list1 =comAuthService.getSpPendAndNormallList(request);
            List<Integer> list2 =comAuthService.getSpNoPasslList(request);
            for(int i=0;i<list2.size();i++){
                list1.add(list2.get(i));
            }
            if(null == list1 || list1.size() ==0 ){
                list1.add(-999);
            }
            params.put("companyIds",list1);
            if(!(name==null)){
                name = new String((name));
                name = URLDecoder.decode(name,"utf-8");
                params.put("name", name);
            }
            if(status !=null){
                params.put("status", status);
            }
            if(provinceID !=null){
                params.put("provinceID", provinceID);
            }
            if(kssj !=null){
                params.put("startTime", kssj);
            }
            if(zzsj !=null){
                params.put("endTime", zzsj);
            }
            params.put("companyIds",list1);
            result = companyIfBiz.searchExportList(params);
            //result = companyIfBiz.selectByExample(params);
        }
        List<CompanyVo> listCv = new ArrayList<>();
        Iterator<Map<String,Object>> it=result.iterator();
        while(it.hasNext()){
            CompanyVo cv = new CompanyVo();
            Map<String,Object> map=it.next();
            cv.setName(map.get("name")== null ? "" :map.get("name").toString());
            cv.setServeType(map.get("serveType")== null ? "" :map.get("serveType").toString());
            cv.setIdCardPic(map.get("idCardNoURL")== null ? "" :map.get("idCardNoURL").toString());
            cv.setIdCardNo(map.get("idCardNo")== null ? "" :map.get("idCardNo").toString());
            cv.setMsisdn(map.get("msisdn")== null ? "" :map.get("msisdn").toString());
            cv.setOrgCode(map.get("orgCode")== null ? "" :map.get("orgCode").toString());
            cv.setUsCode(map.get("usCode")== null ? "" :map.get("usCode").toString());
            cv.setYinyePic(map.get("docURL")== null ? "" :map.get("docURL").toString());
            cv.setAliasName(map.get("aliasName")== null ? "" :map.get("aliasName").toString());
            cv.setCodeFlag(map.get("codeFlag")== null ? "" :map.get("codeFlag").toString());
            cv.setEmail(map.get("email")== null ? "" :map.get("email").toString());
            cv.setAccountName(map.get("accName")== null ? "" :map.get("accName").toString());
            cv.setDocName(map.get("docName")== null ? "" :map.get("docName").toString());
            cv.setUsCodeDocExpireTime(map.get("invalidDate")== null ? "" :map.get("invalidDate").toString());
            cv.setBusinessCode(map.get("businessCode")== null ? "" :map.get("businessCode").toString());
            cv.setTaxCode(map.get("taxCode")== null ? "" :map.get("taxCode").toString());

            cv.setPcStr(map.get("pcStr")== null ? "" :map.get("pcStr").toString());
            cv.setSeverTypeName(companyService.selectServeTypeName(map.get("serveType")== null ? "" :map.get("serveType").toString()));
            listCv.add(cv);
        }

        String path =exportExcel.exportExcel(listCv);
        if(null == path || null == path || path.isEmpty()){

        }else{
            try {
                request.setCharacterEncoding("UTF-8");

                BufferedOutputStream bos = null;
                BufferedInputStream bis = null;
                bis = new BufferedInputStream(new FileInputStream(new File(path)));
                response.setContentType("application/octet-stream");
                response.setHeader("Content-disposition", "attachment; filename="+ new String(path.getBytes("utf-8"), "ISO8859-1"));
                response.setHeader("Content-Length", String.valueOf(bis.available()));
                bos = new BufferedOutputStream(response.getOutputStream());
                byte[] buff = new byte[2048];
                int bytesRead;
                while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                    bos.write(buff, 0, bytesRead);
                }
                bis.close();
                bos.close();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }*/

    public static String encode(String key, String data) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key.getBytes(), "DES"),
                new IvParameterSpec(key.getBytes()));
        return new BASE64Encoder().encodeBuffer(cipher.doFinal(data.getBytes("GB18030")));
    }
    public static String decode(String key, String data) throws Exception {
        new String();
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key.getBytes(), "DES"),
                new IvParameterSpec(key.getBytes()));
        return new String(cipher.doFinal(new BASE64Decoder().decodeBuffer(data)), "GB18030");
    }

    //以下是屏蔽测试公司的账号
    /**
     * 查询需要屏蔽的测试公司
     * @param params
     * @param page
     * @param rows
     * @param request
     * @return
     */
    /*@RequestMapping(value = "/searchCompanySwitch.ajax")
    @ResponseBody
    public Map<String, Object> searchCompanySwitch(Map<String,Object> params,String name,
                                                   @RequestParam(value = "page", required = false) int page,
                                                   @RequestParam(value = "rows", required = false) int rows,
                                                   HttpServletRequest request) {
        List<Map<String,Object>> result=new ArrayList<Map<String,Object>>();
        Map<String, Object> modelMap = new HashMap<String, Object>();
        if(!StringUtil.isEmpty(name)){
            params.put("name", name);
        }
        int start =(page - 1) * rows;
        params.put("start",start);
        params.put("limit",rows);
        try {
            int count = companyMapper.countBySwitchCompany(params);
            result = companyMapper.searchSwitchCompany(params);
            modelMap.put("records", count);//总条数
            modelMap.put("rows",result);//数据
            modelMap.put("page", page);//页数
            modelMap.put("total",(count - 1) / rows + 1);//总页数
            modelMap.put("success", true);
        } catch (BaseException be) {
            LOGGER.error(be.getErrorMessage());
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return modelMap;
    }*/

    /*@RequestMapping(value = "/addOrDeleteTestCompany.ajax")
    @ResponseBody
    public Map<String, Object> addOrDeleteTestCompany(HttpServletRequest request,CompanyVo companyVo,String flag) {
        Map<String , Object> params = new HashMap<String , Object>();
        Map<String , Object> map = new HashMap<String , Object>();
        //String companyName = companyVo.getName();
        Integer compID = companyVo.getCompID();
        try {
		*//*	if(companyName != null && !"".equals(companyName)){//添加测试的公司
				params.put("companyName", companyName);
				Company company = companyMapper.selectSwitch(params);
				if(company == null){
					map.put("code", 400);
					return map;
				}
				params.put("compID", company.getCompID());
				params.put("testSource", 0);
				Integer result = companyMapper.updateTestSource(params);
				if(result>0)
					map.put("code", 200);
			}*//*
            if("1".equals(flag)){//重置为正式公司
                params.put("testSource", 0);
            }else if("2".equals(flag)){//标记为vip公司
                params.put("testSource", 2);
            }else{//标记为测试公司
                params.put("testSource", 1);
            }
            if(compID!=null){
                params.put("compID", compID);
                Integer result = companyMapper.updateTestSource(params);
                if(result>0)
                    map.put("code", 200);
            }

        } catch (Exception e) {
            map.put("code", 400);
            e.printStackTrace();
        }

        return map;
    }*/


	/*@RequestMapping(value = "/switchCompany.ajax")
	@ResponseBody
    public Map<String, Object> switchCompany(HttpServletRequest request,String compID,String flag) {
		Map<String , Object> params = new HashMap<String , Object>();
		Map<String , Object> map = new HashMap<String , Object>();
		String[] arr = compID.split(",");
		try {
			if("1".equals(flag)){//屏蔽传过来的公司
				for(int i=1;i<arr.length;i++){
					params.put("delFlag", 1);
					params.put("compID", arr[i]);
				  Integer count=companyMapper.updateSwitchTestSource(params);
				}

			}

			if("2".equals(flag)){
				for(int i=1;i<arr.length;i++){
					params.put("delFlag", 0);
					params.put("compID", arr[i]);
				  Integer count=companyMapper.updateSwitchTestSource(params);
				}
			}

			map.put("code", 200);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return map;
	}*/


}
