package com.edip.vo;

import org.apache.commons.lang.StringUtils;

/**
 * Copyright(C) 北京创原天地科技有限公司
 * 
 * Module: 电子签章平台
 * 
 * @author zhangjie
 * @version
 * @see
 * @since 2015.03.13
 * @description: 下载证书请求VO
 * @log:
 */
public class AdminDownloadCertReqVO {
	/** 平台标识 */
	private String platformid;
	/** 受理*/
	private String transactioncode;
	/** 公钥 */
	private String subjectpubkey;
	/** 验证 */
	private String authcode;
	
	/**
	 * @description: 构造函数
	 */
	public AdminDownloadCertReqVO(){
		
	}

	/**
	 * Copy Constructor
	 * 
	 * @param downloadCertReqVO
	 *            a <code>DownloadCertReqVO</code> object
	 */
	public AdminDownloadCertReqVO(AdminDownloadCertReqVO downloadCertReqVO) {
		this.platformid = downloadCertReqVO.platformid;
		this.transactioncode = downloadCertReqVO.transactioncode;
		this.subjectpubkey = downloadCertReqVO.subjectpubkey;
		this.authcode = downloadCertReqVO.authcode;
	}

	public String getPlatformid() {
		return platformid;
	}

	public void setPlatformid(String platformid) {
		this.platformid = platformid;
	}

	public String getTransactioncode() {
		return transactioncode;
	}

	public void setTransactioncode(String transactioncode) {
		this.transactioncode = transactioncode;
	}

	public String getSubjectpubkey() {
		return subjectpubkey;
	}

	public void setSubjectpubkey(String subjectpubkey) {
		this.subjectpubkey = subjectpubkey;
	}

	public String getAuthcode() {
		return authcode;
	}

	public void setAuthcode(String authcode) {
		this.authcode = authcode;
	}

	/**
	 * 转为XML
	 * 
	 * @return
	 * @throws NoSuchAlgorithmException
	 */
	public String toXML() {
		StringBuffer buffer = new StringBuffer(
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><request command=\"certDownloadRequest\">");

		buffer.append("<platformid>");
		if (!StringUtils.isEmpty(this.platformid)) {
			buffer.append(this.platformid);
		}
		buffer.append("</platformid>");

		buffer.append("<parameters>");

		buffer.append("<transactioncode>");
		if (!StringUtils.isEmpty(this.transactioncode)) {
			buffer.append(this.transactioncode);
		}
		buffer.append("</transactioncode>");

		buffer.append("<subjectpubkey>");
		if (!StringUtils.isEmpty(this.subjectpubkey)) {
			buffer.append(this.subjectpubkey);
		}
		buffer.append("</subjectpubkey>");

		buffer.append("<authcode>");
		if (!StringUtils.isEmpty(this.authcode)) {
			buffer.append(this.authcode);
		}
		buffer.append("</authcode>");

		buffer.append("</parameters>");
		buffer.append("</request>");

		return buffer.toString();
	}

	/**
	 * Constructs a <code>String</code> with all attributes in name = value
	 * format.
	 * 
	 * @return a <code>String</code> representation of this object.
	 */
	public String toString() {
		final String TAB = "    ";

		String retValue = "";

		retValue = "DownloadCertReqVO ( " + super.toString() + TAB
				+ "platformid = " + this.platformid + TAB
				+ "transactioncode = " + this.transactioncode + TAB
				+ "subjectpubkey = " + this.subjectpubkey + TAB + "authcode = "
				+ this.authcode + TAB + " )";

		return retValue;
	}

}
