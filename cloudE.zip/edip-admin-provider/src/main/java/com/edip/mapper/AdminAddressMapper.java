package com.edip.mapper;

import com.edip.entity.AdminAddress;

public interface AdminAddressMapper {

    int deleteByPrimaryKey(Integer adrID);

    int insert(AdminAddress record);

    int insertSelective(AdminAddress record);

    AdminAddress selectByPrimaryKey(Integer adrID);

    int updateByPrimaryKeySelective(AdminAddress record);

    int updateByPrimaryKey(AdminAddress record);

    AdminAddress selectByCompId(Integer compId);
}