package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ExchangeitemExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public ExchangeitemExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andItemidIsNull() {
            addCriterion("itemID is null");
            return (Criteria) this;
        }

        public Criteria andItemidIsNotNull() {
            addCriterion("itemID is not null");
            return (Criteria) this;
        }

        public Criteria andItemidEqualTo(Integer value) {
            addCriterion("itemID =", value, "itemid");
            return (Criteria) this;
        }

        public Criteria andItemidNotEqualTo(Integer value) {
            addCriterion("itemID <>", value, "itemid");
            return (Criteria) this;
        }

        public Criteria andItemidGreaterThan(Integer value) {
            addCriterion("itemID >", value, "itemid");
            return (Criteria) this;
        }

        public Criteria andItemidGreaterThanOrEqualTo(Integer value) {
            addCriterion("itemID >=", value, "itemid");
            return (Criteria) this;
        }

        public Criteria andItemidLessThan(Integer value) {
            addCriterion("itemID <", value, "itemid");
            return (Criteria) this;
        }

        public Criteria andItemidLessThanOrEqualTo(Integer value) {
            addCriterion("itemID <=", value, "itemid");
            return (Criteria) this;
        }

        public Criteria andItemidIn(List<Integer> values) {
            addCriterion("itemID in", values, "itemid");
            return (Criteria) this;
        }

        public Criteria andItemidNotIn(List<Integer> values) {
            addCriterion("itemID not in", values, "itemid");
            return (Criteria) this;
        }

        public Criteria andItemidBetween(Integer value1, Integer value2) {
            addCriterion("itemID between", value1, value2, "itemid");
            return (Criteria) this;
        }

        public Criteria andItemidNotBetween(Integer value1, Integer value2) {
            addCriterion("itemID not between", value1, value2, "itemid");
            return (Criteria) this;
        }

        public Criteria andProidIsNull() {
            addCriterion("proID is null");
            return (Criteria) this;
        }

        public Criteria andProidIsNotNull() {
            addCriterion("proID is not null");
            return (Criteria) this;
        }

        public Criteria andProidEqualTo(Integer value) {
            addCriterion("proID =", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidNotEqualTo(Integer value) {
            addCriterion("proID <>", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidGreaterThan(Integer value) {
            addCriterion("proID >", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidGreaterThanOrEqualTo(Integer value) {
            addCriterion("proID >=", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidLessThan(Integer value) {
            addCriterion("proID <", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidLessThanOrEqualTo(Integer value) {
            addCriterion("proID <=", value, "proid");
            return (Criteria) this;
        }

        public Criteria andProidIn(List<Integer> values) {
            addCriterion("proID in", values, "proid");
            return (Criteria) this;
        }

        public Criteria andProidNotIn(List<Integer> values) {
            addCriterion("proID not in", values, "proid");
            return (Criteria) this;
        }

        public Criteria andProidBetween(Integer value1, Integer value2) {
            addCriterion("proID between", value1, value2, "proid");
            return (Criteria) this;
        }

        public Criteria andProidNotBetween(Integer value1, Integer value2) {
            addCriterion("proID not between", value1, value2, "proid");
            return (Criteria) this;
        }

        public Criteria andDocidIsNull() {
            addCriterion("docID is null");
            return (Criteria) this;
        }

        public Criteria andDocidIsNotNull() {
            addCriterion("docID is not null");
            return (Criteria) this;
        }

        public Criteria andDocidEqualTo(Integer value) {
            addCriterion("docID =", value, "docid");
            return (Criteria) this;
        }

        public Criteria andDocidNotEqualTo(Integer value) {
            addCriterion("docID <>", value, "docid");
            return (Criteria) this;
        }

        public Criteria andDocidGreaterThan(Integer value) {
            addCriterion("docID >", value, "docid");
            return (Criteria) this;
        }

        public Criteria andDocidGreaterThanOrEqualTo(Integer value) {
            addCriterion("docID >=", value, "docid");
            return (Criteria) this;
        }

        public Criteria andDocidLessThan(Integer value) {
            addCriterion("docID <", value, "docid");
            return (Criteria) this;
        }

        public Criteria andDocidLessThanOrEqualTo(Integer value) {
            addCriterion("docID <=", value, "docid");
            return (Criteria) this;
        }

        public Criteria andDocidIn(List<Integer> values) {
            addCriterion("docID in", values, "docid");
            return (Criteria) this;
        }

        public Criteria andDocidNotIn(List<Integer> values) {
            addCriterion("docID not in", values, "docid");
            return (Criteria) this;
        }

        public Criteria andDocidBetween(Integer value1, Integer value2) {
            addCriterion("docID between", value1, value2, "docid");
            return (Criteria) this;
        }

        public Criteria andDocidNotBetween(Integer value1, Integer value2) {
            addCriterion("docID not between", value1, value2, "docid");
            return (Criteria) this;
        }

        public Criteria andSignflagIsNull() {
            addCriterion("signFlag is null");
            return (Criteria) this;
        }

        public Criteria andSignflagIsNotNull() {
            addCriterion("signFlag is not null");
            return (Criteria) this;
        }

        public Criteria andSignflagEqualTo(Integer value) {
            addCriterion("signFlag =", value, "signflag");
            return (Criteria) this;
        }

        public Criteria andSignflagNotEqualTo(Integer value) {
            addCriterion("signFlag <>", value, "signflag");
            return (Criteria) this;
        }

        public Criteria andSignflagGreaterThan(Integer value) {
            addCriterion("signFlag >", value, "signflag");
            return (Criteria) this;
        }

        public Criteria andSignflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("signFlag >=", value, "signflag");
            return (Criteria) this;
        }

        public Criteria andSignflagLessThan(Integer value) {
            addCriterion("signFlag <", value, "signflag");
            return (Criteria) this;
        }

        public Criteria andSignflagLessThanOrEqualTo(Integer value) {
            addCriterion("signFlag <=", value, "signflag");
            return (Criteria) this;
        }

        public Criteria andSignflagIn(List<Integer> values) {
            addCriterion("signFlag in", values, "signflag");
            return (Criteria) this;
        }

        public Criteria andSignflagNotIn(List<Integer> values) {
            addCriterion("signFlag not in", values, "signflag");
            return (Criteria) this;
        }

        public Criteria andSignflagBetween(Integer value1, Integer value2) {
            addCriterion("signFlag between", value1, value2, "signflag");
            return (Criteria) this;
        }

        public Criteria andSignflagNotBetween(Integer value1, Integer value2) {
            addCriterion("signFlag not between", value1, value2, "signflag");
            return (Criteria) this;
        }

        public Criteria andSendsigncountIsNull() {
            addCriterion("sendSignCount is null");
            return (Criteria) this;
        }

        public Criteria andSendsigncountIsNotNull() {
            addCriterion("sendSignCount is not null");
            return (Criteria) this;
        }

        public Criteria andSendsigncountEqualTo(Integer value) {
            addCriterion("sendSignCount =", value, "sendsigncount");
            return (Criteria) this;
        }

        public Criteria andSendsigncountNotEqualTo(Integer value) {
            addCriterion("sendSignCount <>", value, "sendsigncount");
            return (Criteria) this;
        }

        public Criteria andSendsigncountGreaterThan(Integer value) {
            addCriterion("sendSignCount >", value, "sendsigncount");
            return (Criteria) this;
        }

        public Criteria andSendsigncountGreaterThanOrEqualTo(Integer value) {
            addCriterion("sendSignCount >=", value, "sendsigncount");
            return (Criteria) this;
        }

        public Criteria andSendsigncountLessThan(Integer value) {
            addCriterion("sendSignCount <", value, "sendsigncount");
            return (Criteria) this;
        }

        public Criteria andSendsigncountLessThanOrEqualTo(Integer value) {
            addCriterion("sendSignCount <=", value, "sendsigncount");
            return (Criteria) this;
        }

        public Criteria andSendsigncountIn(List<Integer> values) {
            addCriterion("sendSignCount in", values, "sendsigncount");
            return (Criteria) this;
        }

        public Criteria andSendsigncountNotIn(List<Integer> values) {
            addCriterion("sendSignCount not in", values, "sendsigncount");
            return (Criteria) this;
        }

        public Criteria andSendsigncountBetween(Integer value1, Integer value2) {
            addCriterion("sendSignCount between", value1, value2, "sendsigncount");
            return (Criteria) this;
        }

        public Criteria andSendsigncountNotBetween(Integer value1, Integer value2) {
            addCriterion("sendSignCount not between", value1, value2, "sendsigncount");
            return (Criteria) this;
        }

        public Criteria andSendsignnumIsNull() {
            addCriterion("sendSignNum is null");
            return (Criteria) this;
        }

        public Criteria andSendsignnumIsNotNull() {
            addCriterion("sendSignNum is not null");
            return (Criteria) this;
        }

        public Criteria andSendsignnumEqualTo(Integer value) {
            addCriterion("sendSignNum =", value, "sendsignnum");
            return (Criteria) this;
        }

        public Criteria andSendsignnumNotEqualTo(Integer value) {
            addCriterion("sendSignNum <>", value, "sendsignnum");
            return (Criteria) this;
        }

        public Criteria andSendsignnumGreaterThan(Integer value) {
            addCriterion("sendSignNum >", value, "sendsignnum");
            return (Criteria) this;
        }

        public Criteria andSendsignnumGreaterThanOrEqualTo(Integer value) {
            addCriterion("sendSignNum >=", value, "sendsignnum");
            return (Criteria) this;
        }

        public Criteria andSendsignnumLessThan(Integer value) {
            addCriterion("sendSignNum <", value, "sendsignnum");
            return (Criteria) this;
        }

        public Criteria andSendsignnumLessThanOrEqualTo(Integer value) {
            addCriterion("sendSignNum <=", value, "sendsignnum");
            return (Criteria) this;
        }

        public Criteria andSendsignnumIn(List<Integer> values) {
            addCriterion("sendSignNum in", values, "sendsignnum");
            return (Criteria) this;
        }

        public Criteria andSendsignnumNotIn(List<Integer> values) {
            addCriterion("sendSignNum not in", values, "sendsignnum");
            return (Criteria) this;
        }

        public Criteria andSendsignnumBetween(Integer value1, Integer value2) {
            addCriterion("sendSignNum between", value1, value2, "sendsignnum");
            return (Criteria) this;
        }

        public Criteria andSendsignnumNotBetween(Integer value1, Integer value2) {
            addCriterion("sendSignNum not between", value1, value2, "sendsignnum");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountIsNull() {
            addCriterion("recvSignCount is null");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountIsNotNull() {
            addCriterion("recvSignCount is not null");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountEqualTo(Integer value) {
            addCriterion("recvSignCount =", value, "recvsigncount");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountNotEqualTo(Integer value) {
            addCriterion("recvSignCount <>", value, "recvsigncount");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountGreaterThan(Integer value) {
            addCriterion("recvSignCount >", value, "recvsigncount");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountGreaterThanOrEqualTo(Integer value) {
            addCriterion("recvSignCount >=", value, "recvsigncount");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountLessThan(Integer value) {
            addCriterion("recvSignCount <", value, "recvsigncount");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountLessThanOrEqualTo(Integer value) {
            addCriterion("recvSignCount <=", value, "recvsigncount");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountIn(List<Integer> values) {
            addCriterion("recvSignCount in", values, "recvsigncount");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountNotIn(List<Integer> values) {
            addCriterion("recvSignCount not in", values, "recvsigncount");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountBetween(Integer value1, Integer value2) {
            addCriterion("recvSignCount between", value1, value2, "recvsigncount");
            return (Criteria) this;
        }

        public Criteria andRecvsigncountNotBetween(Integer value1, Integer value2) {
            addCriterion("recvSignCount not between", value1, value2, "recvsigncount");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumIsNull() {
            addCriterion("recvSignNum is null");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumIsNotNull() {
            addCriterion("recvSignNum is not null");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumEqualTo(Integer value) {
            addCriterion("recvSignNum =", value, "recvsignnum");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumNotEqualTo(Integer value) {
            addCriterion("recvSignNum <>", value, "recvsignnum");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumGreaterThan(Integer value) {
            addCriterion("recvSignNum >", value, "recvsignnum");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumGreaterThanOrEqualTo(Integer value) {
            addCriterion("recvSignNum >=", value, "recvsignnum");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumLessThan(Integer value) {
            addCriterion("recvSignNum <", value, "recvsignnum");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumLessThanOrEqualTo(Integer value) {
            addCriterion("recvSignNum <=", value, "recvsignnum");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumIn(List<Integer> values) {
            addCriterion("recvSignNum in", values, "recvsignnum");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumNotIn(List<Integer> values) {
            addCriterion("recvSignNum not in", values, "recvsignnum");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumBetween(Integer value1, Integer value2) {
            addCriterion("recvSignNum between", value1, value2, "recvsignnum");
            return (Criteria) this;
        }

        public Criteria andRecvsignnumNotBetween(Integer value1, Integer value2) {
            addCriterion("recvSignNum not between", value1, value2, "recvsignnum");
            return (Criteria) this;
        }

        public Criteria andDataidIsNull() {
            addCriterion("dataID is null");
            return (Criteria) this;
        }

        public Criteria andDataidIsNotNull() {
            addCriterion("dataID is not null");
            return (Criteria) this;
        }

        public Criteria andDataidEqualTo(Integer value) {
            addCriterion("dataID =", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidNotEqualTo(Integer value) {
            addCriterion("dataID <>", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidGreaterThan(Integer value) {
            addCriterion("dataID >", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidGreaterThanOrEqualTo(Integer value) {
            addCriterion("dataID >=", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidLessThan(Integer value) {
            addCriterion("dataID <", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidLessThanOrEqualTo(Integer value) {
            addCriterion("dataID <=", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidIn(List<Integer> values) {
            addCriterion("dataID in", values, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidNotIn(List<Integer> values) {
            addCriterion("dataID not in", values, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidBetween(Integer value1, Integer value2) {
            addCriterion("dataID between", value1, value2, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidNotBetween(Integer value1, Integer value2) {
            addCriterion("dataID not between", value1, value2, "dataid");
            return (Criteria) this;
        }

        public Criteria andDatatypeIsNull() {
            addCriterion("dataType is null");
            return (Criteria) this;
        }

        public Criteria andDatatypeIsNotNull() {
            addCriterion("dataType is not null");
            return (Criteria) this;
        }

        public Criteria andDatatypeEqualTo(Integer value) {
            addCriterion("dataType =", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeNotEqualTo(Integer value) {
            addCriterion("dataType <>", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeGreaterThan(Integer value) {
            addCriterion("dataType >", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("dataType >=", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeLessThan(Integer value) {
            addCriterion("dataType <", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeLessThanOrEqualTo(Integer value) {
            addCriterion("dataType <=", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeIn(List<Integer> values) {
            addCriterion("dataType in", values, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeNotIn(List<Integer> values) {
            addCriterion("dataType not in", values, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeBetween(Integer value1, Integer value2) {
            addCriterion("dataType between", value1, value2, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeNotBetween(Integer value1, Integer value2) {
            addCriterion("dataType not between", value1, value2, "datatype");
            return (Criteria) this;
        }

        public Criteria andProductidIsNull() {
            addCriterion("productID is null");
            return (Criteria) this;
        }

        public Criteria andProductidIsNotNull() {
            addCriterion("productID is not null");
            return (Criteria) this;
        }

        public Criteria andProductidEqualTo(Integer value) {
            addCriterion("productID =", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotEqualTo(Integer value) {
            addCriterion("productID <>", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidGreaterThan(Integer value) {
            addCriterion("productID >", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidGreaterThanOrEqualTo(Integer value) {
            addCriterion("productID >=", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidLessThan(Integer value) {
            addCriterion("productID <", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidLessThanOrEqualTo(Integer value) {
            addCriterion("productID <=", value, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidIn(List<Integer> values) {
            addCriterion("productID in", values, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotIn(List<Integer> values) {
            addCriterion("productID not in", values, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidBetween(Integer value1, Integer value2) {
            addCriterion("productID between", value1, value2, "productid");
            return (Criteria) this;
        }

        public Criteria andProductidNotBetween(Integer value1, Integer value2) {
            addCriterion("productID not between", value1, value2, "productid");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreatedateEqualTo(Date value) {
            addCriterion("createDate =", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThan(Date value) {
            addCriterion("createDate <", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateIn(List<Date> values) {
            addCriterion("createDate in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andIsfristIsNull() {
            addCriterion("isFrist is null");
            return (Criteria) this;
        }

        public Criteria andIsfristIsNotNull() {
            addCriterion("isFrist is not null");
            return (Criteria) this;
        }

        public Criteria andIsfristEqualTo(Integer value) {
            addCriterion("isFrist =", value, "isfrist");
            return (Criteria) this;
        }

        public Criteria andIsfristNotEqualTo(Integer value) {
            addCriterion("isFrist <>", value, "isfrist");
            return (Criteria) this;
        }

        public Criteria andIsfristGreaterThan(Integer value) {
            addCriterion("isFrist >", value, "isfrist");
            return (Criteria) this;
        }

        public Criteria andIsfristGreaterThanOrEqualTo(Integer value) {
            addCriterion("isFrist >=", value, "isfrist");
            return (Criteria) this;
        }

        public Criteria andIsfristLessThan(Integer value) {
            addCriterion("isFrist <", value, "isfrist");
            return (Criteria) this;
        }

        public Criteria andIsfristLessThanOrEqualTo(Integer value) {
            addCriterion("isFrist <=", value, "isfrist");
            return (Criteria) this;
        }

        public Criteria andIsfristIn(List<Integer> values) {
            addCriterion("isFrist in", values, "isfrist");
            return (Criteria) this;
        }

        public Criteria andIsfristNotIn(List<Integer> values) {
            addCriterion("isFrist not in", values, "isfrist");
            return (Criteria) this;
        }

        public Criteria andIsfristBetween(Integer value1, Integer value2) {
            addCriterion("isFrist between", value1, value2, "isfrist");
            return (Criteria) this;
        }

        public Criteria andIsfristNotBetween(Integer value1, Integer value2) {
            addCriterion("isFrist not between", value1, value2, "isfrist");
            return (Criteria) this;
        }

        public Criteria andSendflagIsNull() {
            addCriterion("sendFlag is null");
            return (Criteria) this;
        }

        public Criteria andSendflagIsNotNull() {
            addCriterion("sendFlag is not null");
            return (Criteria) this;
        }

        public Criteria andSendflagEqualTo(Integer value) {
            addCriterion("sendFlag =", value, "sendflag");
            return (Criteria) this;
        }

        public Criteria andSendflagNotEqualTo(Integer value) {
            addCriterion("sendFlag <>", value, "sendflag");
            return (Criteria) this;
        }

        public Criteria andSendflagGreaterThan(Integer value) {
            addCriterion("sendFlag >", value, "sendflag");
            return (Criteria) this;
        }

        public Criteria andSendflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("sendFlag >=", value, "sendflag");
            return (Criteria) this;
        }

        public Criteria andSendflagLessThan(Integer value) {
            addCriterion("sendFlag <", value, "sendflag");
            return (Criteria) this;
        }

        public Criteria andSendflagLessThanOrEqualTo(Integer value) {
            addCriterion("sendFlag <=", value, "sendflag");
            return (Criteria) this;
        }

        public Criteria andSendflagIn(List<Integer> values) {
            addCriterion("sendFlag in", values, "sendflag");
            return (Criteria) this;
        }

        public Criteria andSendflagNotIn(List<Integer> values) {
            addCriterion("sendFlag not in", values, "sendflag");
            return (Criteria) this;
        }

        public Criteria andSendflagBetween(Integer value1, Integer value2) {
            addCriterion("sendFlag between", value1, value2, "sendflag");
            return (Criteria) this;
        }

        public Criteria andSendflagNotBetween(Integer value1, Integer value2) {
            addCriterion("sendFlag not between", value1, value2, "sendflag");
            return (Criteria) this;
        }

        public Criteria andSigninfoIsNull() {
            addCriterion("signInfo is null");
            return (Criteria) this;
        }

        public Criteria andSigninfoIsNotNull() {
            addCriterion("signInfo is not null");
            return (Criteria) this;
        }

        public Criteria andSigninfoEqualTo(String value) {
            addCriterion("signInfo =", value, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoNotEqualTo(String value) {
            addCriterion("signInfo <>", value, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoGreaterThan(String value) {
            addCriterion("signInfo >", value, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoGreaterThanOrEqualTo(String value) {
            addCriterion("signInfo >=", value, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoLessThan(String value) {
            addCriterion("signInfo <", value, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoLessThanOrEqualTo(String value) {
            addCriterion("signInfo <=", value, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoLike(String value) {
            addCriterion("signInfo like", value, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoNotLike(String value) {
            addCriterion("signInfo not like", value, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoIn(List<String> values) {
            addCriterion("signInfo in", values, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoNotIn(List<String> values) {
            addCriterion("signInfo not in", values, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoBetween(String value1, String value2) {
            addCriterion("signInfo between", value1, value2, "signinfo");
            return (Criteria) this;
        }

        public Criteria andSigninfoNotBetween(String value1, String value2) {
            addCriterion("signInfo not between", value1, value2, "signinfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoIsNull() {
            addCriterion("destSignInfo is null");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoIsNotNull() {
            addCriterion("destSignInfo is not null");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoEqualTo(String value) {
            addCriterion("destSignInfo =", value, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoNotEqualTo(String value) {
            addCriterion("destSignInfo <>", value, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoGreaterThan(String value) {
            addCriterion("destSignInfo >", value, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoGreaterThanOrEqualTo(String value) {
            addCriterion("destSignInfo >=", value, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoLessThan(String value) {
            addCriterion("destSignInfo <", value, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoLessThanOrEqualTo(String value) {
            addCriterion("destSignInfo <=", value, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoLike(String value) {
            addCriterion("destSignInfo like", value, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoNotLike(String value) {
            addCriterion("destSignInfo not like", value, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoIn(List<String> values) {
            addCriterion("destSignInfo in", values, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoNotIn(List<String> values) {
            addCriterion("destSignInfo not in", values, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoBetween(String value1, String value2) {
            addCriterion("destSignInfo between", value1, value2, "destsigninfo");
            return (Criteria) this;
        }

        public Criteria andDestsigninfoNotBetween(String value1, String value2) {
            addCriterion("destSignInfo not between", value1, value2, "destsigninfo");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}