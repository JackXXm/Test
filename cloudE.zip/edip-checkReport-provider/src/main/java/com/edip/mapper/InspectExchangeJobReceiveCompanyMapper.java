package com.edip.mapper;

import com.edip.entity.InspectExchangeJobReceiveCompany;
import com.edip.entity.InspectExchangeJobReceiveCompanyExample;
import com.edip.entity.InspectExchangeJobReceiveCompany;
import com.edip.entity.InspectExchangeJobReceiveCompanyExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InspectExchangeJobReceiveCompanyMapper {
    long countByExample(InspectExchangeJobReceiveCompanyExample example);

    int deleteByExample(InspectExchangeJobReceiveCompanyExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(InspectExchangeJobReceiveCompany record);

    int insertSelective(InspectExchangeJobReceiveCompany record);

    List<InspectExchangeJobReceiveCompany> selectByExample(InspectExchangeJobReceiveCompanyExample example);

    InspectExchangeJobReceiveCompany selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") InspectExchangeJobReceiveCompany record, @Param("example") InspectExchangeJobReceiveCompanyExample example);

    int updateByExample(@Param("record") InspectExchangeJobReceiveCompany record, @Param("example") InspectExchangeJobReceiveCompanyExample example);

    int updateByPrimaryKeySelective(InspectExchangeJobReceiveCompany record);

    int updateByPrimaryKey(InspectExchangeJobReceiveCompany record);
}