package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AdminCompanyBenefitDetailExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public AdminCompanyBenefitDetailExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("ID is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("ID is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("ID =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("ID <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("ID >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ID >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("ID <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("ID <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("ID in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("ID not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("ID between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ID not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andCompidIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompidIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompidEqualTo(Integer value) {
            addCriterion("compID =", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThan(Integer value) {
            addCriterion("compID >", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThan(Integer value) {
            addCriterion("compID <", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidIn(List<Integer> values) {
            addCriterion("compID in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andBenefitidIsNull() {
            addCriterion("benefitID is null");
            return (Criteria) this;
        }

        public Criteria andBenefitidIsNotNull() {
            addCriterion("benefitID is not null");
            return (Criteria) this;
        }

        public Criteria andBenefitidEqualTo(Integer value) {
            addCriterion("benefitID =", value, "benefitid");
            return (Criteria) this;
        }

        public Criteria andBenefitidNotEqualTo(Integer value) {
            addCriterion("benefitID <>", value, "benefitid");
            return (Criteria) this;
        }

        public Criteria andBenefitidGreaterThan(Integer value) {
            addCriterion("benefitID >", value, "benefitid");
            return (Criteria) this;
        }

        public Criteria andBenefitidGreaterThanOrEqualTo(Integer value) {
            addCriterion("benefitID >=", value, "benefitid");
            return (Criteria) this;
        }

        public Criteria andBenefitidLessThan(Integer value) {
            addCriterion("benefitID <", value, "benefitid");
            return (Criteria) this;
        }

        public Criteria andBenefitidLessThanOrEqualTo(Integer value) {
            addCriterion("benefitID <=", value, "benefitid");
            return (Criteria) this;
        }

        public Criteria andBenefitidIn(List<Integer> values) {
            addCriterion("benefitID in", values, "benefitid");
            return (Criteria) this;
        }

        public Criteria andBenefitidNotIn(List<Integer> values) {
            addCriterion("benefitID not in", values, "benefitid");
            return (Criteria) this;
        }

        public Criteria andBenefitidBetween(Integer value1, Integer value2) {
            addCriterion("benefitID between", value1, value2, "benefitid");
            return (Criteria) this;
        }

        public Criteria andBenefitidNotBetween(Integer value1, Integer value2) {
            addCriterion("benefitID not between", value1, value2, "benefitid");
            return (Criteria) this;
        }

        public Criteria andIsgiveIsNull() {
            addCriterion("isGive is null");
            return (Criteria) this;
        }

        public Criteria andIsgiveIsNotNull() {
            addCriterion("isGive is not null");
            return (Criteria) this;
        }

        public Criteria andIsgiveEqualTo(Integer value) {
            addCriterion("isGive =", value, "isgive");
            return (Criteria) this;
        }

        public Criteria andIsgiveNotEqualTo(Integer value) {
            addCriterion("isGive <>", value, "isgive");
            return (Criteria) this;
        }

        public Criteria andIsgiveGreaterThan(Integer value) {
            addCriterion("isGive >", value, "isgive");
            return (Criteria) this;
        }

        public Criteria andIsgiveGreaterThanOrEqualTo(Integer value) {
            addCriterion("isGive >=", value, "isgive");
            return (Criteria) this;
        }

        public Criteria andIsgiveLessThan(Integer value) {
            addCriterion("isGive <", value, "isgive");
            return (Criteria) this;
        }

        public Criteria andIsgiveLessThanOrEqualTo(Integer value) {
            addCriterion("isGive <=", value, "isgive");
            return (Criteria) this;
        }

        public Criteria andIsgiveIn(List<Integer> values) {
            addCriterion("isGive in", values, "isgive");
            return (Criteria) this;
        }

        public Criteria andIsgiveNotIn(List<Integer> values) {
            addCriterion("isGive not in", values, "isgive");
            return (Criteria) this;
        }

        public Criteria andIsgiveBetween(Integer value1, Integer value2) {
            addCriterion("isGive between", value1, value2, "isgive");
            return (Criteria) this;
        }

        public Criteria andIsgiveNotBetween(Integer value1, Integer value2) {
            addCriterion("isGive not between", value1, value2, "isgive");
            return (Criteria) this;
        }

        public Criteria andBenefittypeIsNull() {
            addCriterion("benefitType is null");
            return (Criteria) this;
        }

        public Criteria andBenefittypeIsNotNull() {
            addCriterion("benefitType is not null");
            return (Criteria) this;
        }

        public Criteria andBenefittypeEqualTo(Integer value) {
            addCriterion("benefitType =", value, "benefittype");
            return (Criteria) this;
        }

        public Criteria andBenefittypeNotEqualTo(Integer value) {
            addCriterion("benefitType <>", value, "benefittype");
            return (Criteria) this;
        }

        public Criteria andBenefittypeGreaterThan(Integer value) {
            addCriterion("benefitType >", value, "benefittype");
            return (Criteria) this;
        }

        public Criteria andBenefittypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("benefitType >=", value, "benefittype");
            return (Criteria) this;
        }

        public Criteria andBenefittypeLessThan(Integer value) {
            addCriterion("benefitType <", value, "benefittype");
            return (Criteria) this;
        }

        public Criteria andBenefittypeLessThanOrEqualTo(Integer value) {
            addCriterion("benefitType <=", value, "benefittype");
            return (Criteria) this;
        }

        public Criteria andBenefittypeIn(List<Integer> values) {
            addCriterion("benefitType in", values, "benefittype");
            return (Criteria) this;
        }

        public Criteria andBenefittypeNotIn(List<Integer> values) {
            addCriterion("benefitType not in", values, "benefittype");
            return (Criteria) this;
        }

        public Criteria andBenefittypeBetween(Integer value1, Integer value2) {
            addCriterion("benefitType between", value1, value2, "benefittype");
            return (Criteria) this;
        }

        public Criteria andBenefittypeNotBetween(Integer value1, Integer value2) {
            addCriterion("benefitType not between", value1, value2, "benefittype");
            return (Criteria) this;
        }

        public Criteria andBenefitdataIsNull() {
            addCriterion("benefitData is null");
            return (Criteria) this;
        }

        public Criteria andBenefitdataIsNotNull() {
            addCriterion("benefitData is not null");
            return (Criteria) this;
        }

        public Criteria andBenefitdataEqualTo(Float value) {
            addCriterion("benefitData =", value, "benefitdata");
            return (Criteria) this;
        }

        public Criteria andBenefitdataNotEqualTo(Float value) {
            addCriterion("benefitData <>", value, "benefitdata");
            return (Criteria) this;
        }

        public Criteria andBenefitdataGreaterThan(Float value) {
            addCriterion("benefitData >", value, "benefitdata");
            return (Criteria) this;
        }

        public Criteria andBenefitdataGreaterThanOrEqualTo(Float value) {
            addCriterion("benefitData >=", value, "benefitdata");
            return (Criteria) this;
        }

        public Criteria andBenefitdataLessThan(Float value) {
            addCriterion("benefitData <", value, "benefitdata");
            return (Criteria) this;
        }

        public Criteria andBenefitdataLessThanOrEqualTo(Float value) {
            addCriterion("benefitData <=", value, "benefitdata");
            return (Criteria) this;
        }

        public Criteria andBenefitdataIn(List<Float> values) {
            addCriterion("benefitData in", values, "benefitdata");
            return (Criteria) this;
        }

        public Criteria andBenefitdataNotIn(List<Float> values) {
            addCriterion("benefitData not in", values, "benefitdata");
            return (Criteria) this;
        }

        public Criteria andBenefitdataBetween(Float value1, Float value2) {
            addCriterion("benefitData between", value1, value2, "benefitdata");
            return (Criteria) this;
        }

        public Criteria andBenefitdataNotBetween(Float value1, Float value2) {
            addCriterion("benefitData not between", value1, value2, "benefitdata");
            return (Criteria) this;
        }

        public Criteria andFromcontentIsNull() {
            addCriterion("fromContent is null");
            return (Criteria) this;
        }

        public Criteria andFromcontentIsNotNull() {
            addCriterion("fromContent is not null");
            return (Criteria) this;
        }

        public Criteria andFromcontentEqualTo(String value) {
            addCriterion("fromContent =", value, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentNotEqualTo(String value) {
            addCriterion("fromContent <>", value, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentGreaterThan(String value) {
            addCriterion("fromContent >", value, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentGreaterThanOrEqualTo(String value) {
            addCriterion("fromContent >=", value, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentLessThan(String value) {
            addCriterion("fromContent <", value, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentLessThanOrEqualTo(String value) {
            addCriterion("fromContent <=", value, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentLike(String value) {
            addCriterion("fromContent like", value, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentNotLike(String value) {
            addCriterion("fromContent not like", value, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentIn(List<String> values) {
            addCriterion("fromContent in", values, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentNotIn(List<String> values) {
            addCriterion("fromContent not in", values, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentBetween(String value1, String value2) {
            addCriterion("fromContent between", value1, value2, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andFromcontentNotBetween(String value1, String value2) {
            addCriterion("fromContent not between", value1, value2, "fromcontent");
            return (Criteria) this;
        }

        public Criteria andCreateidIsNull() {
            addCriterion("createID is null");
            return (Criteria) this;
        }

        public Criteria andCreateidIsNotNull() {
            addCriterion("createID is not null");
            return (Criteria) this;
        }

        public Criteria andCreateidEqualTo(Integer value) {
            addCriterion("createID =", value, "createid");
            return (Criteria) this;
        }

        public Criteria andCreateidNotEqualTo(Integer value) {
            addCriterion("createID <>", value, "createid");
            return (Criteria) this;
        }

        public Criteria andCreateidGreaterThan(Integer value) {
            addCriterion("createID >", value, "createid");
            return (Criteria) this;
        }

        public Criteria andCreateidGreaterThanOrEqualTo(Integer value) {
            addCriterion("createID >=", value, "createid");
            return (Criteria) this;
        }

        public Criteria andCreateidLessThan(Integer value) {
            addCriterion("createID <", value, "createid");
            return (Criteria) this;
        }

        public Criteria andCreateidLessThanOrEqualTo(Integer value) {
            addCriterion("createID <=", value, "createid");
            return (Criteria) this;
        }

        public Criteria andCreateidIn(List<Integer> values) {
            addCriterion("createID in", values, "createid");
            return (Criteria) this;
        }

        public Criteria andCreateidNotIn(List<Integer> values) {
            addCriterion("createID not in", values, "createid");
            return (Criteria) this;
        }

        public Criteria andCreateidBetween(Integer value1, Integer value2) {
            addCriterion("createID between", value1, value2, "createid");
            return (Criteria) this;
        }

        public Criteria andCreateidNotBetween(Integer value1, Integer value2) {
            addCriterion("createID not between", value1, value2, "createid");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createTime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createTime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createTime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createTime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createTime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createTime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createTime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createTime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createTime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createTime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createTime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createTime not between", value1, value2, "createtime");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}