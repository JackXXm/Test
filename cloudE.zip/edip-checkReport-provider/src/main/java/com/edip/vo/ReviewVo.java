package com.edip.vo;

import java.util.List;

public class ReviewVo {

    private Integer id;

    private String checkOpinion;

    private Integer themeType;

    private Integer complenteness;

    private List<DocIdVo> docList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCheckOpinion() {
        return checkOpinion;
    }

    public void setCheckOpinion(String checkOpinion) {
        this.checkOpinion = checkOpinion;
    }

    public Integer getThemeType() {
        return themeType;
    }

    public void setThemeType(Integer themeType) {
        this.themeType = themeType;
    }

    public Integer getComplenteness() {
        return complenteness;
    }

    public void setComplenteness(Integer complenteness) {
        this.complenteness = complenteness;
    }

    public List<DocIdVo> getDocList() {
        return docList;
    }

    public void setDocList(List<DocIdVo> docList) {
        this.docList = docList;
    }
}
