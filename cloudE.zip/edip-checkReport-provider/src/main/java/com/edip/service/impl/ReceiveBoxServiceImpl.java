package com.edip.service.impl;
//import com.edip.dto.util.RedisUtil;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edip.controller.ReviewClient;
import com.edip.dto.ServerResponse;
import com.edip.dto.util.CacheKey;
import com.edip.dto.util.RedisUtil;
import com.edip.dto.util.RedisUtilForDiy;
import com.edip.entity.ExchangeJob;
import com.edip.entity.ExchangeJobExample;
import com.edip.feign.ReciveFeign;
import com.edip.mapper.ExchangeJobMapper;
import com.edip.mapper.ExchangeMapper;
import com.edip.mapper.ReceiveBoxMapper;
import com.edip.service.ReceiveBoxService;
import com.edip.utils.DocUtil;
import com.edip.utils.FileUtil;
import com.edip.utils.StringUtil;
import com.edip.vo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ReceiveBoxServiceImpl implements ReceiveBoxService {

    @Autowired
    private ReceiveBoxMapper receiveBoxMapper;


    @Autowired
    private ReciveFeign reciveFeign;
    @Override
    public List<Map<String, Object>> queryReceiveBox(Map<String, Object> params) {
        return receiveBoxMapper.queryReceiveBoxList(params);
    }

    @Override
    @Transactional
    public int updateByJobId(Map<String,Object> info) {
        Integer jobId= (Integer) info.get("jobId");
        String receivedStatus= (String) info.get("receivedStatus");
        String compID= (String) info.get("compID");
        String operator= (String) info.get("operator");
        return receiveBoxMapper.updateByJobid(jobId+"", receivedStatus,compID,operator);
    }

    @Override
    public Map<String, Object> queryReceiveInfomationBox(Map<String, Object> params) {
        Map<String, Object> result = new HashMap<>();
        List<Map<String, Object>> companyInfomationList = new ArrayList<>();
        List<Map<String, Object>> productInfomationList = new ArrayList<>();
        try {
            String jobId= (String) params.get("jobId");
            companyInfomationList = receiveBoxMapper.queryCompanyInfomationBox(jobId);
            productInfomationList = receiveBoxMapper.queryProductInfomationBox(jobId);


            result.put("companyInfomationList", companyInfomationList);
            result.put("productInfomationList", productInfomationList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }










    @Override
    @Transactional
    public int receiveProduct(Map<String, Object> params) throws Exception {

        List<Map<String,Object>> productDocs=receiveBoxMapper.querySendProductInfo(params);
        JSONObject reciveVo=new JSONObject();

        Map<Object,List<Map<String,Object>>> mapGroup= productDocs.stream().collect(Collectors.groupingBy(e ->e.get("productInfoId")));
        Iterator< List<Map<String, Object>>> it=mapGroup.values().iterator();
        List<Map<String,Object>>productVos=new ArrayList<>();
        Integer compId= (Integer) params.get("compID");
        while(it.hasNext()){
            List<Map<String, Object>> entry=it.next();
            JSONObject productVo=new JSONObject(entry.get(0));
            productVo.put("checkDocs",JSONObject.toJSONString(entry));

            JSONObject companyVo=new JSONObject();

            companyVo.put("compId",productVo.getInteger("companyId"));
            productVo.put("companyVoString",companyVo.toJSONString());
            productVos.add(productVo);
        }
        reciveVo.put("productVoList",productVos);
        params.put("compID",compId+"");
        updateByJobId(params);
        ServerResponse response=reciveFeign.reciveCheckBox(reciveVo.toJSONString());
        if(!response.isSuccess()){
            throw  new Exception("查收检验报告出错");
        }

        return 0;
    }













}
