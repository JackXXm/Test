package com.edip.entity;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.Date;

/**
 * @author Administrator
 * @description TODO
 * @DATE 2019/1/23 0023 15:11
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReceiveCompany {

    /**
     * 主键
     */
    private Integer id;

    /**
     * 企业名录id
     */
    private Integer companyNameId;

    /**
     * 企业信息卡id
     */
    private Integer companyCardId;

    /**
     * 归属公司
     */
    private Integer compId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 创建人id
     */
    private Integer createAccountId;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 修改人id
     */
    private Integer updateAccountId;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 逻辑删除
     */
    private Integer deleteFlag;

    /**
     * 归档文件数
     */
    private Integer documentNumber;

    /**
     * 资质文件总数
     */
    private Integer documentTotal;

    /**
     * 人员档案数
     */
    private Integer memberNumber;

    /**
     * 合同档案数
     */
    private Integer contractNumber;

    /**
     * 人员归档数
     */
    private Integer memberArchive;

    /**
     * 合同归档数
     */
    private Integer contractArchive;

    /**
     * 客户关系
     */
    private Integer relationship;

    /**
     * 企业编号
     */
    private String companySerialNumber;

    /**
     * 0:本地上传,1:线上接收
     */
    private Integer informationFrom;

    /**
     * 合并id
     */
    private Integer withId;

    /**
     * 信息类型 0:本企业档案 1:客商 2:生产厂家
     */
    private Integer informationType;

    /**
     * 流转码
     */
    private String exchangeCode;

    /**
     * 主题id
     */
    private Integer projectId;

    /**
     * 厂商来源(供应商company_info_id)
     */
    private Integer companyInfoFrom;
    /**
     * 接受公司名称(receive_company_name)
     */
    private String receiveCompanyName;
    /**
     * 回传状态 1不需要回传，2需要回传 3 全部合同回传完成
     */
    private String returnStatus;

    /**
     * 发送搜不到公司手动添加的联系人
     */
    private  String contacts;


    /**
     * 发送搜不到公司手动添加的联系人电话
     */
    private  String tel;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCompanyNameId() {
        return companyNameId;
    }

    public void setCompanyNameId(Integer companyNameId) {
        this.companyNameId = companyNameId;
    }

    public Integer getCompanyCardId() {
        return companyCardId;
    }

    public void setCompanyCardId(Integer companyCardId) {
        this.companyCardId = companyCardId;
    }

    public Integer getCompId() {
        return compId;
    }

    public void setCompId(Integer compId) {
        this.compId = compId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getCreateAccountId() {
        return createAccountId;
    }

    public void setCreateAccountId(Integer createAccountId) {
        this.createAccountId = createAccountId;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Integer getUpdateAccountId() {
        return updateAccountId;
    }

    public void setUpdateAccountId(Integer updateAccountId) {
        this.updateAccountId = updateAccountId;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Integer getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(Integer documentNumber) {
        this.documentNumber = documentNumber;
    }

    public Integer getDocumentTotal() {
        return documentTotal;
    }

    public void setDocumentTotal(Integer documentTotal) {
        this.documentTotal = documentTotal;
    }

    public Integer getMemberNumber() {
        return memberNumber;
    }

    public void setMemberNumber(Integer memberNumber) {
        this.memberNumber = memberNumber;
    }

    public Integer getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(Integer contractNumber) {
        this.contractNumber = contractNumber;
    }

    public Integer getMemberArchive() {
        return memberArchive;
    }

    public void setMemberArchive(Integer memberArchive) {
        this.memberArchive = memberArchive;
    }

    public Integer getContractArchive() {
        return contractArchive;
    }

    public void setContractArchive(Integer contractArchive) {
        this.contractArchive = contractArchive;
    }

    public Integer getRelationship() {
        return relationship;
    }

    public void setRelationship(Integer relationship) {
        this.relationship = relationship;
    }

    public String getCompanySerialNumber() {
        return companySerialNumber;
    }

    public void setCompanySerialNumber(String companySerialNumber) {
        this.companySerialNumber = companySerialNumber;
    }

    public Integer getInformationFrom() {
        return informationFrom;
    }

    public void setInformationFrom(Integer informationFrom) {
        this.informationFrom = informationFrom;
    }

    public Integer getWithId() {
        return withId;
    }

    public void setWithId(Integer withId) {
        this.withId = withId;
    }

    public Integer getInformationType() {
        return informationType;
    }

    public void setInformationType(Integer informationType) {
        this.informationType = informationType;
    }

    public String getExchangeCode() {
        return exchangeCode;
    }

    public void setExchangeCode(String exchangeCode) {
        this.exchangeCode = exchangeCode;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public Integer getCompanyInfoFrom() {
        return companyInfoFrom;
    }

    public void setCompanyInfoFrom(Integer companyInfoFrom) {
        this.companyInfoFrom = companyInfoFrom;
    }

    public String getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(String returnStatus) {
        this.returnStatus = returnStatus;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        CompanyInfo other = (CompanyInfo) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
                && (this.getCompanyNameId() == null ? other.getCompanyNameId() == null : this.getCompanyNameId().equals(other.getCompanyNameId()))
                && (this.getCompanyCardId() == null ? other.getCompanyCardId() == null : this.getCompanyCardId().equals(other.getCompanyCardId()))
                && (this.getCompId() == null ? other.getCompId() == null : this.getCompId().equals(other.getCompId()))
                && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
                && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
                && (this.getCreateAccountId() == null ? other.getCreateAccountId() == null : this.getCreateAccountId().equals(other.getCreateAccountId()))
                && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
                && (this.getUpdateAccountId() == null ? other.getUpdateAccountId() == null : this.getUpdateAccountId().equals(other.getUpdateAccountId()))
                && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
                && (this.getDeleteFlag() == null ? other.getDeleteFlag() == null : this.getDeleteFlag().equals(other.getDeleteFlag()))
                && (this.getDocumentNumber() == null ? other.getDocumentNumber() == null : this.getDocumentNumber().equals(other.getDocumentNumber()))
                && (this.getDocumentTotal() == null ? other.getDocumentTotal() == null : this.getDocumentTotal().equals(other.getDocumentTotal()))
                && (this.getMemberNumber() == null ? other.getMemberNumber() == null : this.getMemberNumber().equals(other.getMemberNumber()))
                && (this.getContractNumber() == null ? other.getContractNumber() == null : this.getContractNumber().equals(other.getContractNumber()))
                && (this.getMemberArchive() == null ? other.getMemberArchive() == null : this.getMemberArchive().equals(other.getMemberArchive()))
                && (this.getContractArchive() == null ? other.getContractArchive() == null : this.getContractArchive().equals(other.getContractArchive()))
                && (this.getRelationship() == null ? other.getRelationship() == null : this.getRelationship().equals(other.getRelationship()))
                && (this.getCompanySerialNumber() == null ? other.getCompanySerialNumber() == null : this.getCompanySerialNumber().equals(other.getCompanySerialNumber()))
                && (this.getInformationFrom() == null ? other.getInformationFrom() == null : this.getInformationFrom().equals(other.getInformationFrom()))
                && (this.getWithId() == null ? other.getWithId() == null : this.getWithId().equals(other.getWithId()))
                && (this.getInformationType() == null ? other.getInformationType() == null : this.getInformationType().equals(other.getInformationType()))
                && (this.getExchangeCode() == null ? other.getExchangeCode() == null : this.getExchangeCode().equals(other.getExchangeCode()))
                && (this.getProjectId() == null ? other.getProjectId() == null : this.getProjectId().equals(other.getProjectId()))
                && (this.getCompanyInfoFrom() == null ? other.getCompanyInfoFrom() == null : this.getCompanyInfoFrom().equals(other.getCompanyInfoFrom()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getCompanyNameId() == null) ? 0 : getCompanyNameId().hashCode());
        result = prime * result + ((getCompanyCardId() == null) ? 0 : getCompanyCardId().hashCode());
        result = prime * result + ((getCompId() == null) ? 0 : getCompId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getCreateAccountId() == null) ? 0 : getCreateAccountId().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getUpdateAccountId() == null) ? 0 : getUpdateAccountId().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getDeleteFlag() == null) ? 0 : getDeleteFlag().hashCode());
        result = prime * result + ((getDocumentNumber() == null) ? 0 : getDocumentNumber().hashCode());
        result = prime * result + ((getDocumentTotal() == null) ? 0 : getDocumentTotal().hashCode());
        result = prime * result + ((getMemberNumber() == null) ? 0 : getMemberNumber().hashCode());
        result = prime * result + ((getContractNumber() == null) ? 0 : getContractNumber().hashCode());
        result = prime * result + ((getMemberArchive() == null) ? 0 : getMemberArchive().hashCode());
        result = prime * result + ((getContractArchive() == null) ? 0 : getContractArchive().hashCode());
        result = prime * result + ((getRelationship() == null) ? 0 : getRelationship().hashCode());
        result = prime * result + ((getCompanySerialNumber() == null) ? 0 : getCompanySerialNumber().hashCode());
        result = prime * result + ((getInformationFrom() == null) ? 0 : getInformationFrom().hashCode());
        result = prime * result + ((getWithId() == null) ? 0 : getWithId().hashCode());
        result = prime * result + ((getInformationType() == null) ? 0 : getInformationType().hashCode());
        result = prime * result + ((getExchangeCode() == null) ? 0 : getExchangeCode().hashCode());
        result = prime * result + ((getProjectId() == null) ? 0 : getProjectId().hashCode());
        result = prime * result + ((getCompanyInfoFrom() == null) ? 0 : getCompanyInfoFrom().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", companyNameId=").append(companyNameId);
        sb.append(", companyCardId=").append(companyCardId);
        sb.append(", compId=").append(compId);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", createAccountId=").append(createAccountId);
        sb.append(", createBy=").append(createBy);
        sb.append(", updateAccountId=").append(updateAccountId);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", deleteFlag=").append(deleteFlag);
        sb.append(", documentNumber=").append(documentNumber);
        sb.append(", documentTotal=").append(documentTotal);
        sb.append(", memberNumber=").append(memberNumber);
        sb.append(", contractNumber=").append(contractNumber);
        sb.append(", memberArchive=").append(memberArchive);
        sb.append(", contractArchive=").append(contractArchive);
        sb.append(", relationship=").append(relationship);
        sb.append(", companySerialNumber=").append(companySerialNumber);
        sb.append(", informationFrom=").append(informationFrom);
        sb.append(", withId=").append(withId);
        sb.append(", informationType=").append(informationType);
        sb.append(", exchangeCode=").append(exchangeCode);
        sb.append(", projectId=").append(projectId);
        sb.append(", companyInfoFrom=").append(companyInfoFrom);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public String getReceiveCompanyName() {
        return receiveCompanyName;
    }

    public void setReceiveCompanyName(String receiveCompanyName) {
        this.receiveCompanyName = receiveCompanyName;
    }

    public String getContacts() {
        return contacts;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }
}
