package com.edip.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edip.dto.util.RedisUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DecimalFormat;
import java.util.List;

public class GetServerStatusUtil {
    private static final Logger log = LoggerFactory.getLogger(GetServerStatusUtil.class);
    public  static int getAvailableServer( RedisUtil util, int serviceCount){
        int total=0;
        //获取可用服务列表
        List<String> upList= util.searchList("SIGNSERVER");

        long ex = 5 * 1000L;

        String value = String.valueOf(System.currentTimeMillis() + ex);


            if(!util.lock("SignServiceLock",value)){
                return total;
            }
            int maxServer=11;
        for(String server:upList){
            String instanceId= server;
           Integer status=(Integer) util.get(instanceId);


           //达到需要分配的服务数退出
            if(total==serviceCount){
                break;
            }
           if(0==status){
               total++;

               //服务占位
               util.set(instanceId,1);
           }else if(1==status){
               //服务占位但没被使用，将服务设为可用
               util.set(instanceId,0);
           }
           if(total>=maxServer){
               break;
           }

        }
        util.unlock("SignServiceLock",value);

        return total;
    }

    public static String getInstanceId(String instanceId){
        instanceId=instanceId.replaceAll(":","#");
        return instanceId;
    }
    public static  void main(String args[]){
        float money=8f;
        float a=8000;
        float b=3000;
        float t=formatDouble4(a/(a+b));
        float m=formatDouble4(money*t);
        System.out.println(t);
        System.out.println(m);
        System.out.println(formatDouble4(m/money));
        JSONArray jsonArray=new JSONArray();
        JSONObject jsonObject=new JSONObject();
        jsonObject.put("id",1);
        jsonObject.put("firstJobId",1);
        jsonObject.put("returnStatus",4);
        jsonArray.add(jsonObject);
        System.out.println(jsonArray.toJSONString());

    }
    public  static float formatDouble4(float d) {


        DecimalFormat df = new DecimalFormat("#.00");
        return Float.parseFloat(df.format(d));
    }
}

