package com.edip.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import com.edip.vo.AdminAddressVo;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AdminAddressExcel {

    private static String ROOT_PATH;
    @Value("${EXCEL_EXPORT_PATH}")
    public void setROOT_PATH(String ROOT_PATH) {
        this.ROOT_PATH = ROOT_PATH;
    }

    public static String exportExcel(List<AdminAddressVo> list){

        // 第一步，创建一个webbook，对应一个Excel文件
        HSSFWorkbook wb = new HSSFWorkbook();
        // 第二步，在webbook中添加一个sheet,对应Excel文件中的sheet
        HSSFSheet sheet = wb.createSheet("邮寄地址");
        // 第三步，在sheet中添加表头第0行,注意老版本poi对Excel的行数列数有限制short
        HSSFRow row = sheet.createRow((int) 0);
        // 第四步，创建单元格，并设置值表头 设置表头居中
        HSSFCellStyle style = wb.createCellStyle();
//        style.setAlignment(HSSFCellStyle.ALIGN_CENTER); // 创建一个居中格式

        HSSFCell cell = row.createCell((short) 0);
        cell.setCellValue("公司全称");
        cell.setCellStyle(style);
        cell = row.createCell((short) 1);
        cell.setCellValue("地址信息");
        cell.setCellStyle(style);
        cell = row.createCell((short) 2);
        cell.setCellValue("联系人");
        cell.setCellStyle(style);
        cell = row.createCell((short) 3);
        cell.setCellValue("联系方式");
        cell.setCellStyle(style);
        cell = row.createCell((short) 4);
        cell.setCellValue("ukey序列号");
        cell.setCellStyle(style);

        for (int i = 0; i < list.size(); i++)
        {
            row = sheet.createRow((int) i + 1);
            AdminAddressVo cv =  list.get(i);
            // 第四步，创建单元格，并设置值
            row.createCell((short) 0).setCellValue( cv.getCompName());
            if(cv.getCity().substring(0,2).equals(cv.getProvince())){
                row.createCell((short) 1).setCellValue(cv.getCity()+cv.getSite());
            }else{
                row.createCell((short) 1).setCellValue(cv.getProvince()+"省"+cv.getCity()+cv.getSite());
            }
            row.createCell((short) 2).setCellValue(cv.getLinkMan());
            row.createCell((short) 3).setCellValue(cv.getMsisdn());
            row.createCell((short) 4).setCellValue(cv.getUkeySN());
        }
        String path ="";
        // 第六步，将文件存到指定位置
        try
        {
//            String rootPath = AttachmentConfigUtil.getProperty("EXCEL_EXPORT_PATH");
            path =  ROOT_PATH+File.separator+"MailingAddress.xls";
            FileOutputStream fout = new FileOutputStream(path);
            wb.write(fout);
            fout.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return path;

    }
}
