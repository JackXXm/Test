package com.edip.service;


import com.edip.entity.CompanyBenefitDetail;
import com.github.pagehelper.PageInfo;

import java.util.List;
import java.util.Map;

public interface ManageRechargeService {
    /**
     * create by: hym
     * description:查询所有公司账户情况
     * create time: 15:36 2019/2/26
     * 
      * @Param: null
     * @return 
     */
    public PageInfo queryAllBills( Map<String,Object> info);
    /**
     * create by: hym
     * description:公司充值
     * create time: 15:37 2019/2/26
     * 
      * @Param: null
     * @return 
     */
    public int recharge(Map<String,Object> info);
    /**
     * create by: hym
     * description:充值详情
     * create time: 15:37 2019/2/26
     * 
      * @Param: null
     * @return 
     */
    PageInfo queryRechargeDetail(Map<String,Object> info);
    PageInfo queryRechargeDetailBak(Map<String,Object> info);
    /**
     * create by: hym
     * description:扣费详情
     * create time: 17:11 2019/2/26
     * 
      * @Param: null
     * @return 
     */
    PageInfo querySendCost(Map<String,Object> info);

    PageInfo queryPresentationDetails(Map<String,Object> info);

    List<CompanyBenefitDetail> getFreeDelivery(Integer companyID);
}
