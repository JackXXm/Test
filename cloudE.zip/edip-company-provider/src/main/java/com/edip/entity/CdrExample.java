package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CdrExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public CdrExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCdridIsNull() {
            addCriterion("cdrID is null");
            return (Criteria) this;
        }

        public Criteria andCdridIsNotNull() {
            addCriterion("cdrID is not null");
            return (Criteria) this;
        }

        public Criteria andCdridEqualTo(Integer value) {
            addCriterion("cdrID =", value, "cdrid");
            return (Criteria) this;
        }

        public Criteria andCdridNotEqualTo(Integer value) {
            addCriterion("cdrID <>", value, "cdrid");
            return (Criteria) this;
        }

        public Criteria andCdridGreaterThan(Integer value) {
            addCriterion("cdrID >", value, "cdrid");
            return (Criteria) this;
        }

        public Criteria andCdridGreaterThanOrEqualTo(Integer value) {
            addCriterion("cdrID >=", value, "cdrid");
            return (Criteria) this;
        }

        public Criteria andCdridLessThan(Integer value) {
            addCriterion("cdrID <", value, "cdrid");
            return (Criteria) this;
        }

        public Criteria andCdridLessThanOrEqualTo(Integer value) {
            addCriterion("cdrID <=", value, "cdrid");
            return (Criteria) this;
        }

        public Criteria andCdridIn(List<Integer> values) {
            addCriterion("cdrID in", values, "cdrid");
            return (Criteria) this;
        }

        public Criteria andCdridNotIn(List<Integer> values) {
            addCriterion("cdrID not in", values, "cdrid");
            return (Criteria) this;
        }

        public Criteria andCdridBetween(Integer value1, Integer value2) {
            addCriterion("cdrID between", value1, value2, "cdrid");
            return (Criteria) this;
        }

        public Criteria andCdridNotBetween(Integer value1, Integer value2) {
            addCriterion("cdrID not between", value1, value2, "cdrid");
            return (Criteria) this;
        }

        public Criteria andCdrtypeIsNull() {
            addCriterion("cdrType is null");
            return (Criteria) this;
        }

        public Criteria andCdrtypeIsNotNull() {
            addCriterion("cdrType is not null");
            return (Criteria) this;
        }

        public Criteria andCdrtypeEqualTo(Integer value) {
            addCriterion("cdrType =", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeNotEqualTo(Integer value) {
            addCriterion("cdrType <>", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeGreaterThan(Integer value) {
            addCriterion("cdrType >", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("cdrType >=", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeLessThan(Integer value) {
            addCriterion("cdrType <", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeLessThanOrEqualTo(Integer value) {
            addCriterion("cdrType <=", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeIn(List<Integer> values) {
            addCriterion("cdrType in", values, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeNotIn(List<Integer> values) {
            addCriterion("cdrType not in", values, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeBetween(Integer value1, Integer value2) {
            addCriterion("cdrType between", value1, value2, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeNotBetween(Integer value1, Integer value2) {
            addCriterion("cdrType not between", value1, value2, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeIsNull() {
            addCriterion("cdrsubType is null");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeIsNotNull() {
            addCriterion("cdrsubType is not null");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeEqualTo(Integer value) {
            addCriterion("cdrsubType =", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeNotEqualTo(Integer value) {
            addCriterion("cdrsubType <>", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeGreaterThan(Integer value) {
            addCriterion("cdrsubType >", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("cdrsubType >=", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeLessThan(Integer value) {
            addCriterion("cdrsubType <", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeLessThanOrEqualTo(Integer value) {
            addCriterion("cdrsubType <=", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeIn(List<Integer> values) {
            addCriterion("cdrsubType in", values, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeNotIn(List<Integer> values) {
            addCriterion("cdrsubType not in", values, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeBetween(Integer value1, Integer value2) {
            addCriterion("cdrsubType between", value1, value2, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeNotBetween(Integer value1, Integer value2) {
            addCriterion("cdrsubType not between", value1, value2, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCompidIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompidIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompidEqualTo(Integer value) {
            addCriterion("compID =", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThan(Integer value) {
            addCriterion("compID >", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThan(Integer value) {
            addCriterion("compID <", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidIn(List<Integer> values) {
            addCriterion("compID in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andModeidIsNull() {
            addCriterion("modeID is null");
            return (Criteria) this;
        }

        public Criteria andModeidIsNotNull() {
            addCriterion("modeID is not null");
            return (Criteria) this;
        }

        public Criteria andModeidEqualTo(Integer value) {
            addCriterion("modeID =", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidNotEqualTo(Integer value) {
            addCriterion("modeID <>", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidGreaterThan(Integer value) {
            addCriterion("modeID >", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidGreaterThanOrEqualTo(Integer value) {
            addCriterion("modeID >=", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidLessThan(Integer value) {
            addCriterion("modeID <", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidLessThanOrEqualTo(Integer value) {
            addCriterion("modeID <=", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidIn(List<Integer> values) {
            addCriterion("modeID in", values, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidNotIn(List<Integer> values) {
            addCriterion("modeID not in", values, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidBetween(Integer value1, Integer value2) {
            addCriterion("modeID between", value1, value2, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidNotBetween(Integer value1, Integer value2) {
            addCriterion("modeID not between", value1, value2, "modeid");
            return (Criteria) this;
        }

        public Criteria andTargetidIsNull() {
            addCriterion("targetID is null");
            return (Criteria) this;
        }

        public Criteria andTargetidIsNotNull() {
            addCriterion("targetID is not null");
            return (Criteria) this;
        }

        public Criteria andTargetidEqualTo(Integer value) {
            addCriterion("targetID =", value, "targetid");
            return (Criteria) this;
        }

        public Criteria andTargetidNotEqualTo(Integer value) {
            addCriterion("targetID <>", value, "targetid");
            return (Criteria) this;
        }

        public Criteria andTargetidGreaterThan(Integer value) {
            addCriterion("targetID >", value, "targetid");
            return (Criteria) this;
        }

        public Criteria andTargetidGreaterThanOrEqualTo(Integer value) {
            addCriterion("targetID >=", value, "targetid");
            return (Criteria) this;
        }

        public Criteria andTargetidLessThan(Integer value) {
            addCriterion("targetID <", value, "targetid");
            return (Criteria) this;
        }

        public Criteria andTargetidLessThanOrEqualTo(Integer value) {
            addCriterion("targetID <=", value, "targetid");
            return (Criteria) this;
        }

        public Criteria andTargetidIn(List<Integer> values) {
            addCriterion("targetID in", values, "targetid");
            return (Criteria) this;
        }

        public Criteria andTargetidNotIn(List<Integer> values) {
            addCriterion("targetID not in", values, "targetid");
            return (Criteria) this;
        }

        public Criteria andTargetidBetween(Integer value1, Integer value2) {
            addCriterion("targetID between", value1, value2, "targetid");
            return (Criteria) this;
        }

        public Criteria andTargetidNotBetween(Integer value1, Integer value2) {
            addCriterion("targetID not between", value1, value2, "targetid");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andDataidIsNull() {
            addCriterion("dataID is null");
            return (Criteria) this;
        }

        public Criteria andDataidIsNotNull() {
            addCriterion("dataID is not null");
            return (Criteria) this;
        }

        public Criteria andDataidEqualTo(Integer value) {
            addCriterion("dataID =", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidNotEqualTo(Integer value) {
            addCriterion("dataID <>", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidGreaterThan(Integer value) {
            addCriterion("dataID >", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidGreaterThanOrEqualTo(Integer value) {
            addCriterion("dataID >=", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidLessThan(Integer value) {
            addCriterion("dataID <", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidLessThanOrEqualTo(Integer value) {
            addCriterion("dataID <=", value, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidIn(List<Integer> values) {
            addCriterion("dataID in", values, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidNotIn(List<Integer> values) {
            addCriterion("dataID not in", values, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidBetween(Integer value1, Integer value2) {
            addCriterion("dataID between", value1, value2, "dataid");
            return (Criteria) this;
        }

        public Criteria andDataidNotBetween(Integer value1, Integer value2) {
            addCriterion("dataID not between", value1, value2, "dataid");
            return (Criteria) this;
        }

        public Criteria andDatatypeIsNull() {
            addCriterion("dataType is null");
            return (Criteria) this;
        }

        public Criteria andDatatypeIsNotNull() {
            addCriterion("dataType is not null");
            return (Criteria) this;
        }

        public Criteria andDatatypeEqualTo(Integer value) {
            addCriterion("dataType =", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeNotEqualTo(Integer value) {
            addCriterion("dataType <>", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeGreaterThan(Integer value) {
            addCriterion("dataType >", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("dataType >=", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeLessThan(Integer value) {
            addCriterion("dataType <", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeLessThanOrEqualTo(Integer value) {
            addCriterion("dataType <=", value, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeIn(List<Integer> values) {
            addCriterion("dataType in", values, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeNotIn(List<Integer> values) {
            addCriterion("dataType not in", values, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeBetween(Integer value1, Integer value2) {
            addCriterion("dataType between", value1, value2, "datatype");
            return (Criteria) this;
        }

        public Criteria andDatatypeNotBetween(Integer value1, Integer value2) {
            addCriterion("dataType not between", value1, value2, "datatype");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreatedateEqualTo(Date value) {
            addCriterion("createDate =", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThan(Date value) {
            addCriterion("createDate <", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateIn(List<Date> values) {
            addCriterion("createDate in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andSignmoneyIsNull() {
            addCriterion("signMoney is null");
            return (Criteria) this;
        }

        public Criteria andSignmoneyIsNotNull() {
            addCriterion("signMoney is not null");
            return (Criteria) this;
        }

        public Criteria andSignmoneyEqualTo(Float value) {
            addCriterion("signMoney =", value, "signmoney");
            return (Criteria) this;
        }

        public Criteria andSignmoneyNotEqualTo(Float value) {
            addCriterion("signMoney <>", value, "signmoney");
            return (Criteria) this;
        }

        public Criteria andSignmoneyGreaterThan(Float value) {
            addCriterion("signMoney >", value, "signmoney");
            return (Criteria) this;
        }

        public Criteria andSignmoneyGreaterThanOrEqualTo(Float value) {
            addCriterion("signMoney >=", value, "signmoney");
            return (Criteria) this;
        }

        public Criteria andSignmoneyLessThan(Float value) {
            addCriterion("signMoney <", value, "signmoney");
            return (Criteria) this;
        }

        public Criteria andSignmoneyLessThanOrEqualTo(Float value) {
            addCriterion("signMoney <=", value, "signmoney");
            return (Criteria) this;
        }

        public Criteria andSignmoneyIn(List<Float> values) {
            addCriterion("signMoney in", values, "signmoney");
            return (Criteria) this;
        }

        public Criteria andSignmoneyNotIn(List<Float> values) {
            addCriterion("signMoney not in", values, "signmoney");
            return (Criteria) this;
        }

        public Criteria andSignmoneyBetween(Float value1, Float value2) {
            addCriterion("signMoney between", value1, value2, "signmoney");
            return (Criteria) this;
        }

        public Criteria andSignmoneyNotBetween(Float value1, Float value2) {
            addCriterion("signMoney not between", value1, value2, "signmoney");
            return (Criteria) this;
        }

        public Criteria andAccountchargingIsNull() {
            addCriterion("accountCharging is null");
            return (Criteria) this;
        }

        public Criteria andAccountchargingIsNotNull() {
            addCriterion("accountCharging is not null");
            return (Criteria) this;
        }

        public Criteria andAccountchargingEqualTo(Float value) {
            addCriterion("accountCharging =", value, "accountcharging");
            return (Criteria) this;
        }

        public Criteria andAccountchargingNotEqualTo(Float value) {
            addCriterion("accountCharging <>", value, "accountcharging");
            return (Criteria) this;
        }

        public Criteria andAccountchargingGreaterThan(Float value) {
            addCriterion("accountCharging >", value, "accountcharging");
            return (Criteria) this;
        }

        public Criteria andAccountchargingGreaterThanOrEqualTo(Float value) {
            addCriterion("accountCharging >=", value, "accountcharging");
            return (Criteria) this;
        }

        public Criteria andAccountchargingLessThan(Float value) {
            addCriterion("accountCharging <", value, "accountcharging");
            return (Criteria) this;
        }

        public Criteria andAccountchargingLessThanOrEqualTo(Float value) {
            addCriterion("accountCharging <=", value, "accountcharging");
            return (Criteria) this;
        }

        public Criteria andAccountchargingIn(List<Float> values) {
            addCriterion("accountCharging in", values, "accountcharging");
            return (Criteria) this;
        }

        public Criteria andAccountchargingNotIn(List<Float> values) {
            addCriterion("accountCharging not in", values, "accountcharging");
            return (Criteria) this;
        }

        public Criteria andAccountchargingBetween(Float value1, Float value2) {
            addCriterion("accountCharging between", value1, value2, "accountcharging");
            return (Criteria) this;
        }

        public Criteria andAccountchargingNotBetween(Float value1, Float value2) {
            addCriterion("accountCharging not between", value1, value2, "accountcharging");
            return (Criteria) this;
        }

        public Criteria andGivechargingIsNull() {
            addCriterion("giveCharging is null");
            return (Criteria) this;
        }

        public Criteria andGivechargingIsNotNull() {
            addCriterion("giveCharging is not null");
            return (Criteria) this;
        }

        public Criteria andGivechargingEqualTo(Float value) {
            addCriterion("giveCharging =", value, "givecharging");
            return (Criteria) this;
        }

        public Criteria andGivechargingNotEqualTo(Float value) {
            addCriterion("giveCharging <>", value, "givecharging");
            return (Criteria) this;
        }

        public Criteria andGivechargingGreaterThan(Float value) {
            addCriterion("giveCharging >", value, "givecharging");
            return (Criteria) this;
        }

        public Criteria andGivechargingGreaterThanOrEqualTo(Float value) {
            addCriterion("giveCharging >=", value, "givecharging");
            return (Criteria) this;
        }

        public Criteria andGivechargingLessThan(Float value) {
            addCriterion("giveCharging <", value, "givecharging");
            return (Criteria) this;
        }

        public Criteria andGivechargingLessThanOrEqualTo(Float value) {
            addCriterion("giveCharging <=", value, "givecharging");
            return (Criteria) this;
        }

        public Criteria andGivechargingIn(List<Float> values) {
            addCriterion("giveCharging in", values, "givecharging");
            return (Criteria) this;
        }

        public Criteria andGivechargingNotIn(List<Float> values) {
            addCriterion("giveCharging not in", values, "givecharging");
            return (Criteria) this;
        }

        public Criteria andGivechargingBetween(Float value1, Float value2) {
            addCriterion("giveCharging between", value1, value2, "givecharging");
            return (Criteria) this;
        }

        public Criteria andGivechargingNotBetween(Float value1, Float value2) {
            addCriterion("giveCharging not between", value1, value2, "givecharging");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountIsNull() {
            addCriterion("remainGiveAmount is null");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountIsNotNull() {
            addCriterion("remainGiveAmount is not null");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountEqualTo(Float value) {
            addCriterion("remainGiveAmount =", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountNotEqualTo(Float value) {
            addCriterion("remainGiveAmount <>", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountGreaterThan(Float value) {
            addCriterion("remainGiveAmount >", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountGreaterThanOrEqualTo(Float value) {
            addCriterion("remainGiveAmount >=", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountLessThan(Float value) {
            addCriterion("remainGiveAmount <", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountLessThanOrEqualTo(Float value) {
            addCriterion("remainGiveAmount <=", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountIn(List<Float> values) {
            addCriterion("remainGiveAmount in", values, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountNotIn(List<Float> values) {
            addCriterion("remainGiveAmount not in", values, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountBetween(Float value1, Float value2) {
            addCriterion("remainGiveAmount between", value1, value2, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountNotBetween(Float value1, Float value2) {
            addCriterion("remainGiveAmount not between", value1, value2, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountIsNull() {
            addCriterion("remainAmount is null");
            return (Criteria) this;
        }

        public Criteria andRemainamountIsNotNull() {
            addCriterion("remainAmount is not null");
            return (Criteria) this;
        }

        public Criteria andRemainamountEqualTo(Float value) {
            addCriterion("remainAmount =", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountNotEqualTo(Float value) {
            addCriterion("remainAmount <>", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountGreaterThan(Float value) {
            addCriterion("remainAmount >", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountGreaterThanOrEqualTo(Float value) {
            addCriterion("remainAmount >=", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountLessThan(Float value) {
            addCriterion("remainAmount <", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountLessThanOrEqualTo(Float value) {
            addCriterion("remainAmount <=", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountIn(List<Float> values) {
            addCriterion("remainAmount in", values, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountNotIn(List<Float> values) {
            addCriterion("remainAmount not in", values, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountBetween(Float value1, Float value2) {
            addCriterion("remainAmount between", value1, value2, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountNotBetween(Float value1, Float value2) {
            addCriterion("remainAmount not between", value1, value2, "remainamount");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}