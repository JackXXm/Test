package com.edip.mapper;


import com.edip.entity.CompanyCard;
import com.edip.entity.CompanyInfo;
import com.edip.entity.CompanyName;
import com.edip.entity.ProductInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface InspectReportMapperVo {
    List<Map<String, Object>> getInspectReportList(@Param("batchNum") String batchNum, @Param("startTime")String startTime, @Param("endTime")String endTime,@Param("compId") Integer compId,@Param("informationFrom")Integer informationFrom,@Param("productId")Integer productId,@Param("from") int from, @Param("to")int to);

    int getInspectReportListCount(@Param("batchNum")String batchNum,@Param("startTime") String startTime,@Param("endTime") String endTime,@Param("compId") Integer compId,@Param("informationFrom")Integer informationFrom,@Param("productId")Integer productId);

    void changeReportProductId(@Param("infoId")Integer infoId,@Param("reportId") Integer reportId);

    Map getInspectReport(@Param("reportId")Integer reportId);

    List<Map> getReceiveReport(@Param("reportId")Integer reportId);

    int getReportEditionMax(@Param("reportId")Integer reportId);

    //获取检验报告历史数据
    List<Map> getReportList();

    //获取old_company表数据
    String getOldCompanyNameById(@Param("compID")Integer compID);

    //获取产品信息数据
    List<Integer> getProductInfo(@Param("proMap")Map proMap);

    //获取用户名称
    String getAccountName(@Param("accountID")String accountID);

    //获取报告资质数据
    List<Map> getReportDocument(@Param("dipID")Integer dipID);

    Integer getCompanyInfoId(@Param("compID")Integer compID);

    Integer getCompanyNameIdByName(@Param("transmitCompany")String transmitCompany);

    void addCompanyName(CompanyName companyName);

    void addCompanyCard(CompanyCard cc);

    void addCompanyInfo(CompanyInfo companyInfo);

    List<Integer> getCompanyInfoListByName(@Param("nameId")Integer nameId,@Param("infoId") Integer infoId,@Param("informationType") Integer informationType,@Param("compID") Integer compID);

    void addProductInfo(ProductInfo productInfo);

    List<Map> getTransmitList();

    Map getReportById(@Param("dipID")Integer dipID);

    List<Map> getTransmitReportDocument(@Param("transmitItemsId") Integer transmitItemsId);

    void updateTransmitDoc(@Param("inspectionDocumentID")Integer inspectionDocumentID,@Param("docId") Integer docId);

    List<Map> getReportListByProductInfoId(@Param("productId")Integer productId);

    Map getReportDocEditionCount(@Param("reportId")Integer reportId,@Param("informationFrom")Integer informationFrom);

    void updateDocumentReportId(@Param("id")Integer id,@Param("reportId") Integer reportId,@Param("type")Integer type);

    Integer getReportInformationFrom(@Param("id")Integer id);

    Map getReportIdByProductInfoId(@Param("infoId") Integer infoId, @Param("batchNumber") String batchNumber);
}
