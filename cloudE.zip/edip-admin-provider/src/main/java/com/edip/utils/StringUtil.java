package com.edip.utils;

import javax.servlet.http.HttpServletRequest;

/**
 * 字符串工具类
 * @author liyonglun
 *
 */
public class StringUtil {

	/**
	 * 判断字符串是否为空 空则返回true，非空则返回false
	 * @param srcStr 需检查的字符串
	 * @return
	 */
	public static boolean isEmpty(String srcStr){
		boolean ret = false;
		if(null == srcStr || "".equals(srcStr)){
			ret = true;
		}
		return ret;
	}
	  public static String getIp2(HttpServletRequest request) {
          String ip = request.getHeader("X-Forwarded-For");
           if(!StringUtil.isEmpty(ip) && !"unKnown".equalsIgnoreCase(ip)){
               //多次反向代理后会有多个ip值，第一个ip才是真实ip
               int index = ip.indexOf(",");
               if(index != -1){
                   return ip.substring(0,index);
               }else{
                   return ip;
              }
          }
          ip = request.getHeader("X-Real-IP");
          if(!StringUtil.isEmpty(ip) && !"unKnown".equalsIgnoreCase(ip)){
              return ip;
      }
          return request.getRemoteAddr();
      }

}
