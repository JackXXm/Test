package com.edip.utils;

/**
 * Constant.java      2012-8-6
 * 常量类
 * @Description:
 * @Copyright: Copyright (c) 2012
 * @Company: Aspire Technologies
 * @version 1.0
 * @author: huangliang
 */
public class AdminCertificateConstant {
    /**
     * SHA1_RSA签名算法 
     */
    public static final int SHA1_RSA = 0x00000103;
    /**
     * 接收消息成功  
     */
    public static final int RECEIVES_MESSAGE_SUCCESS = 0;
    
    /** MD5摘要算法 */
    public static final int MD5_TYPE = 0x00000402;
    
    /** 企业证书申请操作名称 */
	public static final String OPERATION_NAME_APPENTCERT = "entCertApply";
	
	/** 证书下载操作名称 */
	public static final String OPERATION_NAME_DOWNLOADCERT = "certDownload";
	
	/**个人证书申请操作名称 */
	public static final String OPERATION_NAME_APPINCERT = "personCertApply";
	
	/** 个人证书申请操作名称 */
	public static final String OPERATION_NAME_APPUSERCERT = "personCertApply";	
	
	/** 吊销证书操作名称 */
	public static final String OPERATION_NAME_REVOKECERT = "revokeCert";
	
	/** 更新证书 **/
	public static final String OPERATION_NAME_UPDATECERT = "certUpdate";

}