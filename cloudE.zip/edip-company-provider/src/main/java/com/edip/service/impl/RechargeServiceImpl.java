package com.edip.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edip.controller.RechargeController;
import com.edip.entity.*;
import com.edip.mapper.*;
import com.edip.service.RechargeService;
import com.edip.util.DateUtils;
import io.swagger.models.auth.In;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class RechargeServiceImpl implements RechargeService {
    private Logger logger = LoggerFactory.getLogger(RechargeServiceImpl.class);
    @Autowired
    private RechargeMapper rechargeMapper;
    @Autowired
    private BillMapper billMapper;
    @Autowired
    private BillmodeMapper billmodeMapper;
    @Autowired
    private CdrMapper cdrMapper;
    @Autowired
    private BillMapperVo billMapperVo;
    @Override
    public List<Map<String, Object>> queryBill(Integer compID) throws Exception {
        return rechargeMapper.queryBillList(compID);
    }

    @Override
    public List<Map<String, Object>> queryTopView(Integer compID) throws Exception {
        return rechargeMapper.queryBillAmount(compID);
    }

    @Override
    public List<Map<String, Object>> queryBenefit(Integer compID) throws Exception {
        return rechargeMapper.queryBenefit(compID);
    }

    @Override
    public List<Map<String, Object>> queryExchangeList(Integer compID) throws Exception {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
        List<Map<String , Object>> list = rechargeMapper.querySendList(compID);
        for(Map map : list){
            map.put("unitPrice",Double.parseDouble(map.get("accountCharging").toString())+Double.parseDouble(map.get("giveCharging").toString()));

            if(!"0".equals(map.get("accountCharging").toString())){
                map.put("accountCharging", "-" + map.get("accountCharging"));
            }

            if(!"0".equals(map.get("giveCharging").toString())){
                map.put("giveCharging", "-" + map.get("giveCharging"));
            }

            if(map.containsKey("freeDate")){
                Date beginTime = sdf.parse(map.get("freeDate").toString());
                Date endTime = sdf.parse(sdf.format(new Date()));
                long time1 = beginTime.getTime();
                long time2 = endTime.getTime();
                long between_days = (time1 - time2) / (1000 * 3600 * 24);
                if(between_days>=0){
                    map.put("freeDate",0);
                }else{
                    map.put("freeDate",map.get("signMoney"));
                }
            }
            map.put("consumptionContent",getConsumptionContent(map));

        }

        return list;
    }

    private String getConsumptionContent(Map map) {
        String str = "";
        /*
        * if (Integer.parseInt(map.get("cdrType").toString())==0){
            if (Integer.parseInt(map.get("cdrsubType").toString())==0){
                str = "验证短信缴费";
            }else if (Integer.parseInt(map.get("cdrsubType").toString())==10){
                str = "通知短信缴费";
            }
        }else*/
        if (Integer.parseInt(map.get("cdrType").toString())==1){
            if (Integer.parseInt(map.get("cdrsubType").toString())==10){
                str = "企业资质查询";
            }else if (Integer.parseInt(map.get("cdrsubType").toString())==11){
                str = "个人资质查询";
            }
        }else if (Integer.parseInt(map.get("cdrType").toString())==2){
            if (Integer.parseInt(map.get("cdrsubType").toString())==20){
                str = "个人证书缴费";
            }else if (Integer.parseInt(map.get("cdrsubType").toString())==21){
                str = "企业证书缴费";
            }
        }else{
            str = "首营资料发送";
        }
        return str;
    }

    private Bill getBillInfo(Integer compId){
        BillExample example = new BillExample();

        example.createCriteria().andCompidEqualTo(compId);
        example.setOrderByClause("createDate ");
        List<Bill> bills = billMapper.selectByExample(example);
        if (null != bills && bills.size() > 0) {
            return bills.get(0);
        }else {
            return null;
        }
    }
    private float   countJobTotalCost(JSONArray array,Billmode billmode){

        float totalPrice=0;
        for(int i=0;i<array.size();i++) {
            Charge project = JSONObject.parseObject(array.getString(i), Charge.class);
            Float price = billmode.getUnitprice() * (countCostNumber(project.getCostCount()));
            totalPrice+=price;
        }
        return totalPrice;
    }
    private Cdr setBaseCdr(Cdr cdr, Charge project,Bill bill){
        Integer targetId = project.getReceiveID();

        cdr.setCdrsubtype(30);
        cdr.setCdrtype(3);
        boolean flag = project.isFlag();
        if(targetId!=null){
            if(!flag){
                cdr.setCompid(targetId);
                cdr.setTargetid(project.getComId());
            }else{
                cdr.setCompid(project.getComId());
                cdr.setTargetid(targetId);
            }
        }else{
            cdr.setName(project.getName());
            cdr.setCompid(project.getComId());
        }
        cdr.setDataid(project.getJobId());
        cdr.setCreatedate(new Date());
        cdr.setDatatype(6);
        cdr.setModeid(bill.getModeid());
        return cdr;
    }
    private int countCostNumber(int count){
            int result=1;

             result =count/5;
            boolean flag=count%5==0;
            if(!flag){
                result=result+1;
            }



        return result;
    }
    @Transactional
    @Override
    public int charging(String info,Integer compId) {
        Bill bill=getBillInfo(compId);
        if(bill!=null){
            Billmode billmode = billmodeMapper.selectByPrimaryKey(bill.getModeid());
            if (null == billmode) {
                logger.error("RechargeServiceImpl.chargin(): ------计费方式列表为空------");
                return -2;
            }
            JSONArray array=JSONArray.parseArray(info);

            float totalPrice=countJobTotalCost(array,billmode);
            if (null == bill.getFreedate() || (DateUtils.getDaysBetween(bill.getFreedate())) < 0) {
                Float remainAmount = bill.getRemainamount();
                Float remainGiveAmount = bill.getRemaingiveamount();
                float mount=remainAmount+remainGiveAmount;
                if(mount-totalPrice<0){
                    logger.info("金额不足");
                    return -1;
                }
            }
            Float remainAmount = bill.getRemainamount();
            Float remainGiveAmount = bill.getRemaingiveamount();

            for(int i=0;i<array.size();i++) {
                Charge project = JSONObject.parseObject(array.getString(i), Charge.class);
                Cdr cdr=new Cdr();
                    cdr=setBaseCdr(cdr,project,bill);
                Map<String, Object> paras = new HashMap<String, Object>();
                if (null == bill.getFreedate() || (DateUtils.getDaysBetween(bill.getFreedate())) < 0) {
                    cdr.setSignmoney(billmode.getUnitprice());
                    Float price = billmode.getUnitprice() * (countCostNumber(project.getCostCount()));

                    Float mount=remainAmount+remainGiveAmount;
                    float remainPrice=0;
                    float givePrice=0;
                    if(mount-price>0){
                    float remainPercentage=formatDouble4(remainAmount/(mount));
                    remainPrice=formatDouble4(price*remainPercentage);
                    givePrice=formatDouble4(price-remainPrice);
                    }else {
                        remainPrice= remainAmount;
                        givePrice=remainGiveAmount;
                    }
                    cdr.setAccountcharging(remainPrice);
                    cdr.setGivecharging(givePrice);//单次价格-剩余总金额（赠送金额扣费金额）
                    paras.put("remainPrice", remainPrice);//单次价格
                    paras.put("givePrice", givePrice);//单次价格-剩余总金额
                    paras.put("compId", compId);
                    billMapperVo.updateBillAmount(paras);
                    Map<String,Double> remainBill=billMapperVo.getLeaveMoney(paras);

                    cdr.setRemainamount(remainBill.get("remainAmount"));
                    cdr.setRemaingiveamount(remainBill.get("remainGiveAmount"));


                    logger.debug("------扣费成功------");

                }else{
                    paras.put("compId", compId);
                    billMapperVo.updateBillAmount(paras);
                    logger.info("您还在免费期内，不用扣费！");

                }
                cdrMapper.insertSelective(cdr);
                logger.debug("------生成账单成功------");
            }


        }else {
            logger.error("RechargeServiceImpl.charging(): ------该企业尚未充值------");
            return -3;
        }


            return 0;
        }

    @Override
    public Bill billMaintain(Integer compId) {
        Bill bill = null;
        BillExample example = new BillExample();
        example.createCriteria().andCompidEqualTo(compId);
        List<Bill> bills = billMapper.selectByExample(example);
        if (bills!=null&&bills.size()!=0)
            return bills.get(0);
        else {
            bill = new Bill();
            bill.setCompid(compId);
            bill.setCdrsubtype(30F);
            bill.setCdrtype(3);
            bill.setCreatedate(new Date());
            bill.setTotalamount(0F);
            bill.setRemainamount(0F);
            bill.setGiveamount(0F);
            bill.setRemaingiveamount(0F);
            bill.setModeid(5);
            billMapper.insertSelective(bill);
        }

        return bill;
    }

    public  static float formatDouble4(float d) {
        DecimalFormat df = new DecimalFormat("#.00");


        return Float.parseFloat(df.format(d));
    }
}
