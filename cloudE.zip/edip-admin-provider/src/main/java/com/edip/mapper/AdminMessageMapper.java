package com.edip.mapper;

import java.util.List;
import java.util.Map;

import com.edip.entity.AdminMessage;
import com.edip.entity.AdminMessageExample;
import com.edip.vo.AdminMessageVo;
import org.apache.ibatis.annotations.Param;

public interface AdminMessageMapper {
    int countByExample(AdminMessageExample example);

    int deleteByExample(AdminMessageExample example);

    int deleteByPrimaryKey(Integer msgID);

    int insert(AdminMessage record);

    int insertSelective(AdminMessage record);

    List<AdminMessage> selectByExampleWithBLOBsWithPage(@Param("example") AdminMessageExample example,
                                                   @Param("from") Integer from, @Param("to") Integer to);

    List<AdminMessage> selectByExampleWithBLOBs(AdminMessageExample example);

    List<AdminMessage> selectByExampleWithPage(@Param("example") AdminMessageExample example, @Param("from") Integer from,
                                          @Param("to") Integer to);

    List<AdminMessage> selectByExample(AdminMessageExample example);

    AdminMessage selectByPrimaryKey(Integer msgID);

    int updateByExampleSelective(@Param("record") AdminMessage record, @Param("example") AdminMessageExample example);

    int updateByExampleWithBLOBs(@Param("record") AdminMessage record, @Param("example") AdminMessageExample example);

    int updateByExample(@Param("record") AdminMessage record, @Param("example") AdminMessageExample example);

    int updateByPrimaryKeySelective(AdminMessage record);

    int updateByPrimaryKeyWithBLOBs(AdminMessage record);

    int updateByPrimaryKey(AdminMessage record);

    List<AdminMessage>  selectMsgId(AdminMessage record);
    int updateStatus(AdminMessage record);
    List<AdminMessage> selectByPage(@Param("listCompId") List<Integer> listCompId, @Param("starus") Integer starus,
                               @Param("accountID") Integer accountID,
                               @Param("from") Integer from, @Param("to") Integer to, @Param("domain") String domain,
                               @Param("msgTypeList") List<Integer> msgTypeList);
    
    List<AdminMessage> selectOfSystem(@Param("from") Integer from, @Param("to") Integer to, @Param("reciveIDs") List<Integer> accountID, @Param("status") List<Integer> status);

    int countByPage(@Param("listCompId") List<Integer> listCompId, @Param("starus") Integer starus,
                    @Param("accountID") Integer accountID,
                    @Param("domain") String domain, @Param("msgTypeList") List<Integer> msgTypeList);

	List<Map<String, Object>> messageList(Map<String, Object> params);

	int getMessageCount(Map<String, Object> params);

    AdminMessage searchMessageByMsgID(AdminMessageVo messageVo);

	int editMessageByMsgID(AdminMessageVo messageVo);

	int updateMessageByMsgID(AdminMessageVo messageVo);

	int editMessageInfoByMsgID(AdminMessageVo messageVo);

	int delMessage(Map map);

	List<Map<String, Object>> messageInfoList(Map<String, Object> params);

	int getMessageInfoCount(Map<String, Object> params);

	void messageUpdateRead(AdminMessageVo messageVo);
	
	int countOfSystem(@Param("reciveIDs") List<Integer> accountID, @Param("status") List<Integer> status);

	int updateMessage(AdminMessage message);

	int deleteMessage(@Param("msgIds") String[] msgIds, @Param("status") int status, @Param("delFlag") int delFlag);

	List<Integer> queryStaffByCompanyId(@Param("data") Map<String, Object> map);
	
	void insertMessageSystem(@Param("msgId") Integer msgId, @Param("accountID") Integer accountID, @Param("status") int status);

	List<Integer> queryMessageSystem(@Param("accountID") Integer accountID, @Param("status") int status);

    int insertbatch(List<AdminMessage> list);

	Map<String, Object> queryMessageDocument(@Param("msgId") int msgId);

    List<AdminMessage> getMessageList(@Param("accountID") Integer accountID, @Param("receiveID") Integer receiveID, @Param("from") Integer from, @Param("to") Integer to, @Param("title") String title);
    int countMessageListSize(@Param("accountID") Integer accountID, @Param("receiveID") Integer receiveID, @Param("title") String title);

    //RP消息管理
    List<Map<String , Object >> queryRpMessageList(Map<String, Object> params);
    int countRpMessageList(Map<String, Object> params);
    int updateRpMessageStatus(Map<String, Object> params);

    AdminMessage queryMsgByProjectID(Integer proID);

    List<AdminMessage> queryMsgByCompID(Object compID);

    void updateReturnSignMessages(AdminMessage vo);
}