package com.edip.Servant;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.edip.entity.Cert;
import com.edip.entity.CertExample;
import com.edip.entity.CertVoConvert;
import com.edip.entity.CertWithBLOBs;
import com.edip.mapper.CertMapper;
import com.edip.util.CertConvert;
import com.edip.util.CertificateProperty;
import com.edip.vo.CertVo;
import com.edip.vo.RevokeCertReqVO;
import com.edip.vo.RevokeCertRespVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CertServant {
	
	@Autowired
	private CertMapper certMapper;
	
	/**
	 * 查询证书信息并转换成VO类
	 * @return
	 */
	public List<CertVo> queryWithPage(CertExample example, Integer from, Integer to){
		List<CertWithBLOBs> list = certMapper.selectByExampleWithBLOBsWithPage(example, from, to);
		return CertVoConvert.convert(list);
	}
	
	public CertVo selectByPrimaryKey(Integer certID){
		CertWithBLOBs cert = certMapper.selectByPrimaryKey(certID);
		return CertVoConvert.convert(cert);
	}
	
	public List<CertVo> selectCertByCompId(Integer compId){
		CertExample example = new CertExample();
		List<Integer> status = new ArrayList<Integer>();
		status.add(0);
		status.add(5);
		status.add(1);
		status.add(2);
		example.createCriteria().andCompidEqualTo(compId).andStatusIn(status);
		List<CertWithBLOBs> certs = certMapper.selectByExampleWithBLOBs(example);
		return CertVoConvert.convert(certs);
	}
	
	public CertVo queryCertByCompId(Integer compId,Integer userID){
		CertExample example = new CertExample();
		List<Integer> status = new ArrayList<Integer>();
		status.add(0);
		status.add(5);
		status.add(6);
		example.createCriteria().andCompidEqualTo(compId).andStatusIn(status)/*.andUseridEqualTo(userID)*/;
		List<CertWithBLOBs> certs = certMapper.selectByExampleWithBLOBs(example);
		return CertVoConvert.convert(certs.get(0));
	}
	/**
	 * 插入证书记录
	 */
	public Integer insert(CertWithBLOBs cert){
		
		return null;
	}
	/**
	 * 修改证书信息
	 */
	public Integer UpdateCert(CertWithBLOBs record){
		return certMapper.updateByPrimaryKeySelective(record);
	}
	
	/**
	 * 查询单个证书信息
	 */
	public CertWithBLOBs selectCert(CertVo certVo) {
		return certMapper.selectCert(certVo);
	}
	
	/**
	 * 修改证书信息
	 *//*
	public Integer updateCert(CertVo certVo){
		return certMapper.updateByPrimaryKeySelectiveByVo(certVo);
	}*/
	
	public List<Cert> selectByExample(CertExample example){
		return certMapper.selectByExample(example);
	}

	public Integer revokeCertificate(Integer certId) throws Exception {

		CertVo cert = selectByPrimaryKey(certId);
		Integer result =null;
		RevokeCertRespVO revokeCertRespVO = revokeCert(cert.getCertSN());
		if(revokeCertRespVO.getResult().equals("0")){
			cert.setStatus(CertVo.CERT_REVOKE);//设置为已吊销
			cert.setLupDate(new Date());
			cert.setUserID(-10);
			result = UpdateCert(CertConvert.convert(cert));
			CertExample example = new CertExample();
			example.createCriteria().andCertsnEqualTo(cert.getCertSN()).andCertidNotEqualTo(certId);
			List<CertWithBLOBs> certs = certMapper.selectByExampleWithBLOBs(example);
			if(certs.size() > 0){
				CertWithBLOBs cert2 = certs.get(0);
				cert2.setStatus(CertVo.CERT_REVOKE);
				cert.setLupDate(new Date());
				cert2.setUserid(-10);
				result = UpdateCert(cert2);
			}
		}else{
			if(revokeCertRespVO.getErrormsg().indexOf("Cert already revoke") == -1){
				throw new Exception("吊销证书失败："+revokeCertRespVO.getErrormsg());
			}else{
				cert.setStatus(CertVo.CERT_REVOKE);
				cert.setLupDate(new Date());
				cert.setUserID(-10);
				result =  UpdateCert(CertConvert.convert(cert));
			}
		}
		return result;
	}


	private RevokeCertRespVO revokeCert(String certNO)
			throws Exception {

		RevokeCertReqVO revokeCertReqVO = new RevokeCertReqVO();
		revokeCertReqVO.setPlatformid(CertificateProperty.getProperty("PLATFORMID_SY"));
		revokeCertReqVO.setCertsn(certNO);
		revokeCertReqVO.setOperationtype("2");
		revokeCertReqVO.setRevokeReason("0");

		RevokeCertRespVO revokeCertRespVO = CAClient.revokeCert(revokeCertReqVO);

		return revokeCertRespVO;
	}
	
}
