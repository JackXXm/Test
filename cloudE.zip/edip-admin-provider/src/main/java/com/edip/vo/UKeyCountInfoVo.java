package com.edip.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.metadata.BaseRowModel;

import lombok.Data;

import java.util.Date;

@Data
public class UKeyCountInfoVo extends  BaseRowModel {

    @ExcelProperty(value ={"企业名称"},index = 0)
    private String companyName;

    @ExcelProperty(value ={"企业类型"},index = 1)
    private String companyType;

    @ExcelProperty(value ={"证书号"},index = 2)
    private String certSN;

    @ExcelProperty(value ={"证书序列号"},index = 3)
    private String ukeyCode;

    @ExcelProperty(value ={"省"},index = 4)
    private String province;

    @ExcelProperty(value ={"证书状态"},index = 5)
    private String statusInfo;

    public String getStatusInfo() {
        return statusInfo;
    }

    public void setStatusInfo(String statusInfo) {
        this.statusInfo = statusInfo;
    }

    private String status;

    @ExcelProperty(value ={"UKey申请时间"},index = 6)
    private String createTime;

    private Date createDate;

    @ExcelProperty(value ={"激活时间"},index = 7)
    private String activeTime;

    private Date activeDate;

    @ExcelProperty(value ={"有效期"},index = 8)
    private String invalidTime;

    private Date invalidDate;

    @ExcelProperty(value ={"申请类型"},index = 9)
    private String UKeyStatus;

    private String billFlag;

    private Integer certID;

    public Integer getCertID() {
        return certID;
    }

    public void setCertID(Integer certID) {
        this.certID = certID;
    }

    public String getBillFlag() {
        return billFlag;
    }

    public void setBillFlag(String billFlag) {
        this.billFlag = billFlag;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyType() {
        return companyType;
    }

    public void setCompanyType(String companyType) {
        this.companyType = companyType;
    }

    public String getCertSN() {
        return certSN;
    }

    public void setCertSN(String certSN) {
        this.certSN = certSN;
    }

    public String getUkeyCode() {
        return ukeyCode;
    }

    public void setUkeyCode(String ukeyCode) {
        this.ukeyCode = ukeyCode;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getActiveTime() {
        return activeTime;
    }

    public void setActiveTime(String activeTime) {
        this.activeTime = activeTime;
    }

    public Date getActiveDate() {
        return activeDate;
    }

    public void setActiveDate(Date activeDate) {
        this.activeDate = activeDate;
    }

    public String getInvalidTime() {
        return invalidTime;
    }

    public void setInvalidTime(String invalidTime) {
        this.invalidTime = invalidTime;
    }

    public Date getInvalidDate() {
        return invalidDate;
    }

    public void setInvalidDate(Date invalidDate) {
        this.invalidDate = invalidDate;
    }

    public String getUKeyStatus() {
        return UKeyStatus;
    }

    public void setUKeyStatus(String UKeyStatus) {
        this.UKeyStatus = UKeyStatus;
    }


}
