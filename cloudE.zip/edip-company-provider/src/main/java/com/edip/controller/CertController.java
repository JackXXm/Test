package com.edip.controller;

import com.alibaba.fastjson.JSONObject;
import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.entity.CertExample;
import com.edip.entity.CertWithBLOBs;
import com.edip.feign.AccountFeign;
import com.edip.feign.CompanyFeign;
import com.edip.mapper.CertMapperVo;
import com.edip.service.CertService;
import com.edip.vo.CertApplyRequestVo;
import com.edip.vo.CertVo;
import com.edip.vo.CompVo;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping("/cert")
public class CertController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CertController.class);
    @Autowired
    private HttpServletRequest request;
    @Autowired
    private CertService certService;
    @Autowired
    private CompanyFeign companyFeign;
    @Autowired
    private AccountFeign accountFeign;
    @Autowired
    private CertMapperVo certMapperVo;

    @RequestMapping(value="getCert.ajax")
    public ServerResponse getCert(){
        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            Integer accountID= (Integer) httpSession.getAttribute("accountID");

            return ServerResponse.createBySuccess( certService.getCert(companyId,accountID));
        }catch (Exception e){
            LOGGER.error("getStampList error",e);
            return  ServerResponse.createByError();
        }
    }

    /**
     * 证书申请
     * @return
     * @throws Exception
     */
    @RequestMapping(value="apply.ajax")
    public Map<String,Object> apply(CertApplyRequestVo reqvo, HttpServletRequest request) throws Exception{
        Map<String,Object> params = new HashMap<String,Object>();
        //try{
 		/*BASE64Decoder bd =new  BASE64Decoder();
		byte[] publicKey = bd.decodeBuffer(reqvo.getPublicKey());*/
        Integer accountID = (Integer)SessionContext.getContext().getSession(request).getAttribute("accountID");
        Integer compId = (Integer)SessionContext.getContext().getSession(request).getAttribute("compID");
        ServerResponse compRes = companyFeign.getCompanyByCompanyId(compId);
        CompVo compVo = JSONObject.parseObject(compRes.getData().toString(),CompVo.class);

        if (compVo.getStatus()!=null&&(compVo.getStatus()==1||compVo.getStatus()==9)){
            params.put("success", false);
            params.put("massage","企业信息审核中，无法申请证书！");
            return params;
        }

        //测试数据
//        compId = 3129;
//        accountID = 6331;
//        compName = "卡接收到好";
        Integer userid = 0;
        if(reqvo.getAccountID() != null) {
            userid = reqvo.getAccountID();
        } else {
            userid = accountID;
        }
        CertVo certVo=new CertVo();
        //certVo.setPublicKey(publicKey);
        certVo.setAccountID(accountID);
        certVo.setCompID(compId);
        certVo.setUkStatus(reqvo.getUkStatus());
        certVo.setCreateDate(new Date());
        certVo.setStatus(1);
        certVo.setBillFlag(1);
        certVo.setUserID(userid);
        certVo.setCompName(compVo.getName());
		/*//根据上传身份证判断是否多申请Ukey
		if(!StringUtil.isEmpty(reqvo.getIdCardFace()) && !StringUtil.isEmpty(reqvo.getIdCardBack())){
			certVo.setIDCardFace(reqvo.getIdCardFace());
			certVo.setIDCardBack(reqvo.getIdCardBack());
		}*/
        String title = null;
        try {
//            if(reqvo.getUkStatus().intValue() == 3){
//                Cert cert = certService.queryCertByCompId(compId,accountID);
//                certServant.revokeCertificate(cert.getCertID());
//                title = "你有一条来自"+compName+"的[Ukey丢失补发证书]申请消息";
//            }else if(reqvo.getUkStatus().intValue() == 2){
//                title = "你有一条来自"+compName+"的[公司名称更改补发证书]申请消息";
//            }else{
//                title = "你有一条来自"+compName+"的证书申请消息";
//            }
            Integer result = certService.applyCert(certVo);
            if(result !=1){
                params.put("success", false);
                params.put("massage","证书申请失败！");
            }
            else {
                params.put("success", true);
                if(reqvo.getUkStatus().intValue() == 2){
                    companyFeign.updateCompanyTabByCompanyId(compId);
                }
                //成功加入代办
//                Integer dataID = certVo.getCertID();
//                insertMessages(compId, accountID, dataID, title);
            }
        } catch (Exception e) {
            LOGGER.error(e.toString()+e.getMessage(),e);
            e.printStackTrace();
            params.put("success", false);
            return params;
        }
        return params;
    }

//    public void insertMessages(Integer compId,Integer accountID,Integer dataID,String title) throws Exception{
//        MessageVo messageVo = new MessageVo();
//        messageVo.setCreateDate(new Date());
//        messageVo.setStatus(MessageStatusUtil.MESSAGE_SUCCESS_FLAG);
//        messageVo.setCompID(compId);
//        messageVo.setAccountID(accountID);
//        messageVo.setContent("-");
//        messageVo.setDataID(dataID);
//        messageVo.setDataType(7);
//        messageVo.setSender("通知:");
//        messageVo.setTitle(title);
//        messageVo.setMsgType(MessageStatusUtil.MESSAGESTATUS_MSGTYPE_FROMMP22);//操作
//        messageVo.setReceiveCompID(comAuthService.getMpCompId(NationalAdministrator));
//        messageVo.setUrl("/modules/certificate/CerManage.shtml?certID=" + dataID);
//        messageVo.setLupDate(new Date());
//        messageBiz.insert(messageVo);
//    }

    /**
     * 激活证书
     * @return
     * @throws Exception
     */
    @RequestMapping("/active.ajax")
    @ResponseBody
    public ServerResponse active(String publicKey, String cert,HttpServletRequest request) throws IOException {
        Map<String,Object> params = new HashMap<String,Object>();
        if (StringUtils.isEmpty(cert) || StringUtils.isEmpty(publicKey)) {
            //message = "0";
            params.put("success", false); // cert 和publickey 为空 激活失败
            return ServerResponse.createByErrorMsg("参数异常！");
        }
        Integer accountID = (Integer)SessionContext.getContext().getSession(request).getAttribute("accountID");
        Integer compId = (Integer)SessionContext.getContext().getSession(request).getAttribute("compID");
//        AccountVo ukey =null;
//        //针对单Ukey
//        ServerResponse ukeyResult = accountFeign.getUkeyManager(compId);
//        Map<String,AccountVo> uKey =(Map)ukeyResult.getData();
//        if(uKey==null){
//            params.put("message", false);
//            params.put("data", "该公司没有ukey管理员");
//            return params;
//        }
//        if(uKey.get("ukeyManager")!= null){
//            ukey = uKey.get("ukeyManager");
//        }
//        if(uKey.get("ukeyAdmin")!= null){
//            ukey = uKey.get("ukeyAdmin");
//        }
			/*if( ukey.getAccountID().intValue()!=account.getAccountID().intValue()){//针对单Ukey
				params.put("result", 0);
				params.put("message", "您没有权限激活证书，请通知Ukey管理员激活。");
				return params;
			}*/

        BASE64Decoder bd =new  BASE64Decoder();
        byte[] certs = bd.decodeBuffer(cert.replace("\r\n", ""));
        byte[] pubkey = bd.decodeBuffer(publicKey);
        CertVo  certVo= new CertVo();
        certVo.setX509(certs);
        certVo.setPublicKey(pubkey);
        certVo.setCompID(compId);
        certVo.setAccountID(accountID);
        try {
            CertWithBLOBs activeCert = certService.activeCert(certVo);
//            BillmodeExample example = new BillmodeExample();
//            example.createCriteria().andStatusEqualTo(1);
//            List<Billmode> modes = billmodeMapper.selectByExample(example);
//            BillExample example2 = new BillExample();
//            example2.createCriteria().andCompIDEqualTo(LOGGER);
//            List<Bill> bills = billMapper.selectByExample(example2);
//            if(bills ==null||bills.size()<1){
//                Bill bill= new Bill();
//                bill.setCompID(compId);
//                bill.setModeID(modes.get(0).getModeID());
//                bill.setCreateDate(new Date());
//                bill.setCdrsubType(0);
//                bill.setCdrType(0);
//                billMapper.insertSelective(bill);
//            }else{
//                Bill bill = bills.get(0);
//                bill.setModeID(modes.get(0).getModeID());
//                billMapper.updateByPrimaryKey(bill);
//            }
        } catch (Exception e) {
            LOGGER.error(e.toString(),e);
            e.printStackTrace();
            params.put("success", false);
            return ServerResponse.createByErrorMsg("激活证书失败");
        }
        params.put("success", true);
        return ServerResponse.createBySuccessMsg("激活证书成功");
    }


    /**
     * 证书更新
     * @return
     * @throws Exception
     */
    @RequestMapping("/update.ajax")
    @ResponseBody
    public ServerResponse update(String publicKey, String certsn,HttpServletRequest request) throws IOException{
        //String certsn = getRequest().getParameter("certsn");
        //String publicKey = getRequest().getParameter("publicKey");
//        Map<String,Object> params = new HashMap<String,Object>();
        if (StringUtils.isEmpty(certsn)) {
//            params.put("message", false);
//            params.put("data", "证书序列号为空");
            return ServerResponse.createByErrorMsg("证书序列号为空");
        }
        Integer accountID = (Integer)SessionContext.getContext().getSession(request).getAttribute("accountID");
        Integer compId = (Integer)SessionContext.getContext().getSession(request).getAttribute("compID");
        //针对单Ukey
//        Integer ukey =null;
//        ServerResponse ukeyResult = accountFeign.getUkeyManager(compId);
//        Integer ukey =null;=(Map)ukeyResult.getData();
//        if(uKey==null){
//            params.put("message", false);
//            params.put("data", "该公司没有ukey管理员");
//            return params;
//        }
		/*if(!authentication(account.getAccountID(),certsn)) {
			params.put("message", false);
			params.put("data", "您没有权限更新证书，请通知该ukey使用人更新。");
			return params;
		}*/
        certsn = certsn.toLowerCase();
        BASE64Decoder bd =new  BASE64Decoder();
        //byte[] pubkey = bd.decodeBuffer(publicKey);
        CertVo certVo = new CertVo();
        certVo.setCertSN(certsn);//证书序列号
        //certVo.setPublicKey(pubkey);
        certVo.setAccountID(accountID);
        certVo.setUserID(accountID);
        try {
            certService.updateKeyCertificate(certVo);
        } catch (Exception e) {
            e.printStackTrace();
//            params.put("message", false);
            return ServerResponse.createByErrorMsg("证书更新失败");
        }
//        params.put("message", true);
        return ServerResponse.createBySuccessMsg("证书更新成功");
    }

    /**
     * 判断证书是否有效
     * @return params
     * @throws Exception
     */
    @RequestMapping("/isselfcert.ajax")
    @ResponseBody
    public ServerResponse isselfcert(String cert/*,String nouser,String nostatus,String active*/,HttpServletRequest request) throws Exception{
        Map<String,Object> params = new HashMap<String,Object>();
        cert = cert.toLowerCase();
        Integer compId = (Integer)SessionContext.getContext().getSession(request).getAttribute("compID");
        CertExample example= new CertExample();
        CertExample.Criteria criteria = example.createCriteria();
        criteria.andCompidEqualTo(compId);
        List<Integer> statuss = new ArrayList<Integer>();
        statuss.add(0);
        statuss.add(3);
        statuss.add(5);
        criteria.andStatusIn(statuss);//正常状态下的证书
        criteria.andCertsnEqualTo(cert);
        List<CertVo>  certList = certService.queryCertificateOne(example); //查询证书详情
        // 如果说证书已过期则置为已过期
        if(certList.size()>0){
            CertVo certVo = certList.get(0);
            //判断是否对应的Ukey账户使用
			 /*if(certVo.getUserID() != null) {
			 	if(!certVo.getUserID().equals(accountVo.getAccountID())) {
					params.put("success", false);//
					params.put("messge", "该账户不具备此Ukey使用权限!");
					return params;
				}
			 }*/
            if(certVo==null||certVo.getCompID().intValue() != compId){
//                params.put("success", 3);//
//                params.put("messge", "该证书非本公司证书，无法使用");
                return ServerResponse.createByError(3,"该证书非本公司证书，无法使用");
            }
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy:MM:dd");
            if (certVo != null) {
                if (certVo.getInvalidDate().getTime() > sdf.parse(sdf.format(new Date())).getTime()) {
                    if(getDaysBetween(certVo.getInvalidDate())<30 && getDaysBetween(certVo.getInvalidDate()) > 0){
						certVo.setStatus(CertVo.CERT_EXPIRING);
						certVo.setLupDate(new Date());
						certService.updateCertVo(certVo);//修改数据库操作  更新证书记录
                    }
                    //String activeDate = new SimpleDateFormat("yyyyMMdd");
                    if (certVo.getActiveDate()!=null) {// 不等于空说明已经激活
//                        params.put("success", true);//返回true 说明证书已激活
//                        params.put("messge","该ukey证书已经被激活，不能再次激活");
                        return ServerResponse.createBySuccess("该ukey证书已经被激活，不能再次激活");
                    } else {
//                        params.put("success", false);//
//                        params.put("messge", "证书未激活");
                        return ServerResponse.createByError(5,"证书未激活");
                    }
                }else{
                    certVo.setStatus(CertVo.CERT_EXPIRED);
                    certVo.setLupDate(new Date());
                    certService.updateCertVo(certVo);//修改数据库操作  更新证书记录
//                    params.put("success", 1);//说明已过期 无效证书
//                    params.put("messge", "证书已过期，请更新。");
                    return ServerResponse.createByError(1,"证书已过期，请更新。");
                }
            }
        }else{
//            params.put("success", 2);
//            params.put("messge", "没有找到匹配的证书记录！");
            return ServerResponse.createByError(2,"没有找到匹配的证书记录！");
        }

        return ServerResponse.createBySuccess();
    }

    /**
     * 获取两日期相差的天数
     * @return
     * @throws ParseException
     */
    public static long getDaysBetween(Date Date) {
        long between_days = 0;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd");
        try {
            Date d1 = sdf.parse(sdf.format(Date));
            Date d2 = sdf.parse(sdf.format(new Date()));
            long time1 = d1.getTime();
            long time2 = d2.getTime();
            between_days = (time1-time2)/(1000*3600*24);
        } catch (ParseException e) {

        }
        return between_days;

    }

    /**
     * 	证书下载
     * @param certId
     * @param publicKey
     * @return
     */
    @RequestMapping("/download.ajax")
    @ResponseBody
    public ServerResponse download(String publicKey,Integer ukStatus,HttpServletRequest request ,Integer certId){
        LOGGER.debug("-----------------------开始下载证书------------------");
        Integer accountID = (Integer)SessionContext.getContext().getSession(request).getAttribute("accountID");
        Map<String,Object> result = new HashMap<String,Object>();
        CertWithBLOBs cert = certMapperVo.selectByPrimaryKey(certId);
        if (cert == null) {
            LOGGER.error("CertController.download(): 下载证书失败----- 证书不存在--------");
            return ServerResponse.createByErrorMsg("下载证书失败");
        }
        try {
            //CertWithBLOBs cert = certs.get(0);
            cert.setAccountID(accountID);
            if(ukStatus != 1 && publicKey !=null){
                BASE64Decoder decoder = new BASE64Decoder();
                byte[] publickey = decoder.decodeBuffer(publicKey);
                cert.setPublickey(publickey);
            }
            CertWithBLOBs downloadCert = certService.downloadCert(cert);
            result.put("success", true);
            BASE64Encoder baseE= new BASE64Encoder();
            String certificate = baseE.encode(downloadCert.getX509());
            result.put("cert",certificate );

        } catch (Exception e) {
            LOGGER.error(e.toString(),e);
            e.printStackTrace();
            return ServerResponse.createByErrorMsg("下载证书失败");
        }
        return ServerResponse.createBySuccess(result);
    }

    /**
     * 根据Ukey序列号查询使用人
     * @author Stephen
     * @since 2018-03-26
     */
    @RequestMapping("/getAccountByCertSN.ajax")
    @ResponseBody
    public Map<String,Object> getAccountByCertSN(String cert ,HttpServletRequest request) {
        List<CertVo> certList = new ArrayList<CertVo>();
        Map<String,Object> map = new HashMap<String,Object>();
        cert = cert.toLowerCase();
        CertExample  example= new CertExample();
        CertExample.Criteria criteria = example.createCriteria();
        criteria.andCertsnEqualTo(cert);
        try {
            certList = certService.queryCertificateOne(example); //查询证书详情
            if(certList.size()==0) {
                map.put("success",false);
                map.put("message","该证书不存在");
                return map;
            }
            Integer UserID = certList.get(0).getUserID();
            map = (Map<String, Object>) accountFeign.getAccountInfo(UserID).getData();
            if(map == null) {
                map.put("success",false);
                map.put("message","查询出错！");
                return map;
            }
            map.put("certSN",cert);
        } catch(Exception e) {
            LOGGER.error(e.getMessage(),e);
        }
        return map;
    }


    @RequestMapping("/updateCertByCompanyId.ajax")
    public ServerResponse updateCertByCompanyId(@RequestBody Map<String,Object> param){
        if(param.get("companyId")==null||param.get("companyId").equals(""))
            return ServerResponse.createByErrorMsg("参数异常");
        try {
            certService.updateCertByCompanyId(param);
        }catch (Exception e){
            LOGGER.error("修改失败！"+e.getMessage(),e);
            return ServerResponse.createByErrorMsg("修改失败！");
        }
        return ServerResponse.createBySuccess("修改成功");
    }

    @RequestMapping(value = "getCertValidity.ajax")
    public ServerResponse getCertValidity(HttpServletRequest request){
        Integer companyId = (Integer)SessionContext.getContext().getSession(request).getAttribute("compID");
        companyId = 2735;
        long validity;
        try{
            validity = certService.getCertValidity(companyId);
        }catch (Exception e){
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg(e.getMessage());
        }

        return ServerResponse.createBySuccess(validity);
    }

    /**
     * 判断该账号是否系统管理员
     * @param request
     * @return
     */
    //该接口建议移到用户中心
    /*@RequestMapping("/readyApply.ajax")
    @ResponseBody
    public Map<String,Object> readyApply(HttpServletRequest request) {
        Map<String,Object> map = new HashMap<String,Object>();
        AccountVo account = (AccountVo)SessionContext.getContext().getSession(request).getAttribute("ACCOUNTVO");
        CompanyVo company =(CompanyVo)SessionContext.getContext().getSession(request).getAttribute("COMPANYVO");
        if(company.getAccountID().equals(account.getAccountID())){
            map.put("success",true);
            map.put("data",true);
        } else {
            map.put("success",true);
            map.put("data",false);
        }
        return map;
    }*/

}
