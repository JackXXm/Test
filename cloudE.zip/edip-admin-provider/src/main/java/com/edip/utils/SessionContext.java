package com.edip.utils;

import java.security.interfaces.RSAPrivateKey;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

public class SessionContext {

	public static String LOGIN_STAFF = "LOGIN_STAFF";
	private static final Logger logger = LoggerFactory.getLogger(SessionContext.class);	
	private static SessionContext context;
    private static Map<String, HttpSession> sessionMaps = new ConcurrentHashMap();



	public static synchronized SessionContext getContext() {
		if (context == null) {
			context = new SessionContext();
		}

		return context;
	}

	public void addSession(HttpSession session) {
		   String sessionId=(String) session.getAttribute("saveRedisSessionId");
		  
		if (sessionId!=null) {
			
			JSONObject object=new JSONObject();
			Enumeration<?> enumeration =session.getAttributeNames();
			while(enumeration.hasMoreElements()){
				   String attrName=enumeration.nextElement().toString();
				   Object value=session.getAttribute(attrName);
				   String className=value.getClass().getName();
				   boolean loginInfoClass=className.contains("com.aspire.webbas.portal.common.entity")
						   ||className.contains("cn.everfusion.edata.base.vo")
						   ||className.contains("java.lang");
				   if(loginInfoClass){//只向redis塞必要的数据
					   object.put(attrName+"|"+value.getClass().getName(), value); 
				   }
				   
			}
		 
			RedisUtil.setJson(sessionId, object);
			String logInfo=String.format("SessionContext add session for memcached,sessionId=%s", sessionId);
			logger.debug(logInfo);
			
		}

	
	}

	public void deleteSession(String sessionId) {
		RedisUtil.del(sessionId);
	
	}

    public HttpSession getSession(String sessionId) {
        System.out.println("SessionContext getSession, sessionId=" + sessionId);
        HttpSession session = (HttpSession)sessionMaps.get(sessionId);
        if (session == null) {
            //session = this.memcachedSessionManager.loadSession(sessionId);
            if (session != null) {
                System.out.println("HttpSession load successfully from memcached, session id=" + sessionId);
            }
        } else {
            System.out.println("HttpSession load successfully from container, session id=" + sessionId);
        }

        return (HttpSession)session;
    }


	public HttpSession getSession(HttpServletRequest request) {

		String sessionId=CookieUtil.getCookie(request, "AUTH_TICKET");


    	if(StringUtil.isEmpty(sessionId)){
			sessionId=request.getHeader("weixinauth");//小程序ticket放在header
			String logInfo=String.format("SessionContext get session use header sessionId==%s", sessionId);
			logger.debug(logInfo);
			if(sessionId!=null){
			
				return getSession(sessionId,request);
			}
		}else{
			return getSession(sessionId,request);
		}
		return request.getSession();


	}
	public HttpSession getSession(String sessionId,HttpServletRequest request) {
		
		
		    HttpSession session=request.getSession();
		    boolean getRedisFlag=false;
		    if(session.isNew()){
		    	getRedisFlag=true;
		    }
		    boolean loginFlag=session.getAttribute("LOGIN_STAFF")==null||session.getAttribute("COMPANYVO")==null
		    		||session.getAttribute("ACCOUNTVO")==null;
		    if(!session.isNew()&&loginFlag){
		    	getRedisFlag=true;
		    }
			    if(getRedisFlag){
						JSONObject object=RedisUtil.getJson(sessionId,JSONObject.class);
						if(object!=null){
			                long loginTime=0;
			             	String[]loginInfo=null;
			             	String ip="";
							try {
								
								String privateKey=object.getString("privateKey|java.lang.String");
				             	 ip=StringUtil.getIp2(request);
								RSAPrivateKey rsaPrivateKey=SessionRsaUtil.getPrivateKey(privateKey);
								sessionId=SessionRsaUtil.privateDecrypt(sessionId, rsaPrivateKey);
								loginInfo=sessionId.split("_");
								if(loginInfo.length<2){
									logger.debug("login fail sessionId is wrong");
									return session;
								}
							} catch (Exception e) {
								logger.debug("login exception ",e);
								
							}   
							String loginIp="";
							if(loginInfo!=null){
								 loginTime=Long.parseLong(loginInfo[2]);
								 loginIp= loginInfo[0];
							}
							
								boolean loginExpire=(System.currentTimeMillis()-loginTime)<1000*60*60*12;
								if(ip.equals(loginIp)&&loginExpire){//服务器判断是否是自身登录
									
									Iterator<String>keys=object.keySet().iterator();
									
									
									while(keys.hasNext()){
										String name=keys.next();
										String keyName=name.split("\\|")[0];
										String className=name.split("\\|")[1];
										Object value= object.get(name);
										if(value instanceof JSONObject){
											try {
												value=JSONObject.parseObject(value.toString(),Class.forName(className));
											} catch (ClassNotFoundException e) {
												logger.debug("this class not find",e);
												
											}
										}
									
									session.setAttribute(keyName, value);
									}
									 
									
								
								    String logInfo=String.format("HttpSession load successfully from memcached, session id=%s", sessionId);
									logger.debug(logInfo);
								
								}else{
									String logInfo=String.format("login fail ;ip=%s expire time=%d", ip,loginTime);
									logger.debug(logInfo);
								}
						
							
							
							
						}
			    }

		return session;
	}


}
