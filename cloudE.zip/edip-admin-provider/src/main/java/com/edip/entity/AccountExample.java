package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class AccountExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public AccountExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAccountIDIsNull() {
            addCriterion("accountID is null");
            return (Criteria) this;
        }

        public Criteria andAccountIDIsNotNull() {
            addCriterion("accountID is not null");
            return (Criteria) this;
        }

        public Criteria andAccountIDEqualTo(Integer value) {
            addCriterion("accountID =", value, "accountID");
            return (Criteria) this;
        }

        public Criteria andDelFlagEqualTo(Integer value) {
            addCriterion("delFlag =", value, "delFlag");
            return (Criteria) this;
        }

        public Criteria andAccountIDNotEqualTo(Integer value) {
            addCriterion("accountID <>", value, "accountID");
            return (Criteria) this;
        }

        public Criteria andAccountIDGreaterThan(Integer value) {
            addCriterion("accountID >", value, "accountID");
            return (Criteria) this;
        }

        public Criteria andAccountIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("accountID >=", value, "accountID");
            return (Criteria) this;
        }

        public Criteria andAccountIDLessThan(Integer value) {
            addCriterion("accountID <", value, "accountID");
            return (Criteria) this;
        }

        public Criteria andAccountIDLessThanOrEqualTo(Integer value) {
            addCriterion("accountID <=", value, "accountID");
            return (Criteria) this;
        }

        public Criteria andAccountIDIn(List<Integer> values) {
            addCriterion("accountID in", values, "accountID");
            return (Criteria) this;
        }

        public Criteria andAccountIDNotIn(List<Integer> values) {
            addCriterion("accountID not in", values, "accountID");
            return (Criteria) this;
        }

        public Criteria andAccountIDBetween(Integer value1, Integer value2) {
            addCriterion("accountID between", value1, value2, "accountID");
            return (Criteria) this;
        }

        public Criteria andAccountIDNotBetween(Integer value1, Integer value2) {
            addCriterion("accountID not between", value1, value2, "accountID");
            return (Criteria) this;
        }

        public Criteria andStaffIDIsNull() {
            addCriterion("staffID is null");
            return (Criteria) this;
        }

        public Criteria andStaffIDIsNotNull() {
            addCriterion("staffID is not null");
            return (Criteria) this;
        }

        public Criteria andStaffIDEqualTo(Integer value) {
            addCriterion("staffID =", value, "staffID");
            return (Criteria) this;
        }

        public Criteria andStaffIDNotEqualTo(Integer value) {
            addCriterion("staffID <>", value, "staffID");
            return (Criteria) this;
        }

        public Criteria andStaffIDGreaterThan(Integer value) {
            addCriterion("staffID >", value, "staffID");
            return (Criteria) this;
        }

        public Criteria andStaffIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("staffID >=", value, "staffID");
            return (Criteria) this;
        }

        public Criteria andStaffIDLessThan(Integer value) {
            addCriterion("staffID <", value, "staffID");
            return (Criteria) this;
        }

        public Criteria andStaffIDLessThanOrEqualTo(Integer value) {
            addCriterion("staffID <=", value, "staffID");
            return (Criteria) this;
        }

        public Criteria andStaffIDIn(List<Integer> values) {
            addCriterion("staffID in", values, "staffID");
            return (Criteria) this;
        }

        public Criteria andStaffIDNotIn(List<Integer> values) {
            addCriterion("staffID not in", values, "staffID");
            return (Criteria) this;
        }

        public Criteria andStaffIDBetween(Integer value1, Integer value2) {
            addCriterion("staffID between", value1, value2, "staffID");
            return (Criteria) this;
        }

        public Criteria andStaffIDNotBetween(Integer value1, Integer value2) {
            addCriterion("staffID not between", value1, value2, "staffID");
            return (Criteria) this;
        }

        public Criteria andCompIDIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompIDIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompIDEqualTo(Integer value) {
            addCriterion("compID =", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDGreaterThan(Integer value) {
            addCriterion("compID >", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDLessThan(Integer value) {
            addCriterion("compID <", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDIn(List<Integer> values) {
            addCriterion("compID in", values, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compID");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andIdCardNoIsNull() {
            addCriterion("idCardNo is null");
            return (Criteria) this;
        }

        public Criteria andIdCardNoIsNotNull() {
            addCriterion("idCardNo is not null");
            return (Criteria) this;
        }

        public Criteria andIdCardNoEqualTo(String value) {
            addCriterion("idCardNo =", value, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoNotEqualTo(String value) {
            addCriterion("idCardNo <>", value, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoGreaterThan(String value) {
            addCriterion("idCardNo >", value, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoGreaterThanOrEqualTo(String value) {
            addCriterion("idCardNo >=", value, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoLessThan(String value) {
            addCriterion("idCardNo <", value, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoLessThanOrEqualTo(String value) {
            addCriterion("idCardNo <=", value, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoLike(String value) {
            addCriterion("idCardNo like", value, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoNotLike(String value) {
            addCriterion("idCardNo not like", value, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoIn(List<String> values) {
            addCriterion("idCardNo in", values, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoNotIn(List<String> values) {
            addCriterion("idCardNo not in", values, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoBetween(String value1, String value2) {
            addCriterion("idCardNo between", value1, value2, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoNotBetween(String value1, String value2) {
            addCriterion("idCardNo not between", value1, value2, "idCardNo");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLIsNull() {
            addCriterion("idCardNoURL is null");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLIsNotNull() {
            addCriterion("idCardNoURL is not null");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLEqualTo(String value) {
            addCriterion("idCardNoURL =", value, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLNotEqualTo(String value) {
            addCriterion("idCardNoURL <>", value, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLGreaterThan(String value) {
            addCriterion("idCardNoURL >", value, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLGreaterThanOrEqualTo(String value) {
            addCriterion("idCardNoURL >=", value, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLLessThan(String value) {
            addCriterion("idCardNoURL <", value, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLLessThanOrEqualTo(String value) {
            addCriterion("idCardNoURL <=", value, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLLike(String value) {
            addCriterion("idCardNoURL like", value, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLNotLike(String value) {
            addCriterion("idCardNoURL not like", value, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLIn(List<String> values) {
            addCriterion("idCardNoURL in", values, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLNotIn(List<String> values) {
            addCriterion("idCardNoURL not in", values, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLBetween(String value1, String value2) {
            addCriterion("idCardNoURL between", value1, value2, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNoURLNotBetween(String value1, String value2) {
            addCriterion("idCardNoURL not between", value1, value2, "idCardNoURL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLIsNull() {
            addCriterion("idCardNo2URL is null");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLIsNotNull() {
            addCriterion("idCardNo2URL is not null");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLEqualTo(String value) {
            addCriterion("idCardNo2URL =", value, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLNotEqualTo(String value) {
            addCriterion("idCardNo2URL <>", value, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLGreaterThan(String value) {
            addCriterion("idCardNo2URL >", value, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLGreaterThanOrEqualTo(String value) {
            addCriterion("idCardNo2URL >=", value, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLLessThan(String value) {
            addCriterion("idCardNo2URL <", value, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLLessThanOrEqualTo(String value) {
            addCriterion("idCardNo2URL <=", value, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLLike(String value) {
            addCriterion("idCardNo2URL like", value, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLNotLike(String value) {
            addCriterion("idCardNo2URL not like", value, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLIn(List<String> values) {
            addCriterion("idCardNo2URL in", values, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLNotIn(List<String> values) {
            addCriterion("idCardNo2URL not in", values, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLBetween(String value1, String value2) {
            addCriterion("idCardNo2URL between", value1, value2, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andIdCardNo2URLNotBetween(String value1, String value2) {
            addCriterion("idCardNo2URL not between", value1, value2, "idCardNo2URL");
            return (Criteria) this;
        }

        public Criteria andAliasNameIsNull() {
            addCriterion("aliasName is null");
            return (Criteria) this;
        }

        public Criteria andAliasNameIsNotNull() {
            addCriterion("aliasName is not null");
            return (Criteria) this;
        }

        public Criteria andAliasNameEqualTo(String value) {
            addCriterion("aliasName =", value, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameNotEqualTo(String value) {
            addCriterion("aliasName <>", value, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameGreaterThan(String value) {
            addCriterion("aliasName >", value, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameGreaterThanOrEqualTo(String value) {
            addCriterion("aliasName >=", value, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameLessThan(String value) {
            addCriterion("aliasName <", value, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameLessThanOrEqualTo(String value) {
            addCriterion("aliasName <=", value, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameLike(String value) {
            addCriterion("aliasName like", value, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameNotLike(String value) {
            addCriterion("aliasName not like", value, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameIn(List<String> values) {
            addCriterion("aliasName in", values, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameNotIn(List<String> values) {
            addCriterion("aliasName not in", values, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameBetween(String value1, String value2) {
            addCriterion("aliasName between", value1, value2, "aliasName");
            return (Criteria) this;
        }

        public Criteria andAliasNameNotBetween(String value1, String value2) {
            addCriterion("aliasName not between", value1, value2, "aliasName");
            return (Criteria) this;
        }

        public Criteria andMsisdnIsNull() {
            addCriterion("msisdn is null");
            return (Criteria) this;
        }

        public Criteria andMsisdnIsNotNull() {
            addCriterion("msisdn is not null");
            return (Criteria) this;
        }

        public Criteria andMsisdnEqualTo(String value) {
            addCriterion("msisdn =", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnNotEqualTo(String value) {
            addCriterion("msisdn <>", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnGreaterThan(String value) {
            addCriterion("msisdn >", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnGreaterThanOrEqualTo(String value) {
            addCriterion("msisdn >=", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnLessThan(String value) {
            addCriterion("msisdn <", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnLessThanOrEqualTo(String value) {
            addCriterion("msisdn <=", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnLike(String value) {
            addCriterion("msisdn like", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnNotLike(String value) {
            addCriterion("msisdn not like", value, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnIn(List<String> values) {
            addCriterion("msisdn in", values, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnNotIn(List<String> values) {
            addCriterion("msisdn not in", values, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnBetween(String value1, String value2) {
            addCriterion("msisdn between", value1, value2, "msisdn");
            return (Criteria) this;
        }

        public Criteria andMsisdnNotBetween(String value1, String value2) {
            addCriterion("msisdn not between", value1, value2, "msisdn");
            return (Criteria) this;
        }

        public Criteria andEmailIsNull() {
            addCriterion("email is null");
            return (Criteria) this;
        }

        public Criteria andEmailIsNotNull() {
            addCriterion("email is not null");
            return (Criteria) this;
        }

        public Criteria andEmailEqualTo(String value) {
            addCriterion("email =", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotEqualTo(String value) {
            addCriterion("email <>", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThan(String value) {
            addCriterion("email >", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailGreaterThanOrEqualTo(String value) {
            addCriterion("email >=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThan(String value) {
            addCriterion("email <", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLessThanOrEqualTo(String value) {
            addCriterion("email <=", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailLike(String value) {
            addCriterion("email like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotLike(String value) {
            addCriterion("email not like", value, "email");
            return (Criteria) this;
        }

        public Criteria andEmailIn(List<String> values) {
            addCriterion("email in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotIn(List<String> values) {
            addCriterion("email not in", values, "email");
            return (Criteria) this;
        }

        public Criteria andEmailBetween(String value1, String value2) {
            addCriterion("email between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andEmailNotBetween(String value1, String value2) {
            addCriterion("email not between", value1, value2, "email");
            return (Criteria) this;
        }

        public Criteria andAuditInfoIsNull() {
            addCriterion("auditInfo is null");
            return (Criteria) this;
        }

        public Criteria andAuditInfoIsNotNull() {
            addCriterion("auditInfo is not null");
            return (Criteria) this;
        }

        public Criteria andAuditInfoEqualTo(String value) {
            addCriterion("auditInfo =", value, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoNotEqualTo(String value) {
            addCriterion("auditInfo <>", value, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoGreaterThan(String value) {
            addCriterion("auditInfo >", value, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoGreaterThanOrEqualTo(String value) {
            addCriterion("auditInfo >=", value, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoLessThan(String value) {
            addCriterion("auditInfo <", value, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoLessThanOrEqualTo(String value) {
            addCriterion("auditInfo <=", value, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoLike(String value) {
            addCriterion("auditInfo like", value, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoNotLike(String value) {
            addCriterion("auditInfo not like", value, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoIn(List<String> values) {
            addCriterion("auditInfo in", values, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoNotIn(List<String> values) {
            addCriterion("auditInfo not in", values, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoBetween(String value1, String value2) {
            addCriterion("auditInfo between", value1, value2, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andAuditInfoNotBetween(String value1, String value2) {
            addCriterion("auditInfo not between", value1, value2, "auditInfo");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDateEqualTo(Date value) {
            addCriterion("createDate =", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThan(Date value) {
            addCriterion("createDate <", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateIn(List<Date> values) {
            addCriterion("createDate in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}