package com.edip.mapper;

import com.edip.entity.InspectExchangeJob;
import com.edip.entity.InspectExchangeJobExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InspectExchangeJobMapper {
    long countByExample(InspectExchangeJobExample example);

    int deleteByExample(InspectExchangeJobExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(InspectExchangeJob record);

    int insertSelective(InspectExchangeJob record);

    List<InspectExchangeJob> selectByExample(InspectExchangeJobExample example);

    InspectExchangeJob selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") InspectExchangeJob record, @Param("example") InspectExchangeJobExample example);

    int updateByExample(@Param("record") InspectExchangeJob record, @Param("example") InspectExchangeJobExample example);

    int updateByPrimaryKeySelective(InspectExchangeJob record);

    int updateByPrimaryKey(InspectExchangeJob record);
}