package com.edip.entity;

import java.util.Date;

public class AdminBill {
	private Integer billID;

	private Integer cdrType;

	private float cdrsubType;

	private Integer totalCount;

	private Integer usedCount;

	private Integer remainCount;

	private Integer remainder;

	private Double totalAmount;

	private Double remainAmount;

	private Integer compID;

	private Date createDate;

	private Integer modeID;

	private Date freeDate;

	private Integer accountID;
    //累计赠送总金额
	private Double giveAmount;
    //赠送余额
	private Double remainGiveAmount;

	public Date getFreeDate() {
		return freeDate;
	}

	public void setFreeDate(Date freeDate) {
		this.freeDate = freeDate;
	}

	public Integer getBillID() {
		return billID;
	}

	public void setBillID(Integer billID) {
		this.billID = billID;
	}

	public Integer getCdrType() {
		return cdrType;
	}

	public void setCdrType(Integer cdrType) {
		this.cdrType = cdrType;
	}

	public float getCdrsubType() {
		return cdrsubType;
	}

	public void setCdrsubType(float cdrsubType) {
		this.cdrsubType = cdrsubType;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public Integer getUsedCount() {
		return usedCount;
	}

	public void setUsedCount(Integer usedCount) {
		this.usedCount = usedCount;
	}

	public Integer getRemainCount() {
		return remainCount;
	}

	public void setRemainCount(Integer remainCount) {
		this.remainCount = remainCount;
	}

	public Integer getRemainder() {
		return remainder;
	}

	public void setRemainder(Integer remainder) {
		this.remainder = remainder;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Double getRemainAmount() {
		return remainAmount;
	}

	public void setRemainAmount(Double remainAmount) {
		this.remainAmount = remainAmount;
	}

	public Integer getCompID() {
		return compID;
	}

	public void setCompID(Integer compID) {
		this.compID = compID;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Integer getModeID() {
		return modeID;
	}

	public void setModeID(Integer modeID) {
		this.modeID = modeID;
	}

	public Integer getAccountID() {
		return accountID;
	}

	public void setAccountID(Integer accountID) {
		this.accountID = accountID;
	}

	public Double getGiveAmount() {
		return giveAmount;
	}

	public void setGiveAmount(Double giveAmount) {
		this.giveAmount = giveAmount;
	}

	public Double getRemainGiveAmount() {
		return remainGiveAmount;
	}

	public void setRemainGiveAmount(Double remainGiveAmount) {
		this.remainGiveAmount = remainGiveAmount;
	}
}