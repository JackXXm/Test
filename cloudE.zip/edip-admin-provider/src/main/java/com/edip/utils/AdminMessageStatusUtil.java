package com.edip.utils;

/**
 * Created by qiaoxiaolong on 2017/5/9.
 * 针对消息的各种魔术类
 */
public class AdminMessageStatusUtil {
    public static Integer MESSAGE_SUCCESS_FLAG           = 0;           //数据状态 正常

    public static Integer MESSAGE_EXPIRE_FLAG            = 7;           //数据状态 过期

    public static String  MESSAGE_CREATE_ORDER           = "createDate";//按照创建时间排序

    public static Integer MESSAGESTATUS_MESSAGE_FROM     = 0;           //0 来自message表

    public static Integer MESSAGESTATUS_MSGTYPE_FROMSP11 = 11;          //11 sp 查看 12 sp操作类
    public static Integer MESSAGESTATUS_MSGTYPE_FROMSP12 = 12;
    public static Integer MESSAGESTATUS_MSGTYPE_FROMMP21 = 21;          //21 mp查看 22mp操作
    public static Integer MESSAGESTATUS_MSGTYPE_FROMMP22 = 22;

    public static String  MESSAGESTATUS_MP               = "mp";        //mp端
    public static String  MESSAGESTATUS_SP               = "sp";        //sp端
}
