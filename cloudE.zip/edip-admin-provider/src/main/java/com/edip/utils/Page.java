package com.edip.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Page<T>  {
	private static final long serialVersionUID = -6436330541983205290L;
	  private int pageNo = 1;
	  private int pageSize = 9;
	  private int start = 0;
	  private int limit = 9;
	  private Integer page = Integer.valueOf(1);
	  private Integer rows = Integer.valueOf(9);
	  private int total;
	  private int totalPage;
	  private List<T> datas;
	  private Map<String, Object> params = new HashMap();
	  private String sortName;
	  private String order;
	  private String sort;
	  private String dir;
	  private String assembleOrderBy;
	  public static final String ASC = "asc";
	  public static final String DESC = "desc";
	  
	  public int getPageNo()
	  {
	    return this.page != null ? this.page.intValue() : getStart() / getLimit() + 1;
	  }
	  
	  public int getPageSize()
	  {
	    return this.rows != null ? this.rows.intValue() : getLimit();
	  }
	  
	  public int getTotal()
	  {
	    return this.total;
	  }
	  
	  public void setTotal(int totalRecord)
	  {
	    this.total = totalRecord;
	    
	    int totalPage = totalRecord % this.rows.intValue() == 0 ? totalRecord / this.rows.intValue() : 
	      totalRecord / this.rows.intValue() + 1;
	    setTotalPage(totalPage);
	  }
	  
	  public int getTotalPage()
	  {
	    return this.totalPage;
	  }
	  
	  public void setTotalPage(int totalPage)
	  {
	    this.totalPage = totalPage;
	  }
	  
	  public List<T> getDatas()
	  {
	    return this.datas;
	  }
	  
	  public void setDatas(List<T> datas)
	  {
	    this.datas = datas;
	  }
	  
	  public Map<String, Object> getParams()
	  {
	    return this.params;
	  }
	  
	  public void addParam(String key, String value)
	  {
	    this.params.put(key, value);
	  }
	  
	  public void setParams(Map<String, Object> params)
	  {
	    this.params = params;
	  }
	  
	  public String getSortName()
	  {
	    return this.sortName;
	  }
	  
	  public void setSortName(String sortName)
	  {
	    this.sortName = sortName;
	  }
	  
	  public String getOrder()
	  {
	    return this.order;
	  }
	  
	  public void setOrder(String order)
	  {
	    this.order = order;
	  }
	  
	  public int getStart()
	  {
	    return this.start;
	  }
	  
	  public void setStart(int start)
	  {
	    this.start = start;
	  }
	  
	  public int getLimit()
	  {
	    return this.limit;
	  }
	  
	  public void setLimit(int limit)
	  {
	    this.limit = limit;
	  }
	  
	  public Integer getPage()
	  {
	    return this.page;
	  }
	  
	  public void setPage(Integer page)
	  {
	    this.page = page;
	  }
	  
	  public Integer getRows()
	  {
	    return this.rows;
	  }
	  
	  public void setRows(Integer rows)
	  {
	    this.rows = rows;
	  }
	  
	  public String getSort()
	  {
	    return this.sort;
	  }
	  
	  public void setSort(String sort)
	  {
	    this.sort = sort;
	  }
	  
	  public String getDir()
	  {
	    return this.dir;
	  }
	  
	  public void setDir(String dir)
	  {
	    this.dir = dir;
	  }
	  
	  public String getAssembleOrderBy()
	  {
	    return this.assembleOrderBy;
	  }
	  
	  public void setAssembleOrderBy(String assembleOrderBy)
	  {
	    this.assembleOrderBy = assembleOrderBy;
	  }
	  
	  public String toString()
	  {
	    return 
	    



	      "Page [pageNo=" + this.pageNo + ", pageSize=" + this.pageSize + ", start=" + this.start + ", limit=" + this.limit + ", page=" + this.page + ", rows=" + this.rows + ", total=" + this.total + ", totalPage=" + this.totalPage + ", datas=" + this.datas + ", params=" + this.params + ", sortName=" + this.sortName + ", order=" + this.order + ", sort=" + this.sort + ", dir=" + this.dir + ", assembleOrderBy=" + this.assembleOrderBy + "]";
	  }

}
