package com.edip.tree;

import java.io.Serializable;
import java.util.*;

public class TreeNode implements Serializable {
    private static final long serialVersionUID = -3703021663416516423L;
    private String id;
    private String parentId;
    private String text;
    private boolean expanded = false;
    private boolean leaf = true;
    private Set<TreeNode> children = new LinkedHashSet();

    public TreeNode() {
    }

    public TreeNode(String id, String parentId, String text) {
        this.id = id;
        this.parentId = parentId;
        this.text = text;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getParentId() {
        return this.parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getText() {
        return this.text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public boolean isExpanded() {
        return this.expanded;
    }

    public void setExpanded(boolean expanded) {
        this.expanded = expanded;
    }

    public boolean isLeaf() {
        return this.leaf;
    }

    public void setLeaf(boolean leaf) {
        this.leaf = leaf;
    }

    public Set<TreeNode> getChildren() {
        return this.children;
    }

    public void setChildren(Set<TreeNode> children) {
        if (this.isLeaf()) {
            this.setLeaf(false);
        }

        this.children = children;
    }

    public void addChild(TreeNode node) {
        if (this.isLeaf()) {
            this.setLeaf(false);
        }

        this.children.add(node);
    }

    public void removeChild(TreeNode node) {
        this.children.remove(node);
        if (this.children.size() == 0) {
            this.setLeaf(true);
        }

    }

    public static TreeNode buildTree(List<TreeNode> list) {
        Map<String, TreeNode> map = new HashMap();
        TreeNode top = null;
        Iterator var4 = list.iterator();

        while(true) {
            TreeNode node;
            do {
                if (!var4.hasNext()) {
                    var4 = list.iterator();

                    while(var4.hasNext()) {
                        node = (TreeNode)var4.next();
                        if (node.getParentId() != null && !"".equals(node.getParentId())) {
                            TreeNode tmpNode = (TreeNode)map.get(node.getParentId());
                            tmpNode.addChild(node);
                        }
                    }

                    return top;
                }

                node = (TreeNode)var4.next();
                map.put(node.getId(), node);
            } while(node.getParentId() != null && !"".equals(node.getParentId()));

            top = node;
        }
    }
}
