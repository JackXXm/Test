package com.edip.service.impl;

import com.edip.dto.ServerResponse;
import com.edip.dto.util.RedisUtil;
import com.edip.entity.*;
import com.edip.mapper.InspectDocumentMapper;
import com.edip.mapper.InspectReportMapper;
import com.edip.mapper.InspectReportMapperVo;
import com.edip.service.InspectReportService;
import com.edip.utils.FileUtil;
import com.edip.utils.StringUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service("inspectReportService")
public class InspectReportServiceImpl implements InspectReportService {
    @Autowired
    private InspectReportMapper inspectReportMapper;
    @Autowired
    private InspectDocumentMapper inspectDocumentMapper;
    @Autowired
    private InspectReportMapperVo inspectReportMapperVo;
    @Autowired
    private RedisUtil redisUtil;

    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Override
    @Transactional
    public ServerResponse changeInspectReport(String data, HttpSession session) throws Exception {
        Integer compId = (Integer) session.getAttribute("compID");
        JSONObject jsonObject = JSONObject.fromObject(data);
        JSONArray jsonArray = jsonObject.getJSONArray("doc");
        List<Map> docList = net.sf.json.JSONArray.toList(jsonArray, Map.class);
        InspectReport inspectReport = new InspectReport();
        int edition = 1;
        InspectReportExample inspectReportExample = new InspectReportExample();
        inspectReportExample.createCriteria().andCompIdEqualTo(compId).andBatchNumEqualTo(jsonObject.getString("batchNum")).
                andProductInfoIdEqualTo(jsonObject.getInt("productInfoId")).andDelFlagEqualTo(0);
        List<InspectReport> reportList = inspectReportMapper.selectByExample(inspectReportExample);
        Integer reportId = 0;
        Integer informationFrom = 0;
        boolean flag = true;
        boolean flagEdition = true;
        if (reportList.size() > 0) {
            reportId = reportList.get(0).getId();
        } else {
            flag = false;
        }

        if (jsonObject.containsKey("informationFrom") && jsonObject.getInt("informationFrom") == 1) {
            informationFrom = 1;
            flagEdition = false;
        }

        if (flag) {
            InspectReport report = inspectReportMapper.selectByPrimaryKey(reportId);
            edition = report.getEdition();
            inspectReport.setId(reportId);
            if (jsonObject.containsKey("reportNum") && StringUtil.isNotEmpty(jsonObject.getString("reportNum")))
                inspectReport.setReportNum(jsonObject.getString("reportNum"));
            if (jsonObject.containsKey("reportTime") && StringUtil.isNotEmpty(jsonObject.getString("reportTime")))
                inspectReport.setReportTime(sdf.parse(jsonObject.getString("reportTime")));
            inspectReport.setUpdateAccountId((Integer) session.getAttribute("accountID"));
            inspectReport.setUpdateBy(session.getAttribute("accountName").toString());
            inspectReport.setUpdateTime(new Date());
            inspectReportMapper.updateByPrimaryKeySelective(inspectReport);

            if (jsonObject.containsKey("informationFrom") && jsonObject.getInt("informationFrom") == 1) {
                int count = inspectReportMapperVo.getReportEditionMax(reportId);
                edition = count + 1;
            }
        } else {
            inspectReport.setBatchNum(jsonObject.getString("batchNum"));
            inspectReport.setCompId(compId);
            inspectReport.setCreateAccountId((Integer) session.getAttribute("accountID"));
            inspectReport.setCreateBy(session.getAttribute("accountName").toString());
            inspectReport.setCreateTime(new Date());
            inspectReport.setProductInfoId(jsonObject.getInt("productInfoId"));
            if (jsonObject.containsKey("reportNum") && StringUtil.isNotEmpty(jsonObject.getString("reportNum")))
                inspectReport.setReportNum(jsonObject.getString("reportNum"));
            if (jsonObject.containsKey("reportTime") && StringUtil.isNotEmpty(jsonObject.getString("reportTime")))
                inspectReport.setReportTime(sdf.parse(jsonObject.getString("reportTime")));
            if (jsonObject.containsKey("informationFrom"))
                inspectReport.setInformationFrom(jsonObject.getInt("informationFrom"));
            inspectReport.setEdition(1);
            inspectReport.setMeansNum(docList.size());
            inspectReportMapper.insertSelective(inspectReport);
        }

        for (Map docMap : docList) {
            if (!docMap.containsKey("docId")) {
                InspectDocument inspectDocument = new InspectDocument();
                if (docMap.containsKey("cloneId"))
                    inspectDocument.setCloneId(Integer.valueOf(docMap.get("cloneId").toString()));
                inspectDocument.setCompId(compId);
                inspectDocument.setCreateAccountId((Integer) session.getAttribute("accountID"));
                inspectDocument.setCreateBy(session.getAttribute("accountName").toString());
                inspectDocument.setCreateTime(new Date());
                inspectDocument.setDocName(docMap.get("docName").toString());
                if (flagEdition) {
                    inspectDocument.setDocUrl(FileUtil.fileMove(docMap.get("docUrl").toString(), "report", compId.toString(), redisUtil));
                } else {
                    inspectDocument.setDocUrl(docMap.get("docUrl").toString());
                    inspectDocument.setDocumentUrl(docMap.containsKey("documentUrl") ? docMap.get("documentUrl").toString() : "");
                }
                inspectDocument.setInspectReportId(inspectReport.getId());
                inspectDocument.setEdition(edition);
                inspectDocument.setInformationFrom(informationFrom);
                inspectDocumentMapper.insertSelective(inspectDocument);
            }
        }
        return ServerResponse.createBySuccess();
    }

    @Override
    public List<Map<String, Object>> getInspectReportList(String batchNum, String startTime, String endTime, Integer compId, Integer informationFrom, Integer productId, int from, int to) {
        return inspectReportMapperVo.getInspectReportList(batchNum, startTime, endTime, compId, informationFrom, productId, from, to);
    }

    @Override
    public int getInspectReportListCount(String batchNum, String startTime, String endTime, Integer compId, Integer informationFrom, Integer productId) {
        return inspectReportMapperVo.getInspectReportListCount(batchNum, startTime, endTime, compId, informationFrom, productId);
    }

    @Override
    public void delInspectReport(Integer inspectReportId) {
        InspectReport inspectReport = new InspectReport();
        inspectReport.setId(inspectReportId);
        inspectReport.setDelFlag(-1);
        inspectReportMapper.updateByPrimaryKeySelective(inspectReport);

        InspectDocument inspectDocument = new InspectDocument();
        inspectDocument.setDelFlag(-1);
        InspectDocumentExample inspectDocumentExample = new InspectDocumentExample();
        inspectDocumentExample.createCriteria().andInspectReportIdEqualTo(inspectReportId);
        inspectDocumentMapper.updateByExampleSelective(inspectDocument, inspectDocumentExample);
    }

    @Override
    public void delInspectDocument(String docId) {
        String[] docIds = docId.split(",");
        for (int i = 0; i < docIds.length; i++) {
            InspectDocument inspectDocument = new InspectDocument();
            inspectDocument.setId(Integer.valueOf(docIds[i]));
            inspectDocument.setDelFlag(-1);
            inspectDocumentMapper.updateByPrimaryKeySelective(inspectDocument);
        }
    }

    @Override
    public Map getInspectReportDetail(Integer reportId) {
        Map map = new HashedMap();
        Map reportMap = inspectReportMapperVo.getInspectReport(reportId);
        map.put("report", reportMap);
        InspectDocumentExample inspectDocumentExample = new InspectDocumentExample();
        inspectDocumentExample.createCriteria().andInspectReportIdEqualTo(reportId).andDelFlagEqualTo(0).andStatusEqualTo(0).
                andEditionEqualTo(Integer.valueOf(reportMap.get("currentEdition").toString()));
        List<InspectDocument> docList = inspectDocumentMapper.selectByExample(inspectDocumentExample);
        for (InspectDocument doc : docList) {
            String filePath = doc.getDocumentUrl();
            if (filePath == null) {
                filePath = doc.getDocUrl();
            }
            doc.setDocUrl(com.edip.dto.util.StringUtils.getFilePath(filePath, redisUtil));
        }
        map.put("docList", docList);
        return map;
    }

    @Override
    public Integer checkBatchNum(Integer productInfoId, String batchNum, Integer compId) {
        InspectReportExample inspectReportExample = new InspectReportExample();
        inspectReportExample.createCriteria().andBatchNumEqualTo(batchNum).
                andProductInfoIdEqualTo(productInfoId).andCompIdEqualTo(compId).andDelFlagEqualTo(0);
        List<InspectReport> reportList = inspectReportMapper.selectByExample(inspectReportExample);
        return reportList.size();
    }

    @Override
    public void changeReportProductId(Integer productId, Integer infoId) {
        try {
            List<Map> reportList = inspectReportMapperVo.getReportListByProductInfoId(productId);
            for (Map reportMap : reportList) {
                if (reportMap.get("information_from").equals(0)) {
                    Map docMap = inspectReportMapperVo.getReportDocEditionCount((Integer) reportMap.get("id"), 1);
                    if (docMap != null) {
                        if (Integer.valueOf(docMap.get("num").toString()) > 0)
                            changeReportEdition(reportMap, docMap, infoId, (Integer) docMap.get("information_from"), 1);
                    }
                } else {
                    Map docMap = inspectReportMapperVo.getReportDocEditionCount((Integer) reportMap.get("id"), 2);
                    if (docMap != null) {
                        changeReportEdition(reportMap, docMap, productId, 0, 2);
                    }
                    inspectReportMapperVo.changeReportProductId(infoId, (Integer) reportMap.get("id"));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void changeReportEdition(Map reportMap, Map docMap, Integer infoId, Integer informationFrom, Integer type) throws Exception {
        InspectReport inspectReport = new InspectReport();
        inspectReport.setInformationFrom(informationFrom);
        inspectReport.setCompId((Integer) reportMap.get("comp_id"));
        inspectReport.setMeansNum(Integer.valueOf(docMap.get("docNum").toString()));
        inspectReport.setProductInfoId(infoId);
        inspectReport.setCreateTime(simpleDateFormat.parse(reportMap.get("create_time").toString()));
        inspectReport.setCreateAccountId((Integer) reportMap.get("create_account_id"));
        inspectReport.setCreateBy(reportMap.get("create_by").toString());
        inspectReport.setBatchNum(reportMap.get("batch_num").toString());
        inspectReport.setEdition(Integer.valueOf(docMap.get("edition").toString()));
        if (reportMap.containsKey("report_num"))
            inspectReport.setReportNum(reportMap.get("report_num").toString());
        if (reportMap.containsKey("report_time"))
            inspectReport.setReportTime(sdf.parse(reportMap.get("report_time").toString()));
        inspectReportMapper.insertSelective(inspectReport);
        inspectReportMapperVo.updateDocumentReportId(inspectReport.getId(), (Integer) reportMap.get("id"), type);
    }

    @Override
    public List<Map> getReceiveReport(Integer reportId) {
        return inspectReportMapperVo.getReceiveReport(reportId);
    }

    @Override
    public void updateReceiveReport(Integer reportId, Integer edition, Integer ascription) {
        InspectReport inspectReport = new InspectReport();
        inspectReport.setInformationFrom(ascription);
        inspectReport.setEdition(edition);
        inspectReport.setId(reportId);
        inspectReportMapper.updateByPrimaryKeySelective(inspectReport);
    }

    @Override
    public void reportTransfer() throws Exception {
        List<Map> reportList = inspectReportMapperVo.getReportList();
        Integer reportId = null;
        for (Map reportMap : reportList) {
            String companyName = inspectReportMapperVo.getOldCompanyNameById((Integer) reportMap.get("compID"));

            Map proMap = new HashedMap();
            proMap.put("productId", reportMap.get("proId"));
            proMap.put("compId", reportMap.get("compID"));
            if (reportMap.containsKey("manufacturer")) {
                proMap.put("manufacturer", reportMap.get("manufacturer"));
            } else {
                proMap.put("manufacturer", companyName);
            }
            /*if (reportMap.containsKey("transmitCompany")) {
                proMap.put("transmitCompany", reportMap.get("transmitCompany"));
            } else {
                proMap.put("transmitCompany", companyName);
            }*/
            List<Integer> infoIdList = inspectReportMapperVo.getProductInfo(proMap);

            List<Map> docList = inspectReportMapperVo.getReportDocument((Integer) reportMap.get("dipID"));
            Integer companyInfoId = inspectReportMapperVo.getCompanyInfoId((Integer) reportMap.get("compID"));
            if (infoIdList.size() > 0) {
                reportId = changeReport(reportMap, infoIdList.get(0), docList.size());
            } else {
                ProductInfo productInfo = new ProductInfo();
                Integer infoId = companyInfoId;
                if (reportMap.containsKey("transmitCompany")) {
                    if (reportMap.get("transmitCompany").equals(companyName)) {
                        productInfo.setOfflineCooperate(companyName);
                    } else {
                        infoId = changeCompany(reportMap.get("transmitCompany").toString(), null, reportMap, 1);
                        productInfo.setOfflineCooperate(reportMap.get("transmitCompany").toString());
                    }
                } else {
                    productInfo.setOfflineCooperate(companyName);
                }
                productInfo.setProductId((Integer) reportMap.get("proId"));
                productInfo.setCompanyInfoId(infoId);
                productInfo.setCreateBy(inspectReportMapperVo.getAccountName(reportMap.get("accountID").toString()));
                productInfo.setCreateAccountId((Integer) reportMap.get("accountID"));
                productInfo.setCreateTime(simpleDateFormat.parse(reportMap.get("createDate").toString()));
                productInfo.setCompId((Integer) reportMap.get("compID"));
                productInfo.setInformationFrom(0);

                if (reportMap.containsKey("manufacturer")) {
                    if (reportMap.get("manufacturer").equals(companyName)) {
                        productInfo.setManuf(companyName);
                        productInfo.setManufId(companyInfoId);
                    } else {
                        productInfo.setManuf(reportMap.get("manufacturer").toString());
                        productInfo.setManufId(changeCompany(reportMap.get("manufacturer").toString(), infoId, reportMap, 2));
                    }
                } else {
                    productInfo.setManuf(companyName);
                    productInfo.setManufId(companyInfoId);
                }

                inspectReportMapperVo.addProductInfo(productInfo);
                reportId = changeReport(reportMap, productInfo.getId(), docList.size());
            }

            if (docList.size() > 0) {
                changeReportDocument(docList, reportMap, reportId);//新增检验报告资质
            }
        }
    }

    @Override
    public void transmitReportTransfer() throws Exception {
        List<Map> transmitList = inspectReportMapperVo.getTransmitList();
        Integer reportId = null;
        for (Map transmitMap : transmitList) {
            Map reportMap = inspectReportMapperVo.getReportById((Integer) transmitMap.get("dipID"));

            Map proMap = new HashedMap();
            proMap.put("productId", reportMap.get("proId"));
            proMap.put("compId", transmitMap.get("compID"));
            proMap.put("manufacturer", reportMap.get("manufacturer"));
            proMap.put("transmitCompany", transmitMap.get("name"));
            List<Integer> infoIdList = inspectReportMapperVo.getProductInfo(proMap);

            List<Map> docList = inspectReportMapperVo.getTransmitReportDocument((Integer) transmitMap.get("transmitItemsId"));
            Integer companyInfoId = inspectReportMapperVo.getCompanyInfoId((Integer) transmitMap.get("compID"));
            String companyName = inspectReportMapperVo.getOldCompanyNameById((Integer) transmitMap.get("compID"));
            int edition = 1;
            if (infoIdList.size() > 0) {
                Map dipMap = inspectReportMapperVo.getReportIdByProductInfoId(infoIdList.get(0), reportMap.get("batchNumber").toString());
                if (dipMap != null) {
                    reportId = (Integer) dipMap.get("id");
                    edition = edition + Integer.valueOf(dipMap.get("edition").toString());
                } else {
                    reportId = changeTransmitReport(reportMap, transmitMap, infoIdList.get(0), docList.size());
                }
            } else {
                ProductInfo productInfo = new ProductInfo();

                Integer infoId = companyInfoId;
                if (transmitMap.get("name").equals(companyName)) {
                    productInfo.setOfflineCooperate(companyName);
                } else {
                    infoId = changeCompany(transmitMap.get("name").toString(), null, transmitMap, 1);
                    productInfo.setOfflineCooperate(transmitMap.get("name").toString());
                }

                productInfo.setProductId((Integer) reportMap.get("proId"));
                productInfo.setCompanyInfoId(infoId);
                productInfo.setCreateBy(transmitMap.get("name").toString());
                productInfo.setCreateAccountId((Integer) transmitMap.get("accountID"));
                productInfo.setCreateTime(simpleDateFormat.parse(transmitMap.get("createDate").toString()));
                productInfo.setCompId((Integer) transmitMap.get("compID"));
                productInfo.setInformationFrom(0);

                if (reportMap.get("manufacturer").equals(companyName)) {
                    productInfo.setManuf(companyName);
                    productInfo.setManufId(companyInfoId);
                } else {
                    productInfo.setManuf(reportMap.get("manufacturer").toString());
                    productInfo.setManufId(changeCompany(reportMap.get("manufacturer").toString(), infoId, transmitMap, 2));
                }

                inspectReportMapperVo.addProductInfo(productInfo);
                reportId = changeTransmitReport(reportMap, transmitMap, productInfo.getId(), docList.size());
            }

            if (docList.size() > 0) {
                for (Map docMap : docList) {
                    InspectDocument inspectDocument = new InspectDocument();
                    inspectDocument.setEdition(edition);
                    inspectDocument.setInspectReportId(reportId);
                    inspectDocument.setDocUrl(docMap.get("docURL").toString());
                    inspectDocument.setDocumentUrl(docMap.get("docURL").toString());
                    inspectDocument.setDocName(docMap.get("docName").toString());
                    inspectDocument.setCreateTime(simpleDateFormat.parse(transmitMap.get("createDate").toString()));
                    inspectDocument.setCreateBy(transmitMap.get("aliasName").toString());
                    inspectDocument.setCreateAccountId((Integer) transmitMap.get("accountID"));
                    inspectDocument.setCompId((Integer) transmitMap.get("compID"));
                    if(transmitMap.get("sourceWay").equals(0)){
                        inspectDocument.setInformationFrom(1);
                    }else{
                        inspectDocument.setInformationFrom(2);
                    }
                    inspectDocumentMapper.insertSelective(inspectDocument);

                    inspectReportMapperVo.updateTransmitDoc((Integer) docMap.get("inspectionDocumentID"), inspectDocument.getId());
                }
            }
        }
    }

    private Integer changeCompany(String transmitCompany, Integer infoId, Map reportMap, Integer informationType) throws Exception {
        Integer nameId = inspectReportMapperVo.getCompanyNameIdByName(transmitCompany);
        if (nameId == null) {
            CompanyName companyName = new CompanyName();
            companyName.setCompanyName(transmitCompany);
            inspectReportMapperVo.addCompanyName(companyName);
            nameId = companyName.getId();
        }

        List<Integer> infoList = inspectReportMapperVo.getCompanyInfoListByName(nameId, infoId, informationType, (Integer) reportMap.get("compID"));
        if (infoList.size() > 0) {
            return infoList.get(0);
        } else {
            CompanyCard cc = new CompanyCard();
            cc.setCompId((Integer) reportMap.get("compID"));
            cc.setCompanyNameId(nameId);
            if (informationType == 1) {
                cc.setCompanyType("41,");
                cc.setBusinessType("17,");
            } else {
                cc.setCompanyType("39,");
                cc.setBusinessType("17,");
            }
            inspectReportMapperVo.addCompanyCard(cc);

            CompanyInfo companyInfo = new CompanyInfo();
            companyInfo.setCompanyCardId(cc.getId());
            companyInfo.setCompanyNameId(nameId);
            companyInfo.setCompId((Integer) reportMap.get("compID"));
            companyInfo.setCreateTime(simpleDateFormat.parse(reportMap.get("createDate").toString()));
            companyInfo.setCreateAccountId((Integer) reportMap.get("accountID"));
            companyInfo.setCreateBy(inspectReportMapperVo.getAccountName(reportMap.get("accountID").toString()));
            companyInfo.setInformationFrom(0);
            companyInfo.setInformationType(informationType);
            inspectReportMapperVo.addCompanyInfo(companyInfo);
            return companyInfo.getId();
        }
    }

    private void changeReportDocument(List<Map> docList, Map reportMap, int reportId) throws Exception {
        for (Map docMap : docList) {
            InspectDocument inspectDocument = new InspectDocument();
            inspectDocument.setEdition(1);
            inspectDocument.setInspectReportId(reportId);
            inspectDocument.setDocUrl(docMap.get("docURL").toString());
            inspectDocument.setDocumentUrl(docMap.get("docURL").toString());
            inspectDocument.setDocName(docMap.get("docName").toString());
            inspectDocument.setCreateTime(simpleDateFormat.parse(reportMap.get("createDate").toString()));
            inspectDocument.setCreateBy(docMap.get("createBy").toString());
            inspectDocument.setCreateAccountId((Integer) reportMap.get("accountID"));
            inspectDocument.setCompId((Integer) reportMap.get("compID"));
            inspectDocumentMapper.insertSelective(inspectDocument);
        }
    }

    public Integer changeReport(Map reportMap, int infoId, int count) throws Exception {
        InspectReport inspectReport = new InspectReport();
        inspectReport.setEdition(1);
        inspectReport.setInformationFrom(0);
        if (reportMap.containsKey("reportNumber"))
            inspectReport.setReportNum(reportMap.get("reportNumber").toString());
        if (reportMap.containsKey("reportDate"))
            inspectReport.setReportTime(sdf.parse(reportMap.get("reportDate").toString()));
        inspectReport.setBatchNum(reportMap.get("batchNumber").toString());
        inspectReport.setCreateBy(inspectReportMapperVo.getAccountName(reportMap.get("accountID").toString()));
        inspectReport.setCreateAccountId((Integer) reportMap.get("accountID"));
        inspectReport.setCreateTime(simpleDateFormat.parse(reportMap.get("createDate").toString()));
        inspectReport.setProductInfoId(infoId);
        inspectReport.setMeansNum(count);
        inspectReport.setCompId((Integer) reportMap.get("compID"));
        inspectReportMapper.insertSelective(inspectReport);
        return inspectReport.getId();
    }

    public Integer changeTransmitReport(Map reportMap, Map transmitMap, int infoId, int count) throws Exception {
        InspectReport inspectReport = new InspectReport();
        inspectReport.setEdition(1);
        inspectReport.setCompId((Integer) transmitMap.get("compID"));
        if (reportMap.containsKey("reportNumber"))
            inspectReport.setReportNum(reportMap.get("reportNumber").toString());
        if (reportMap.containsKey("reportDate"))
            inspectReport.setReportTime(sdf.parse(reportMap.get("reportDate").toString()));
        inspectReport.setBatchNum(reportMap.get("batchNumber").toString());
        inspectReport.setCreateBy(transmitMap.get("aliasName").toString());
        inspectReport.setCreateAccountId((Integer) transmitMap.get("accountID"));
        inspectReport.setCreateTime(simpleDateFormat.parse(transmitMap.get("createDate").toString()));
        inspectReport.setProductInfoId(infoId);
        inspectReport.setMeansNum(count);
        if (transmitMap.get("sourceWay").equals(0)) {
            inspectReport.setInformationFrom(1);
        } else {
            inspectReport.setInformationFrom(2);
        }
        inspectReportMapper.insertSelective(inspectReport);
        return inspectReport.getId();
    }
}
