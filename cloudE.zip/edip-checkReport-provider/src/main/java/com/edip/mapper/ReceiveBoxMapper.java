package com.edip.mapper;

import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface ReceiveBoxMapper {

    List<Map<String,Object>> queryReceiveBoxList(Map<String, Object> params);

    int updateByJobid(@Param("id") String id, @Param("receivedStatus") String receivedStatus,
                      @Param("compID") String compID, @Param("operator") String operator);

   //查询企业摘要信息
   List<Map<String,Object>> queryCompanyInfomationBox(@Param("jobId") String jobId);
    //查询品种摘要
    List<Map<String,Object>> queryProductInfomationBox(@Param("jobId") String jobId);

    List<Map<String,Object>> queryCompOrProductDocDetail(@Param("id") String id, @Param("type") String type);

    List<Map<String,Object>> queryCompOrProductDocDetailForReceive(@Param("id") String id, @Param("type") String type);

    //分类合同，人员
    Map<String,Object> queryManufName(@Param("dataId") String dataId);

    Map<String,Object> queryMemberDic(@Param("dataId") String dataId);

    Map<String,Object> queryContractDic(@Param("dataId") String dataId);

    List<Map<String,Object>> queryProductDocDetail(@Param("id") String id);

    //所有企业品种主题id
    List<Map<String , Object>> getAllProductIdsByJobId(@Param("jobId") String jobId, @Param("typeP") String typeP, @Param("typeC") String typeC);

    List<Map<String,Object>> queryPassBackInfo(String jobId);
    Integer queryProductNum(@Param("productProjectId") String productProjectId);

    Integer addCompIdByCompanyName(Map<String, Object> params);

    Integer addCompanyContractsCompIdByCompanyName(Map<String, Object> params);

    Integer sumReceBox(Map<String, Object> params);
    List<Map<String,Object>>querySendProductInfo(Map<String, Object> params);



}
