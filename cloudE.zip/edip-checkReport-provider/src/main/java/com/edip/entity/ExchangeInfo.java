package com.edip.entity;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.List;

/**
 * @author lilin
 * @description 发送实体类
 * @DATE 2019/1/4  14:40
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExchangeInfo implements Serializable{
    private static final long serialVersionUID = 4387976240591001742L;

    private String jobId;
    /**
     * job信息
     */
    private ExchangeJob exchangeJob;

    /**
     * 接收公司
     */
    private List<ReceiveCompany> companyInfoList;
    /**
     * 主题List
     */
    private List<ExchangeProject> projectList;
    /**
     * 产品List
     */
    private List<List<ExchangeProject>> productInfoList;
    /**
     * 资质主键
     */
    private String docId;

    public ExchangeJob getExchangeJob() {
        return exchangeJob;
    }

    public void setExchangeJob(ExchangeJob exchangeJob) {
        this.exchangeJob = exchangeJob;
    }

    public List<ReceiveCompany> getCompanyInfoList() {
        return companyInfoList;
    }

    public void setCompanyInfoList(List<ReceiveCompany> companyInfoList) {
        this.companyInfoList = companyInfoList;
    }

    public List<List<ExchangeProject>> getProductInfoList() {
        return productInfoList;
    }

    public void setProductInfoList(List<List<ExchangeProject>> productInfoList) {
        this.productInfoList = productInfoList;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public List<ExchangeProject> getProjectList() {
        return projectList;
    }

    public void setProjectList(List<ExchangeProject> projectList) {
        this.projectList = projectList;
    }
}
