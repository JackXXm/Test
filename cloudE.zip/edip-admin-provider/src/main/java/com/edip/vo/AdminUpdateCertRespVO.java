package com.edip.vo;

import java.io.StringReader;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/**
 * 更新证书返回消息体
 * @author zhangjie_d
 *
 */
public class AdminUpdateCertRespVO {

    private String result;//结果
    private String errormsg;//错误信息
    private String transactioncode;
	private String authcode;
	private String certtype;
	private String certformat;
	private String signcert;
	private String enccert;
	private String encprikey;
	
	public AdminUpdateCertRespVO(){
		
	}
	
	public AdminUpdateCertRespVO(String xml) throws DocumentException{
		toBean(xml);
	}
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getErrormsg() {
		return errormsg;
	}
	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}
	public String getTransactioncode() {
		return transactioncode;
	}
	public void setTransactioncode(String transactioncode) {
		this.transactioncode = transactioncode;
	}
	public String getAuthcode() {
		return authcode;
	}
	public void setAuthcode(String authcode) {
		this.authcode = authcode;
	}
	public String getCerttype() {
		return certtype;
	}
	public void setCerttype(String certtype) {
		this.certtype = certtype;
	}
	public String getCertformat() {
		return certformat;
	}
	public void setCertformat(String certformat) {
		this.certformat = certformat;
	}
	public String getSigncert() {
		return signcert;
	}
	public void setSigncert(String signcert) {
		this.signcert = signcert;
	}
	public String getEnccert() {
		return enccert;
	}
	public void setEnccert(String enccert) {
		this.enccert = enccert;
	}
	public String getEncprikey() {
		return encprikey;
	}
	public void setEncprikey(String encprikey) {
		this.encprikey = encprikey;
	}
    private void toBean(String xml)	throws DocumentException {
		SAXReader reader = new SAXReader();
		Document document = reader.read(new StringReader(xml));
		Element body = document.getRootElement();
		this.result = body.element("result").getText();
		this.errormsg = body.element("errormsg").getText();
		this.transactioncode = body.element("transactioncode").getText();
		this.authcode = body.element("authcode").getText();
		this.certtype = body.element("certtype").getText();
		this.certformat = body.element("certformat").getText();
		this.signcert = body.element("signcert").getText();
		this.enccert = body.element("enccert").getText();
		this.encprikey = body.element("encprikey").getText();
    }
}
