package com.edip.entity;

import java.util.List;

import com.edip.vo.CertVo;
import com.google.common.collect.Lists;

/**
 * @Package cn.everfusion.edata.project.util 
 * @author zhuy
 * @data 2017年5月10日 下午4:19:30 
 * @version V1.0
 * @Description 
 */
public class CertVoConvert {
	private CertVoConvert(){}
	
	public static final CertVo convert(CertWithBLOBs cw) {
        if (null == cw) {
            return null;
        }
        CertVo c = new CertVo();
        c.setAccountID(cw.getAccountID());
        c.setActiveDate(cw.getActiveDate());
        c.setUkStatus(cw.getUkStatus());
        c.setBillAccount(cw.getBillAccount());
        c.setBillFlag(cw.getBillFlag());
        c.setBillNum(cw.getBillNum());
        c.setCertID(cw.getCertID());
        c.setCertSN(cw.getCertSN());
        c.setCompID(cw.getCompID());
        c.setCreateDate(cw.getCreateDate());
        c.setDeliverFlag(cw.getDeliverFlag());
        c.setInvalidDate(cw.getInvalidDate());
        c.setLupDate(cw.getLupDate());
        c.setPublicKey(cw.getPublickey());
        c.setStatus(cw.getStatus());
        c.setUkeyCode(cw.getUkeyCode());
        c.setValidDate(cw.getValidDate());
        c.setX509(cw.getX509());
        c.setBillTime(cw.getBillTime());
        c.setUserID(cw.getUserid());
        return c;
    }

   public static final List<CertVo> convert(List<CertWithBLOBs> listProject) {
        if (listProject == null) {
            return Lists.newArrayList();
        }
        List<CertVo> listProjectVo = Lists.newArrayList();
        for (CertWithBLOBs cw : listProject) {
        	listProjectVo.add(CertVoConvert.convert(cw));
        }
        return listProjectVo;
    }
}
