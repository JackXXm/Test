package com.edip.mapper;

import com.edip.entity.InspectExchangeFileItem;
import com.edip.entity.InspectExchangeFileItemExample;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

public interface InspectExchangeFileItemMapper {
    long countByExample(InspectExchangeFileItemExample example);

    int deleteByExample(InspectExchangeFileItemExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(InspectExchangeFileItem record);

    int insertSelective(InspectExchangeFileItem record);

    List<InspectExchangeFileItem> selectByExample(InspectExchangeFileItemExample example);

    InspectExchangeFileItem selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") InspectExchangeFileItem record, @Param("example") InspectExchangeFileItemExample example);

    int updateByExample(@Param("record") InspectExchangeFileItem record, @Param("example") InspectExchangeFileItemExample example);

    int updateByPrimaryKeySelective(InspectExchangeFileItem record);

    int updateByPrimaryKey(InspectExchangeFileItem record);
    String getCompanyName(@Param("companyId") Integer companyId);
    String getAccountName(@Param("accountId") Integer accountId);
    List<Map<String,Object>>queryAlltransmitItems(Map<String,Object>args);
    List<Map<String,Object>>queryTransmitItemsInfo(Map<String,Object>args);

}