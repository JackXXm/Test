package com.edip.utils;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class XmlUtil {
    private static final String ENCODING = "UTF-8";
    private static ThreadLocal<Map<Class<?>, Marshaller>> local_m = new ThreadLocal<Map<Class<?>, Marshaller>>();
    private static ThreadLocal<Map<Class<?>, Unmarshaller>> local_um = new ThreadLocal<Map<Class<?>, Unmarshaller>>();

    public static <T> Marshaller getMarshaller(Class<T> clazz) {
        Map<Class<?>, Marshaller> map = (Map<Class<?>, Marshaller>) local_m.get();
        if (map == null) {
            map = new HashMap<Class<?>, Marshaller>();
        }

        Marshaller m = (Marshaller) map.get(clazz);
        if (m == null) {
            try {
                JAXBContext jc = JAXBContext.newInstance(new Class[] { clazz });
                m = jc.createMarshaller();
                m.setProperty("jaxb.encoding", ENCODING);
                map.put(clazz, m);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        local_m.set(map);
        return m;
    }

    public static <T> Unmarshaller getUnmarshaller(Class<T> clazz) {
        Map<Class<?>, Unmarshaller> map = (Map<Class<?>, Unmarshaller>) local_um.get();
        if (map == null) {
            map = new HashMap<Class<?>, Unmarshaller>();
        }

        Unmarshaller um = (Unmarshaller) map.get(clazz);
        if (um == null) {
            try {
                JAXBContext jc = JAXBContext.newInstance(new Class[] { clazz });
                um = jc.createUnmarshaller();
                map.put(clazz, um);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        local_um.set(map);
        return um;
    }

    public static String beanToXml(Object obj) {
        StringWriter sw = new StringWriter();
        try {
            if (obj != null) {
                Marshaller m = getMarshaller(obj.getClass());
                m.marshal(obj, sw);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sw.toString();
    }

    @SuppressWarnings("unchecked")
    public static <T> T xmlToBean(String xml, Class<T> requiredType) {
        Object obj = null;
        if ((xml != null) && (!("".equals(xml)))) {
            try {
                Unmarshaller um = getUnmarshaller(requiredType);
                obj = um.unmarshal(new StringReader(xml));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return (T) obj;
    }
}
