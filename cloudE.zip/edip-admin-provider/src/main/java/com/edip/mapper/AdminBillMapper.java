package com.edip.mapper;

import java.util.List;
import java.util.Map;

import com.edip.entity.AdminBill;
import com.edip.entity.AdminBillExample;
import org.apache.ibatis.annotations.Param;

public interface AdminBillMapper {
    int countByExample(AdminBillExample example);

    int deleteByExample(AdminBillExample example);

    int deleteByPrimaryKey(Integer billID);

    int insert(AdminBill record);

    int insertSelective(AdminBill record);

    List<AdminBill> selectByExampleWithPage(@Param("example") AdminBillExample example, @Param("from") Integer from, @Param("to") Integer to);

    List<AdminBill> selectByExample(AdminBillExample example);

    AdminBill selectByPrimaryKey(Integer billID);

    int updateByExampleSelective(@Param("record") AdminBill record, @Param("example") AdminBillExample example);

    int updateByExample(@Param("record") AdminBill record, @Param("example") AdminBillExample example);

    int updateByPrimaryKeySelective(AdminBill record);

    int updateByPrimaryKey(AdminBill record);

    /*
     * 查询交换数据业务账单免费期即将到期（提前7天）的账单
     */
    List<AdminBill> selectBillOutOfDate();

    int billCountByExample(Map<String, Object> params);

    List<Map<String, Object>> searchByExampleWithPage(Map<String, Object> params);



    //查询出所有已通过和未通过的公司消费信息searchCompanyBasic
    List<Map<String, Object>> searchByExampleWithPage1(Map<String, Object> params);
    //查询要导出的基础信息列表
    List<Map<String, Object>> searchCompanyBasic(Map<String, Object> params);

    int countNums(Map<String, Object> params);
    //查询公司接收明细
    List<Map<String, Object>> searchReceiveList(Map<String, Object> params);
    //查询接收明细条数
    int countRecieveNums(Map<String, Object> params);


}
