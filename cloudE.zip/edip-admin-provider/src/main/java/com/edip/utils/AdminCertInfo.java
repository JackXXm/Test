package com.edip.utils;
import java.io.ByteArrayInputStream;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;

import org.bouncycastle.util.encoders.Base64;

public class AdminCertInfo {
	public X509Certificate x509cert;

	private String issuerDN;

	private String subjectDN;

	private String serialNumber;

	private String notBefore;

	private String notAfter;

	private byte[] publicKey;

	private int publicKeyLen;

	private int version;

	private Date notBeforeDate;

	private Date notAfterDate;

	public X509Certificate getX509cert() {
		return x509cert;
	}

	public void setX509cert(X509Certificate x509cert) {
		this.x509cert = x509cert;
	}

	public String getIssuerDN() {
		return issuerDN;
	}

	public void setIssuerDN(String issuerDN) {
		this.issuerDN = issuerDN;
	}

	public String getSubjectDN() {
		return subjectDN;
	}

	public void setSubjectDN(String subjectDN) {
		this.subjectDN = subjectDN;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getNotBefore() {
		return notBefore;
	}

	public void setNotBefore(String notBefore) {
		this.notBefore = notBefore;
	}

	public String getNotAfter() {
		return notAfter;
	}

	public void setNotAfter(String notAfter) {
		this.notAfter = notAfter;
	}

	public byte[] getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(byte[] publicKey) {
		this.publicKey = publicKey;
	}

	public int getPublicKeyLen() {
		return publicKeyLen;
	}

	public void setPublicKeyLen(int publicKeyLen) {
		this.publicKeyLen = publicKeyLen;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public Date getNotBeforeDate() {
		return notBeforeDate;
	}

	public void setNotBeforeDate(Date notBeforeDate) {
		this.notBeforeDate = notBeforeDate;
	}

	public Date getNotAfterDate() {
		return notAfterDate;
	}

	public void setNotAfterDate(Date notAfterDate) {
		this.notAfterDate = notAfterDate;
	}

	public AdminCertInfo(byte[] cer) throws Exception {

		try {
			/*certs = certs.replaceAll("-----BEGIN NEW CERTIFICATE REQUEST-----",
					"");
			certs = certs.replaceAll("-----END NEW CERTIFICATE REQUEST-----",
					"");
			certs = certs.replaceAll("/r/n", "");
			certs = certs.replaceAll("-----BEGIN CERTIFICATE-----", "");
			certs = certs.replaceAll("-----END CERTIFICATE-----", "");
			certs = certs.replaceAll("-----BEGIN CERTIFICATE REQUEST-----", "");
			certs = certs.replaceAll("-----END CERTIFICATE REQUEST-----", "");
			certs = certs.replaceAll("-----BEGINCERTIFICATE-----", "");
			certs = certs.replaceAll("-----ENDCERTIFICATE-----", "");
			byte[] cer = Base64.decode(certs.getBytes());*/
			ByteArrayInputStream bis = new ByteArrayInputStream(cer);
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			x509cert = (X509Certificate) cf.generateCertificate(bis);
			bis.close();
			subjectDN = x509cert.getSubjectDN().toString();
			issuerDN = x509cert.getIssuerDN().toString();
			String certSN = x509cert.getSerialNumber().toString(16);
			if (!(certSN.length() % 2 == 0)) {
				certSN = "0" + certSN;
			}
			certSN = certSN.toLowerCase();
			setSerialNumber(certSN);

			setIssuerDN(x509cert.getIssuerDN().toString());

			setSubjectDN(x509cert.getSubjectDN().toString());

			setNotBefore(StringToDate(x509cert.getNotBefore()));

			setNotAfter(StringToDate(x509cert.getNotAfter()));

			setNotBeforeDate(x509cert.getNotBefore());

			setNotAfterDate(x509cert.getNotAfter());

			setPublicKey(x509cert.getPublicKey().getEncoded());

			setPublicKeyLen(x509cert.getPublicKey().getEncoded().length);

			setVersion(x509cert.getVersion());

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Certificate parse error!" + e.getMessage());
		}

	}

	private static String StringToDate(Date param) {
		String strTime = "";
		try {

			GregorianCalendar calendar = new GregorianCalendar();
			calendar.setTime(param);

			int year = calendar.get(java.util.Calendar.YEAR);
			int month = calendar.get(java.util.Calendar.MONTH) + 1;
			int day = calendar.get(java.util.Calendar.DAY_OF_MONTH);
			int hour = calendar.get(java.util.Calendar.HOUR_OF_DAY);
			int minute = calendar.get(java.util.Calendar.MINUTE);
			int second = calendar.get(java.util.Calendar.SECOND);
			strTime = year
					+ (month >= 10 ? ("." + month) : (".0" + month))
					+ (day >= 10 ? ("." + day) : (".0" + day))
					+
					// (hour >= 10 ? (" " + hour) : (":0" + hour)) +
					(hour >= 10 ? (" " + hour) : (" 0" + hour))
					+ (minute >= 10 ? (":" + minute) : (":0" + minute))
					+ (second >= 10 ? (":" + second) : (":0" + second));
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
		return strTime;
	}
	
	@Override
	public String toString() {
		return "CertInfo [x509cert=" + x509cert + ", issuerDN=" + issuerDN
				+ ", subjectDN=" + subjectDN + ", serialNumber=" + serialNumber
				+ ", notBefore=" + notBefore + ", notAfter=" + notAfter
				+ ", publicKey=" + Arrays.toString(publicKey)
				+ ", publicKeyLen=" + publicKeyLen + ", version=" + version
				+ ", notBeforeDate=" + notBeforeDate + ", notAfterDate="
				+ notAfterDate + "]";
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

//		CertInfo certINFO = new CertInfo(
//				"MIICrzCCAhqgAwIBAgIBFzALBgkqhkiG9w0BAQUwbjELMAkGA1UEBhMCQ04xDjAMBgNVBAgMBUpJTElOMRIwEAYDVQQHDAlDSEFOR0NIVU4xDjAMBgNVBAsMBUNOQ0NBMQwwCgYDVQQKDANDTkMxHTAbBgNVBAMMFENISU5BIFVOSUNPTSBST09UIENBMB4XDTEwMTAxNTA1NTY1NVoXDTMwMTAxNTA1NTY1NVowNjELMAkGA1UEBhMCQ04xJzAlBgNVBAMMHuWcqOe6v+WuieWFqOeuoeeQhuWRmOeOi+aZk+aZqDCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAtdKFHd10dPv/JClJMkJakBimByEsO2pUlPRH09DusfX2RDrY29a64A50Xp9tyMCkNnbJFNR4I9QEnGR2v5XpKnPgQug9TOWn5Jz9GuCaVjfoB489DiCBvF+DDVlNOXuxUox4Y8182MTx4ij5dJxDn16xTx+X9FMS3+AoV8DQtBkCAwEAAaOBmDCBlTAfBgNVHSMEGDAWgBQN6tmVHL4bv+LrTpRBqh/fBf5GqjAdBgNVHQ4EFgQUXL4PYVl/UYZnLpRNB8ZGWiLxRZkwDAYDVR0TBAUwAwEB/zA4BgNVHR8EMTAvMC2gK6AphidodHRwOi8vd3d3LmNjaXQuY29tLmNuL3N5c3RlbWNhL2NybC5jcmwwCwYDVR0PBAQDAgGGMAsGCSqGSIb3DQEBBQOBgQAlvy6rNT22EzQcO4PEvREAA8ujECUqeLSC6qS2WcNu6fSXaY/AR1VMr4RI0u/sYOnb3ZOsNby+VLFNq0aTpQIWX5Ym7eN58Mwl+gCHttGaFuo3EWhPwW43T5XrG1vffM5/K/6JdX+PXI+nypoDP+qvV63jlhKWez+0CaGXFEsKMg==");

		//System.out.println(certINFO);

	}

}
