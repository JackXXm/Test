package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class Project implements Serializable {
    /**
     * 项目ID
     */
    private Integer proid;

    /**
     * 项目名称
     */
    private String proname;

    /**
     * 归属公司
     */
    private Integer compid;

    /**
     * 线下交换的公司名称
     */
    private String name;

    /**
     * 项目包含的产品ID
     */
    private Integer productid;

    /**
     * 帐号ID
     */
    private Integer accountid;

    /**
     * 接受方公司ID
     */
    private Integer receiveid;

    /**
     * 收件人ID
     */
    private Integer consigneeid;

    /**
     * 发送日期
     */
    private Date senddate;

    /**
     * 接受日期
     */
    private Date receivedate;

    /**
     * 补发时间
     */
    private Date reissuedate;

    /**
     * 补发状态
                                                                    0:无需补发
                                                                    1:需要补发
     */
    private Integer reissueflag;

    /**
     * 补发接受时间
     */
    private Date reissuerecdate;

    /**
     * 留言
     */
    private String note;

    /**
     * 文件总数
     */
    private Integer filecount;

    /**
     * 项目资料是否完整
                                                                     0:完整
                                                                     1:缺失
     */
    private Integer completeflag;

    /**
     * 是否已归档
                                                                     0:已归档
                                                                     1:未归档
     */
    private Integer archiveflag;

    /**
     * 状态
                                                                     0:已完成
                                                                     1:待发送
                                                                     2:已发送
                                                                     3:未回传
                                                                     4:已回传
                                                                     9:审批失败
     */
    private Integer status;

    /**
     * 创建时间
     */
    private Date createdate;

    /**
     * 更新时间
     */
    private Date lupdate;

    /**
     * 归档时间
     */
    private Date archivedate;

    /**
     * 回传状态
     */
    private Integer returnstatus;

    private Integer docstatus;

    private String reportnumber;

    /**
     * 新页面发送主题标志位, 0:老页面	1：新页面 
     */
    private Integer isnew;

    /**
     * 是否是企业资料, 0:企业资料	1：品种资料  2：线上关联企业 3：线下关联企业
     */
    private Integer isvariety;

    /**
     * 是否存在签章异常
     */
    private Integer hasexc;

    /**
     * 业务ID，对应isVariety
     */
    private Integer businessid;

    /**
     * 修改时间
     */
    private Date updatedate;

    /**
     * 品种来源 0线上 1线下 
     */
    private Integer source;

    /**
     * 品种来源公司id 
     */
    private Integer sourcecompid;

    private static final long serialVersionUID = 1L;

    public Integer getProid() {
        return proid;
    }

    public void setProid(Integer proid) {
        this.proid = proid;
    }

    public String getProname() {
        return proname;
    }

    public void setProname(String proname) {
        this.proname = proname;
    }

    public Integer getCompid() {
        return compid;
    }

    public void setCompid(Integer compid) {
        this.compid = compid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getProductid() {
        return productid;
    }

    public void setProductid(Integer productid) {
        this.productid = productid;
    }

    public Integer getAccountid() {
        return accountid;
    }

    public void setAccountid(Integer accountid) {
        this.accountid = accountid;
    }

    public Integer getReceiveid() {
        return receiveid;
    }

    public void setReceiveid(Integer receiveid) {
        this.receiveid = receiveid;
    }

    public Integer getConsigneeid() {
        return consigneeid;
    }

    public void setConsigneeid(Integer consigneeid) {
        this.consigneeid = consigneeid;
    }

    public Date getSenddate() {
        return senddate;
    }

    public void setSenddate(Date senddate) {
        this.senddate = senddate;
    }

    public Date getReceivedate() {
        return receivedate;
    }

    public void setReceivedate(Date receivedate) {
        this.receivedate = receivedate;
    }

    public Date getReissuedate() {
        return reissuedate;
    }

    public void setReissuedate(Date reissuedate) {
        this.reissuedate = reissuedate;
    }

    public Integer getReissueflag() {
        return reissueflag;
    }

    public void setReissueflag(Integer reissueflag) {
        this.reissueflag = reissueflag;
    }

    public Date getReissuerecdate() {
        return reissuerecdate;
    }

    public void setReissuerecdate(Date reissuerecdate) {
        this.reissuerecdate = reissuerecdate;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Integer getFilecount() {
        return filecount;
    }

    public void setFilecount(Integer filecount) {
        this.filecount = filecount;
    }

    public Integer getCompleteflag() {
        return completeflag;
    }

    public void setCompleteflag(Integer completeflag) {
        this.completeflag = completeflag;
    }

    public Integer getArchiveflag() {
        return archiveflag;
    }

    public void setArchiveflag(Integer archiveflag) {
        this.archiveflag = archiveflag;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getLupdate() {
        return lupdate;
    }

    public void setLupdate(Date lupdate) {
        this.lupdate = lupdate;
    }

    public Date getArchivedate() {
        return archivedate;
    }

    public void setArchivedate(Date archivedate) {
        this.archivedate = archivedate;
    }

    public Integer getReturnstatus() {
        return returnstatus;
    }

    public void setReturnstatus(Integer returnstatus) {
        this.returnstatus = returnstatus;
    }

    public Integer getDocstatus() {
        return docstatus;
    }

    public void setDocstatus(Integer docstatus) {
        this.docstatus = docstatus;
    }

    public String getReportnumber() {
        return reportnumber;
    }

    public void setReportnumber(String reportnumber) {
        this.reportnumber = reportnumber;
    }

    public Integer getIsnew() {
        return isnew;
    }

    public void setIsnew(Integer isnew) {
        this.isnew = isnew;
    }

    public Integer getIsvariety() {
        return isvariety;
    }

    public void setIsvariety(Integer isvariety) {
        this.isvariety = isvariety;
    }

    public Integer getHasexc() {
        return hasexc;
    }

    public void setHasexc(Integer hasexc) {
        this.hasexc = hasexc;
    }

    public Integer getBusinessid() {
        return businessid;
    }

    public void setBusinessid(Integer businessid) {
        this.businessid = businessid;
    }

    public Date getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(Date updatedate) {
        this.updatedate = updatedate;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public Integer getSourcecompid() {
        return sourcecompid;
    }

    public void setSourcecompid(Integer sourcecompid) {
        this.sourcecompid = sourcecompid;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Project other = (Project) that;
        return (this.getProid() == null ? other.getProid() == null : this.getProid().equals(other.getProid()))
            && (this.getProname() == null ? other.getProname() == null : this.getProname().equals(other.getProname()))
            && (this.getCompid() == null ? other.getCompid() == null : this.getCompid().equals(other.getCompid()))
            && (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getProductid() == null ? other.getProductid() == null : this.getProductid().equals(other.getProductid()))
            && (this.getAccountid() == null ? other.getAccountid() == null : this.getAccountid().equals(other.getAccountid()))
            && (this.getReceiveid() == null ? other.getReceiveid() == null : this.getReceiveid().equals(other.getReceiveid()))
            && (this.getConsigneeid() == null ? other.getConsigneeid() == null : this.getConsigneeid().equals(other.getConsigneeid()))
            && (this.getSenddate() == null ? other.getSenddate() == null : this.getSenddate().equals(other.getSenddate()))
            && (this.getReceivedate() == null ? other.getReceivedate() == null : this.getReceivedate().equals(other.getReceivedate()))
            && (this.getReissuedate() == null ? other.getReissuedate() == null : this.getReissuedate().equals(other.getReissuedate()))
            && (this.getReissueflag() == null ? other.getReissueflag() == null : this.getReissueflag().equals(other.getReissueflag()))
            && (this.getReissuerecdate() == null ? other.getReissuerecdate() == null : this.getReissuerecdate().equals(other.getReissuerecdate()))
            && (this.getNote() == null ? other.getNote() == null : this.getNote().equals(other.getNote()))
            && (this.getFilecount() == null ? other.getFilecount() == null : this.getFilecount().equals(other.getFilecount()))
            && (this.getCompleteflag() == null ? other.getCompleteflag() == null : this.getCompleteflag().equals(other.getCompleteflag()))
            && (this.getArchiveflag() == null ? other.getArchiveflag() == null : this.getArchiveflag().equals(other.getArchiveflag()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getCreatedate() == null ? other.getCreatedate() == null : this.getCreatedate().equals(other.getCreatedate()))
            && (this.getLupdate() == null ? other.getLupdate() == null : this.getLupdate().equals(other.getLupdate()))
            && (this.getArchivedate() == null ? other.getArchivedate() == null : this.getArchivedate().equals(other.getArchivedate()))
            && (this.getReturnstatus() == null ? other.getReturnstatus() == null : this.getReturnstatus().equals(other.getReturnstatus()))
            && (this.getDocstatus() == null ? other.getDocstatus() == null : this.getDocstatus().equals(other.getDocstatus()))
            && (this.getReportnumber() == null ? other.getReportnumber() == null : this.getReportnumber().equals(other.getReportnumber()))
            && (this.getIsnew() == null ? other.getIsnew() == null : this.getIsnew().equals(other.getIsnew()))
            && (this.getIsvariety() == null ? other.getIsvariety() == null : this.getIsvariety().equals(other.getIsvariety()))
            && (this.getHasexc() == null ? other.getHasexc() == null : this.getHasexc().equals(other.getHasexc()))
            && (this.getBusinessid() == null ? other.getBusinessid() == null : this.getBusinessid().equals(other.getBusinessid()))
            && (this.getUpdatedate() == null ? other.getUpdatedate() == null : this.getUpdatedate().equals(other.getUpdatedate()))
            && (this.getSource() == null ? other.getSource() == null : this.getSource().equals(other.getSource()))
            && (this.getSourcecompid() == null ? other.getSourcecompid() == null : this.getSourcecompid().equals(other.getSourcecompid()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getProid() == null) ? 0 : getProid().hashCode());
        result = prime * result + ((getProname() == null) ? 0 : getProname().hashCode());
        result = prime * result + ((getCompid() == null) ? 0 : getCompid().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getProductid() == null) ? 0 : getProductid().hashCode());
        result = prime * result + ((getAccountid() == null) ? 0 : getAccountid().hashCode());
        result = prime * result + ((getReceiveid() == null) ? 0 : getReceiveid().hashCode());
        result = prime * result + ((getConsigneeid() == null) ? 0 : getConsigneeid().hashCode());
        result = prime * result + ((getSenddate() == null) ? 0 : getSenddate().hashCode());
        result = prime * result + ((getReceivedate() == null) ? 0 : getReceivedate().hashCode());
        result = prime * result + ((getReissuedate() == null) ? 0 : getReissuedate().hashCode());
        result = prime * result + ((getReissueflag() == null) ? 0 : getReissueflag().hashCode());
        result = prime * result + ((getReissuerecdate() == null) ? 0 : getReissuerecdate().hashCode());
        result = prime * result + ((getNote() == null) ? 0 : getNote().hashCode());
        result = prime * result + ((getFilecount() == null) ? 0 : getFilecount().hashCode());
        result = prime * result + ((getCompleteflag() == null) ? 0 : getCompleteflag().hashCode());
        result = prime * result + ((getArchiveflag() == null) ? 0 : getArchiveflag().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getCreatedate() == null) ? 0 : getCreatedate().hashCode());
        result = prime * result + ((getLupdate() == null) ? 0 : getLupdate().hashCode());
        result = prime * result + ((getArchivedate() == null) ? 0 : getArchivedate().hashCode());
        result = prime * result + ((getReturnstatus() == null) ? 0 : getReturnstatus().hashCode());
        result = prime * result + ((getDocstatus() == null) ? 0 : getDocstatus().hashCode());
        result = prime * result + ((getReportnumber() == null) ? 0 : getReportnumber().hashCode());
        result = prime * result + ((getIsnew() == null) ? 0 : getIsnew().hashCode());
        result = prime * result + ((getIsvariety() == null) ? 0 : getIsvariety().hashCode());
        result = prime * result + ((getHasexc() == null) ? 0 : getHasexc().hashCode());
        result = prime * result + ((getBusinessid() == null) ? 0 : getBusinessid().hashCode());
        result = prime * result + ((getUpdatedate() == null) ? 0 : getUpdatedate().hashCode());
        result = prime * result + ((getSource() == null) ? 0 : getSource().hashCode());
        result = prime * result + ((getSourcecompid() == null) ? 0 : getSourcecompid().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", proid=").append(proid);
        sb.append(", proname=").append(proname);
        sb.append(", compid=").append(compid);
        sb.append(", name=").append(name);
        sb.append(", productid=").append(productid);
        sb.append(", accountid=").append(accountid);
        sb.append(", receiveid=").append(receiveid);
        sb.append(", consigneeid=").append(consigneeid);
        sb.append(", senddate=").append(senddate);
        sb.append(", receivedate=").append(receivedate);
        sb.append(", reissuedate=").append(reissuedate);
        sb.append(", reissueflag=").append(reissueflag);
        sb.append(", reissuerecdate=").append(reissuerecdate);
        sb.append(", note=").append(note);
        sb.append(", filecount=").append(filecount);
        sb.append(", completeflag=").append(completeflag);
        sb.append(", archiveflag=").append(archiveflag);
        sb.append(", status=").append(status);
        sb.append(", createdate=").append(createdate);
        sb.append(", lupdate=").append(lupdate);
        sb.append(", archivedate=").append(archivedate);
        sb.append(", returnstatus=").append(returnstatus);
        sb.append(", docstatus=").append(docstatus);
        sb.append(", reportnumber=").append(reportnumber);
        sb.append(", isnew=").append(isnew);
        sb.append(", isvariety=").append(isvariety);
        sb.append(", hasexc=").append(hasexc);
        sb.append(", businessid=").append(businessid);
        sb.append(", updatedate=").append(updatedate);
        sb.append(", source=").append(source);
        sb.append(", sourcecompid=").append(sourcecompid);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}