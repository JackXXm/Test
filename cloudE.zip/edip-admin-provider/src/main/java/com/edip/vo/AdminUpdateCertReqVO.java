package com.edip.vo;

import org.apache.commons.lang.StringUtils;

/**
 * 更新证书的请求VO 
 * @author zhangjie_d
 *
 */
public class AdminUpdateCertReqVO {
	
	private String platformid;//平台标识
	private String certsn;//证书序列号
	private String subjectpubkey;//公钥
	private String certstoragetype;//证书存储类型
	private String notbefore;//证书生效日期
	private String notafter;//证书失效日期
	
	public String getPlatformid() {
		return platformid;
	}
	public void setPlatformid(String platformid) {
		this.platformid = platformid;
	}
	public String getCertsn() {
		return certsn;
	}
	public void setCertsn(String certsn) {
		this.certsn = certsn;
	}
	public String getSubjectpubkey() {
		return subjectpubkey;
	}
	public void setSubjectpubkey(String subjectpubkey) {
		this.subjectpubkey = subjectpubkey;
	}
	public String getCertstoragetype() {
		return certstoragetype;
	}
	public void setCertstoragetype(String certstoragetype) {
		this.certstoragetype = certstoragetype;
	}
	public String getNotbefore() {
		return notbefore;
	}
	public void setNotbefore(String notbefore) {
		this.notbefore = notbefore;
	}
	public String getNotafter() {
		return notafter;
	}
	public void setNotafter(String notafter) {
		this.notafter = notafter;
	}
	
	/**
	 * 转为XML
	 * 
	 * @return
	 */
	public String toXML() {
		StringBuffer buffer = new StringBuffer(
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?><request command=\"certUpdateRequest\">");
		
		buffer.append("<platformid>");
		if (!StringUtils.isEmpty(this.platformid)) {
			buffer.append(this.platformid);
		}
		buffer.append("</platformid>");

		buffer.append("<parameters>");

		buffer.append("<certsn>");
		if (!StringUtils.isEmpty(this.certsn)) {
			buffer.append(this.certsn);
		}
		buffer.append("</certsn>");

		buffer.append("<subjectpubkey>");
		if (!StringUtils.isEmpty(this.subjectpubkey)) {
			buffer.append(this.subjectpubkey);
		}
		buffer.append("</subjectpubkey>");

		buffer.append("<certstoragetype>");
		if (!StringUtils.isEmpty(this.certstoragetype)) {
			buffer.append(this.certstoragetype);
		}
		buffer.append("</certstoragetype>");

		buffer.append("<notbefore>");
		if (!StringUtils.isEmpty(this.notbefore)) {
			buffer.append(this.notbefore);
		}
		buffer.append("</notbefore>");

		buffer.append("<notafter>");
		if (!StringUtils.isEmpty(this.notafter)) {
			buffer.append(this.notafter);
		}
		buffer.append("</notafter>");
		
		buffer.append("</parameters>");
		buffer.append("</request>");

		return buffer.toString();
	}	
	
}
