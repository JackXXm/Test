package com.edip.controller;

import com.alibaba.fastjson.JSONObject;
import com.edip.dto.ServerResponse;
import com.edip.service.NoticeService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * 添加系统公告
 */
@RestController
@RequestMapping("/notice")
public class NoticeController {
    private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);
    @Autowired
    private NoticeService noticeService;

    /**
     * 添加系统公告
     *
     * @param classify
     * @param popup
     * @param title
     * @param content
     * @param type:0保存 1保存并发送
     * @param request
     * @return
     */
    @RequestMapping("/addNotice.ajax")
    public ServerResponse addNotice(@RequestBody Map<String,Object> params, HttpServletRequest request) {
        logger.debug("=================进入添加公告接口=================");
        try {
            noticeService.addNotice(params, request);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ServerResponse.createByError();
        }
        return ServerResponse.createBySuccess();
    }

    /**
     * 获取系统公告列表
     *
     * @param title 主題
     * @param classify 消息类型
     * @param beginDate
     * @param endDate
     * @param send 发送状态
     * @return
     */
    @RequestMapping("/getNotice.ajax")
    public ServerResponse getNotice(@RequestBody Map<String, Object> params) {
        logger.debug("=================进入公告列表接口=================");
        try {
            Integer page = (Integer) params.get("page");
            Integer rows = (Integer) params.get("rows");
            PageHelper.startPage(page, rows);
            List<Map<String, Object>> list = noticeService.getNotice(params);
            PageInfo pageInfo = new PageInfo(list);
            return ServerResponse.createBySuccess(pageInfo);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ServerResponse.createByError();
        }
    }

    /**
     * 编辑系统公告
     *
     * @param id
     * @param classify
     * @param popup
     * @param title
     * @param content
     * @param request
     * @return
     */
    @RequestMapping("/editNotice.ajax")
    public ServerResponse editNotice(@RequestBody Map<String,Object> params, HttpServletRequest request) {
        logger.debug("=================进入公告编辑接口=================");
        try {
            noticeService.editNotice(params, request);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ServerResponse.createByError();
        }
        return ServerResponse.createBySuccess();
    }

    /**
     * 删除公告
     * @param id
     * @return
     */
    @RequestMapping("/deleteNotice.ajax")
    public ServerResponse deleteNotice(String id) {
        logger.debug("=================进入公告删除接口=================");
        try {
            noticeService.deleteNotice(id);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return ServerResponse.createByError();
        }
        return ServerResponse.createBySuccess();
    }

    /**
     * 发送公告
     * @param id
     * @return
     */
    @RequestMapping("/sendNotice.ajax")
    public ServerResponse sendNotice( Integer id){
        logger.debug("=================进入发送公告接口=================");
        try {
            noticeService.sendNotice(id);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
            return ServerResponse.createByError();
        }
        return ServerResponse.createBySuccess();
    }
}
