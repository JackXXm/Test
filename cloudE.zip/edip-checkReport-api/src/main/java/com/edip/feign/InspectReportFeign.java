package com.edip.feign;

import com.edip.dto.ServerResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(serviceId = "edip-checkReport-provider")
public interface InspectReportFeign {

    @RequestMapping("/inspect_report/changeReportProductId.ajax")
    void changeReportProductId(@RequestParam("productId")Integer productId,@RequestParam("infoId")Integer infoId);
    @RequestMapping("/inspect_report/changeInspectReport.ajax")
    ServerResponse changeInspectReport(@RequestBody String data);
}
