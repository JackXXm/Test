package com.edip.controller;

import com.alibaba.fastjson.JSONObject;
import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.dto.util.SessionAttributeUtil;
import com.edip.feign.ReciveFeign;
import com.edip.service.ReceiveBoxService;
import com.edip.utils.StringUtils;
import com.edip.vo.*;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.github.pagehelper.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/receive")
public class ReceiveController {

    private Logger LOGGER = LoggerFactory.getLogger(ReceiveController.class);
    @Autowired
    private HttpServletRequest request;

    @Autowired
    private ReceiveBoxService receiveBoxService;





    /**
     *
     * @param info
     * @return
     */
    @RequestMapping(value = "/receiveList.ajax",method = RequestMethod.POST,produces = "application/json; charset=UTF-8")
    public ServerResponse receiveList(@RequestBody Map<String,Object> info) {
        Map<String,Object> sessionMap = SessionAttributeUtil.getAttribute(request);
        Integer compID = (Integer)sessionMap.get("compID");
        Map<String,Object> param = new HashMap<String,Object>();
        try {
            String sender= (String) info.get("sender");
            String sendCompany= (String) info.get("sendCompany");
            String receivedStatus= (String) info.get("receivedStatus");
            String startTime= (String) info.get("startTime");
            String endTime= (String) info.get("endTime");
            Integer page = (int)info.get("page");
            Integer rows = (int)info.get("rows");
            param.put("sender",sender);
            param.put("sendCompany",sendCompany);
            param.put("startTime",startTime);
            param.put("endTime",endTime);
            param.put("compID", compID);
            param.put("dataDigest", info.get("dataDigest"));
            if(StringUtils.isNotBlank(receivedStatus)){
                param.put("receivedStatus", receivedStatus);
            }

            PageHelper.startPage(Integer.valueOf(page), Integer.valueOf(rows));
            List<Map<String, Object>> boxes = receiveBoxService.queryReceiveBox(param);

            PageInfo pageInfo = new PageInfo(boxes);

            return ServerResponse.createBySuccess("success", pageInfo);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取收件箱列表失败！");
        }
    }

    /**
     * hyj
     * 收件箱拒收
     * @param
     * @return
     */
    @RequestMapping("/rejectReceiveTask.ajax")
    public ServerResponse updateById(@RequestBody Map<String,Object> info) {

        try {
            Integer compID = (Integer)SessionContext.getContext().getSession(request).getAttribute("compID");
            Integer jobId= (Integer) info.get("jobId");
            String operator = (String)SessionContext.getContext().getSession(request).getAttribute("createBy");

            info.put("compID",compID+"");
            info.put("operator",operator);
            info.put("receivedStatus",3+"");
            int updateNUms = receiveBoxService.updateByJobId(info);
            return ServerResponse.createBySuccessMsg("拒收成功");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("拒收失败");
        }
    }

    /**
     * hyj
     * 查询接收企业列表和品种的基本概要信息
     * @param jobId  任务id
     * @return
     */
    @RequestMapping("/queryReceiveInfomationBox.ajax")
    public ServerResponse queryReceiveInfomationBox(@RequestBody Map<String,Object>args) {
        try {
            Map<String, Object> result = receiveBoxService.queryReceiveInfomationBox(args);
            return ServerResponse.createBySuccess(result);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("查询任务详情失败！");
        }
    }

    /**
     * hyj
     * 收件箱拒收
     * @param
     * @return
     */
    @RequestMapping("/receiveProduct.ajax")
    public ServerResponse receiveProduct(@RequestBody Map<String,Object> info) {

        try {
            Integer compID = (Integer)SessionContext.getContext().getSession(request).getAttribute("compID");

            String operator = (String)SessionContext.getContext().getSession(request).getAttribute("createBy");
            info.put("compID",compID);
            info.put("operator",operator);
            info.put("receivedStatus",2+"");
            int updateNUms = receiveBoxService.receiveProduct(info);
            return ServerResponse.createBySuccessMsg("查收成功");
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("查收失败");
        }
    }





}
