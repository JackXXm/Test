package com.edip.mapper;


import com.edip.entity.AdminProvince;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface AdminProvinceMapper {
//    int countByExample(ProvinceExample example);

//    int deleteByExample(ProvinceExample example);

    int deleteByPrimaryKey(Integer PROVINCE_ID);

    int insert(AdminProvince record);

    int insertSelective(AdminProvince record);

//    List<Province> selectByExampleWithPage(@Param("example") ProvinceExample example, @Param("from") Integer from, @Param("to") Integer to);

//    List<Province> selectByExample(ProvinceExample example);

    AdminProvince selectByPrimaryKey(Integer PROVINCE_ID);

//    int updateByExampleSelective(@Param("record")AdminProvince record, @Param("example") ProvinceExample example);

//    int updateByExample(@Param("record")AdminProvince record, @Param("example") ProvinceExample example);

    int updateByPrimaryKeySelective(AdminProvince record);

    int updateByPrimaryKey(AdminProvince record);

    List<Map<String,Object>> getProvinceName(@Param("ukeyInfos") List<Map<String,Object>> ukeyInfos);

    List<AdminProvince> getProvinces();
}