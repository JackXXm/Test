package com.edip.feign;

import com.edip.dto.ServerResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@FeignClient(serviceId = "edip-company-provider")
public interface CertFeign {


    @RequestMapping("/cert/updateCertByCompanyId.ajax")
    ServerResponse updateCertByCompanyId(@RequestBody Map<String,Object> param);

}
