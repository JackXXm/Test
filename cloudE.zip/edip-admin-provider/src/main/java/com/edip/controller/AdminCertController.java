package com.edip.controller;

import com.edip.config.ConfigurationHelper;
import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.dto.util.Page;
import com.edip.entity.AdminCertWithBLOBs;
import com.edip.feign.CompanyFeign;
import com.edip.mapper.AdminCertMapperVo;
import com.edip.service.AdminCertService;
import com.edip.service.AdminMessageBiz;
import com.edip.utils.AdminAddressExcel;
import com.edip.utils.AdminMessageStatusUtil;
import com.edip.vo.AdminAddressVo;
import com.edip.vo.AdminCertVo;
import com.edip.vo.AdminMessageVo;
import com.edip.vo.UKeyCountInfoVo;
import com.github.pagehelper.PageHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.text.Collator;
import java.util.*;

@RestController
@RequestMapping("/cert")
public class AdminCertController {
    private static final Logger logger = LoggerFactory.getLogger(AdminCertController.class);

    @Autowired
    private AdminCertService adminCertService;
    @Autowired
    private AdminCertMapperVo adminCertMapperVo;

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private CompanyFeign companyFeign;

    @Autowired
    private AdminMessageBiz adminMessageBiz;

    public static final String EXCEL_PATH_COMPARE = ConfigurationHelper.getBasePath()+ "/excel/excelmodel";

    private static final String FILE_PATH  = ConfigurationHelper.getBasePath() + "/excel/excelmodel";
    private static final String EXCEL_PATH = ConfigurationHelper.getBasePath() + "/excel/excelmodel";
    /**
     * 获取证书列表
     * @return
     */
    @RequestMapping(value="/query.ajax")
    public ServerResponse listCert(@RequestBody Map<String,Object> params) {
        List<Map<String,Object>> list = new ArrayList<>();
        Integer provinceID = (Integer) SessionContext.getContext().getSession(request).getAttribute("province");
	/*	int from = (page.getPage()-1)*page.getPageSize();
		int to = page.getPage()* page.getPageSize();*/
        Map<String, Object> modelMap = new HashMap<String, Object>();
//        Map<String, Object> params = new HashMap<String, Object>();
        Integer page = (Integer)params.get("page");
        Integer rows = (Integer)params.get("rows");
        int from =(page - 1) * rows;
        int number = 0;
        int pageSize = 0;
        params.put("companyName",params.get("companyName").toString().trim());
        List<Integer> compId =  new ArrayList<Integer>();
        try{
			/*List<Integer> spNoramlList = comAuthService.getSpNoramlList(request);
			CertExample  example = new CertExample();
			Criteria criteria = example.createCriteria();
			if(spNoramlList.size()>0)criteria.andCompIDIn(spNoramlList);
			if(certStatus!=null)criteria.andStatusEqualTo(certStatus);
			if(deliverFlag!=null)criteria.andDeliverFlagEqualTo(deliverFlag);
			if(billFlag!=null)criteria.andBillFlagEqualTo(billFlag);*/
            //分页
            params.put("from", from);
            params.put("to", rows);
			/*if(!StringUtil.isEmpty(startbillTime) && !StringUtil.isEmpty(endbillTime)){
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date start =  sdf.parse(startbillTime);
				Date end =  sdf.parse(endbillTime);
				criteria.andBillTimeBetween(start, end);
			}*/
            //example.setOrderByClause("createDate  desc");
            if(params.get("certType")!=null&&!params.get("certType").toString().equals("")){
                Integer certType = (Integer)params.get("certType");
                if (certType==0)
                    certType=-1;
                params.put("certType",certType);
            }
            if (params.get("certStatus")!=null&&!params.get("certStatus").equals("")){
                if (Integer.valueOf(params.get("certStatus").toString())==0)
                    params.put("certStatus",-1);
            }
            if(provinceID==-1&&params.get("provinceID")!=null&&!params.get("provinceID").toString().trim().equals(""))
                provinceID = Integer.parseInt(params.get("provinceID").toString());
            if(provinceID!=-1){
                List<Map<String , Object>> listInfo  = (List<Map<String, Object>>) companyFeign.queryCompanyByProvinceID(provinceID);
                if(listInfo.size()>0){
                    for(int i=0;i<listInfo.size();i++) {
                        compId.add((Integer) listInfo.get(i).get("compID"));
                        params.put("compId",compId);

                    }
                }

            }
                PageHelper.startPage(page, rows);
                number = adminCertService.countCertNums(params);
                list = adminCertService.selectCertVo(params);


            modelMap.put("records", number);//总条数
            modelMap.put("rows",list);//数据
            modelMap.put("page", page);//页数
            modelMap.put("total",(number - 1) / rows + 1);//总页数
            modelMap.put("success", true);
            return ServerResponse.createBySuccess(modelMap);
        }catch(Exception e){
//            e.printStackTrace();
            logger.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取失败！");
        }
    }

    /**
     * 获取企业变更信息
     * @return
     */
//    @RequestMapping(value="/compInfoForUpList.ajax")
//    @ResponseBody
//    public Map<String,Object> compInfoForUpList(Integer compID, HttpServletRequest request, HttpSession session) {
//        List<CompInfoForUpRecord> list = new ArrayList<CompInfoForUpRecord>();
//	/*	int from = (page.getPage()-1)*page.getPageSize();
//		int to = page.getPage()* page.getPageSize();*/
//        Map<String, Object> modelMap = new HashMap<String, Object>();
//        Map<String, Object> params = new HashMap<String, Object>();
//        //int from =(page - 1) * rows;
//        int number = 0;
//        //List<Integer> compId =new ArrayList<Integer>();
//        try{
//
//
//            //分页
//            //params.put("from", from);
//            //params.put("to", rows);
//
//            number = certService.compInfoForUpCount(compID);
//            list = certService.compInfoForUpList(compID);
//
//        }catch(Exception e){
//            e.printStackTrace();
//            logger.error(e.toString());
//        }
//
//        modelMap.put("records", number);//总条数
//        modelMap.put("rows",list);//数据
//        //modelMap.put("page", page);//页数
//        //modelMap.put("total",(number - 1) / rows + 1);//总页数
//        modelMap.put("success", true);
//        return modelMap;
//    }

    /**
     * 	证书下载
     * @param certId
     * @param publicKey
     * @return
     */
    @RequestMapping("/download.ajax")
    @ResponseBody
    public ServerResponse download(Integer certId,String publicKey){
        logger.debug("-----------------------开始下载证书------------------");
        AdminCertWithBLOBs cert = adminCertMapperVo.selectByPrimaryKey(certId);
        if (cert == null) {
            logger.error("下载证书失败----- 证书不存在--------");
            return ServerResponse.createByErrorMsg("下载失败!证书不存在!");
        }
        if (cert.getBillFlag()==null||cert.getBillFlag()!=0){
            logger.error("下载证书失败----- 当前证书未扣费！--------");
            return ServerResponse.createByErrorMsg("下载失败!证书未扣费!");
        }
        try {
            BASE64Decoder dec=new BASE64Decoder();
            byte[] pubKey = dec.decodeBuffer(publicKey);
            cert.setPublickey(pubKey);
            AdminCertWithBLOBs downloadCert = adminCertService.downloadCert(cert);
            BASE64Encoder baseE= new BASE64Encoder();
            String certificate = baseE.encode(downloadCert.getX509());
            return ServerResponse.createBySuccess("下载成功！",certificate);
        } catch (Exception e) {
            logger.error("下载证书失败"+e.toString(),e);
            return ServerResponse.createByErrorMsg("下载证书失败");
        }
    }


    /**
     * 证书吊销
     * @param certId
     * @return
     */
    @RequestMapping("/revoke.ajax")
    public ServerResponse revoke(Integer certId){
        Map<String,Object> result= new HashMap<String,Object>();
        try {
            Integer updata = adminCertService.revokeCertificate(certId);
            if(updata!=1){
                return ServerResponse.createByErrorMsg("修改证书记录失败");
            }
        } catch (Exception e) {
            logger.error(e.toString(),e);
            return ServerResponse.createByErrorMsg("吊销证书异常");
        }
        return ServerResponse.createBySuccessMsg("吊销成功");
    }



    /**
     * 下载批量导入文件模板
     */
//    @RequestMapping(value = "/downup.ajax")
//    public void download(HttpServletRequest request, HttpServletResponse response) throws IOException {
//        String fileName = "中国.xlsx";
//        String path = EXCEL_PATH_COMPARE + "/bankStatement.xlsx";
//        ExcelUtil.uploadFile(fileName, path, request, response);
//
//    }
    /**
     * 修改ukey序列号
     */
    @RequestMapping(value = "/ukeySN.ajax")
    @ResponseBody
    public ServerResponse ukeySN(Integer certId,String ukeySN) {
        Map<String,Object> param = new HashMap<String,Object>();
        AdminCertVo cert = new AdminCertVo();
        cert.setUkeyCode(ukeySN);
        cert.setCertID(certId);
        int result = adminCertMapperVo.updateByPrimaryKeySelective(cert);
        if(result!=1){
            return ServerResponse.createByErrorMsg("修改失败！");
        }
        return ServerResponse.createBySuccessMsg("修改成功！");
    }

    /**
     * 导出邮寄地址
     * @param compId
     * @param compids
     * @param request
     * @param response
     */
    @RequestMapping(value = "/exportAddress.ajax")
    public void exportExcel(Integer[] compIds,HttpServletRequest request,
                            HttpServletResponse response){
        List<AdminAddressVo> list = new ArrayList<>();
        for(int i=0;i<compIds.length;i++){
            AdminAddressVo address = adminCertService.getAddress(compIds[i]);
            list.add(address);
        }

        String path =AdminAddressExcel.exportExcel(list);

        try {
            request.setCharacterEncoding("UTF-8");

            BufferedOutputStream bos = null;
            BufferedInputStream bis = null;
            bis = new BufferedInputStream(new FileInputStream(new File(path)));
            response.setContentType("application/octet-stream");
            response.setHeader("Content-disposition", "attachment; filename="+ new String(path.getBytes("utf-8"), "ISO8859-1"));
            response.setHeader("Content-Length", String.valueOf(bis.available()));
            bos = new BufferedOutputStream(response.getOutputStream());
            byte[] buff = new byte[2048];
            int bytesRead;
            while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                bos.write(buff, 0, bytesRead);
            }
            bis.close();
            bos.close();

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//    @RequestMapping(value = "/exportBilling.ajax")
//    public void exportBilling(Integer compId,Integer[] compids,Integer certId,Integer[] certIds,HttpServletRequest request,
//                              HttpServletResponse response){
//        List<BilllingVo> list = new ArrayList<BilllingVo>();
//        if(compids==null){
//            BilllingVo billlingVo = certService.getBillling(compId,certId);
//            list.add(billlingVo);
//        }else{
//            for(int i=0;i<compids.length;i++){
//                //for( i=0;i<certIds.length;i++){
//                BilllingVo billlingVo = certService.getBillling(compids[i],certIds[i]);
//                list.add(billlingVo);
//                //}
//            }
//        }
//
//        String path =BilllingExcel.exportBilling(list);
//
//        try {
//            request.setCharacterEncoding("UTF-8");
//
//            BufferedOutputStream bos = null;
//            BufferedInputStream bis = null;
//            bis = new BufferedInputStream(new FileInputStream(new File(path)));
//            response.setContentType("application/octet-stream");
//            response.setHeader("Content-disposition", "attachment; filename="+ new String(path.getBytes("utf-8"), "ISO8859-1"));
//            response.setHeader("Content-Length", String.valueOf(bis.available()));
//            bos = new BufferedOutputStream(response.getOutputStream());
//            byte[] buff = new byte[2048];
//            int bytesRead;
//            while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
//                bos.write(buff, 0, bytesRead);
//            }
//            bis.close();
//            bos.close();
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    @RequestMapping("/isMail.ajax")
    @ResponseBody
    public ServerResponse isMail(@RequestBody Map<String,Object> params,HttpServletRequest request){
//        HttpSession httpSession = SessionContext.getContext().getSession(request);
//        Integer accountID= (Integer) httpSession.getAttribute("accountID");
//        Integer compID = (Integer) httpSession.getAttribute("compID");
//        params.put("accountID",accountID);
//        params.put("companyId",compID);
        try{
            int result = adminCertService.isMill(params);
            if(result==-1){
                return ServerResponse.createByErrorMsg("这条记录已邮寄，请勿重复确认");
            }else if (result==-2){
                return ServerResponse.createByErrorMsg("当前证书未完成缴费！");
            }else if(result==-3){
                return ServerResponse.createByErrorMsg("当前证书未完成下载！");
            }else if (result!=1){
                return ServerResponse.createByErrorMsg("确认邮寄失败");
            }else {
                return ServerResponse.createBySuccessMsg("确认邮寄成功");
            }
        }catch (Exception e){
            logger.error("确认邮寄失败！"+e.getMessage(),e);
            return ServerResponse.createByErrorMsg("确认邮寄失败！");
        }
    }

    @RequestMapping("/MailAddress.ajax")
    @ResponseBody
    public Map<String,Object> MailAddress(Integer compId){
        Map<String,Object> param = new HashMap<String,Object>();
        try{
            AdminAddressVo address = adminCertService.getAddress(compId);
            param.put("success", true);
            param.put("data", address);
        }catch(Exception e){
            logger.error("获取地址失败---------------"+e.toString());
            param.put("success", false);
        }
        return param;
    }
    @RequestMapping("/check.ajax")
    public ServerResponse CertCheck(Integer certId){
        if(certId==null){
            return ServerResponse.createByErrorMsg("参数异常！");
        }
        try {
            Map<String, Object> param = adminCertService.checkCertDetil(certId);
            return ServerResponse.createBySuccess(param);
        }catch (Exception e){
            logger.error(e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取失败！");
        }
    }

    @RequestMapping("/payment.ajax")
    public ServerResponse CertPayment(@RequestBody Map<String,Integer> params,HttpServletRequest request){
        if(params.get("pay")==null||params.get("companyId")==null){
            return ServerResponse.createByErrorMsg("参数异常！");
        }
        try {
            Integer result = adminCertService.CertPayment(params);
            if (result==-5){
                return ServerResponse.createByErrorMsg("用户未充值，请提醒用户充值后，在进行缴费！");
            }else if(result==-1)
                return ServerResponse.createByErrorMsg("账单数据异常！");
            else if (result==-2)
                return ServerResponse.createByErrorMsg("账户余额不足！");
            else if (result==-3)
                return ServerResponse.createByErrorMsg("未存在证书记录");
            else if (result==-4)
                return ServerResponse.createByErrorMsg("该证书已扣费，请勿重复扣费！");
            else
            return ServerResponse.createBySuccessMsg("扣费成功！");
        }catch (Exception e){
            logger.error("扣费失败！"+e.getMessage(),e);
            return ServerResponse.createByErrorMsg("扣费失败!");
        }
    }

    @RequestMapping(value = "getMailInfo.ajax")
    public ServerResponse getMailInfo(Integer certId){
        if (certId==null)
            return ServerResponse.createByErrorMsg("参数异常");
        try {
            return ServerResponse.createBySuccess(adminCertService.getMailInfo(certId));
        }catch (Exception e){
            logger.error("获取邮寄信息失败！"+e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取邮寄信息失败!");
        }
    }

    @RequestMapping(value = "getUkeyCountInfo.ajax")
    public ServerResponse getUkeyCountInfo(Page page,String startTime,String endTime,Integer status,Integer ukStatus,
                                           Integer provinceID,String serveType,String ukeyInfo,String orderBy){

        Integer provinceId = (Integer) SessionContext.getContext().getSession(request).getAttribute("province");
        Map<String,Object> params = new HashMap<>();
        List<Integer> compId =  new ArrayList<Integer>();

        if (orderBy==null|| orderBy.trim().equals("")){
            //params.put("orderBy","createDate desc");
            params.put("orderBy","createDate desc");
        }else {
            params.put("orderBy",orderBy);
        }
        if (startTime!=null&&!startTime.trim().equals(""))
            params.put("startTime",startTime+" 00:00:00");
        if (endTime!=null&&!endTime.trim().equals(""))
            params.put("endTime",endTime+" 23:59:59");
        params.put("ukStatus",ukStatus);
        params.put("status",status);
        params.put("serveType",serveType);
        params.put("ukeyInfo",ukeyInfo);


        if (provinceID!=null&&provinceId==-1)
            provinceId = provinceID;

        if(provinceId!=-1){
            List<Map<String , Object>> listInfo  = (List<Map<String, Object>>) companyFeign.queryCompanyByProvinceID(provinceId);
            if(listInfo.size()>0){
                params.put("listInfo",listInfo);
                for(int i=0;i<listInfo.size();i++) {
                    compId.add((Integer) listInfo.get(i).get("compID"));
                    params.put("compId",compId);

                }
            }

        }

        if ((serveType==null||serveType.trim().equals(""))&&provinceID==null){
            params.put("limitFlag",true);
            params.put("from",(page.getPage()-1)*page.getPageSize());
            params.put("to",10);
        }
        try {
            page = adminCertService.getUkeyCountInfo(page,params);
            List<UKeyCountInfoVo> ukeyInfos = page.getDatas();
            if(params.get("orderBy").equals("companyName")) {
                Collections.sort(ukeyInfos, new Comparator<UKeyCountInfoVo>() {
                    @Override
                    public int compare(UKeyCountInfoVo o1, UKeyCountInfoVo o2) {
                        Collator cmp = Collator.getInstance(java.util.Locale.CHINA);
                        String name1 = o1.getCompanyName();
                        String name2 = o2.getCompanyName();
                        return cmp.compare(name1, name2);
                    }
                });
            } else if(params.get("orderBy").equals("companyName desc")) {
                Collections.sort(ukeyInfos, new Comparator<UKeyCountInfoVo>() {
                    @Override
                    public int compare(UKeyCountInfoVo o1, UKeyCountInfoVo o2) {
                        Collator cmp = Collator.getInstance(java.util.Locale.CHINA);
                        String name1 = o1.getCompanyName();
                        String name2 = o2.getCompanyName();
                        return cmp.compare(name2, name1);
                    }
                });
            }
            return ServerResponse.createBySuccess(page);
        }catch (Exception e){
            logger.error("获取ukey数量失败！"+e.getMessage(),e);
            return ServerResponse.createByErrorMsg("获取ukey数量失败！");
        }
    }

    @RequestMapping(value = "exportUkeyCountInfo.ajax")
    public ServerResponse exportUkeyCountInfo(String startTime,String endTime,Integer status,String orderBy,Integer ukStatus,
                                              Integer provinceID,String serveType,String ukeyInfo,
                                              HttpServletRequest request,HttpServletResponse response){
        Integer provinceId = (Integer) SessionContext.getContext().getSession(request).getAttribute("province");
        if (provinceId!=-1)
            provinceID = provinceId;
        Map<String,Object> params = new HashMap<>();
        List<Integer> compId =  new ArrayList<Integer>();

        if (orderBy==null|| orderBy.trim().equals("")){
            params.put("orderBy","createDate desc");
        }else {
            params.put("orderBy",orderBy);
        }

        if (startTime!=null&&!startTime.trim().equals(""))
            params.put("startTime",startTime+" 00:00:00");
        if (endTime!=null&&!endTime.trim().equals(""))
            params.put("endTime",endTime+" 23:59:59");
        params.put("status",status);
        params.put("ukStatus",ukStatus);
        params.put("serveType",serveType);
        params.put("ukeyInfo",ukeyInfo);


        if (provinceID!=null&&provinceId==-1)
            provinceId = provinceID;

        if(provinceId!=-1){
            List<Map<String , Object>> listInfo  = (List<Map<String, Object>>) companyFeign.queryCompanyByProvinceID(provinceId);
            if(listInfo.size()>0){
                params.put("listInfo",listInfo);
                for(int i=0;i<listInfo.size();i++) {
                    compId.add(Integer.parseInt(listInfo.get(i).get("compID").toString()));
                    params.put("compId",compId);

                }
            }

        }
        try {
            String path = adminCertService.writeExcelWithModel(params,request,response);
            if (path!=null&&path.equals("IsTooLong"))
                return ServerResponse.createByErrorMsg("数据超过10000条，请更换条件分批导出！");
            return ServerResponse.createBySuccess("导出成功！",path);
        }catch (Exception e){
            logger.error("导出失败！"+e.getMessage(),e);
            return ServerResponse.createByErrorMsg("导出失败！");
        }
    }

}

