package com.edip.mapper;

import com.edip.entity.Project;
import com.edip.entity.ProjectExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface ProjectMapper {
    long countByExample(ProjectExample example);

    int deleteByExample(ProjectExample example);

    int deleteByPrimaryKey(Integer proid);

    int insert(Project record);

    int insertSelective(Project record);

    List<Project> selectByExample(ProjectExample example);

    Project selectByPrimaryKey(Integer proid);

    int updateByExampleSelective(@Param("record") Project record, @Param("example") ProjectExample example);

    int updateByExample(@Param("record") Project record, @Param("example") ProjectExample example);

    int updateByPrimaryKeySelective(Project record);

    int updateByPrimaryKey(Project record);
    List<Project> queryLeaveData(Map<String, Object> map);
    List<Integer> updateStatus();
    void updatestaut2(Map<String, Object> map);
    List<Map<String,Object>>updateStatus3();
    void updateStatus4(Map<String, Object> map);
    List<Map<String,Object>>updateStatus5();
}