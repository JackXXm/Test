package com.edip.task;

import com.edip.entity.*;
import com.edip.exception.BaseException;
import com.edip.mapper.AdminBillMapper;
import com.edip.mapper.AdminCertMapper;
import com.edip.mapper.AdminCompanyBenefitDetailMapper;
import com.edip.vo.AdminCertVo;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Slf4j
@Component
public class TimingTaskJob {
    private static final Logger logger = LoggerFactory.getLogger(TimingTaskJob.class);

    @Autowired
    private AdminCertMapper adminCertMapper;
    @Autowired
    private AdminBillMapper adminBillMapper;
    @Autowired
    private AdminCompanyBenefitDetailMapper adminCompanyBenefitDetailMapper;

    @Scheduled(cron = "0 0 0 * * ?")
    @Transactional
    public void updateCertStatus() {
        Long t1 = System.currentTimeMillis();
        logger.info("开始证书即将过期、过期处理任务:" + new Date());

        try{
            Date date = new Date();
            Calendar rightNow = Calendar.getInstance();
            rightNow.setTime(date);
//            rightNow.add(Calendar.DAY_OF_YEAR,1);//日期加1天

            //修改已过期证书状态
            Date dt1=rightNow.getTime();

            //proc invalidated cert
            AdminCertExample certExample = new AdminCertExample();
            AdminCertExample.Criteria criteria = certExample.createCriteria();
            criteria.andInvaliddateLessThan(dt1);
            criteria.andStatusNotEqualTo(AdminCertVo.CERT_EXPIRED); //未失效的证书
            criteria.andStatusNotEqualTo(AdminCertVo.CERT_REVOKE); //未吊销的证书
            criteria.andStatusNotEqualTo(AdminCertVo.CERT_AUDITNOPASS); //未审批失败的证书
            criteria.andStatusNotEqualTo(AdminCertVo.CERT_TOAUDIT);//待审批的不处理
            criteria.andStatusNotEqualTo(AdminCertVo.CERT_TODOWNLOAD);//待下载的不处理

            List<AdminCert> list = adminCertMapper.selectByExample(certExample);
            if(null != list && list.size() >0){
                //invalidate cert records
                list.forEach(cert ->InvalidCert(cert));
            }

            //修改即将过期证书状态
            rightNow.add(Calendar.DAY_OF_YEAR,30);//日期加30天
            dt1=rightNow.getTime();

            certExample = new AdminCertExample();
            AdminCertExample.Criteria criteria1 = certExample.createCriteria();
            criteria1.andInvaliddateLessThan(dt1);
            criteria1.andStatusNotEqualTo(AdminCertVo.CERT_EXPIRED); //未失效的证书
            criteria1.andStatusNotEqualTo(AdminCertVo.CERT_REVOKE); //未吊销的证书
            criteria1.andStatusNotEqualTo(AdminCertVo.CERT_AUDITNOPASS); //未审批失败的证书
            criteria1.andStatusNotEqualTo(AdminCertVo.CERT_EXPIRING);//即将过期的不重复处理
            criteria1.andStatusNotEqualTo(AdminCertVo.CERT_TOAUDIT);//待审批的不处理
            criteria1.andStatusNotEqualTo(AdminCertVo.CERT_TODOWNLOAD);//待下载的不处理

            List<AdminCert> list1 = adminCertMapper.selectByExample(certExample);

            if(null != list1 && list1.size() >0){
                list1.forEach(cert ->remindCert(cert));
            }
            Long end = System.currentTimeMillis();
            logger.info("结束证书、资质过期处理任务:" + new Date() + "执行时间长：" + (end - t1) + "毫秒");

            //抛出异常，数据还原
            //throw new BaseException("lalalala");
        }catch (Exception e){
            logger.error(e.getMessage(),e);
            throw new BaseException("修改证书状态失败！");
        }
    }

    private void remindCert(AdminCert cert) {
        //更新cert状态为预过期
        AdminCertWithBLOBs updateCert = new AdminCertWithBLOBs();
        updateCert.setCertID(cert.getCertID());
        updateCert.setStatus(AdminCertVo.CERT_EXPIRING);
        adminCertMapper.updateByPrimaryKeySelective(updateCert);
    }

    private void InvalidCert(AdminCert cert) {
        //更新cert状态为预过期
        AdminCertWithBLOBs updateCert = new AdminCertWithBLOBs();
        updateCert.setCertID(cert.getCertID());
        updateCert.setStatus(AdminCertVo.CERT_EXPIRED);
        adminCertMapper.updateByPrimaryKeySelective(updateCert);
    }

    @Scheduled(cron = "0 30 0 * * ?")
    @Transactional
    public void updateBillFreeDate(){
        Long t1 = System.currentTimeMillis();
        logger.info("开始修改账单免费日期任务:" + new Date());

        try{
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            List<AdminCompanyBenefitDetail> list =adminCompanyBenefitDetailMapper.getCompanyBenefitDetailByDate(sdf.format(new Date()));
            list.forEach(adminCompanyBenefitDetail -> {
                AdminBillExample example = new AdminBillExample();
                example.createCriteria().andCompIDEqualTo(adminCompanyBenefitDetail.getCompid());
                List<AdminBill> adminBills = adminBillMapper.selectByExample(example);
                if (adminBills!=null&&adminBills.size()>0){
                    adminBills.get(0).setFreeDate(adminCompanyBenefitDetail.getEndTime());
                    adminBillMapper.updateByPrimaryKeySelective(adminBills.get(0));
                }
            });
            Long end = System.currentTimeMillis();
            logger.info("结束修改账单免费日期任务:" + new Date() + "执行时间长：" + (end - t1) + "毫秒");

            //抛出异常，数据还原
            //throw new BaseException("lalalala");
        }catch (Exception e){
            logger.error(e.getMessage(),e);
            throw new BaseException("修改账单免费日期任务失败！");
        }
    }

    /*
        @Scheduled(fixedRate = 5000)

        public void scheduled1() {

            log.info("=====>>>>>使用fixedRate{}", System.currentTimeMillis());

        }

        @Scheduled(fixedDelay = 5000)

        public void scheduled2() {

            log.info("=====>>>>>fixedDelay{}",System.currentTimeMillis());

        }
    */

}
