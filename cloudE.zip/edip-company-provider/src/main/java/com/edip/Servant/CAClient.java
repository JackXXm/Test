package com.edip.Servant;

import com.edip.util.CertificateConstant;
import com.edip.util.CertificateProperty;
import com.edip.vo.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.DocumentException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
//import org.dom4j.DocumentException;

/**
 * CAClient.java 2012-8-3 CA客户端操作类
 * 
 * @System: CA 1.0
 * @Description:
 * @Copyright: Copyright (c) 2012
 * @Company: Aspire Technologies
 * @version 1.0
 * @author: zhangjie
 */
@Component
public class CAClient {
	private static final Log logger = LogFactory.getLog(CAClient.class);

	public CAClient() {

	}

	/**
	 * @description: 申请企业证书
	 * @param applyEntCertReqVO
	 *            申请企业证书请求VO
	 * @return CertResponseVO
	 * @throws CaCommunicationException
	 * @throws DocumentException
	 */
//	public static CertResponseVO applyEntcert(
//			ApplyEntCertReqVO applyEntCertReqVO)
//			throws CaCommunicationException, DocumentException {
//		logger.debug("Enter into applyEntcert of CAClient!******");
//		String url = CertificateProperty.getProperty("applyEntCert_url");
//		String reqXml = applyEntCertReqVO.toXML();
//		String responseXml = XFireClient.webServiceReq(
//				CertificateConstant.OPERATION_NAME_APPENTCERT, url, reqXml);
//		CertResponseVO certResponseVO = new CertResponseVO(responseXml);// 将响应xml转化为VO
//
//		return certResponseVO;
//	}

	/**
	 * @description: 下载证书
	 * @param downloadCertReqVO
	 *            证书下载请求VO
	 * @return CertResponseVO
	 * @throws CaCommunicationException
	 * @throws DocumentException
	 */

	private static String DOWNLOADCERT_URL;
	@Value("${downloadCert_url}")
	public void setDOWNLOADCERT_URL(String DOWNLOADCERT_URL) {
		this.DOWNLOADCERT_URL = DOWNLOADCERT_URL;
	}
	private static String REVOKECERT_URL;
	@Value("${updateCert_url}")
	public void setREVOKECERT_URL(String REVOKECERT_URL) {
		this.REVOKECERT_URL = REVOKECERT_URL;
	}
	private static String UPDATECERT_URL;
	@Value("${updateCert_url}")
	public void setUPDATECERT_URL(String UPDATECERT_URL) {
		this.UPDATECERT_URL = UPDATECERT_URL;
	}
	private static String APPLYENTCERT_URL;
	@Value("${applyEntCert_url}")
	public void setAPPLYENTCERT_URL(String APPLYENTCERT_URL) {
		this.APPLYENTCERT_URL = APPLYENTCERT_URL;
	}
	public static CertResponseVO downloadCert(
			DownloadCertReqVO downloadCertReqVO)
			throws Exception {
		logger.debug("Enter into downloadCert of CAClient!******");
		String url = null;
		String reqXml = null;
		String responseXml = null;
		CertResponseVO certResponseVO = null;

		reqXml = downloadCertReqVO.toXML();
		responseXml = XFireClient.webServiceReq(
				CertificateConstant.OPERATION_NAME_DOWNLOADCERT, DOWNLOADCERT_URL, reqXml);
		certResponseVO = new CertResponseVO(responseXml);// 将响应xml转化为VO

		return certResponseVO;
	}

	/**
	 * 吊销证书
	 * 
	 * @param revokeCertReqVO
	 * @return
	 * @throws CaCommunicationException
	 * @throws DocumentException
	 */
	public static RevokeCertRespVO revokeCert(RevokeCertReqVO revokeCertReqVO)
			throws Exception {
		logger.debug("Enter into revokeCert of CAClient!******");
		RevokeCertRespVO revokeCertRespVO = null;
		String url = CertificateProperty.getProperty("revokeCert_url");
		String reqXml = revokeCertReqVO.toXML();
		String responseXml = null;
		responseXml = XFireClient.webServiceReq(
				CertificateConstant.OPERATION_NAME_REVOKECERT, REVOKECERT_URL, reqXml);
		revokeCertRespVO = new RevokeCertRespVO(responseXml);
		return revokeCertRespVO;
	}
//
//	public static UpdateCertRespVO updateCert(UpdateCertReqVO updateCertReqVO)
//			throws CaCommunicationException, DocumentException {
//		logger.debug("Enter into revokeCert of CAClient!********");
//		UpdateCertRespVO updateCertRespVO = null;
//		String url = CertificateProperty.getProperty("updateCert_url");
//		String reqXml = updateCertReqVO.toXML();
//		String responseXml = null;
//		responseXml = XFireClient.webServiceReq(
//				CertificateConstant.OPERATION_NAME_UPDATECERT, url, reqXml);
//		updateCertRespVO = new UpdateCertRespVO(responseXml);
//		return updateCertRespVO;
//	}

}
