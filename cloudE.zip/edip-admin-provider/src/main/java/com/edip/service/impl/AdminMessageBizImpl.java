package com.edip.service.impl;

import java.util.List;

import com.edip.entity.AdminMessage;
import com.edip.entity.AdminMessageExample;
import com.edip.mapper.AdminMessageMapper;
import com.edip.mapper.AdminMessagestatusMapper;
import com.edip.service.AdminMessageBiz;
import com.edip.utils.AdminMessageConvert;
import com.edip.utils.AdminMessageStatusUtil;
import com.edip.utils.AdminMessageVoConvert;
import com.edip.vo.AdminMessageVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by qiaoxiaolong on 2017/5/9.
 */
@Service("messageBiz")
public class AdminMessageBizImpl implements AdminMessageBiz {
    private static final Logger LOGGER = LoggerFactory.getLogger(AdminMessageBizImpl.class);
    @Autowired
    protected AdminMessageMapper adminMessageMapper;
    @Autowired
    protected AdminMessagestatusMapper messagestatusMapper;

    /**
     * 查询状态正常的 代办  按照时间倒叙排列--sp端的
     *
     * @return List<MessageVo>  返回消息业务类
     */
    @Override
    public List<AdminMessageVo> selectByExample(List<Integer> listCompId, Integer accountID, List<Integer> msgTypeList,
												String domain) {
        List<AdminMessage> list = null;
        try {
            Integer starus = AdminMessageStatusUtil.MESSAGE_SUCCESS_FLAG;
            Integer from = 0;
            Integer to = 100000000;
            list = adminMessageMapper.selectByPage(listCompId, starus, accountID, from, to, domain, msgTypeList);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            throw new RuntimeException(e.getMessage());
        }
        return AdminMessageVoConvert.convert(list);
    }

    /**
     * 插入代办
     *
     * @param messageVo 业务类
     * @return 返回主键
     */
    @Override
    public int insert(AdminMessageVo messageVo) {
        if (null == messageVo) {
            LOGGER.warn("MessageVo为空");
            throw new RuntimeException("MessageVo为空");
        }
		AdminMessage message = AdminMessageConvert.convert(messageVo);
        return adminMessageMapper.insert(message);
    }

    /**
     * 根据主键更新
     *
     * @param messageVo 业务类
     * @return int
     */

    @Override
    public int updateByPrimaryKey(AdminMessageVo messageVo) {
        if (null == messageVo) {
            LOGGER.warn("MessageVo为空");
            throw new RuntimeException("MessageVo为空");
        }
		AdminMessage message = AdminMessageConvert.convert(messageVo);
        return adminMessageMapper.updateByPrimaryKey(message);
    }
//
//    @Override
//    public int updateByExample(MessageVo messageVo, MessageExample messageExample) {
//        if (null == messageVo) {
//            LOGGER.warn("MessageVo为空");
//            throw new BaseException("MessageVo为空");
//        }
//        Message message = MessageConvert.convert(messageVo);
//        return messageMapper.updateByExampleSelective(message, messageExample);
//    }
//
	@Override
	public List<AdminMessage> selectByExample(AdminMessageExample messageExample) {

		return adminMessageMapper.selectByExample(messageExample);
	}
//
//	@Override
//	public int updateStatus(MessageVo messageVo) {
//		   if (null == messageVo) {
//	            LOGGER.warn("MessageVo为空");
//	            throw new BaseException("MessageVo为空");
//	        }
//	        Message message = MessageConvert.convert(messageVo);
//		return messageMapper.updateStatus(message);
//	}
//
//	@Override
//	public List<Message> selectMsgId(MessageVo messageVo) {
//		  if (null == messageVo) {
//	            LOGGER.warn("MessageVo为空");
//	            throw new BaseException("MessageVo为空");
//	        }
//	        Message message = MessageConvert.convert(messageVo);
//		return messageMapper.selectMsgId(message);
//	}
//
//	@Override
//	public Message searchMessageByMsgID(MessageVo messageVo) {
//		// TODO Auto-generated method stub
//		return messageMapper.searchMessageByMsgID(messageVo);
//	}
//
//	@Override
//	public int editMessageByMsgID(MessageVo messageVo) {
//
//		return messageMapper.editMessageByMsgID(messageVo);
//	}
//
//	@Override
//	public int updateMessageByMsgID(MessageVo messageVo) {
//
//		return messageMapper.updateMessageByMsgID(messageVo);
//	}
//
//	@Override
//	public int editMessageInfoByMsgID(MessageVo messageVo) {
//		// TODO Auto-generated method stub
//		return messageMapper.editMessageInfoByMsgID(messageVo);
//	}
//
//	@Override
//	public Integer 	delMessageInfo(Integer msgID) {
//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("msgID", msgID);
//		return messageMapper.delMessage(map);
//
//	}
//
//	@Override
//	public void messageUpdateRead(Integer msgId, Integer status) {
//		MessageVo messageVo = new MessageVo();
//		messageVo.setMsgID(msgId);
//		messageVo.setStatus(status);
//		messageMapper.messageUpdateRead(messageVo);
//
//	}
}
