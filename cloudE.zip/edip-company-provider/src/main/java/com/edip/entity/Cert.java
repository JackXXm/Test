package com.edip.entity;

import java.util.Date;

public class Cert {
    private Integer certID;

    private Integer compID;

    private Integer accountID;

    private String billAccount;

    private Integer billNum;

    private Integer billFlag;

    private String certSN;

    private String ukeyCode;

    private Integer deliverFlag;

    private Date activeDate;

    private Date validDate;

    private Date invalidDate;

    private Integer status;

    private Date createDate;

    private Date lupDate;

    private Integer ukStatus;

    private Date billTime;

    private String txcode;

    private Integer userid;

    private  Integer operID;

    private Integer provinceID;

    private Integer cityID;

    private Integer areaID;

    private String compName;

    public Integer getProvinceID() {
        return provinceID;
    }

    public void setProvinceID(Integer provinceID) {
        this.provinceID = provinceID;
    }

    public Integer getCityID() {
        return cityID;
    }

    public void setCityID(Integer cityID) {
        this.cityID = cityID;
    }

    public Integer getAreaID() {
        return areaID;
    }

    public void setAreaID(Integer areaID) {
        this.areaID = areaID;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public Integer getOperID() {
        return operID;
    }

    public void setOperID(Integer operID) {
        this.operID = operID;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Integer getCertID() {
        return certID;
    }

    public void setCertID(Integer certID) {
        this.certID = certID;
    }

    public Integer getCompID() {
        return compID;
    }

    public void setCompID(Integer compID) {
        this.compID = compID;
    }

    public Integer getAccountID() {
        return accountID;
    }

    public void setAccountID(Integer accountID) {
        this.accountID = accountID;
    }

    public String getBillAccount() {
        return billAccount;
    }

    public void setBillAccount(String billAccount) {
        this.billAccount = billAccount == null ? null : billAccount.trim();
    }

    public Integer getBillNum() {
        return billNum;
    }

    public void setBillNum(Integer billNum) {
        this.billNum = billNum;
    }

    public Integer getBillFlag() {
        return billFlag;
    }

    public void setBillFlag(Integer billFlag) {
        this.billFlag = billFlag;
    }

    public String getCertSN() {
        return certSN;
    }

    public void setCertSN(String certSN) {
        this.certSN = certSN == null ? null : certSN.trim();
    }

    public String getUkeyCode() {
        return ukeyCode;
    }

    public void setUkeyCode(String ukeyCode) {
        this.ukeyCode = ukeyCode == null ? null : ukeyCode.trim();
    }

    public Integer getDeliverFlag() {
        return deliverFlag;
    }

    public void setDeliverFlag(Integer deliverFlag) {
        this.deliverFlag = deliverFlag;
    }

    public Date getActiveDate() {
        return activeDate;
    }

    public void setActiveDate(Date activeDate) {
        this.activeDate = activeDate;
    }

    public Date getValidDate() {
        return validDate;
    }

    public void setValidDate(Date validDate) {
        this.validDate = validDate;
    }

    public Date getInvalidDate() {
        return invalidDate;
    }

    public void setInvalidDate(Date invalidDate) {
        this.invalidDate = invalidDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getLupDate() {
        return lupDate;
    }

    public void setLupDate(Date lupDate) {
        this.lupDate = lupDate;
    }

    public Integer getUkStatus() {
        return ukStatus;
    }

    public void setUkStatus(Integer ukStatus) {
        this.ukStatus = ukStatus;
    }

    public Date getBillTime() {
        return billTime;
    }

    public void setBillTime(Date billTime) {
        this.billTime = billTime;
    }

    public String getTxcode() {
        return txcode;
    }

    public void setTxcode(String txcode) {
        this.txcode = txcode == null ? null : txcode.trim();
    }

}