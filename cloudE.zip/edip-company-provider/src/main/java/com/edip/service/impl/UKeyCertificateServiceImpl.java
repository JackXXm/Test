package com.edip.service.impl;

import com.edip.controller.ChinaAreaClient;
import com.edip.dto.ServerResponse;
import com.edip.entity.Cert;
import com.edip.entity.CertExample;
import com.edip.feign.AccountFeign;
import com.edip.mapper.CertMapper;
import com.edip.mapper.StampMapperVo;
import com.edip.service.UKeyCertificateService;
import com.edip.vo.CertVo;
import com.edip.vo.UKeyVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service("uKeyCertificateService")
public class UKeyCertificateServiceImpl implements UKeyCertificateService {
	@Autowired
	@Qualifier("stampMapperVo")
	private StampMapperVo stampMapperVo;

	@Autowired
	@Qualifier("certMapper")
	private CertMapper certMapper;
	@Autowired
	private ChinaAreaClient chinaAreaClient;
	@Autowired
	private AccountFeign accountFeign;

	public List<Map<String, Object>> checkMessage(UKeyVo uKeyVo, Map<String, Object> map) {
		List<Map<String, Object>> list = stampMapperVo.checkMessage(map);
		
		for(int i=0;i<list.size();i++){
			if(list.size()>1){
				Map<String,Object>mm=list.get(i);
				int accountID = Integer.parseInt(mm.get("accountID").toString());
//				Account account = accountMapper.selectByPrimaryKey(accountID);
//				String aliasName = account.getAliasName();
//				String idCardNo = account.getIdCardNo();
//				String idCardNoURL = account.getIdCardNoURL();
				ServerResponse pcStr = chinaAreaClient.getPCStr(Integer.parseInt(mm.get("provinceID").toString()), Integer.parseInt(mm.get("cityID").toString()));
				Object accResult =accountFeign.getAccountInfo(accountID).getData();
				if(Integer.parseInt(mm.get("status").toString())!=-1){
					list.set(0, mm);
					mm.put("name1", mm.get("name").toString());
					mm.put("account",accResult);
					mm.put("provinceID", pcStr.getData());
					break;
				}else if(Integer.parseInt(mm.get("status").toString())==-1){
					mm.put("stampContent", "");
					mm.put("stampType", "");
					mm.put("name1", "");
					mm.put("account",accResult);
					mm.put("provinceID", pcStr.getData());

				}
			}else if(list.size()==1){
				Map<String,Object>mm=list.get(i);
				int accountID = Integer.parseInt(mm.get("accountID").toString());
//					Account account = accountMapper.selectByPrimaryKey(accountID);
//					String aliasName = account.getAliasName();
//					String idCardNo = account.getIdCardNo();
//					String idCardNoURL = account.getIdCardNoURL();
				ServerResponse pcStr = chinaAreaClient.getPCStr(Integer.parseInt(mm.get("provinceID").toString()), Integer.parseInt(mm.get("cityID").toString()));
				Object accResult = accountFeign.getAccountInfo(accountID).getData();
				if(Integer.parseInt(mm.get("status").toString())==-1){
					mm.put("stampContent", "");
					mm.put("stampType", "");
					mm.put("name1", "");
				}else{
					mm.put("name1", mm.get("name").toString());
				}
				mm.put("account",accResult);
				mm.put("provinceID", pcStr.getData());
			}
//
		}
		return list;
	}
	public int queryCert(Integer compID) {
		CertExample cert = new CertExample ();
		List<Integer> status = new ArrayList<Integer>();
		status.add(CertVo.CERT_OK);
		status.add(CertVo.CERT_EXPIRING);
		status.add(CertVo.CERT_EXPIRED);
		status.add(CertVo.CERT_TOAUDIT);
		status.add(CertVo.CERT_TODOWNLOAD);
		CertExample.Criteria criteria = cert.createCriteria();
		criteria.andCompidEqualTo(compID);
		//criteria.andStatusIn(status);
		criteria.andStatusNotEqualTo(4);
		List<Cert> list = certMapper.selectByExample(cert);
		
		int amount = 0;
		if(list.size()>0){
			amount=1;
		}
		return amount;
	}

}
