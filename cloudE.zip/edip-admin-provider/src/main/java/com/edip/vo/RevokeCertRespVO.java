package com.edip.vo;

import java.io.StringReader;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/**
 * 吊销证书返回消息实体
 * @author zhangjie_d
 *
 */
public class RevokeCertRespVO {

	private String result;//返回结果： 0-	申请处理成功 s1-	受理成功，需要审核2-	失败
	
	private String errormsg;//表示异常的描述
	
	private String transactioncode;//业务受理号

	public RevokeCertRespVO(){
		
	}
	
	public RevokeCertRespVO(String xml) throws DocumentException {
		toBean(xml);
	}	
	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getErrormsg() {
		return errormsg;
	}

	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}

	public String getTransactioncode() {
		return transactioncode;
	}

	public void setTransactioncode(String transactioncode) {
		this.transactioncode = transactioncode;
	}
	
	private void toBean(String xml) throws DocumentException {
		// 解析xml
		SAXReader reader = new SAXReader();
		Document document = reader.read(new StringReader(xml));
		Element body = document.getRootElement();
		this.result = body.element("result").getText();
		this.errormsg = body.element("errormsg").getText();
		this.transactioncode = body.element("transactioncode").getText();
	}
	
}
