package com.edip.mapper;

import com.edip.entity.AdminCompanyBenefitDetail;
import com.edip.entity.AdminCompanyBenefitDetailExample;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

public interface AdminCompanyBenefitDetailMapper {
    long countByExample(AdminCompanyBenefitDetailExample example);

    int deleteByExample(AdminCompanyBenefitDetailExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(AdminCompanyBenefitDetail record);

    int insertSelective(AdminCompanyBenefitDetail record);

    List<AdminCompanyBenefitDetail> selectByExample(AdminCompanyBenefitDetailExample example);

    AdminCompanyBenefitDetail selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") AdminCompanyBenefitDetail record, @Param("example") AdminCompanyBenefitDetailExample example);

    int updateByExample(@Param("record") AdminCompanyBenefitDetail record, @Param("example") AdminCompanyBenefitDetailExample example);

    int updateByPrimaryKeySelective(AdminCompanyBenefitDetail record);

    int updateByPrimaryKey(AdminCompanyBenefitDetail record);

    List<AdminCompanyBenefitDetail> getCompanyBenefitDetailByDate(@Param("startTime") String dt1);
}