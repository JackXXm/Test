package com.edip.service;

import com.edip.entity.Stamp;

import java.util.List;

public interface StampService {
    public List<Stamp>getStampList(String stampName,int companyId,boolean signList,boolean checkReportFlag);
    public int addStamp(Stamp stamp) throws Exception;

    Integer updateStamp (Integer stampID,String tempUrl,Integer compID,String accountName,Integer accountID) throws Exception;

    //印章管理的删除操作
    int deleteData(Integer stampID);
    //企业管理的删除公章操作
    int deleteDataByCompID(Integer compID);

    int deleteData2(Integer companyId);
}
