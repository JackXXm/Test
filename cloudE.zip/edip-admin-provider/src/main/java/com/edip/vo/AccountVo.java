package com.edip.vo;

import java.util.Date;
import java.util.List;

public class AccountVo {
    private Integer accountID;

    private Integer staffID;

    private Integer compID;

    private String name;

    private String idCardNo;

    private String idCardNoURL;

    private String idCardNo2URL;

    private String aliasName;

    private String msisdn;

    private String email;

    private String auditInfo;

    private Date createDate;

    private Integer status;

    private Date beginDate;

    private Date endDate;

    private Date idCardDate;

    private String accountType;

    private int page = 1;

    private int rows = 10;

    private int from = 0;

    private int to = Integer.MAX_VALUE;

    private String beginDateString;

    private String endDateString;

    private List<String> accountTypeList;

    private String conpanyName;

    private String taxNo;

    private String conpanyAddress;

    private String tel;

    private String openBank;

    private String acctNo;

    private String memo;

    private String docUrl;

    private String weituoshuDocExpireTime;	//企业管理员授权委托书失效时间

    private Integer tab;

    private byte[] logoFileUrl;

    private String cityname;

    private Integer provinceID;

    private String roleName;

    private String logoDocUrl;

    private Integer certID;
    //记录此用户持有的证书序列号
    private String certSN;

    public String getLogoDocUrl() {
        return logoDocUrl;
    }

    public void setLogoDocUrl(String logoDocUrl) {
        this.logoDocUrl = logoDocUrl;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Integer getProvinceID() {
        return provinceID;
    }

    public void setProvinceID(Integer provinceID) {
        this.provinceID = provinceID;
    }

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public byte[] getLogoFileUrl() {
        return logoFileUrl;
    }

    public void setLogoFileUrl(byte[] logoFileUrl) {
        this.logoFileUrl = logoFileUrl;
    }

    public Integer getTab() {
        return tab;
    }

    public void setTab(Integer tab) {
        this.tab = tab;
    }

    public String getWeituoshuDocExpireTime() {
        return weituoshuDocExpireTime;
    }

    public void setWeituoshuDocExpireTime(String weituoshuDocExpireTime) {
        this.weituoshuDocExpireTime = weituoshuDocExpireTime;
    }

    public String getDocUrl() {
        return docUrl;
    }

    public void setDocUrl(String docUrl) {
        this.docUrl = docUrl;
    }

    public String getConpanyName() {
        return conpanyName;
    }

    public void setConpanyName(String conpanyName) {
        this.conpanyName = conpanyName;
    }

    public String getTaxNo() {
        return taxNo;
    }

    public void setTaxNo(String taxNo) {
        this.taxNo = taxNo;
    }

    public String getConpanyAddress() {
        return conpanyAddress;
    }

    public void setConpanyAddress(String conpanyAddress) {
        this.conpanyAddress = conpanyAddress;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getOpenBank() {
        return openBank;
    }

    public void setOpenBank(String openBank) {
        this.openBank = openBank;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getIdCardNo2URL() {
        return idCardNo2URL;
    }

    public void setIdCardNo2URL(String idCardNo2URL) {
        this.idCardNo2URL = idCardNo2URL;
    }

    public Date getIdCardDate() {
        return idCardDate;
    }

    public void setIdCardDate(Date idCardDate) {
        this.idCardDate = idCardDate;
    }

    public List<String> getAccountTypeList() {
        return accountTypeList;
    }

    public void setAccountTypeList(List<String> accountTypeList) {
        this.accountTypeList = accountTypeList;
    }

    public int getFrom() {
        return from;
    }

    public void setFrom(int from) {
        this.from = from;
    }

    public int getTo() {
        return to;
    }

    public void setTo(int to) {
        this.to = to;
    }

    public String getBeginDateString() {
        return beginDateString;
    }

    public void setBeginDateString(String beginDateString) {
        this.beginDateString = beginDateString;
    }

    public String getEndDateString() {
        return endDateString;
    }

    public void setEndDateString(String endDateString) {
        this.endDateString = endDateString;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Integer getAccountID() {
        return accountID;
    }

    public void setAccountID(Integer accountID) {
        this.accountID = accountID;
    }

    public Integer getStaffID() {
        return staffID;
    }

    public void setStaffID(Integer staffID) {
        this.staffID = staffID;
    }

    public Integer getCompID() {
        return compID;
    }

    public void setCompID(Integer compID) {
        this.compID = compID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo == null ? null : idCardNo.trim();
    }

    public String getIdCardNoURL() {
        return idCardNoURL;
    }

    public void setIdCardNoURL(String idCardNoURL) {
        this.idCardNoURL = idCardNoURL == null ? null : idCardNoURL.trim();
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName == null ? null : aliasName.trim();
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn == null ? null : msisdn.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getAuditInfo() {
        return auditInfo;
    }

    public void setAuditInfo(String auditInfo) {
        this.auditInfo = auditInfo == null ? null : auditInfo.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }


    public Integer getCertID() {
        return certID;
    }

    public void setCertID(Integer certID) {
        this.certID = certID;
    }

    public String getCertSN() {
        return certSN;
    }

    public void setCertSN(String certSN) {
        this.certSN = certSN;
    }
}
