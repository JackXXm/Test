package com.edip.mapper;

import com.edip.entity.StampChangeResore;
import com.edip.entity.StampChangeResoreExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface StampChangeResoreMapper {
    long countByExample(StampChangeResoreExample example);

    int deleteByExample(StampChangeResoreExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(StampChangeResore record);

    int insertSelective(StampChangeResore record);

    List<StampChangeResore> selectByExample(StampChangeResoreExample example);

    StampChangeResore selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") StampChangeResore record, @Param("example") StampChangeResoreExample example);

    int updateByExample(@Param("record") StampChangeResore record, @Param("example") StampChangeResoreExample example);

    int updateByPrimaryKeySelective(StampChangeResore record);

    int updateByPrimaryKey(StampChangeResore record);
}