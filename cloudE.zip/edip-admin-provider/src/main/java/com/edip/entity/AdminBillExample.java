package com.edip.entity;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AdminBillExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public AdminBillExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andBillIDIsNull() {
            addCriterion("billID is null");
            return (Criteria) this;
        }

        public Criteria andBillIDIsNotNull() {
            addCriterion("billID is not null");
            return (Criteria) this;
        }

        public Criteria andBillIDEqualTo(Integer value) {
            addCriterion("billID =", value, "billID");
            return (Criteria) this;
        }

        public Criteria andBillIDNotEqualTo(Integer value) {
            addCriterion("billID <>", value, "billID");
            return (Criteria) this;
        }

        public Criteria andBillIDGreaterThan(Integer value) {
            addCriterion("billID >", value, "billID");
            return (Criteria) this;
        }

        public Criteria andBillIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("billID >=", value, "billID");
            return (Criteria) this;
        }

        public Criteria andBillIDLessThan(Integer value) {
            addCriterion("billID <", value, "billID");
            return (Criteria) this;
        }

        public Criteria andBillIDLessThanOrEqualTo(Integer value) {
            addCriterion("billID <=", value, "billID");
            return (Criteria) this;
        }

        public Criteria andBillIDIn(List<Integer> values) {
            addCriterion("billID in", values, "billID");
            return (Criteria) this;
        }

        public Criteria andBillIDNotIn(List<Integer> values) {
            addCriterion("billID not in", values, "billID");
            return (Criteria) this;
        }

        public Criteria andBillIDBetween(Integer value1, Integer value2) {
            addCriterion("billID between", value1, value2, "billID");
            return (Criteria) this;
        }

        public Criteria andBillIDNotBetween(Integer value1, Integer value2) {
            addCriterion("billID not between", value1, value2, "billID");
            return (Criteria) this;
        }

        public Criteria andCdrTypeIsNull() {
            addCriterion("cdrType is null");
            return (Criteria) this;
        }

        public Criteria andCdrTypeIsNotNull() {
            addCriterion("cdrType is not null");
            return (Criteria) this;
        }

        public Criteria andCdrTypeEqualTo(Integer value) {
            addCriterion("cdrType =", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeNotEqualTo(Integer value) {
            addCriterion("cdrType <>", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeGreaterThan(Integer value) {
            addCriterion("cdrType >", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("cdrType >=", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeLessThan(Integer value) {
            addCriterion("cdrType <", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeLessThanOrEqualTo(Integer value) {
            addCriterion("cdrType <=", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeIn(List<Integer> values) {
            addCriterion("cdrType in", values, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeNotIn(List<Integer> values) {
            addCriterion("cdrType not in", values, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeBetween(Integer value1, Integer value2) {
            addCriterion("cdrType between", value1, value2, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("cdrType not between", value1, value2, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeIsNull() {
            addCriterion("cdrsubType is null");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeIsNotNull() {
            addCriterion("cdrsubType is not null");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeEqualTo(Integer value) {
            addCriterion("cdrsubType =", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeNotEqualTo(Integer value) {
            addCriterion("cdrsubType <>", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeGreaterThan(Integer value) {
            addCriterion("cdrsubType >", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("cdrsubType >=", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeLessThan(Integer value) {
            addCriterion("cdrsubType <", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeLessThanOrEqualTo(Integer value) {
            addCriterion("cdrsubType <=", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeIn(List<Integer> values) {
            addCriterion("cdrsubType in", values, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeNotIn(List<Integer> values) {
            addCriterion("cdrsubType not in", values, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeBetween(Integer value1, Integer value2) {
            addCriterion("cdrsubType between", value1, value2, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("cdrsubType not between", value1, value2, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andTotalCountIsNull() {
            addCriterion("totalCount is null");
            return (Criteria) this;
        }

        public Criteria andTotalCountIsNotNull() {
            addCriterion("totalCount is not null");
            return (Criteria) this;
        }

        public Criteria andTotalCountEqualTo(Integer value) {
            addCriterion("totalCount =", value, "totalCount");
            return (Criteria) this;
        }

        public Criteria andTotalCountNotEqualTo(Integer value) {
            addCriterion("totalCount <>", value, "totalCount");
            return (Criteria) this;
        }

        public Criteria andTotalCountGreaterThan(Integer value) {
            addCriterion("totalCount >", value, "totalCount");
            return (Criteria) this;
        }

        public Criteria andTotalCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("totalCount >=", value, "totalCount");
            return (Criteria) this;
        }

        public Criteria andTotalCountLessThan(Integer value) {
            addCriterion("totalCount <", value, "totalCount");
            return (Criteria) this;
        }

        public Criteria andTotalCountLessThanOrEqualTo(Integer value) {
            addCriterion("totalCount <=", value, "totalCount");
            return (Criteria) this;
        }

        public Criteria andTotalCountIn(List<Integer> values) {
            addCriterion("totalCount in", values, "totalCount");
            return (Criteria) this;
        }

        public Criteria andTotalCountNotIn(List<Integer> values) {
            addCriterion("totalCount not in", values, "totalCount");
            return (Criteria) this;
        }

        public Criteria andTotalCountBetween(Integer value1, Integer value2) {
            addCriterion("totalCount between", value1, value2, "totalCount");
            return (Criteria) this;
        }

        public Criteria andTotalCountNotBetween(Integer value1, Integer value2) {
            addCriterion("totalCount not between", value1, value2, "totalCount");
            return (Criteria) this;
        }

        public Criteria andUsedCountIsNull() {
            addCriterion("usedCount is null");
            return (Criteria) this;
        }

        public Criteria andUsedCountIsNotNull() {
            addCriterion("usedCount is not null");
            return (Criteria) this;
        }

        public Criteria andUsedCountEqualTo(Integer value) {
            addCriterion("usedCount =", value, "usedCount");
            return (Criteria) this;
        }

        public Criteria andUsedCountNotEqualTo(Integer value) {
            addCriterion("usedCount <>", value, "usedCount");
            return (Criteria) this;
        }

        public Criteria andUsedCountGreaterThan(Integer value) {
            addCriterion("usedCount >", value, "usedCount");
            return (Criteria) this;
        }

        public Criteria andUsedCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("usedCount >=", value, "usedCount");
            return (Criteria) this;
        }

        public Criteria andUsedCountLessThan(Integer value) {
            addCriterion("usedCount <", value, "usedCount");
            return (Criteria) this;
        }

        public Criteria andUsedCountLessThanOrEqualTo(Integer value) {
            addCriterion("usedCount <=", value, "usedCount");
            return (Criteria) this;
        }

        public Criteria andUsedCountIn(List<Integer> values) {
            addCriterion("usedCount in", values, "usedCount");
            return (Criteria) this;
        }

        public Criteria andUsedCountNotIn(List<Integer> values) {
            addCriterion("usedCount not in", values, "usedCount");
            return (Criteria) this;
        }

        public Criteria andUsedCountBetween(Integer value1, Integer value2) {
            addCriterion("usedCount between", value1, value2, "usedCount");
            return (Criteria) this;
        }

        public Criteria andUsedCountNotBetween(Integer value1, Integer value2) {
            addCriterion("usedCount not between", value1, value2, "usedCount");
            return (Criteria) this;
        }

        public Criteria andRemainCountIsNull() {
            addCriterion("remainCount is null");
            return (Criteria) this;
        }

        public Criteria andRemainCountIsNotNull() {
            addCriterion("remainCount is not null");
            return (Criteria) this;
        }

        public Criteria andRemainCountEqualTo(Integer value) {
            addCriterion("remainCount =", value, "remainCount");
            return (Criteria) this;
        }

        public Criteria andRemainCountNotEqualTo(Integer value) {
            addCriterion("remainCount <>", value, "remainCount");
            return (Criteria) this;
        }

        public Criteria andRemainCountGreaterThan(Integer value) {
            addCriterion("remainCount >", value, "remainCount");
            return (Criteria) this;
        }

        public Criteria andRemainCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("remainCount >=", value, "remainCount");
            return (Criteria) this;
        }

        public Criteria andRemainCountLessThan(Integer value) {
            addCriterion("remainCount <", value, "remainCount");
            return (Criteria) this;
        }

        public Criteria andRemainCountLessThanOrEqualTo(Integer value) {
            addCriterion("remainCount <=", value, "remainCount");
            return (Criteria) this;
        }

        public Criteria andRemainCountIn(List<Integer> values) {
            addCriterion("remainCount in", values, "remainCount");
            return (Criteria) this;
        }

        public Criteria andRemainCountNotIn(List<Integer> values) {
            addCriterion("remainCount not in", values, "remainCount");
            return (Criteria) this;
        }

        public Criteria andRemainCountBetween(Integer value1, Integer value2) {
            addCriterion("remainCount between", value1, value2, "remainCount");
            return (Criteria) this;
        }

        public Criteria andRemainCountNotBetween(Integer value1, Integer value2) {
            addCriterion("remainCount not between", value1, value2, "remainCount");
            return (Criteria) this;
        }

        public Criteria andRemainderIsNull() {
            addCriterion("remainder is null");
            return (Criteria) this;
        }

        public Criteria andRemainderIsNotNull() {
            addCriterion("remainder is not null");
            return (Criteria) this;
        }

        public Criteria andRemainderEqualTo(Integer value) {
            addCriterion("remainder =", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderNotEqualTo(Integer value) {
            addCriterion("remainder <>", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderGreaterThan(Integer value) {
            addCriterion("remainder >", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderGreaterThanOrEqualTo(Integer value) {
            addCriterion("remainder >=", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderLessThan(Integer value) {
            addCriterion("remainder <", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderLessThanOrEqualTo(Integer value) {
            addCriterion("remainder <=", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderIn(List<Integer> values) {
            addCriterion("remainder in", values, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderNotIn(List<Integer> values) {
            addCriterion("remainder not in", values, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderBetween(Integer value1, Integer value2) {
            addCriterion("remainder between", value1, value2, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderNotBetween(Integer value1, Integer value2) {
            addCriterion("remainder not between", value1, value2, "remainder");
            return (Criteria) this;
        }

        public Criteria andTotalAmountIsNull() {
            addCriterion("totalAmount is null");
            return (Criteria) this;
        }

        public Criteria andTotalAmountIsNotNull() {
            addCriterion("totalAmount is not null");
            return (Criteria) this;
        }

        public Criteria andTotalAmountEqualTo(Integer value) {
            addCriterion("totalAmount =", value, "totalAmount");
            return (Criteria) this;
        }

        public Criteria andTotalAmountNotEqualTo(Integer value) {
            addCriterion("totalAmount <>", value, "totalAmount");
            return (Criteria) this;
        }

        public Criteria andTotalAmountGreaterThan(Integer value) {
            addCriterion("totalAmount >", value, "totalAmount");
            return (Criteria) this;
        }

        public Criteria andTotalAmountGreaterThanOrEqualTo(Integer value) {
            addCriterion("totalAmount >=", value, "totalAmount");
            return (Criteria) this;
        }

        public Criteria andTotalAmountLessThan(Integer value) {
            addCriterion("totalAmount <", value, "totalAmount");
            return (Criteria) this;
        }

        public Criteria andTotalAmountLessThanOrEqualTo(Integer value) {
            addCriterion("totalAmount <=", value, "totalAmount");
            return (Criteria) this;
        }

        public Criteria andTotalAmountIn(List<Integer> values) {
            addCriterion("totalAmount in", values, "totalAmount");
            return (Criteria) this;
        }

        public Criteria andTotalAmountNotIn(List<Integer> values) {
            addCriterion("totalAmount not in", values, "totalAmount");
            return (Criteria) this;
        }

        public Criteria andTotalAmountBetween(Integer value1, Integer value2) {
            addCriterion("totalAmount between", value1, value2, "totalAmount");
            return (Criteria) this;
        }

        public Criteria andTotalAmountNotBetween(Integer value1, Integer value2) {
            addCriterion("totalAmount not between", value1, value2, "totalAmount");
            return (Criteria) this;
        }

        public Criteria andRemainAmountIsNull() {
            addCriterion("remainAmount is null");
            return (Criteria) this;
        }

        public Criteria andRemainAmountIsNotNull() {
            addCriterion("remainAmount is not null");
            return (Criteria) this;
        }

        public Criteria andRemainAmountEqualTo(Integer value) {
            addCriterion("remainAmount =", value, "remainAmount");
            return (Criteria) this;
        }

        public Criteria andRemainAmountNotEqualTo(Integer value) {
            addCriterion("remainAmount <>", value, "remainAmount");
            return (Criteria) this;
        }

        public Criteria andRemainAmountGreaterThan(Integer value) {
            addCriterion("remainAmount >", value, "remainAmount");
            return (Criteria) this;
        }

        public Criteria andRemainAmountGreaterThanOrEqualTo(Integer value) {
            addCriterion("remainAmount >=", value, "remainAmount");
            return (Criteria) this;
        }

        public Criteria andRemainAmountLessThan(Integer value) {
            addCriterion("remainAmount <", value, "remainAmount");
            return (Criteria) this;
        }

        public Criteria andRemainAmountLessThanOrEqualTo(Integer value) {
            addCriterion("remainAmount <=", value, "remainAmount");
            return (Criteria) this;
        }

        public Criteria andRemainAmountIn(List<Integer> values) {
            addCriterion("remainAmount in", values, "remainAmount");
            return (Criteria) this;
        }

        public Criteria andRemainAmountNotIn(List<Integer> values) {
            addCriterion("remainAmount not in", values, "remainAmount");
            return (Criteria) this;
        }

        public Criteria andRemainAmountBetween(Integer value1, Integer value2) {
            addCriterion("remainAmount between", value1, value2, "remainAmount");
            return (Criteria) this;
        }

        public Criteria andRemainAmountNotBetween(Integer value1, Integer value2) {
            addCriterion("remainAmount not between", value1, value2, "remainAmount");
            return (Criteria) this;
        }

        public Criteria andCompIDIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompIDIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompIDEqualTo(Integer value) {
            addCriterion("compID =", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDGreaterThan(Integer value) {
            addCriterion("compID >", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDLessThan(Integer value) {
            addCriterion("compID <", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDIn(List<Integer> values) {
            addCriterion("compID in", values, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compID");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDateEqualTo(Date value) {
            addCriterion("createDate =", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThan(Date value) {
            addCriterion("createDate <", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateIn(List<Date> values) {
            addCriterion("createDate in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andModeIDIsNull() {
            addCriterion("modeID is null");
            return (Criteria) this;
        }

        public Criteria andModeIDIsNotNull() {
            addCriterion("modeID is not null");
            return (Criteria) this;
        }

        public Criteria andModeIDEqualTo(Integer value) {
            addCriterion("modeID =", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDNotEqualTo(Integer value) {
            addCriterion("modeID <>", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDGreaterThan(Integer value) {
            addCriterion("modeID >", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("modeID >=", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDLessThan(Integer value) {
            addCriterion("modeID <", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDLessThanOrEqualTo(Integer value) {
            addCriterion("modeID <=", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDIn(List<Integer> values) {
            addCriterion("modeID in", values, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDNotIn(List<Integer> values) {
            addCriterion("modeID not in", values, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDBetween(Integer value1, Integer value2) {
            addCriterion("modeID between", value1, value2, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDNotBetween(Integer value1, Integer value2) {
            addCriterion("modeID not between", value1, value2, "modeID");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}