package com.edip.config;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.tree.xpath.XPathExpressionEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Config {
    private static final Logger logger = LoggerFactory.getLogger(Config.class);
    private static Configuration configuration = null;
    private static Config config;
    private static final String DEFAULT_CONFIGURATION_FILENAME = "webbas.xml";
    private static String configurationFileName = "webbas.xml";

    private Config() {
        if (configuration == null) {
            refresh();
        }

    }

    public static Config getInstance() {
        if (config == null) {
            config = new Config();
        }

        return config;
    }

    private static void refresh() {
        configuration = ConfigurationHelper.getConfiguration(configurationFileName, 50000L);
        if (configuration == null) {
            logger.error("读portal配置文件失败, 配置文件：" + configurationFileName);
        } else {
            ((XMLConfiguration)configuration).setExpressionEngine(new XPathExpressionEngine());
        }

    }

    public String getTitle() {
        return this.getString("portal/title");
    }

    public boolean isOldPasswordSupport() {
        String support = this.getString("portal/old-password-crypt-support", "on");
        return "on".equalsIgnoreCase(support);
    }

    public boolean isCheckCodeOn() {
        String support = this.getString("portal/checkCode", "false");
        return "true".equalsIgnoreCase(support);
    }

    public boolean isContractAgreementOn() {
        String support = this.getString("portal/contractAgreement", "false");
        return "true".equalsIgnoreCase(support);
    }

    public boolean isRegisterOn() {
        String support = this.getString("portal/is-register-on", "false");
        return "true".equalsIgnoreCase(support);
    }

    public String getRegisterUrl() {
        return this.getString("portal/register-url");
    }

    public boolean isForgotpwdOn() {
        String support = this.getString("portal/is-forgotpwd-on", "false");
        return "true".equalsIgnoreCase(support);
    }

    public String getForgotpwdUrl() {
        return this.getString("portal/forgotpwd-url");
    }

    private String getString(String arg) {
        return configuration == null ? null : configuration.getString(arg);
    }

    private String getString(String arg, String def) {
        return configuration == null ? def : configuration.getString(arg, def);
    }

    public List getDomainList() {
        if (configuration == null) {
            return new LinkedList();
        } else {
            List<Object> domainNameList = configuration.getList("domains/domain");
            List<Object> domainTypeList = configuration.getList("domains/domain/@type");
            List<Object> domainDescList = configuration.getList("domains/domain/@desc");
            List<HashMap<String, String>> result = new ArrayList();

            for(int i = 0; i < domainNameList.size(); ++i) {
                String domainName = (String)domainNameList.get(i);
                String domainType = (String)domainTypeList.get(i);
                String domainDesc = (String)domainDescList.get(i);
                HashMap<String, String> map = new HashMap();
                map.put("domainName", domainName);
                map.put("domainType", domainType);
                map.put("domainDesc", domainDesc);
                result.add(map);
            }

            return result;
        }
    }

    public String getSpDomaminName() {
        return configuration == null ? "SP" : configuration.getString("domains/domain[@type=\"SP\"]", "SP");
    }

    public String getAdminDomaminName() {
        return configuration == null ? "SYS_ADMIN" : configuration.getString("domains/domain[@type=\"ADMIN\"]", "SYS_ADMIN");
    }

    public List getAuthStaffExportDomains() {
        return configuration == null ? null : configuration.getList("auth-staff-export-domains");
    }

    public String getAdminUrl() {
        return this.getString("portal/admin-url");
    }

    public boolean isInvalidPasswordCheckOn() {
        String support = this.getString("portal/is-invalid-password-check", "false");
        return "true".equalsIgnoreCase(support);
    }

    public Integer getInvalidPasswordAlert() {
        return this.getInteger("portal/invalid-password-alert", 3);
    }

    public Integer getMaxInvalidPassword() {
        return this.getInteger("portal/max-invalid-password-number", 5);
    }

    public Integer getAutoLockDays() {
        return this.getInteger("portal/auto-lock-days", 1);
    }

    private Integer getInteger(String key, Integer defaultValue) {
        return configuration == null ? defaultValue : configuration.getInteger(key, defaultValue);
    }

    public String getConfig(String name) {
        return configuration.getString(name);
    }

    public String getDomainName(String ctPath) {
        Object domainName = this.getDomainConfig(ctPath, "name");
        if (domainName == null) {
            logger.info("domainName==null,取ctpath值" + ctPath);
            return ctPath;
        } else {
            return (String)domainName;
        }
    }

    public boolean allowCrossDomain() {
        String cross_domain = this.getString("cross-domain");
        return !"false".equalsIgnoreCase(cross_domain);
    }

    public Object getDomainConfig(String ctPath, String configName) {
        if (configuration == null) {
            return null;
        } else {
            if (ctPath == null || ctPath.equalsIgnoreCase("")) {
                ctPath = "default";
            }

            return configuration.getProperty(ctPath + "-domain/" + configName);
        }
    }
}
