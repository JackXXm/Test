package com.edip.mapper;

import com.edip.entity.ExchangeJobReceiveCompany;
import com.edip.entity.ExchangeJobReceiveCompanyExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ExchangeJobReceiveCompanyMapper {
    long countByExample(ExchangeJobReceiveCompanyExample example);

    int deleteByExample(ExchangeJobReceiveCompanyExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ExchangeJobReceiveCompany record);

    int insertSelective(ExchangeJobReceiveCompany record);

    List<ExchangeJobReceiveCompany> selectByExample(ExchangeJobReceiveCompanyExample example);

    ExchangeJobReceiveCompany selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ExchangeJobReceiveCompany record, @Param("example") ExchangeJobReceiveCompanyExample example);

    int updateByExample(@Param("record") ExchangeJobReceiveCompany record, @Param("example") ExchangeJobReceiveCompanyExample example);

    int updateByPrimaryKeySelective(ExchangeJobReceiveCompany record);

    int updateByPrimaryKey(ExchangeJobReceiveCompany record);
}