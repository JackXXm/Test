package com.edip.vo;

import org.slf4j.LoggerFactory;


/**
 * BaseException.java      2015-3-12
 * 基础异常类
 * @System: CA 1.0
 * @Description:
 * @Copyright: Copyright (c) 2012
 * @Company: Aspire Technologies
 * @version 1.0
 * @author: zhangjie
 */
@SuppressWarnings("serial")
public class AdminBaseException extends Exception{

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AdminBaseException.class);
	
	public AdminBaseException() {
		super();
	}

	public AdminBaseException(String msg) {
		super(msg);
		//why logger error??? sunchong
        LOGGER.error(msg);
	}

	public AdminBaseException(String submodul, String msg) {
		super(submodul + ":" + msg);
        //why logger error??? sunchong
        LOGGER.error(submodul + ":" + msg);
	}
}
