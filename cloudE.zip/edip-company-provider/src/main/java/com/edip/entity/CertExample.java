package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class CertExample {
    protected String orderByClause = "createDate desc";

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CertExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andCertidIsNull() {
            addCriterion("certID is null");
            return (Criteria) this;
        }

        public Criteria andCertidIsNotNull() {
            addCriterion("certID is not null");
            return (Criteria) this;
        }

        public Criteria andCertidEqualTo(Integer value) {
            addCriterion("certID =", value, "certid");
            return (Criteria) this;
        }

        public Criteria andCertidNotEqualTo(Integer value) {
            addCriterion("certID <>", value, "certid");
            return (Criteria) this;
        }

        public Criteria andCertidGreaterThan(Integer value) {
            addCriterion("certID >", value, "certid");
            return (Criteria) this;
        }

        public Criteria andCertidGreaterThanOrEqualTo(Integer value) {
            addCriterion("certID >=", value, "certid");
            return (Criteria) this;
        }

        public Criteria andCertidLessThan(Integer value) {
            addCriterion("certID <", value, "certid");
            return (Criteria) this;
        }

        public Criteria andCertidLessThanOrEqualTo(Integer value) {
            addCriterion("certID <=", value, "certid");
            return (Criteria) this;
        }

        public Criteria andCertidIn(List<Integer> values) {
            addCriterion("certID in", values, "certid");
            return (Criteria) this;
        }

        public Criteria andCertidNotIn(List<Integer> values) {
            addCriterion("certID not in", values, "certid");
            return (Criteria) this;
        }

        public Criteria andCertidBetween(Integer value1, Integer value2) {
            addCriterion("certID between", value1, value2, "certid");
            return (Criteria) this;
        }

        public Criteria andCertidNotBetween(Integer value1, Integer value2) {
            addCriterion("certID not between", value1, value2, "certid");
            return (Criteria) this;
        }

        public Criteria andCompidIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompidIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompidEqualTo(Integer value) {
            addCriterion("compID =", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThan(Integer value) {
            addCriterion("compID >", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThan(Integer value) {
            addCriterion("compID <", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidIn(List<Integer> values) {
            addCriterion("compID in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNull() {
            addCriterion("accountID is null");
            return (Criteria) this;
        }

        public Criteria andAccountidIsNotNull() {
            addCriterion("accountID is not null");
            return (Criteria) this;
        }

        public Criteria andAccountidEqualTo(Integer value) {
            addCriterion("accountID =", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotEqualTo(Integer value) {
            addCriterion("accountID <>", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThan(Integer value) {
            addCriterion("accountID >", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidGreaterThanOrEqualTo(Integer value) {
            addCriterion("accountID >=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThan(Integer value) {
            addCriterion("accountID <", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidLessThanOrEqualTo(Integer value) {
            addCriterion("accountID <=", value, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidIn(List<Integer> values) {
            addCriterion("accountID in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotIn(List<Integer> values) {
            addCriterion("accountID not in", values, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidBetween(Integer value1, Integer value2) {
            addCriterion("accountID between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andAccountidNotBetween(Integer value1, Integer value2) {
            addCriterion("accountID not between", value1, value2, "accountid");
            return (Criteria) this;
        }

        public Criteria andOperidIsNull() {
            addCriterion("operID is null");
            return (Criteria) this;
        }

        public Criteria andOperidIsNotNull() {
            addCriterion("operID is not null");
            return (Criteria) this;
        }

        public Criteria andOperidEqualTo(Integer value) {
            addCriterion("operID =", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidNotEqualTo(Integer value) {
            addCriterion("operID <>", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidGreaterThan(Integer value) {
            addCriterion("operID >", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidGreaterThanOrEqualTo(Integer value) {
            addCriterion("operID >=", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidLessThan(Integer value) {
            addCriterion("operID <", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidLessThanOrEqualTo(Integer value) {
            addCriterion("operID <=", value, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidIn(List<Integer> values) {
            addCriterion("operID in", values, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidNotIn(List<Integer> values) {
            addCriterion("operID not in", values, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidBetween(Integer value1, Integer value2) {
            addCriterion("operID between", value1, value2, "operid");
            return (Criteria) this;
        }

        public Criteria andOperidNotBetween(Integer value1, Integer value2) {
            addCriterion("operID not between", value1, value2, "operid");
            return (Criteria) this;
        }

        public Criteria andBillaccountIsNull() {
            addCriterion("billAccount is null");
            return (Criteria) this;
        }

        public Criteria andBillaccountIsNotNull() {
            addCriterion("billAccount is not null");
            return (Criteria) this;
        }

        public Criteria andBillaccountEqualTo(String value) {
            addCriterion("billAccount =", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountNotEqualTo(String value) {
            addCriterion("billAccount <>", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountGreaterThan(String value) {
            addCriterion("billAccount >", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountGreaterThanOrEqualTo(String value) {
            addCriterion("billAccount >=", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountLessThan(String value) {
            addCriterion("billAccount <", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountLessThanOrEqualTo(String value) {
            addCriterion("billAccount <=", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountLike(String value) {
            addCriterion("billAccount like", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountNotLike(String value) {
            addCriterion("billAccount not like", value, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountIn(List<String> values) {
            addCriterion("billAccount in", values, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountNotIn(List<String> values) {
            addCriterion("billAccount not in", values, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountBetween(String value1, String value2) {
            addCriterion("billAccount between", value1, value2, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillaccountNotBetween(String value1, String value2) {
            addCriterion("billAccount not between", value1, value2, "billaccount");
            return (Criteria) this;
        }

        public Criteria andBillnumIsNull() {
            addCriterion("billNum is null");
            return (Criteria) this;
        }

        public Criteria andBillnumIsNotNull() {
            addCriterion("billNum is not null");
            return (Criteria) this;
        }

        public Criteria andBillnumEqualTo(Integer value) {
            addCriterion("billNum =", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumNotEqualTo(Integer value) {
            addCriterion("billNum <>", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumGreaterThan(Integer value) {
            addCriterion("billNum >", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumGreaterThanOrEqualTo(Integer value) {
            addCriterion("billNum >=", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumLessThan(Integer value) {
            addCriterion("billNum <", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumLessThanOrEqualTo(Integer value) {
            addCriterion("billNum <=", value, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumIn(List<Integer> values) {
            addCriterion("billNum in", values, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumNotIn(List<Integer> values) {
            addCriterion("billNum not in", values, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumBetween(Integer value1, Integer value2) {
            addCriterion("billNum between", value1, value2, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillnumNotBetween(Integer value1, Integer value2) {
            addCriterion("billNum not between", value1, value2, "billnum");
            return (Criteria) this;
        }

        public Criteria andBillflagIsNull() {
            addCriterion("billFlag is null");
            return (Criteria) this;
        }

        public Criteria andBillflagIsNotNull() {
            addCriterion("billFlag is not null");
            return (Criteria) this;
        }

        public Criteria andBillflagEqualTo(Integer value) {
            addCriterion("billFlag =", value, "billflag");
            return (Criteria) this;
        }

        public Criteria andBillflagNotEqualTo(Integer value) {
            addCriterion("billFlag <>", value, "billflag");
            return (Criteria) this;
        }

        public Criteria andBillflagGreaterThan(Integer value) {
            addCriterion("billFlag >", value, "billflag");
            return (Criteria) this;
        }

        public Criteria andBillflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("billFlag >=", value, "billflag");
            return (Criteria) this;
        }

        public Criteria andBillflagLessThan(Integer value) {
            addCriterion("billFlag <", value, "billflag");
            return (Criteria) this;
        }

        public Criteria andBillflagLessThanOrEqualTo(Integer value) {
            addCriterion("billFlag <=", value, "billflag");
            return (Criteria) this;
        }

        public Criteria andBillflagIn(List<Integer> values) {
            addCriterion("billFlag in", values, "billflag");
            return (Criteria) this;
        }

        public Criteria andBillflagNotIn(List<Integer> values) {
            addCriterion("billFlag not in", values, "billflag");
            return (Criteria) this;
        }

        public Criteria andBillflagBetween(Integer value1, Integer value2) {
            addCriterion("billFlag between", value1, value2, "billflag");
            return (Criteria) this;
        }

        public Criteria andBillflagNotBetween(Integer value1, Integer value2) {
            addCriterion("billFlag not between", value1, value2, "billflag");
            return (Criteria) this;
        }

        public Criteria andBilltimeIsNull() {
            addCriterion("billTime is null");
            return (Criteria) this;
        }

        public Criteria andBilltimeIsNotNull() {
            addCriterion("billTime is not null");
            return (Criteria) this;
        }

        public Criteria andBilltimeEqualTo(Date value) {
            addCriterion("billTime =", value, "billtime");
            return (Criteria) this;
        }

        public Criteria andBilltimeNotEqualTo(Date value) {
            addCriterion("billTime <>", value, "billtime");
            return (Criteria) this;
        }

        public Criteria andBilltimeGreaterThan(Date value) {
            addCriterion("billTime >", value, "billtime");
            return (Criteria) this;
        }

        public Criteria andBilltimeGreaterThanOrEqualTo(Date value) {
            addCriterion("billTime >=", value, "billtime");
            return (Criteria) this;
        }

        public Criteria andBilltimeLessThan(Date value) {
            addCriterion("billTime <", value, "billtime");
            return (Criteria) this;
        }

        public Criteria andBilltimeLessThanOrEqualTo(Date value) {
            addCriterion("billTime <=", value, "billtime");
            return (Criteria) this;
        }

        public Criteria andBilltimeIn(List<Date> values) {
            addCriterion("billTime in", values, "billtime");
            return (Criteria) this;
        }

        public Criteria andBilltimeNotIn(List<Date> values) {
            addCriterion("billTime not in", values, "billtime");
            return (Criteria) this;
        }

        public Criteria andBilltimeBetween(Date value1, Date value2) {
            addCriterion("billTime between", value1, value2, "billtime");
            return (Criteria) this;
        }

        public Criteria andBilltimeNotBetween(Date value1, Date value2) {
            addCriterion("billTime not between", value1, value2, "billtime");
            return (Criteria) this;
        }

        public Criteria andCertsnIsNull() {
            addCriterion("certSN is null");
            return (Criteria) this;
        }

        public Criteria andCertsnIsNotNull() {
            addCriterion("certSN is not null");
            return (Criteria) this;
        }

        public Criteria andCertsnEqualTo(String value) {
            addCriterion("certSN =", value, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnNotEqualTo(String value) {
            addCriterion("certSN <>", value, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnGreaterThan(String value) {
            addCriterion("certSN >", value, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnGreaterThanOrEqualTo(String value) {
            addCriterion("certSN >=", value, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnLessThan(String value) {
            addCriterion("certSN <", value, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnLessThanOrEqualTo(String value) {
            addCriterion("certSN <=", value, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnLike(String value) {
            addCriterion("certSN like", value, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnNotLike(String value) {
            addCriterion("certSN not like", value, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnIn(List<String> values) {
            addCriterion("certSN in", values, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnNotIn(List<String> values) {
            addCriterion("certSN not in", values, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnBetween(String value1, String value2) {
            addCriterion("certSN between", value1, value2, "certsn");
            return (Criteria) this;
        }

        public Criteria andCertsnNotBetween(String value1, String value2) {
            addCriterion("certSN not between", value1, value2, "certsn");
            return (Criteria) this;
        }

        public Criteria andUkeycodeIsNull() {
            addCriterion("ukeyCode is null");
            return (Criteria) this;
        }

        public Criteria andUkeycodeIsNotNull() {
            addCriterion("ukeyCode is not null");
            return (Criteria) this;
        }

        public Criteria andUkeycodeEqualTo(String value) {
            addCriterion("ukeyCode =", value, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeNotEqualTo(String value) {
            addCriterion("ukeyCode <>", value, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeGreaterThan(String value) {
            addCriterion("ukeyCode >", value, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeGreaterThanOrEqualTo(String value) {
            addCriterion("ukeyCode >=", value, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeLessThan(String value) {
            addCriterion("ukeyCode <", value, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeLessThanOrEqualTo(String value) {
            addCriterion("ukeyCode <=", value, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeLike(String value) {
            addCriterion("ukeyCode like", value, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeNotLike(String value) {
            addCriterion("ukeyCode not like", value, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeIn(List<String> values) {
            addCriterion("ukeyCode in", values, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeNotIn(List<String> values) {
            addCriterion("ukeyCode not in", values, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeBetween(String value1, String value2) {
            addCriterion("ukeyCode between", value1, value2, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andUkeycodeNotBetween(String value1, String value2) {
            addCriterion("ukeyCode not between", value1, value2, "ukeycode");
            return (Criteria) this;
        }

        public Criteria andDeliverflagIsNull() {
            addCriterion("deliverFlag is null");
            return (Criteria) this;
        }

        public Criteria andDeliverflagIsNotNull() {
            addCriterion("deliverFlag is not null");
            return (Criteria) this;
        }

        public Criteria andDeliverflagEqualTo(Integer value) {
            addCriterion("deliverFlag =", value, "deliverflag");
            return (Criteria) this;
        }

        public Criteria andDeliverflagNotEqualTo(Integer value) {
            addCriterion("deliverFlag <>", value, "deliverflag");
            return (Criteria) this;
        }

        public Criteria andDeliverflagGreaterThan(Integer value) {
            addCriterion("deliverFlag >", value, "deliverflag");
            return (Criteria) this;
        }

        public Criteria andDeliverflagGreaterThanOrEqualTo(Integer value) {
            addCriterion("deliverFlag >=", value, "deliverflag");
            return (Criteria) this;
        }

        public Criteria andDeliverflagLessThan(Integer value) {
            addCriterion("deliverFlag <", value, "deliverflag");
            return (Criteria) this;
        }

        public Criteria andDeliverflagLessThanOrEqualTo(Integer value) {
            addCriterion("deliverFlag <=", value, "deliverflag");
            return (Criteria) this;
        }

        public Criteria andDeliverflagIn(List<Integer> values) {
            addCriterion("deliverFlag in", values, "deliverflag");
            return (Criteria) this;
        }

        public Criteria andDeliverflagNotIn(List<Integer> values) {
            addCriterion("deliverFlag not in", values, "deliverflag");
            return (Criteria) this;
        }

        public Criteria andDeliverflagBetween(Integer value1, Integer value2) {
            addCriterion("deliverFlag between", value1, value2, "deliverflag");
            return (Criteria) this;
        }

        public Criteria andDeliverflagNotBetween(Integer value1, Integer value2) {
            addCriterion("deliverFlag not between", value1, value2, "deliverflag");
            return (Criteria) this;
        }

        public Criteria andActivedateIsNull() {
            addCriterion("activeDate is null");
            return (Criteria) this;
        }

        public Criteria andActivedateIsNotNull() {
            addCriterion("activeDate is not null");
            return (Criteria) this;
        }

        public Criteria andActivedateEqualTo(Date value) {
            addCriterionForJDBCDate("activeDate =", value, "activedate");
            return (Criteria) this;
        }

        public Criteria andActivedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("activeDate <>", value, "activedate");
            return (Criteria) this;
        }

        public Criteria andActivedateGreaterThan(Date value) {
            addCriterionForJDBCDate("activeDate >", value, "activedate");
            return (Criteria) this;
        }

        public Criteria andActivedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("activeDate >=", value, "activedate");
            return (Criteria) this;
        }

        public Criteria andActivedateLessThan(Date value) {
            addCriterionForJDBCDate("activeDate <", value, "activedate");
            return (Criteria) this;
        }

        public Criteria andActivedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("activeDate <=", value, "activedate");
            return (Criteria) this;
        }

        public Criteria andActivedateIn(List<Date> values) {
            addCriterionForJDBCDate("activeDate in", values, "activedate");
            return (Criteria) this;
        }

        public Criteria andActivedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("activeDate not in", values, "activedate");
            return (Criteria) this;
        }

        public Criteria andActivedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("activeDate between", value1, value2, "activedate");
            return (Criteria) this;
        }

        public Criteria andActivedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("activeDate not between", value1, value2, "activedate");
            return (Criteria) this;
        }

        public Criteria andValiddateIsNull() {
            addCriterion("validDate is null");
            return (Criteria) this;
        }

        public Criteria andValiddateIsNotNull() {
            addCriterion("validDate is not null");
            return (Criteria) this;
        }

        public Criteria andValiddateEqualTo(Date value) {
            addCriterionForJDBCDate("validDate =", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateNotEqualTo(Date value) {
            addCriterionForJDBCDate("validDate <>", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateGreaterThan(Date value) {
            addCriterionForJDBCDate("validDate >", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("validDate >=", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateLessThan(Date value) {
            addCriterionForJDBCDate("validDate <", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("validDate <=", value, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateIn(List<Date> values) {
            addCriterionForJDBCDate("validDate in", values, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateNotIn(List<Date> values) {
            addCriterionForJDBCDate("validDate not in", values, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("validDate between", value1, value2, "validdate");
            return (Criteria) this;
        }

        public Criteria andValiddateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("validDate not between", value1, value2, "validdate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateIsNull() {
            addCriterion("invalidDate is null");
            return (Criteria) this;
        }

        public Criteria andInvaliddateIsNotNull() {
            addCriterion("invalidDate is not null");
            return (Criteria) this;
        }

        public Criteria andInvaliddateEqualTo(Date value) {
            addCriterionForJDBCDate("invalidDate =", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateNotEqualTo(Date value) {
            addCriterionForJDBCDate("invalidDate <>", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateGreaterThan(Date value) {
            addCriterionForJDBCDate("invalidDate >", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("invalidDate >=", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateLessThan(Date value) {
            addCriterionForJDBCDate("invalidDate <", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("invalidDate <=", value, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateIn(List<Date> values) {
            addCriterionForJDBCDate("invalidDate in", values, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateNotIn(List<Date> values) {
            addCriterionForJDBCDate("invalidDate not in", values, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("invalidDate between", value1, value2, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andInvaliddateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("invalidDate not between", value1, value2, "invaliddate");
            return (Criteria) this;
        }

        public Criteria andUkstatusIsNull() {
            addCriterion("ukStatus is null");
            return (Criteria) this;
        }

        public Criteria andUkstatusIsNotNull() {
            addCriterion("ukStatus is not null");
            return (Criteria) this;
        }

        public Criteria andUkstatusEqualTo(Integer value) {
            addCriterion("ukStatus =", value, "ukstatus");
            return (Criteria) this;
        }

        public Criteria andUkstatusNotEqualTo(Integer value) {
            addCriterion("ukStatus <>", value, "ukstatus");
            return (Criteria) this;
        }

        public Criteria andUkstatusGreaterThan(Integer value) {
            addCriterion("ukStatus >", value, "ukstatus");
            return (Criteria) this;
        }

        public Criteria andUkstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("ukStatus >=", value, "ukstatus");
            return (Criteria) this;
        }

        public Criteria andUkstatusLessThan(Integer value) {
            addCriterion("ukStatus <", value, "ukstatus");
            return (Criteria) this;
        }

        public Criteria andUkstatusLessThanOrEqualTo(Integer value) {
            addCriterion("ukStatus <=", value, "ukstatus");
            return (Criteria) this;
        }

        public Criteria andUkstatusIn(List<Integer> values) {
            addCriterion("ukStatus in", values, "ukstatus");
            return (Criteria) this;
        }

        public Criteria andUkstatusNotIn(List<Integer> values) {
            addCriterion("ukStatus not in", values, "ukstatus");
            return (Criteria) this;
        }

        public Criteria andUkstatusBetween(Integer value1, Integer value2) {
            addCriterion("ukStatus between", value1, value2, "ukstatus");
            return (Criteria) this;
        }

        public Criteria andUkstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("ukStatus not between", value1, value2, "ukstatus");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreatedateEqualTo(Date value) {
            addCriterion("createDate =", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThan(Date value) {
            addCriterion("createDate <", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateIn(List<Date> values) {
            addCriterion("createDate in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andLupdateIsNull() {
            addCriterion("lupDate is null");
            return (Criteria) this;
        }

        public Criteria andLupdateIsNotNull() {
            addCriterion("lupDate is not null");
            return (Criteria) this;
        }

        public Criteria andLupdateEqualTo(Date value) {
            addCriterion("lupDate =", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotEqualTo(Date value) {
            addCriterion("lupDate <>", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateGreaterThan(Date value) {
            addCriterion("lupDate >", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateGreaterThanOrEqualTo(Date value) {
            addCriterion("lupDate >=", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateLessThan(Date value) {
            addCriterion("lupDate <", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateLessThanOrEqualTo(Date value) {
            addCriterion("lupDate <=", value, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateIn(List<Date> values) {
            addCriterion("lupDate in", values, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotIn(List<Date> values) {
            addCriterion("lupDate not in", values, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateBetween(Date value1, Date value2) {
            addCriterion("lupDate between", value1, value2, "lupdate");
            return (Criteria) this;
        }

        public Criteria andLupdateNotBetween(Date value1, Date value2) {
            addCriterion("lupDate not between", value1, value2, "lupdate");
            return (Criteria) this;
        }

        public Criteria andTxcodeIsNull() {
            addCriterion("txcode is null");
            return (Criteria) this;
        }

        public Criteria andTxcodeIsNotNull() {
            addCriterion("txcode is not null");
            return (Criteria) this;
        }

        public Criteria andTxcodeEqualTo(String value) {
            addCriterion("txcode =", value, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeNotEqualTo(String value) {
            addCriterion("txcode <>", value, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeGreaterThan(String value) {
            addCriterion("txcode >", value, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeGreaterThanOrEqualTo(String value) {
            addCriterion("txcode >=", value, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeLessThan(String value) {
            addCriterion("txcode <", value, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeLessThanOrEqualTo(String value) {
            addCriterion("txcode <=", value, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeLike(String value) {
            addCriterion("txcode like", value, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeNotLike(String value) {
            addCriterion("txcode not like", value, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeIn(List<String> values) {
            addCriterion("txcode in", values, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeNotIn(List<String> values) {
            addCriterion("txcode not in", values, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeBetween(String value1, String value2) {
            addCriterion("txcode between", value1, value2, "txcode");
            return (Criteria) this;
        }

        public Criteria andTxcodeNotBetween(String value1, String value2) {
            addCriterion("txcode not between", value1, value2, "txcode");
            return (Criteria) this;
        }

        public Criteria andUseridIsNull() {
            addCriterion("userid is null");
            return (Criteria) this;
        }

        public Criteria andUseridIsNotNull() {
            addCriterion("userid is not null");
            return (Criteria) this;
        }

        public Criteria andUseridEqualTo(Integer value) {
            addCriterion("userid =", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotEqualTo(Integer value) {
            addCriterion("userid <>", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThan(Integer value) {
            addCriterion("userid >", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridGreaterThanOrEqualTo(Integer value) {
            addCriterion("userid >=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThan(Integer value) {
            addCriterion("userid <", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridLessThanOrEqualTo(Integer value) {
            addCriterion("userid <=", value, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridIn(List<Integer> values) {
            addCriterion("userid in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotIn(List<Integer> values) {
            addCriterion("userid not in", values, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridBetween(Integer value1, Integer value2) {
            addCriterion("userid between", value1, value2, "userid");
            return (Criteria) this;
        }

        public Criteria andUseridNotBetween(Integer value1, Integer value2) {
            addCriterion("userid not between", value1, value2, "userid");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}