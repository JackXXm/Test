package com.edip.mapper;

import com.edip.entity.Cert;
import com.edip.entity.CertExample;
import com.edip.entity.CertWithBLOBs;
import java.util.List;

import com.edip.vo.CertVo;
import org.apache.ibatis.annotations.Param;

public interface CertMapper {
    long countByExample(CertExample example);

    int deleteByExample(CertExample example);

    int deleteByPrimaryKey(Integer certid);

    int insert(CertWithBLOBs record);

    int insertSelective(CertWithBLOBs record);

    List<CertWithBLOBs> selectByExampleWithBLOBs(CertExample example);

    List<Cert> selectByExample(CertExample example);

    CertWithBLOBs selectByPrimaryKey(Integer certid);

    List<CertWithBLOBs> selectByExampleWithBLOBsWithPage(@Param("example") CertExample example, @Param("from") Integer from, @Param("to") Integer to);

    int updateByExampleSelective(@Param("record") CertWithBLOBs record, @Param("example") CertExample example);

    int updateByExampleWithBLOBs(@Param("record") CertWithBLOBs record, @Param("example") CertExample example);

    int updateByExample(@Param("record") Cert record, @Param("example") CertExample example);

    int updateByPrimaryKeySelective(CertWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(CertWithBLOBs record);

    int updateByPrimaryKey(Cert record);

    CertWithBLOBs selectCert(CertVo certVo);

    Integer deleteCertBycompanyId(Integer compID);
}