package com.edip.entity;

import java.util.Date;

/**
 * @author Administrator
 * @description TODO
 * @DATE 2019/1/23 0023 15:17
 */
public class DocumentVo {

    /**
     * 主键
     */
    private Integer id;

    /**
     * 克隆id
     */
    private Integer cloneId;

    /**
     * 档案类型:参考dic的type=docType+dataType
     */
    private String docType;

    /**
     * 实体记录id
     */
    private Integer dataId;

    /**
     * 实体类型0:公司1:人员2:产品3:合同4:图章 5:证书6:项目7:归档 8其他公司企业 9其他人员 10其他合同
     */
    private Integer dataType;

    /**
     * 0:线上1:线下
     */
    private Integer onlineType;

    /**
     * 归属公司
     */
    private Integer compId;

    /**
     * 账号id
     */
    private Integer createAccountId;

    /**
     * 原始档案URL
     */
    private String docUrl;

    /**
     * 失效日期
     */
    private Date invalidDate;

    /**
     * 文档名称
     */
    private String docName;

    /**
     * 签章后档案URL
     */
    private String documentUrl;

    /**
     * 文档上传时名称
     */
    private String aliasName;

    /**
     * 审核意见
     */
    private String anditInfo;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 创建人id
     */
    private Integer updateAccountId;

    /**
     * 修改人
     */
    private String updateBy;

    /**
     * 0:正常1:待审批2:即将过期3:已过期9:审批失败
     */
    private Integer status;

    /**
     * 发证日期
     */
    private String issueDate;

    /**
     * 证书编号
     */
    private String certNo;

    /**
     * 上传者
     */
    private String createBy;

    /**
     * 材质说明
     */
    private String illustrate;

    /**
     * 报告编号
     */
    private String reportNumber;

    /**
     * 0:是1:否
     */
    private Integer archiveFlag;

    /**
     * 0:待审批1:审批中2:审批通过3:审批失败
     */
    private Integer reviewFlag;

    /**
     * 是否是oportal集成过来的数据（或者是oportal修改了edipdb当前的数据）Y：是，N：否
     */
    private Integer isUpload;

    /**
     * 验签文件
     */
    private String handleFile;

    /**
     * 验签文件大小
     */
    private String handleFileSize;

    /**
     * 文件大小
     */
    private String srcFileSize;

    /**
     * pdf页数
     */
    private String pdfPages;

    /**
     * 委托书负责人
     */
    private String responsible;

    /**
     * 文件归属
     */
    private String docAttribution;

    /**
     * 逻辑删除,删除:-1
     */
    private Integer deleteFlag;

    /**
     * 流转码
     */
    private String exchangeCode;

    /**
     * 0 无更新资质 1有更新资质可更新
     */
    private Integer updateFlag;
    /**
     * 是否要回传
     */
    private Integer returnStatus;
    /**
     * 回传印章信息
     */
    private String destSignInfo;
    /**
     * 资质对应产品信息id
     */
    private Integer infoId;
    /**
     * 公司名称
     */
    private String companyName;
    /**
     * 电子检验报告id
     */
    private Integer inspectId;
    private Integer cloneStatus;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCloneId() {
        return cloneId;
    }

    public void setCloneId(Integer cloneId) {
        this.cloneId = cloneId;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public Integer getDataId() {
        return dataId;
    }

    public void setDataId(Integer dataId) {
        this.dataId = dataId;
    }

    public Integer getDataType() {
        return dataType;
    }

    public void setDataType(Integer dataType) {
        this.dataType = dataType;
    }

    public Integer getOnlineType() {
        return onlineType;
    }

    public void setOnlineType(Integer onlineType) {
        this.onlineType = onlineType;
    }

    public Integer getCompId() {
        return compId;
    }

    public void setCompId(Integer compId) {
        this.compId = compId;
    }

    public Integer getCreateAccountId() {
        return createAccountId;
    }

    public void setCreateAccountId(Integer createAccountId) {
        this.createAccountId = createAccountId;
    }

    public String getDocUrl() {
        return docUrl;
    }

    public void setDocUrl(String docUrl) {
        this.docUrl = docUrl;
    }

    public Date getInvalidDate() {
        return invalidDate;
    }

    public void setInvalidDate(Date invalidDate) {
        this.invalidDate = invalidDate;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getDocumentUrl() {
        return documentUrl;
    }

    public void setDocumentUrl(String documentUrl) {
        this.documentUrl = documentUrl;
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }

    public String getAnditInfo() {
        return anditInfo;
    }

    public void setAnditInfo(String anditInfo) {
        this.anditInfo = anditInfo;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getUpdateAccountId() {
        return updateAccountId;
    }

    public void setUpdateAccountId(Integer updateAccountId) {
        this.updateAccountId = updateAccountId;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getCertNo() {
        return certNo;
    }

    public void setCertNo(String certNo) {
        this.certNo = certNo;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getIllustrate() {
        return illustrate;
    }

    public void setIllustrate(String illustrate) {
        this.illustrate = illustrate;
    }

    public String getReportNumber() {
        return reportNumber;
    }

    public void setReportNumber(String reportNumber) {
        this.reportNumber = reportNumber;
    }

    public Integer getArchiveFlag() {
        return archiveFlag;
    }

    public void setArchiveFlag(Integer archiveFlag) {
        this.archiveFlag = archiveFlag;
    }

    public Integer getReviewFlag() {
        return reviewFlag;
    }

    public void setReviewFlag(Integer reviewFlag) {
        this.reviewFlag = reviewFlag;
    }

    public Integer getIsUpload() {
        return isUpload;
    }

    public void setIsUpload(Integer isUpload) {
        this.isUpload = isUpload;
    }

    public String getHandleFile() {
        return handleFile;
    }

    public void setHandleFile(String handleFile) {
        this.handleFile = handleFile;
    }

    public String getHandleFileSize() {
        return handleFileSize;
    }

    public void setHandleFileSize(String handleFileSize) {
        this.handleFileSize = handleFileSize;
    }

    public String getSrcFileSize() {
        return srcFileSize;
    }

    public void setSrcFileSize(String srcFileSize) {
        this.srcFileSize = srcFileSize;
    }

    public String getPdfPages() {
        return pdfPages;
    }

    public void setPdfPages(String pdfPages) {
        this.pdfPages = pdfPages;
    }

    public String getResponsible() {
        return responsible;
    }

    public void setResponsible(String responsible) {
        this.responsible = responsible;
    }

    public String getDocAttribution() {
        return docAttribution;
    }

    public void setDocAttribution(String docAttribution) {
        this.docAttribution = docAttribution;
    }

    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getExchangeCode() {
        return exchangeCode;
    }

    public void setExchangeCode(String exchangeCode) {
        this.exchangeCode = exchangeCode;
    }

    public Integer getUpdateFlag() {
        return updateFlag;
    }

    public void setUpdateFlag(Integer updateFlag) {
        this.updateFlag = updateFlag;
    }

    public Integer getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(Integer returnStatus) {
        this.returnStatus = returnStatus;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Document other = (Document) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
                && (this.getCloneId() == null ? other.getCloneId() == null : this.getCloneId().equals(other.getCloneId()))
                && (this.getDocType() == null ? other.getDocType() == null : this.getDocType().equals(other.getDocType()))
                && (this.getDataId() == null ? other.getDataId() == null : this.getDataId().equals(other.getDataId()))
                && (this.getDataType() == null ? other.getDataType() == null : this.getDataType().equals(other.getDataType()))
                && (this.getOnlineType() == null ? other.getOnlineType() == null : this.getOnlineType().equals(other.getOnlineType()))
                && (this.getCompId() == null ? other.getCompId() == null : this.getCompId().equals(other.getCompId()))
                && (this.getCreateAccountId() == null ? other.getCreateAccountId() == null : this.getCreateAccountId().equals(other.getCreateAccountId()))
                && (this.getDocUrl() == null ? other.getDocUrl() == null : this.getDocUrl().equals(other.getDocUrl()))
                && (this.getInvalidDate() == null ? other.getInvalidDate() == null : this.getInvalidDate().equals(other.getInvalidDate()))
                && (this.getDocName() == null ? other.getDocName() == null : this.getDocName().equals(other.getDocName()))
                && (this.getDocumentUrl() == null ? other.getDocumentUrl() == null : this.getDocumentUrl().equals(other.getDocumentUrl()))
                && (this.getAliasName() == null ? other.getAliasName() == null : this.getAliasName().equals(other.getAliasName()))
                && (this.getAnditInfo() == null ? other.getAnditInfo() == null : this.getAnditInfo().equals(other.getAnditInfo()))
                && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
                && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
                && (this.getUpdateAccountId() == null ? other.getUpdateAccountId() == null : this.getUpdateAccountId().equals(other.getUpdateAccountId()))
                && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
                && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
                && (this.getIssueDate() == null ? other.getIssueDate() == null : this.getIssueDate().equals(other.getIssueDate()))
                && (this.getCertNo() == null ? other.getCertNo() == null : this.getCertNo().equals(other.getCertNo()))
                && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
                && (this.getIllustrate() == null ? other.getIllustrate() == null : this.getIllustrate().equals(other.getIllustrate()))
                && (this.getReportNumber() == null ? other.getReportNumber() == null : this.getReportNumber().equals(other.getReportNumber()))
                && (this.getArchiveFlag() == null ? other.getArchiveFlag() == null : this.getArchiveFlag().equals(other.getArchiveFlag()))
                && (this.getReviewFlag() == null ? other.getReviewFlag() == null : this.getReviewFlag().equals(other.getReviewFlag()))
                && (this.getIsUpload() == null ? other.getIsUpload() == null : this.getIsUpload().equals(other.getIsUpload()))
                && (this.getHandleFile() == null ? other.getHandleFile() == null : this.getHandleFile().equals(other.getHandleFile()))
                && (this.getHandleFileSize() == null ? other.getHandleFileSize() == null : this.getHandleFileSize().equals(other.getHandleFileSize()))
                && (this.getSrcFileSize() == null ? other.getSrcFileSize() == null : this.getSrcFileSize().equals(other.getSrcFileSize()))
                && (this.getPdfPages() == null ? other.getPdfPages() == null : this.getPdfPages().equals(other.getPdfPages()))
                && (this.getResponsible() == null ? other.getResponsible() == null : this.getResponsible().equals(other.getResponsible()))
                && (this.getDocAttribution() == null ? other.getDocAttribution() == null : this.getDocAttribution().equals(other.getDocAttribution()))
                && (this.getDeleteFlag() == null ? other.getDeleteFlag() == null : this.getDeleteFlag().equals(other.getDeleteFlag()))
                && (this.getExchangeCode() == null ? other.getExchangeCode() == null : this.getExchangeCode().equals(other.getExchangeCode()))
                && (this.getUpdateFlag() == null ? other.getUpdateFlag() == null : this.getUpdateFlag().equals(other.getUpdateFlag()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getCloneId() == null) ? 0 : getCloneId().hashCode());
        result = prime * result + ((getDocType() == null) ? 0 : getDocType().hashCode());
        result = prime * result + ((getDataId() == null) ? 0 : getDataId().hashCode());
        result = prime * result + ((getDataType() == null) ? 0 : getDataType().hashCode());
        result = prime * result + ((getOnlineType() == null) ? 0 : getOnlineType().hashCode());
        result = prime * result + ((getCompId() == null) ? 0 : getCompId().hashCode());
        result = prime * result + ((getCreateAccountId() == null) ? 0 : getCreateAccountId().hashCode());
        result = prime * result + ((getDocUrl() == null) ? 0 : getDocUrl().hashCode());
        result = prime * result + ((getInvalidDate() == null) ? 0 : getInvalidDate().hashCode());
        result = prime * result + ((getDocName() == null) ? 0 : getDocName().hashCode());
        result = prime * result + ((getDocumentUrl() == null) ? 0 : getDocumentUrl().hashCode());
        result = prime * result + ((getAliasName() == null) ? 0 : getAliasName().hashCode());
        result = prime * result + ((getAnditInfo() == null) ? 0 : getAnditInfo().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getUpdateAccountId() == null) ? 0 : getUpdateAccountId().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getIssueDate() == null) ? 0 : getIssueDate().hashCode());
        result = prime * result + ((getCertNo() == null) ? 0 : getCertNo().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getIllustrate() == null) ? 0 : getIllustrate().hashCode());
        result = prime * result + ((getReportNumber() == null) ? 0 : getReportNumber().hashCode());
        result = prime * result + ((getArchiveFlag() == null) ? 0 : getArchiveFlag().hashCode());
        result = prime * result + ((getReviewFlag() == null) ? 0 : getReviewFlag().hashCode());
        result = prime * result + ((getIsUpload() == null) ? 0 : getIsUpload().hashCode());
        result = prime * result + ((getHandleFile() == null) ? 0 : getHandleFile().hashCode());
        result = prime * result + ((getHandleFileSize() == null) ? 0 : getHandleFileSize().hashCode());
        result = prime * result + ((getSrcFileSize() == null) ? 0 : getSrcFileSize().hashCode());
        result = prime * result + ((getPdfPages() == null) ? 0 : getPdfPages().hashCode());
        result = prime * result + ((getResponsible() == null) ? 0 : getResponsible().hashCode());
        result = prime * result + ((getDocAttribution() == null) ? 0 : getDocAttribution().hashCode());
        result = prime * result + ((getDeleteFlag() == null) ? 0 : getDeleteFlag().hashCode());
        result = prime * result + ((getExchangeCode() == null) ? 0 : getExchangeCode().hashCode());
        result = prime * result + ((getUpdateFlag() == null) ? 0 : getUpdateFlag().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", cloneId=").append(cloneId);
        sb.append(", docType=").append(docType);
        sb.append(", dataId=").append(dataId);
        sb.append(", dataType=").append(dataType);
        sb.append(", onlineType=").append(onlineType);
        sb.append(", compId=").append(compId);
        sb.append(", createAccountId=").append(createAccountId);
        sb.append(", docUrl=").append(docUrl);
        sb.append(", invalidDate=").append(invalidDate);
        sb.append(", docName=").append(docName);
        sb.append(", documentUrl=").append(documentUrl);
        sb.append(", aliasName=").append(aliasName);
        sb.append(", anditInfo=").append(anditInfo);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", updateAccountId=").append(updateAccountId);
        sb.append(", updateBy=").append(updateBy);
        sb.append(", status=").append(status);
        sb.append(", issueDate=").append(issueDate);
        sb.append(", certNo=").append(certNo);
        sb.append(", createBy=").append(createBy);
        sb.append(", illustrate=").append(illustrate);
        sb.append(", reportNumber=").append(reportNumber);
        sb.append(", archiveFlag=").append(archiveFlag);
        sb.append(", reviewFlag=").append(reviewFlag);
        sb.append(", isUpload=").append(isUpload);
        sb.append(", handleFile=").append(handleFile);
        sb.append(", handleFileSize=").append(handleFileSize);
        sb.append(", srcFileSize=").append(srcFileSize);
        sb.append(", pdfPages=").append(pdfPages);
        sb.append(", responsible=").append(responsible);
        sb.append(", docAttribution=").append(docAttribution);
        sb.append(", deleteFlag=").append(deleteFlag);
        sb.append(", exchangeCode=").append(exchangeCode);
        sb.append(", updateFlag=").append(updateFlag);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public String getDestSignInfo() {
        return destSignInfo;
    }

    public void setDestSignInfo(String destSignInfo) {
        this.destSignInfo = destSignInfo;
    }

    public Integer getInfoId() {
        return infoId;
    }

    public void setInfoId(Integer infoId) {
        this.infoId = infoId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getInspectId() {
        return inspectId;
    }

    public void setInspectId(Integer inspectId) {
        this.inspectId = inspectId;
    }

    public Integer getCloneStatus() {
        return cloneStatus;
    }

    public void setCloneStatus(Integer cloneStatus) {
        this.cloneStatus = cloneStatus;
    }
}
