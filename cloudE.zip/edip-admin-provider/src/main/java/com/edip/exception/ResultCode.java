package com.edip.exception;

public interface ResultCode {
    String getErrorCode();

    int getStatusCode();
}
