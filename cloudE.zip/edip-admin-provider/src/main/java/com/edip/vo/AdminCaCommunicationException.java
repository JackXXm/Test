package com.edip.vo;


import com.edip.vo.AdminBaseException;

/**
 * @author zhangjie
 * @date 2015/03/12
 */
@SuppressWarnings("serial")
public class AdminCaCommunicationException extends AdminBaseException {
	public AdminCaCommunicationException() {
		super();
	}

	public AdminCaCommunicationException(String msg) {
		super("[CA处理error]",msg);
	}
}
