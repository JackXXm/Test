package com.edip.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@XmlAccessorType(XmlAccessType.FIELD)
public class Item {
    /**
     * 企业名称
     */
    private String a1Entname;
    /**
     * 法定代表人
     */
    private String a1Frname;
    /**
     * 注册号
     */
    private String a1Regno;
    /**
     * 组织机构代码
     */
    private String a1Orgcodes;
    /**
     * 实收资本（万元）
     */
    private String a1Reccap;
    /**
     * 注册资本币种
     */
    private String a1Regcapcur;
    /**
     * 成立日期
     */
    private String a1Esdate;
    /**
     * 经营限期自
     */
    private String a1Opfrom;
    /**
     * 经营限期至
     */
    private String a1Opto;
    /**
     * 企业（机构）类型
     */
    private String a1Enttype;
    /**
     * 经营状态
     */
    private String a1Entstatus;
    /**
     * 变更日期
     */
    private String a1Changedate;
    /**
     * 注销日期
     */
    private String a1Candate;
    /**
     * 吊销日期
     */
    private String a1Revdate;
    /**
     * 住址
     */
    private String a1Dom;
    /**
     * 一般经营项目
     */
    private String a1Cbuitem;
    /**
     * 经营（业务）范围
     */
    private String a1Opscope;
    /**
     * 经营（业务）范围及方式
     */
    private String a1Opscoandform;
    /**
     * 经营业务范围
     */
    private String a1Zsopscope;
    /**
     * 登记机关
     */
    private String a1Regorg;
    /**
     * 注册地址行政区编码
     */
    private String a1Regorgcode;
    /**
     * 所在省份
     */
    private String a1Regorgprovince;
    /**
     * 最后年检日期
     */
    private String a1Anchedate;
    /**
     * 企业英文名称
     */
    private String a1Entnameeng;
    /**
     * 统一社会信用代码
     */
    private String a1Creditcod;
    /**
     * 注册资本（万元）
     */
    private String a1Regcap;
    /**
     * 许可经营项目
     */
    private String a1Abuitem;

    public String getA1Entname() {
        return a1Entname;
    }

    public void setA1Entname(String a1Entname) {
        this.a1Entname = a1Entname;
    }

    public String getA1Frname() {
        return a1Frname;
    }

    public void setA1Frname(String a1Frname) {
        this.a1Frname = a1Frname;
    }

    public String getA1Regno() {
        return a1Regno;
    }

    public void setA1Regno(String a1Regno) {
        this.a1Regno = a1Regno;
    }

    public String getA1Orgcodes() {
        return a1Orgcodes;
    }

    public void setA1Orgcodes(String a1Orgcodes) {
        this.a1Orgcodes = a1Orgcodes;
    }

    public String getA1Reccap() {
        return a1Reccap;
    }

    public void setA1Reccap(String a1Reccap) {
        this.a1Reccap = a1Reccap;
    }

    public String getA1Regcapcur() {
        return a1Regcapcur;
    }

    public void setA1Regcapcur(String a1Regcapcur) {
        this.a1Regcapcur = a1Regcapcur;
    }

    public String getA1Esdate() {
        return a1Esdate;
    }

    public void setA1Esdate(String a1Esdate) {
        this.a1Esdate = a1Esdate;
    }

    public String getA1Opfrom() {
        return a1Opfrom;
    }

    public void setA1Opfrom(String a1Opfrom) {
        this.a1Opfrom = a1Opfrom;
    }

    public String getA1Opto() {
        return a1Opto;
    }

    public void setA1Opto(String a1Opto) {
        this.a1Opto = a1Opto;
    }

    public String getA1Enttype() {
        return a1Enttype;
    }

    public void setA1Enttype(String a1Enttype) {
        this.a1Enttype = a1Enttype;
    }

    public String getA1Entstatus() {
        return a1Entstatus;
    }

    public void setA1Entstatus(String a1Entstatus) {
        this.a1Entstatus = a1Entstatus;
    }

    public String getA1Changedate() {
        return a1Changedate;
    }

    public void setA1Changedate(String a1Changedate) {
        this.a1Changedate = a1Changedate;
    }

    public String getA1Candate() {
        return a1Candate;
    }

    public void setA1Candate(String a1Candate) {
        this.a1Candate = a1Candate;
    }

    public String getA1Revdate() {
        return a1Revdate;
    }

    public void setA1Revdate(String a1Revdate) {
        this.a1Revdate = a1Revdate;
    }

    public String getA1Dom() {
        return a1Dom;
    }

    public void setA1Dom(String a1Dom) {
        this.a1Dom = a1Dom;
    }

    public String getA1Cbuitem() {
        return a1Cbuitem;
    }

    public void setA1Cbuitem(String a1Cbuitem) {
        this.a1Cbuitem = a1Cbuitem;
    }

    public String getA1Opscope() {
        return a1Opscope;
    }

    public void setA1Opscope(String a1Opscope) {
        this.a1Opscope = a1Opscope;
    }

    public String getA1Opscoandform() {
        return a1Opscoandform;
    }

    public void setA1Opscoandform(String a1Opscoandform) {
        this.a1Opscoandform = a1Opscoandform;
    }

    public String getA1Zsopscope() {
        return a1Zsopscope;
    }

    public void setA1Zsopscope(String a1Zsopscope) {
        this.a1Zsopscope = a1Zsopscope;
    }

    public String getA1Regorg() {
        return a1Regorg;
    }

    public void setA1Regorg(String a1Regorg) {
        this.a1Regorg = a1Regorg;
    }

    public String getA1Regorgcode() {
        return a1Regorgcode;
    }

    public void setA1Regorgcode(String a1Regorgcode) {
        this.a1Regorgcode = a1Regorgcode;
    }

    public String getA1Regorgprovince() {
        return a1Regorgprovince;
    }

    public void setA1Regorgprovince(String a1Regorgprovince) {
        this.a1Regorgprovince = a1Regorgprovince;
    }

    public String getA1Anchedate() {
        return a1Anchedate;
    }

    public void setA1Anchedate(String a1Anchedate) {
        this.a1Anchedate = a1Anchedate;
    }

    public String getA1Entnameeng() {
        return a1Entnameeng;
    }

    public void setA1Entnameeng(String a1Entnameeng) {
        this.a1Entnameeng = a1Entnameeng;
    }

    public String getA1Creditcod() {
        return a1Creditcod;
    }

    public void setA1Creditcod(String a1Creditcod) {
        this.a1Creditcod = a1Creditcod;
    }

    public String getA1Regcap() {
        return a1Regcap;
    }

    public void setA1Regcap(String a1Regcap) {
        this.a1Regcap = a1Regcap;
    }

    public String getA1Abuitem() {
        return a1Abuitem;
    }

    public void setA1Abuitem(String a1Abuitem) {
        this.a1Abuitem = a1Abuitem;
    }

}
