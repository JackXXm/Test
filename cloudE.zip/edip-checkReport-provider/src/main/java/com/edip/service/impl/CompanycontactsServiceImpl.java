package com.edip.service.impl;

import com.edip.controller.ChinaAreaClient;
import com.edip.dto.SessionContext;
import com.edip.entity.Companycontacts;
import com.edip.entity.CompanycontactsVO;
import com.edip.feign.CompanyFeign;
import com.edip.mapper.CompanycontactsMapper;
import com.edip.mapper.OutBoxMapper;
import com.edip.mapper.ReceiveBoxMapper;
import com.edip.service.CompanycontactsService;

import com.edip.utils.FileTypeUtil;
import com.edip.utils.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Field;
import java.util.*;




@Service("companycontactsService")
public class CompanycontactsServiceImpl implements CompanycontactsService {
	private static final Logger logger = LoggerFactory.getLogger(CompanycontactsServiceImpl.class);

	@Autowired
	private CompanycontactsMapper companycontactsMapper;

    @Autowired
    private ChinaAreaClient chinaAreaClient;

    @Autowired
    private CompanyFeign companyFeign;

    @Autowired
    private ReceiveBoxMapper receiveBoxMapper;

    @Autowired
    private OutBoxMapper outBoxMapper;

    //private static final String EXCEL_PATH =  System.getProperty("user.dir") + "/excel";

    private static String LOCAL_ABSOLUTE_TEMP_PATH;
    @Value("${LOCAL_ABSOLUTE_TEMP_PATH}")
    public void setLOCAL_ABSOLUTE_TEMP_PATH(String excelPath) {
        this.LOCAL_ABSOLUTE_TEMP_PATH = excelPath;
    }

    @Override
	public List<Map<String, Object>> selectWithPage(Map<String, Object> params) throws Exception {
		return companycontactsMapper.queryCompanycontactsList(params);
	}

	@Override
	public Map<String , Object> update(Map<String, Object> params, HttpServletRequest request) {
		Map<String , Object> map = new HashMap<String , Object>();
        Integer compID = (Integer) SessionContext.getContext().getSession(request).getAttribute("compID");
        params.put("compID" , compID);
		try {
			Integer ccid = companycontactsMapper.selectByEntityCode(params);
			if(ccid!=null){
                if(ccid.toString().equals(params.get("ccid").toString())){
                    Integer result = companycontactsMapper.updateCompanycontacts(params);
                    if(result>=0){
                        map.put("code",0);
                    }
                }else{
                    map.put("code",2);
                    map.put("msg","改公司已经添加！");
                }
            }else {
                String cocomp = this.getCompIdByName(params.get("companyName").toString());
                if(cocomp!=null){
                    params.put("cocompID" ,cocomp);
                }
                Integer result = companycontactsMapper.updateCompanycontacts(params);
                if(result>=0){
                    map.put("code",0);
                }
            }

		} catch (Exception e) {
			e.printStackTrace();
			map.put("code", 1);
			map.put("msg", "更新失败！");
		}
		return map;
	}

	@Override
	public Integer deleteCompanycontacts(Map<String, Object> params) {
		return companycontactsMapper.deleteCompanycontacts(params);
	}



	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Map<String, Object> uploadCompanycontacts(HttpServletRequest request, HttpServletResponse response) {
		Workbook wb = null;
		Sheet sheet = null;
		Row row = null;
		List msglist = new ArrayList();
		Map<String, Object> res = new HashMap<String, Object>();
		Map<String, Object> params = new HashMap<String, Object>();
		try {
			// 获得excel上传后地址
			String filePath =null;// ExcelUtil.saveFile(request, LOCAL_ABSOLUTE_TEMP_PATH);
			String fileType = new FileTypeUtil().getFileType(filePath);
			if(!fileType.equals("xlsx") && !fileType.equals("xls")){
                msglist.add("文件上传格式有误，请上传excel文件！");
				res.put("result", false);
				res.put("msglist", msglist);
				return res;
			}
            wb = null;//ExcelReadUtil.readExcel(filePath);
			/*if(fileType.equals("xls")){
                wb = ExcelReadUtil.readExcel(filePath);
            }else if(fileType.equals("xlsx")){
			    wb=ExcelReadUtil.readExcel1(filePath,"xlsx");
            }*/

			// 读取 ececl信息
			if (wb != null) {
				// 获取第一个sheet
				sheet = wb.getSheetAt(0);
				// 获取最大行数
				int rownum = sheet.getPhysicalNumberOfRows();
				// 获取第一行
				row = sheet.getRow(0);
				// 获取最大列数
				int colnum = row.getPhysicalNumberOfCells();
				List<CompanycontactsVO> companycontactsvoList = new ArrayList<CompanycontactsVO>();
				CompanycontactsVO companycontactsVO = null;
				Field[] mBeanFiled = null;

				for (int i = 0; i < rownum + 1; i++) {
					companycontactsVO = new CompanycontactsVO();
					mBeanFiled = companycontactsVO.getClass().getDeclaredFields();
					row = sheet.getRow(i);
					if (row != null) {
						for (int j = 0; j < colnum; j++) {
							// 循环每一行中的所有列,就是得到单元格中的数据
							try {
								// 强制反射,让private 的属性也可以访问
								mBeanFiled[j].setAccessible(true);
								// 把得到的属性进行赋值，就是把读取到的单元格中的数据赋给对应的属性
								mBeanFiled[j].set(companycontactsVO, "");
							} catch (IllegalArgumentException e) {
								e.printStackTrace();
							} catch (IllegalAccessException e) {
								e.printStackTrace();
							}

						}
					} else {
						logger.debug("execl第" + i + "行------>为空");
						break;
					}
					companycontactsvoList.add(companycontactsVO);
				}
				boolean flag = true;
                CompanycontactsVO oneRow = companycontactsvoList.get(0);//判断模板正确性
                if(oneRow!=null){
                    if(!oneRow.getCompanyName().equals("企业名称*") || !oneRow.getUpstreamSupplier().equals("供应商") || !oneRow.getDownCustom().equals("客户")){
                        msglist.add("文件模板有误，请使用正确的模板！");
                        res.put("result", false);
                        res.put("msglist", msglist);
                        return res;
                    }
                }
				for (int i = 1; i < companycontactsvoList.size(); i++) {
					int k = i + 1;
					Companycontacts cc = new Companycontacts();
					if (companycontactsvoList.get(i).getDownCustom() != null && !"".equals(companycontactsvoList.get(i).getDownCustom())) {
						if("是".equals(companycontactsvoList.get(i).getDownCustom())){
							cc.setDownCustom(1);
						}else{
							cc.setDownCustom(0);
						}
						
					}
					
					if (companycontactsvoList.get(i).getUpstreamSupplier() != null && !"".equals(companycontactsvoList.get(i).getUpstreamSupplier())) {
						if("是".equals(companycontactsvoList.get(i).getUpstreamSupplier())){
							cc.setUpstreamSupplier(1);
						}else{
							cc.setUpstreamSupplier(0);
						}
		
					}
					
					if (companycontactsvoList.get(i).getAdress() != null && !"".equals(companycontactsvoList.get(i).getAdress())) {
						//params.put("provName", companycontactsvoList.get(i).getAdress());
						Integer address = (Integer) chinaAreaClient.searchProIdByName(companycontactsvoList.get(i).getAdress()).getData();
						if(address!=null){
                            cc.setAddress(address.toString());
                        }

					}
					
					if (companycontactsvoList.get(i).getCompanyName() != null && !"".equals(companycontactsvoList.get(i).getCompanyName())) {
						cc.setCompanyName(companycontactsvoList.get(i).getCompanyName());
					} else {
						logger.debug("第" + (k+1) + "行通讯录部分信息上传失败，-------》合作公司名称为空");
						msglist.add("第" + (k+1) + "行通讯录部分信息上传失败，-------》合作公司名称为空");
						flag = false;
						continue;
					}
					
					if (companycontactsvoList.get(i).getName() != null && !"".equals(companycontactsvoList.get(i).getName())) {
						cc.setName(companycontactsvoList.get(i).getName());
					}/*else {
						logger.debug("第" + (k+1) + "行合作企业信息上传失败，-------》联系人为空");
						msglist.add("第" + (k+1) + "行合作企业信息上传失败，-------》联系人为空");
						flag = false;
						continue;
					} */
					
					if (companycontactsvoList.get(i).getPhone() != null && !"".equals(companycontactsvoList.get(i).getPhone())) {
						cc.setPhone(companycontactsvoList.get(i).getPhone());
					}/*else {
						logger.debug("第" + (k+1) + "行合作企业信息上传失败，-------》联系人电话为空");
						msglist.add("第" + (k+1) + "行合作企业信息上传失败，-------》联系人电话为空");
						flag = false;
						continue;
					}*/
                    Integer compID = (Integer) SessionContext.getContext().getSession(request).getAttribute("compID");
					cc.setCompID(compID);
					cc.setDeleteFlag(0);
					cc.setCreateTime(new Date());
					String cocomp = this.getCompIdByName(cc.getCompanyName());
					if(cocomp!=null){
					    cc.setCocompID(Integer.valueOf(cocomp));
                    }
					// 插入数据库
					List<Companycontacts> list = companycontactsMapper.selectByEntity(cc);
					if (list.size() > 0) {
					    Integer ccid = list.get(0).getCcid();
					    cc.setCcid(ccid);
					    companycontactsMapper.updateImport(cc);
					} else {
						companycontactsMapper.insert(cc);
					}
				}
				if (flag == true) {
					res.put("result", true);
					res.put("msglist", msglist);
				} else {
					res.put("result", false);
					res.put("msglist", msglist);
				}
			}
		} catch (Exception e) {
			logger.error("上传失败------>", e.getMessage(), e);
            msglist.add("文件模板有误，请使用正确的模板！");
			res.put("result", false);
			res.put("msglist", msglist);
		}
		return res;
	}

	@Override
	public Map<String, Object> search(Map<String, Object> params) throws Exception {
		return companycontactsMapper.search(params);
	}

    @Override
    @Transactional
    public Integer insertOneCompanyContracts(Map<String, Object> params) {
        String cocomp = this.getCompIdByName(params.get("companyName").toString());
        if(cocomp!=null){
            params.put("cocompID" ,cocomp);
        }
        return companycontactsMapper.insertOne(params);
    }

    @Override
    public Map<String, Object> getReSeNum(Integer compID) {
        Map<String , Object> result = new HashMap<>();
        Map<String , Object> params = new HashMap<>();
        params.put("compID",compID);
        Integer  outListNum = outBoxMapper.statisticsOutBox(compID);
        Integer receiveNum = receiveBoxMapper.sumReceBox(params);
        result.put("outTotal",outListNum);
        result.put("recTotal",receiveNum);
        return result;
    }

    @Override
    public List<Map<String, Object>> queryCompanySendList(Integer compID) {
        return companycontactsMapper.queryCompanySendList(compID);
    }

    @Override
    public List<Map<String, Object>> queryCompanyReceiveList(Integer compID) {
        return companycontactsMapper.queryCompanyRecceiveList(compID);
    }


    public String getCompIdByName(String companyName){
        String compID = (String)companyFeign.getCompanyByName(companyName).getData();
        if (StringUtils.isNotEmpty(compID)){
            return compID;
        }
        return  null;
    }

    }
