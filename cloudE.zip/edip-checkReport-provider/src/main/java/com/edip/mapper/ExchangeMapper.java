package com.edip.mapper;

import com.edip.entity.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Map;

public interface ExchangeMapper {
    List<Map<String,Object>> queryReceiveCompany(@Param("compID") Integer compID, @Param("companyName") String companyName);

    /**
     * 新增发送任务
     * @param exchangeJob
     */
    void insertExchangeJob(@RequestBody ExchangeJob exchangeJob);

    /**
     * 新增project
     * @param project
     * @return
     */
    int insertProject(@RequestBody ExchangeProject project);
    /**
     * 新增ReceiveCompany
     * @param receiveCompany
     * @return
     */
    int insertReceiveCompany(@RequestBody ReceiveCompany receiveCompany);
    int updateReceiveCompany(Map<String, String> param);
    String queryReturnDocStatus(Map<String, String> param);
    void insertProductCompany(ExchangeProductCompany exchangeProductCompany);
    Integer queryAllFileItem(int jobId);
    void insertFileItem(ExchangeFileItem fileItem);
    List<DocumentVo>queryAllDocByIds(Map<String, Object> params);
    List<Map<String,Object>>getCheckReportDetail(Map<String, Object> params);
    List<Map<String,Object>>getSendReportDocDetail(Map<String, Object> params);
}
