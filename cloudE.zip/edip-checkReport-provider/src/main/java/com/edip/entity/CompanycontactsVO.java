package com.edip.entity;

public class CompanycontactsVO {
	
	private String companyName;//合作企业名称

    private String upstreamSupplier;//上游供应商 0.不是 1.是

    private String downCustom;//下游客户 0.不是  1.是

	private String adress;//合作公司所在省
	
	private String name;//合作公司联系人
	
	private String phone;


    public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getUpstreamSupplier() {
		return upstreamSupplier;
	}

	public void setUpstreamSupplier(String upstreamSupplier) {
		this.upstreamSupplier = upstreamSupplier;
	}

	public String getDownCustom() {
		return downCustom;
	}

	public void setDownCustom(String downCustom) {
		this.downCustom = downCustom;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
   

		
	
	
    
    


   
	

}