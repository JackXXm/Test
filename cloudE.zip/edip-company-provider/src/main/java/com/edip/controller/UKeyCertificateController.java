package com.edip.controller;

import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.service.UKeyCertificateService;
import com.edip.vo.UKeyVo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * UKey证书管理控制器
 * 
 * @author Administrator
 *
 */
@Controller
@RequestMapping(value = "/UKeyController")
public class UKeyCertificateController {
	private static final Logger logger = LoggerFactory.getLogger(UKeyCertificateController.class);
	@Autowired
	@Qualifier("uKeyCertificateService")
	private UKeyCertificateService uKeyCertificateService;

	/**
	 * 点击提交
	 */
	
	@RequestMapping(value="/check.ajax")
	@ResponseBody
	public List<Map<String,Object>> checkMessage(HttpServletRequest request, UKeyVo uKeyVo){
		List<Map<String,Object>> flag = new ArrayList<Map<String,Object>>();
		Integer compID = (Integer) SessionContext.getContext().getSession(request).getAttribute("compID");
		String stampType="公章";
		
		Map<String,Object>params = new HashMap<String,Object>();
		params.put("compID", compID);
		params.put("stampType", stampType);
		try{
			flag = uKeyCertificateService.checkMessage(uKeyVo,params);
		}catch(Exception e){
			logger.error("查询失败", e);
		}
		
		return flag;
	}

	@RequestMapping(value="/cert.ajax")
	@ResponseBody
	public ServerResponse checkCert(HttpServletRequest request){
		Integer compID = (Integer) SessionContext.getContext().getSession(request).getAttribute("compID");
		if(compID ==null ){
			return ServerResponse.createByErrorMsg("请退出，重新登录。");
		}
		try{
			int amount = uKeyCertificateService.queryCert(compID);
			if(amount==1){
				return ServerResponse.createBySuccess();
			}else{
				return ServerResponse.createByError(-1,"证书不存在");
			}
		}catch(Exception e){
			return ServerResponse.createByErrorMsg("查询失败");
		}
	}
	

}
