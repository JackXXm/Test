package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class BillExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public BillExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andBillidIsNull() {
            addCriterion("billID is null");
            return (Criteria) this;
        }

        public Criteria andBillidIsNotNull() {
            addCriterion("billID is not null");
            return (Criteria) this;
        }

        public Criteria andBillidEqualTo(Integer value) {
            addCriterion("billID =", value, "billid");
            return (Criteria) this;
        }

        public Criteria andBillidNotEqualTo(Integer value) {
            addCriterion("billID <>", value, "billid");
            return (Criteria) this;
        }

        public Criteria andBillidGreaterThan(Integer value) {
            addCriterion("billID >", value, "billid");
            return (Criteria) this;
        }

        public Criteria andBillidGreaterThanOrEqualTo(Integer value) {
            addCriterion("billID >=", value, "billid");
            return (Criteria) this;
        }

        public Criteria andBillidLessThan(Integer value) {
            addCriterion("billID <", value, "billid");
            return (Criteria) this;
        }

        public Criteria andBillidLessThanOrEqualTo(Integer value) {
            addCriterion("billID <=", value, "billid");
            return (Criteria) this;
        }

        public Criteria andBillidIn(List<Integer> values) {
            addCriterion("billID in", values, "billid");
            return (Criteria) this;
        }

        public Criteria andBillidNotIn(List<Integer> values) {
            addCriterion("billID not in", values, "billid");
            return (Criteria) this;
        }

        public Criteria andBillidBetween(Integer value1, Integer value2) {
            addCriterion("billID between", value1, value2, "billid");
            return (Criteria) this;
        }

        public Criteria andBillidNotBetween(Integer value1, Integer value2) {
            addCriterion("billID not between", value1, value2, "billid");
            return (Criteria) this;
        }

        public Criteria andCdrtypeIsNull() {
            addCriterion("cdrType is null");
            return (Criteria) this;
        }

        public Criteria andCdrtypeIsNotNull() {
            addCriterion("cdrType is not null");
            return (Criteria) this;
        }

        public Criteria andCdrtypeEqualTo(Integer value) {
            addCriterion("cdrType =", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeNotEqualTo(Integer value) {
            addCriterion("cdrType <>", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeGreaterThan(Integer value) {
            addCriterion("cdrType >", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("cdrType >=", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeLessThan(Integer value) {
            addCriterion("cdrType <", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeLessThanOrEqualTo(Integer value) {
            addCriterion("cdrType <=", value, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeIn(List<Integer> values) {
            addCriterion("cdrType in", values, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeNotIn(List<Integer> values) {
            addCriterion("cdrType not in", values, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeBetween(Integer value1, Integer value2) {
            addCriterion("cdrType between", value1, value2, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrtypeNotBetween(Integer value1, Integer value2) {
            addCriterion("cdrType not between", value1, value2, "cdrtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeIsNull() {
            addCriterion("cdrsubType is null");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeIsNotNull() {
            addCriterion("cdrsubType is not null");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeEqualTo(Float value) {
            addCriterion("cdrsubType =", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeNotEqualTo(Float value) {
            addCriterion("cdrsubType <>", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeGreaterThan(Float value) {
            addCriterion("cdrsubType >", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeGreaterThanOrEqualTo(Float value) {
            addCriterion("cdrsubType >=", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeLessThan(Float value) {
            addCriterion("cdrsubType <", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeLessThanOrEqualTo(Float value) {
            addCriterion("cdrsubType <=", value, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeIn(List<Float> values) {
            addCriterion("cdrsubType in", values, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeNotIn(List<Float> values) {
            addCriterion("cdrsubType not in", values, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeBetween(Float value1, Float value2) {
            addCriterion("cdrsubType between", value1, value2, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andCdrsubtypeNotBetween(Float value1, Float value2) {
            addCriterion("cdrsubType not between", value1, value2, "cdrsubtype");
            return (Criteria) this;
        }

        public Criteria andTotalcountIsNull() {
            addCriterion("totalCount is null");
            return (Criteria) this;
        }

        public Criteria andTotalcountIsNotNull() {
            addCriterion("totalCount is not null");
            return (Criteria) this;
        }

        public Criteria andTotalcountEqualTo(Float value) {
            addCriterion("totalCount =", value, "totalcount");
            return (Criteria) this;
        }

        public Criteria andTotalcountNotEqualTo(Float value) {
            addCriterion("totalCount <>", value, "totalcount");
            return (Criteria) this;
        }

        public Criteria andTotalcountGreaterThan(Float value) {
            addCriterion("totalCount >", value, "totalcount");
            return (Criteria) this;
        }

        public Criteria andTotalcountGreaterThanOrEqualTo(Float value) {
            addCriterion("totalCount >=", value, "totalcount");
            return (Criteria) this;
        }

        public Criteria andTotalcountLessThan(Float value) {
            addCriterion("totalCount <", value, "totalcount");
            return (Criteria) this;
        }

        public Criteria andTotalcountLessThanOrEqualTo(Float value) {
            addCriterion("totalCount <=", value, "totalcount");
            return (Criteria) this;
        }

        public Criteria andTotalcountIn(List<Float> values) {
            addCriterion("totalCount in", values, "totalcount");
            return (Criteria) this;
        }

        public Criteria andTotalcountNotIn(List<Float> values) {
            addCriterion("totalCount not in", values, "totalcount");
            return (Criteria) this;
        }

        public Criteria andTotalcountBetween(Float value1, Float value2) {
            addCriterion("totalCount between", value1, value2, "totalcount");
            return (Criteria) this;
        }

        public Criteria andTotalcountNotBetween(Float value1, Float value2) {
            addCriterion("totalCount not between", value1, value2, "totalcount");
            return (Criteria) this;
        }

        public Criteria andUsedcountIsNull() {
            addCriterion("usedCount is null");
            return (Criteria) this;
        }

        public Criteria andUsedcountIsNotNull() {
            addCriterion("usedCount is not null");
            return (Criteria) this;
        }

        public Criteria andUsedcountEqualTo(Float value) {
            addCriterion("usedCount =", value, "usedcount");
            return (Criteria) this;
        }

        public Criteria andUsedcountNotEqualTo(Float value) {
            addCriterion("usedCount <>", value, "usedcount");
            return (Criteria) this;
        }

        public Criteria andUsedcountGreaterThan(Float value) {
            addCriterion("usedCount >", value, "usedcount");
            return (Criteria) this;
        }

        public Criteria andUsedcountGreaterThanOrEqualTo(Float value) {
            addCriterion("usedCount >=", value, "usedcount");
            return (Criteria) this;
        }

        public Criteria andUsedcountLessThan(Float value) {
            addCriterion("usedCount <", value, "usedcount");
            return (Criteria) this;
        }

        public Criteria andUsedcountLessThanOrEqualTo(Float value) {
            addCriterion("usedCount <=", value, "usedcount");
            return (Criteria) this;
        }

        public Criteria andUsedcountIn(List<Float> values) {
            addCriterion("usedCount in", values, "usedcount");
            return (Criteria) this;
        }

        public Criteria andUsedcountNotIn(List<Float> values) {
            addCriterion("usedCount not in", values, "usedcount");
            return (Criteria) this;
        }

        public Criteria andUsedcountBetween(Float value1, Float value2) {
            addCriterion("usedCount between", value1, value2, "usedcount");
            return (Criteria) this;
        }

        public Criteria andUsedcountNotBetween(Float value1, Float value2) {
            addCriterion("usedCount not between", value1, value2, "usedcount");
            return (Criteria) this;
        }

        public Criteria andRemaincountIsNull() {
            addCriterion("remainCount is null");
            return (Criteria) this;
        }

        public Criteria andRemaincountIsNotNull() {
            addCriterion("remainCount is not null");
            return (Criteria) this;
        }

        public Criteria andRemaincountEqualTo(Float value) {
            addCriterion("remainCount =", value, "remaincount");
            return (Criteria) this;
        }

        public Criteria andRemaincountNotEqualTo(Float value) {
            addCriterion("remainCount <>", value, "remaincount");
            return (Criteria) this;
        }

        public Criteria andRemaincountGreaterThan(Float value) {
            addCriterion("remainCount >", value, "remaincount");
            return (Criteria) this;
        }

        public Criteria andRemaincountGreaterThanOrEqualTo(Float value) {
            addCriterion("remainCount >=", value, "remaincount");
            return (Criteria) this;
        }

        public Criteria andRemaincountLessThan(Float value) {
            addCriterion("remainCount <", value, "remaincount");
            return (Criteria) this;
        }

        public Criteria andRemaincountLessThanOrEqualTo(Float value) {
            addCriterion("remainCount <=", value, "remaincount");
            return (Criteria) this;
        }

        public Criteria andRemaincountIn(List<Float> values) {
            addCriterion("remainCount in", values, "remaincount");
            return (Criteria) this;
        }

        public Criteria andRemaincountNotIn(List<Float> values) {
            addCriterion("remainCount not in", values, "remaincount");
            return (Criteria) this;
        }

        public Criteria andRemaincountBetween(Float value1, Float value2) {
            addCriterion("remainCount between", value1, value2, "remaincount");
            return (Criteria) this;
        }

        public Criteria andRemaincountNotBetween(Float value1, Float value2) {
            addCriterion("remainCount not between", value1, value2, "remaincount");
            return (Criteria) this;
        }

        public Criteria andRemainderIsNull() {
            addCriterion("remainder is null");
            return (Criteria) this;
        }

        public Criteria andRemainderIsNotNull() {
            addCriterion("remainder is not null");
            return (Criteria) this;
        }

        public Criteria andRemainderEqualTo(Integer value) {
            addCriterion("remainder =", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderNotEqualTo(Integer value) {
            addCriterion("remainder <>", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderGreaterThan(Integer value) {
            addCriterion("remainder >", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderGreaterThanOrEqualTo(Integer value) {
            addCriterion("remainder >=", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderLessThan(Integer value) {
            addCriterion("remainder <", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderLessThanOrEqualTo(Integer value) {
            addCriterion("remainder <=", value, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderIn(List<Integer> values) {
            addCriterion("remainder in", values, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderNotIn(List<Integer> values) {
            addCriterion("remainder not in", values, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderBetween(Integer value1, Integer value2) {
            addCriterion("remainder between", value1, value2, "remainder");
            return (Criteria) this;
        }

        public Criteria andRemainderNotBetween(Integer value1, Integer value2) {
            addCriterion("remainder not between", value1, value2, "remainder");
            return (Criteria) this;
        }

        public Criteria andTotalamountIsNull() {
            addCriterion("totalAmount is null");
            return (Criteria) this;
        }

        public Criteria andTotalamountIsNotNull() {
            addCriterion("totalAmount is not null");
            return (Criteria) this;
        }

        public Criteria andTotalamountEqualTo(Float value) {
            addCriterion("totalAmount =", value, "totalamount");
            return (Criteria) this;
        }

        public Criteria andTotalamountNotEqualTo(Float value) {
            addCriterion("totalAmount <>", value, "totalamount");
            return (Criteria) this;
        }

        public Criteria andTotalamountGreaterThan(Float value) {
            addCriterion("totalAmount >", value, "totalamount");
            return (Criteria) this;
        }

        public Criteria andTotalamountGreaterThanOrEqualTo(Float value) {
            addCriterion("totalAmount >=", value, "totalamount");
            return (Criteria) this;
        }

        public Criteria andTotalamountLessThan(Float value) {
            addCriterion("totalAmount <", value, "totalamount");
            return (Criteria) this;
        }

        public Criteria andTotalamountLessThanOrEqualTo(Float value) {
            addCriterion("totalAmount <=", value, "totalamount");
            return (Criteria) this;
        }

        public Criteria andTotalamountIn(List<Float> values) {
            addCriterion("totalAmount in", values, "totalamount");
            return (Criteria) this;
        }

        public Criteria andTotalamountNotIn(List<Float> values) {
            addCriterion("totalAmount not in", values, "totalamount");
            return (Criteria) this;
        }

        public Criteria andTotalamountBetween(Float value1, Float value2) {
            addCriterion("totalAmount between", value1, value2, "totalamount");
            return (Criteria) this;
        }

        public Criteria andTotalamountNotBetween(Float value1, Float value2) {
            addCriterion("totalAmount not between", value1, value2, "totalamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountIsNull() {
            addCriterion("remainAmount is null");
            return (Criteria) this;
        }

        public Criteria andRemainamountIsNotNull() {
            addCriterion("remainAmount is not null");
            return (Criteria) this;
        }

        public Criteria andRemainamountEqualTo(Float value) {
            addCriterion("remainAmount =", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountNotEqualTo(Float value) {
            addCriterion("remainAmount <>", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountGreaterThan(Float value) {
            addCriterion("remainAmount >", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountGreaterThanOrEqualTo(Float value) {
            addCriterion("remainAmount >=", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountLessThan(Float value) {
            addCriterion("remainAmount <", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountLessThanOrEqualTo(Float value) {
            addCriterion("remainAmount <=", value, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountIn(List<Float> values) {
            addCriterion("remainAmount in", values, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountNotIn(List<Float> values) {
            addCriterion("remainAmount not in", values, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountBetween(Float value1, Float value2) {
            addCriterion("remainAmount between", value1, value2, "remainamount");
            return (Criteria) this;
        }

        public Criteria andRemainamountNotBetween(Float value1, Float value2) {
            addCriterion("remainAmount not between", value1, value2, "remainamount");
            return (Criteria) this;
        }

        public Criteria andCompidIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompidIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompidEqualTo(Integer value) {
            addCriterion("compID =", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThan(Integer value) {
            addCriterion("compID >", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThan(Integer value) {
            addCriterion("compID <", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidIn(List<Integer> values) {
            addCriterion("compID in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andCompidNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compid");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreatedateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreatedateEqualTo(Date value) {
            addCriterion("createDate =", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThan(Date value) {
            addCriterion("createDate <", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateIn(List<Date> values) {
            addCriterion("createDate in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andCreatedateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createdate");
            return (Criteria) this;
        }

        public Criteria andModeidIsNull() {
            addCriterion("modeID is null");
            return (Criteria) this;
        }

        public Criteria andModeidIsNotNull() {
            addCriterion("modeID is not null");
            return (Criteria) this;
        }

        public Criteria andModeidEqualTo(Integer value) {
            addCriterion("modeID =", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidNotEqualTo(Integer value) {
            addCriterion("modeID <>", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidGreaterThan(Integer value) {
            addCriterion("modeID >", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidGreaterThanOrEqualTo(Integer value) {
            addCriterion("modeID >=", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidLessThan(Integer value) {
            addCriterion("modeID <", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidLessThanOrEqualTo(Integer value) {
            addCriterion("modeID <=", value, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidIn(List<Integer> values) {
            addCriterion("modeID in", values, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidNotIn(List<Integer> values) {
            addCriterion("modeID not in", values, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidBetween(Integer value1, Integer value2) {
            addCriterion("modeID between", value1, value2, "modeid");
            return (Criteria) this;
        }

        public Criteria andModeidNotBetween(Integer value1, Integer value2) {
            addCriterion("modeID not between", value1, value2, "modeid");
            return (Criteria) this;
        }

        public Criteria andFreedateIsNull() {
            addCriterion("freeDate is null");
            return (Criteria) this;
        }

        public Criteria andFreedateIsNotNull() {
            addCriterion("freeDate is not null");
            return (Criteria) this;
        }

        public Criteria andFreedateEqualTo(Date value) {
            addCriterionForJDBCDate("freeDate =", value, "freedate");
            return (Criteria) this;
        }

        public Criteria andFreedateNotEqualTo(Date value) {
            addCriterionForJDBCDate("freeDate <>", value, "freedate");
            return (Criteria) this;
        }

        public Criteria andFreedateGreaterThan(Date value) {
            addCriterionForJDBCDate("freeDate >", value, "freedate");
            return (Criteria) this;
        }

        public Criteria andFreedateGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("freeDate >=", value, "freedate");
            return (Criteria) this;
        }

        public Criteria andFreedateLessThan(Date value) {
            addCriterionForJDBCDate("freeDate <", value, "freedate");
            return (Criteria) this;
        }

        public Criteria andFreedateLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("freeDate <=", value, "freedate");
            return (Criteria) this;
        }

        public Criteria andFreedateIn(List<Date> values) {
            addCriterionForJDBCDate("freeDate in", values, "freedate");
            return (Criteria) this;
        }

        public Criteria andFreedateNotIn(List<Date> values) {
            addCriterionForJDBCDate("freeDate not in", values, "freedate");
            return (Criteria) this;
        }

        public Criteria andFreedateBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("freeDate between", value1, value2, "freedate");
            return (Criteria) this;
        }

        public Criteria andFreedateNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("freeDate not between", value1, value2, "freedate");
            return (Criteria) this;
        }

        public Criteria andGiveamountIsNull() {
            addCriterion("giveAmount is null");
            return (Criteria) this;
        }

        public Criteria andGiveamountIsNotNull() {
            addCriterion("giveAmount is not null");
            return (Criteria) this;
        }

        public Criteria andGiveamountEqualTo(Float value) {
            addCriterion("giveAmount =", value, "giveamount");
            return (Criteria) this;
        }

        public Criteria andGiveamountNotEqualTo(Float value) {
            addCriterion("giveAmount <>", value, "giveamount");
            return (Criteria) this;
        }

        public Criteria andGiveamountGreaterThan(Float value) {
            addCriterion("giveAmount >", value, "giveamount");
            return (Criteria) this;
        }

        public Criteria andGiveamountGreaterThanOrEqualTo(Float value) {
            addCriterion("giveAmount >=", value, "giveamount");
            return (Criteria) this;
        }

        public Criteria andGiveamountLessThan(Float value) {
            addCriterion("giveAmount <", value, "giveamount");
            return (Criteria) this;
        }

        public Criteria andGiveamountLessThanOrEqualTo(Float value) {
            addCriterion("giveAmount <=", value, "giveamount");
            return (Criteria) this;
        }

        public Criteria andGiveamountIn(List<Float> values) {
            addCriterion("giveAmount in", values, "giveamount");
            return (Criteria) this;
        }

        public Criteria andGiveamountNotIn(List<Float> values) {
            addCriterion("giveAmount not in", values, "giveamount");
            return (Criteria) this;
        }

        public Criteria andGiveamountBetween(Float value1, Float value2) {
            addCriterion("giveAmount between", value1, value2, "giveamount");
            return (Criteria) this;
        }

        public Criteria andGiveamountNotBetween(Float value1, Float value2) {
            addCriterion("giveAmount not between", value1, value2, "giveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountIsNull() {
            addCriterion("remainGiveAmount is null");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountIsNotNull() {
            addCriterion("remainGiveAmount is not null");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountEqualTo(Float value) {
            addCriterion("remainGiveAmount =", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountNotEqualTo(Float value) {
            addCriterion("remainGiveAmount <>", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountGreaterThan(Float value) {
            addCriterion("remainGiveAmount >", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountGreaterThanOrEqualTo(Float value) {
            addCriterion("remainGiveAmount >=", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountLessThan(Float value) {
            addCriterion("remainGiveAmount <", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountLessThanOrEqualTo(Float value) {
            addCriterion("remainGiveAmount <=", value, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountIn(List<Float> values) {
            addCriterion("remainGiveAmount in", values, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountNotIn(List<Float> values) {
            addCriterion("remainGiveAmount not in", values, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountBetween(Float value1, Float value2) {
            addCriterion("remainGiveAmount between", value1, value2, "remaingiveamount");
            return (Criteria) this;
        }

        public Criteria andRemaingiveamountNotBetween(Float value1, Float value2) {
            addCriterion("remainGiveAmount not between", value1, value2, "remaingiveamount");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}