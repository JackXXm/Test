package com.edip.entity;

public class AdminCertWithBLOBs extends AdminCert {
    private byte[] x509;

    private byte[] publicKey;

    public byte[] getX509() {
        return x509;
    }

    public void setX509(byte[] x509) {
        this.x509 = x509;
    }

    public byte[] getPublickey() {
        return publicKey;
    }

    public void setPublickey(byte[] publickey) {
        this.publicKey = publickey;
    }
}