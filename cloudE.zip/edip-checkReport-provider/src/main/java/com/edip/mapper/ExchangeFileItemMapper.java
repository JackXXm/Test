package com.edip.mapper;

import com.edip.entity.ExchangeFileItem;
import com.edip.entity.ExchangeFileItemExample;
import com.edip.entity.SignInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface ExchangeFileItemMapper {
    long countByExample(ExchangeFileItemExample example);

    int deleteByExample(ExchangeFileItemExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ExchangeFileItem record);

    int insertSelective(ExchangeFileItem record);

    List<ExchangeFileItem> selectByExample(ExchangeFileItemExample example);

    ExchangeFileItem selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ExchangeFileItem record, @Param("example") ExchangeFileItemExample example);

    int updateByExample(@Param("record") ExchangeFileItem record, @Param("example") ExchangeFileItemExample example);

    int updateByPrimaryKeySelective(ExchangeFileItem record);

    int updateByPrimaryKey(ExchangeFileItem record);
    List<SignInfo>getSignDocInfo(Map<String, Object> signInfo);
    List<Map<String,Object>>queryDeleteDocs(Map<String, Object> signInfo);
    int updateSignStatus(Map<String, Object> updateMap);
    int updateSignDoc(Map<String, Object> updateMap);
    List<SignInfo> getReturnSignDocInfo(Map<String, Object> signInfo);
    Map<String,Object> getReturnSignatureInfo(String signInfo);
    List<ExchangeFileItem>getSendDocs(Map<String, Object> signInfo);
}