package com.edip.entity;

import java.io.Serializable;

/**
 * @author 
 */
public class Billmode implements Serializable {
    /**
     * 计费策略ID
     */
    private Integer modeid;

    /**
     * 归属公司
     */
    private Integer compid;

    /**
     * 计费方式
                                     																		0:按次
                                     																		1:按额度
     */
    private Integer modetype;

    /**
     * 首次免费天数
     */
    private Integer firstfree;

    /**
     * 单次价格
     */
    private Float unitprice;

    /**
     * 折扣率(0~9)
     */
    private Integer rebate;

    /**
     * 状态
                                     																		0:无效
                                     																		1:有效
     */
    private Integer status;

    private static final long serialVersionUID = 1L;

    public Integer getModeid() {
        return modeid;
    }

    public void setModeid(Integer modeid) {
        this.modeid = modeid;
    }

    public Integer getCompid() {
        return compid;
    }

    public void setCompid(Integer compid) {
        this.compid = compid;
    }

    public Integer getModetype() {
        return modetype;
    }

    public void setModetype(Integer modetype) {
        this.modetype = modetype;
    }

    public Integer getFirstfree() {
        return firstfree;
    }

    public void setFirstfree(Integer firstfree) {
        this.firstfree = firstfree;
    }

    public Float getUnitprice() {
        return unitprice;
    }

    public void setUnitprice(Float unitprice) {
        this.unitprice = unitprice;
    }

    public Integer getRebate() {
        return rebate;
    }

    public void setRebate(Integer rebate) {
        this.rebate = rebate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Billmode other = (Billmode) that;
        return (this.getModeid() == null ? other.getModeid() == null : this.getModeid().equals(other.getModeid()))
            && (this.getCompid() == null ? other.getCompid() == null : this.getCompid().equals(other.getCompid()))
            && (this.getModetype() == null ? other.getModetype() == null : this.getModetype().equals(other.getModetype()))
            && (this.getFirstfree() == null ? other.getFirstfree() == null : this.getFirstfree().equals(other.getFirstfree()))
            && (this.getUnitprice() == null ? other.getUnitprice() == null : this.getUnitprice().equals(other.getUnitprice()))
            && (this.getRebate() == null ? other.getRebate() == null : this.getRebate().equals(other.getRebate()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getModeid() == null) ? 0 : getModeid().hashCode());
        result = prime * result + ((getCompid() == null) ? 0 : getCompid().hashCode());
        result = prime * result + ((getModetype() == null) ? 0 : getModetype().hashCode());
        result = prime * result + ((getFirstfree() == null) ? 0 : getFirstfree().hashCode());
        result = prime * result + ((getUnitprice() == null) ? 0 : getUnitprice().hashCode());
        result = prime * result + ((getRebate() == null) ? 0 : getRebate().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", modeid=").append(modeid);
        sb.append(", compid=").append(compid);
        sb.append(", modetype=").append(modetype);
        sb.append(", firstfree=").append(firstfree);
        sb.append(", unitprice=").append(unitprice);
        sb.append(", rebate=").append(rebate);
        sb.append(", status=").append(status);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}