package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class InspectDocument implements Serializable {
    /**
     * 检验报告资料id
     */
    private Integer id;

    /**
     * 克隆id
     */
    private Integer cloneId;

    /**
     * 报告id
     */
    private Integer inspectReportId;

    /**
     * 归属公司
     */
    private Integer compId;

    /**
     * 文件名称
     */
    private String docName;

    /**
     * 文件url
     */
    private String docUrl;

    /**
     * 签章后文件url
     */
    private String documentUrl;

    /**
     * 删除标示 0 正常 -1 删除
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人id
     */
    private Integer createAccountId;

    /**
     * 创建人
     */
    private String createBy;

    /**
     * 状态 0 正常 1  待发送
     */
    private Integer status;

    /**
     * 版本号
     */
    private Integer edition;

    /**
     * 来源 0 本地上传 1 在线接收 2 收藏
     */
    private Integer informationFrom;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCloneId() {
        return cloneId;
    }

    public void setCloneId(Integer cloneId) {
        this.cloneId = cloneId;
    }

    public Integer getInspectReportId() {
        return inspectReportId;
    }

    public void setInspectReportId(Integer inspectReportId) {
        this.inspectReportId = inspectReportId;
    }

    public Integer getCompId() {
        return compId;
    }

    public void setCompId(Integer compId) {
        this.compId = compId;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getDocUrl() {
        return docUrl;
    }

    public void setDocUrl(String docUrl) {
        this.docUrl = docUrl;
    }

    public String getDocumentUrl() {
        return documentUrl;
    }

    public void setDocumentUrl(String documentUrl) {
        this.documentUrl = documentUrl;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getCreateAccountId() {
        return createAccountId;
    }

    public void setCreateAccountId(Integer createAccountId) {
        this.createAccountId = createAccountId;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getEdition() {
        return edition;
    }

    public void setEdition(Integer edition) {
        this.edition = edition;
    }

    public Integer getInformationFrom() {
        return informationFrom;
    }

    public void setInformationFrom(Integer informationFrom) {
        this.informationFrom = informationFrom;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        InspectDocument other = (InspectDocument) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getCloneId() == null ? other.getCloneId() == null : this.getCloneId().equals(other.getCloneId()))
            && (this.getInspectReportId() == null ? other.getInspectReportId() == null : this.getInspectReportId().equals(other.getInspectReportId()))
            && (this.getCompId() == null ? other.getCompId() == null : this.getCompId().equals(other.getCompId()))
            && (this.getDocName() == null ? other.getDocName() == null : this.getDocName().equals(other.getDocName()))
            && (this.getDocUrl() == null ? other.getDocUrl() == null : this.getDocUrl().equals(other.getDocUrl()))
            && (this.getDocumentUrl() == null ? other.getDocumentUrl() == null : this.getDocumentUrl().equals(other.getDocumentUrl()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getCreateAccountId() == null ? other.getCreateAccountId() == null : this.getCreateAccountId().equals(other.getCreateAccountId()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getEdition() == null ? other.getEdition() == null : this.getEdition().equals(other.getEdition()))
            && (this.getInformationFrom() == null ? other.getInformationFrom() == null : this.getInformationFrom().equals(other.getInformationFrom()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getCloneId() == null) ? 0 : getCloneId().hashCode());
        result = prime * result + ((getInspectReportId() == null) ? 0 : getInspectReportId().hashCode());
        result = prime * result + ((getCompId() == null) ? 0 : getCompId().hashCode());
        result = prime * result + ((getDocName() == null) ? 0 : getDocName().hashCode());
        result = prime * result + ((getDocUrl() == null) ? 0 : getDocUrl().hashCode());
        result = prime * result + ((getDocumentUrl() == null) ? 0 : getDocumentUrl().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getCreateAccountId() == null) ? 0 : getCreateAccountId().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getEdition() == null) ? 0 : getEdition().hashCode());
        result = prime * result + ((getInformationFrom() == null) ? 0 : getInformationFrom().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", cloneId=").append(cloneId);
        sb.append(", inspectReportId=").append(inspectReportId);
        sb.append(", compId=").append(compId);
        sb.append(", docName=").append(docName);
        sb.append(", docUrl=").append(docUrl);
        sb.append(", documentUrl=").append(documentUrl);
        sb.append(", delFlag=").append(delFlag);
        sb.append(", createTime=").append(createTime);
        sb.append(", createAccountId=").append(createAccountId);
        sb.append(", createBy=").append(createBy);
        sb.append(", status=").append(status);
        sb.append(", edition=").append(edition);
        sb.append(", informationFrom=").append(informationFrom);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}