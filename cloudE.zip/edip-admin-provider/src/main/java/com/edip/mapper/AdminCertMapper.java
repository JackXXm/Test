package com.edip.mapper;

import com.edip.entity.AdminCert;
import com.edip.entity.AdminCertExample;
import com.edip.entity.AdminCertWithBLOBs;
import com.edip.vo.AdminCertVo;

import java.util.List;
import java.util.Map;

public interface AdminCertMapper {

    //优化证书查询
    List<Map<String,Object>> searchCert(Map<String , Object> params);

    Integer countCertTotal(Map<String, Object> params);

    AdminCertVo selectByPrimaryKey(Integer certID);

    List<AdminCertVo> selelctCertCompId(Integer compid);

    Integer updateByPrimaryKeySelective(AdminCertWithBLOBs record);

    List<AdminCertWithBLOBs> selectByExampleWithBLOBs(AdminCertExample example);

    Map<String,Object> getMailInfo(Integer certId);

    List<AdminCert> selectByExample(AdminCertExample example);

}
