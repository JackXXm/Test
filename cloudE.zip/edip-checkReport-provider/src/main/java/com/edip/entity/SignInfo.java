package com.edip.entity;

import java.util.Date;

public class SignInfo {
    //任务id
    private long taskId;
    //文件id
    private long docId;
    //文件名
    private String pdfName;
    //签章文件名
    private String signedPdfName;
    //自定义签章信息
    private String signInfo;
    //回传签章信息
    private String destSignInfo;
    //文件名
    private String aliasName;
    private String docType;

    private Date createDate;
    private Integer status;

    public long getDocId() {
        return docId;
    }

    public void setDocId(long docId) {
        this.docId = docId;
    }

    public String getPdfName() {
        return pdfName;
    }

    public void setPdfName(String pdfName) {
        this.pdfName = pdfName;
    }

    public String getSignedPdfName() {
        return signedPdfName;
    }

    public void setSignedPdfName(String signedPdfName) {
        this.signedPdfName = signedPdfName;
    }

    public String getSignInfo() {
        return signInfo;
    }

    public void setSignInfo(String signInfo) {
        this.signInfo = signInfo;
    }

    public String getDestSignInfo() {
        return destSignInfo;
    }

    public void setDestSignInfo(String destSignInfo) {
        this.destSignInfo = destSignInfo;
    }

    public long getTaskId() {
        return taskId;
    }

    public void setTaskId(long taskId) {
        this.taskId = taskId;
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
