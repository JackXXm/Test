package com.edip.entity;

import java.util.Date;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class Cdr {
    private Integer cdrID;

    private Integer cdrType;

    private Integer cdrsubType;

    private Integer compID;

    private Integer modeID;

    private Integer targetID;

    private Date createDate;

    private String name;

    private Integer dataType;

    private Integer dataID;

    private Integer signMoney ;
    private Integer accountCharging ;
    private Integer giveCharging ;

    public Integer getCdrID() {
        return cdrID;
    }

    public void setCdrID(Integer cdrID) {
        this.cdrID = cdrID;
    }

    public Integer getCdrType() {
        return cdrType;
    }

    public void setCdrType(Integer cdrType) {
        this.cdrType = cdrType;
    }

    public Integer getCdrsubType() {
        return cdrsubType;
    }

    public void setCdrsubType(Integer cdrsubType) {
        this.cdrsubType = cdrsubType;
    }

    public Integer getCompID() {
        return compID;
    }

    public void setCompID(Integer compID) {
        this.compID = compID;
    }

    public Integer getModeID() {
        return modeID;
    }

    public void setModeID(Integer modeID) {
        this.modeID = modeID;
    }

    public Integer getTargetID() {
        return targetID;
    }

    public void setTargetID(Integer targetID) {
        this.targetID = targetID;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Integer getDataType() {
        return dataType;
    }

    public void setDataType(Integer dataType) {
        this.dataType = dataType;
    }

    public Integer getDataID() {
        return dataID;
    }

    public void setDataID(Integer dataID) {
        this.dataID = dataID;
    }

    public Integer getSignMoney() {
        return signMoney;
    }

    public void setSignMoney(Integer signMoney) {
        this.signMoney = signMoney;
    }

    public Integer getAccountCharging() {
        return accountCharging;
    }

    public void setAccountCharging(Integer accountCharging) {
        this.accountCharging = accountCharging;
    }

    public Integer getGiveCharging() {
        return giveCharging;
    }

    public void setGiveCharging(Integer giveCharging) {
        this.giveCharging = giveCharging;
    }

}