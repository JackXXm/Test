package com.edip.mapper;

import com.edip.entity.Companycontacts;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CompanycontactsMapper {

	public List<Map<String, Object>> queryCompanycontactsList(Map<String, Object> params);

	int updateCompanycontacts(Map<String, Object> params);

	int deleteCompanycontacts(Map<String, Object> params);

	void insert(Companycontacts companycontacts);

	Integer insertOne(Map<String, Object> params);

	Integer selectByEntityCode(Map<String, Object> params);

	List<Map<String , Object>> queryByCompIdAndName(Map<String, Object> param);

    public List<Companycontacts> selectByEntity(Companycontacts companycontacts);


	public List<Map<String, Object>> selectByCompanyName(Companycontacts companycontacts);

	void updateImport(Companycontacts companycontacts);

    void updateImportSend(Companycontacts companycontacts);



	public Map<String, Object> selectProviceIdByName(Map<String, Object> params);

	public Map<String, Object> selectProviceNameById(Map<String, Object> params);

	Map<String, Object> search(Map<String, Object> params);



	public List<Map<String, Object>> querySendList(Map<String, Object> params);

	public Map<String , Object> queryRole(Integer compID);

	public int countSend(Map<String, Object> params);

	public List<Map<String, Object>> selectByCompanyNameAndCompID(Companycontacts com);


    public List<Map<String, Object>> queryOneSendList(Map<String, Object> params);

	public int countOneSend(Map<String, Object> params);

	public List<Map<String , Object>> queryCompanycontactStatus();

	public List<Map<String , Object>> selectByCompanyName1(String companyName);

	void updateStatusByCompany(Map<String, Object> params);

	//管理端发送记录
	List<Map<String , Object>> queryCompanySendList(@Param("compID") Integer compID);
    //统计单个公司发送给某个公司的主题包数
	Integer sumOneSendToatal(Map<String, Object> params);
	Integer sumOneSendToatalCompany(Map<String, Object> params);


    //管理端接收记录
    List<Map<String , Object>> queryCompanyRecceiveList(@Param("compID") Integer compID);
    //统计单个公司接收的主题包数
    Integer sumOneReceiveToatal(Map<String, Object> params);
    //统计接收的企业
    Integer sumOneReceiveToatalCompany(Map<String, Object> params);





}
