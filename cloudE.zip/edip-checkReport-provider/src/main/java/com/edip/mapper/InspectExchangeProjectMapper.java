package com.edip.mapper;

import com.edip.entity.InspectExchangeProject;
import com.edip.entity.InspectExchangeProjectExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InspectExchangeProjectMapper {
    long countByExample(InspectExchangeProjectExample example);

    int deleteByExample(InspectExchangeProjectExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(InspectExchangeProject record);

    int insertSelective(InspectExchangeProject record);

    List<InspectExchangeProject> selectByExample(InspectExchangeProjectExample example);

    InspectExchangeProject selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") InspectExchangeProject record, @Param("example") InspectExchangeProjectExample example);

    int updateByExample(@Param("record") InspectExchangeProject record, @Param("example") InspectExchangeProjectExample example);

    int updateByPrimaryKeySelective(InspectExchangeProject record);

    int updateByPrimaryKey(InspectExchangeProject record);
}