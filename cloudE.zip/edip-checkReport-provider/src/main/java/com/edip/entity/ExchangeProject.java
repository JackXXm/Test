package com.edip.entity;

import com.itextpdf.kernel.ProductInfo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author 
 */
    public class ExchangeProject implements Serializable {
    private Integer id;

    /**
     * 任务id
     */
    private Integer jobId;

    private Date createTime;

    private Date upateTime;

    private Integer createAccountId;

    private Integer updateAccountId;

    private String deleteFlag;

    /**
     * 例如药品基本信息
     */
    private String themeInfo;

    /**
     * 统计文件中的数目
     */
    private Integer themeDocNum;

    /**
     * 1企业，2药品，3器械，4保健品,5生产企业
     */
    private Integer themeType;

    /**
     * 对应theme_type 如product_info_id
     */
    private Integer infoId;
    /**
     * docId
     */
    private List<DocumentVo> docList;
    /**
     * 企业信息/生产企业
     */
    private ReceiveCompany receiveCompany;
    /**
     * 产品信息
     */
    private ProductInfo productInfo;
    private boolean flag=true;


    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getJobId() {
        return jobId;
    }

    public void setJobId(Integer jobId) {
        this.jobId = jobId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpateTime() {
        return upateTime;
    }

    public void setUpateTime(Date upateTime) {
        this.upateTime = upateTime;
    }

    public Integer getCreateAccountId() {
        return createAccountId;
    }

    public void setCreateAccountId(Integer createAccountId) {
        this.createAccountId = createAccountId;
    }

    public Integer getUpdateAccountId() {
        return updateAccountId;
    }

    public void setUpdateAccountId(Integer updateAccountId) {
        this.updateAccountId = updateAccountId;
    }

    public String getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getThemeInfo() {
        return themeInfo;
    }

    public void setThemeInfo(String themeInfo) {
        this.themeInfo = themeInfo;
    }

    public Integer getThemeDocNum() {
        return themeDocNum;
    }

    public void setThemeDocNum(Integer themeDocNum) {
        this.themeDocNum = themeDocNum;
    }

    public Integer getThemeType() {
        return themeType;
    }

    public void setThemeType(Integer themeType) {
        this.themeType = themeType;
    }

    public Integer getInfoId() {
        return infoId;
    }

    public void setInfoId(Integer infoId) {
        this.infoId = infoId;
    }


    public List<DocumentVo> getDocList() {
        return docList;
    }

    public void setDocList(List<DocumentVo> docList) {
        this.docList = docList;
    }

    public ReceiveCompany getCompanyInfo() {
        return receiveCompany;
    }

    public void setCompanyInfo(ReceiveCompany receiveCompany) {
        this.receiveCompany = receiveCompany;
    }

    public ProductInfo getProductInfo() {
        return productInfo;
    }

    public void setProductInfo(ProductInfo productInfo) {
        this.productInfo = productInfo;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        ExchangeProject other = (ExchangeProject) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getJobId() == null ? other.getJobId() == null : this.getJobId().equals(other.getJobId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpateTime() == null ? other.getUpateTime() == null : this.getUpateTime().equals(other.getUpateTime()))
            && (this.getCreateAccountId() == null ? other.getCreateAccountId() == null : this.getCreateAccountId().equals(other.getCreateAccountId()))
            && (this.getUpdateAccountId() == null ? other.getUpdateAccountId() == null : this.getUpdateAccountId().equals(other.getUpdateAccountId()))
            && (this.getDeleteFlag() == null ? other.getDeleteFlag() == null : this.getDeleteFlag().equals(other.getDeleteFlag()))
            && (this.getThemeInfo() == null ? other.getThemeInfo() == null : this.getThemeInfo().equals(other.getThemeInfo()))
            && (this.getThemeDocNum() == null ? other.getThemeDocNum() == null : this.getThemeDocNum().equals(other.getThemeDocNum()))
            && (this.getThemeType() == null ? other.getThemeType() == null : this.getThemeType().equals(other.getThemeType()))
            && (this.getInfoId() == null ? other.getInfoId() == null : this.getInfoId().equals(other.getInfoId()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getJobId() == null) ? 0 : getJobId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpateTime() == null) ? 0 : getUpateTime().hashCode());
        result = prime * result + ((getCreateAccountId() == null) ? 0 : getCreateAccountId().hashCode());
        result = prime * result + ((getUpdateAccountId() == null) ? 0 : getUpdateAccountId().hashCode());
        result = prime * result + ((getDeleteFlag() == null) ? 0 : getDeleteFlag().hashCode());
        result = prime * result + ((getThemeInfo() == null) ? 0 : getThemeInfo().hashCode());
        result = prime * result + ((getThemeDocNum() == null) ? 0 : getThemeDocNum().hashCode());
        result = prime * result + ((getThemeType() == null) ? 0 : getThemeType().hashCode());
        result = prime * result + ((getInfoId() == null) ? 0 : getInfoId().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", jobId=").append(jobId);
        sb.append(", createTime=").append(createTime);
        sb.append(", upateTime=").append(upateTime);
        sb.append(", createAccountId=").append(createAccountId);
        sb.append(", updateAccountId=").append(updateAccountId);
        sb.append(", deleteFlag=").append(deleteFlag);
        sb.append(", themeInfo=").append(themeInfo);
        sb.append(", themeDocNum=").append(themeDocNum);
        sb.append(", themeType=").append(themeType);
        sb.append(", infoId=").append(infoId);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }
}