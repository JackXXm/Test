package com.edip.entity;

import java.util.Date;

public class AdminAccount {
    private Integer accountID;

    private Integer staffID;

    private Integer staffid;

    private Integer compID;

    private String name;

    private String idCardNo;

    private String idCardNoURL;

    private String idCardNo2URL;

    private String aliasName;

    private String msisdn;

    private String email;

    private String auditInfo;

    private Date createDate;

    private Integer status;

    private Date idCardDate;
    private String conpanyName;   			//企业名称

    private Integer delFlag;

    private String logoDocUrl;

    public String getLogoDocUrl() {
        return logoDocUrl;
    }

    public void setLogoDocUrl(String logoDocUrl) {
        this.logoDocUrl = logoDocUrl;
    }

    public String getConpanyName() {
        return conpanyName;
    }

    public void setConpanyName(String conpanyName) {
        this.conpanyName = conpanyName;
    }

    public String getTaxNo() {
        return taxNo;
    }

    public void setTaxNo(String taxNo) {
        this.taxNo = taxNo;
    }

    public String getConpanyAddress() {
        return conpanyAddress;
    }

    public void setConpanyAddress(String conpanyAddress) {
        this.conpanyAddress = conpanyAddress;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getOpenBank() {
        return openBank;
    }

    public void setOpenBank(String openBank) {
        this.openBank = openBank;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public String getDocUrl() {
        return docUrl;
    }

    public void setDocUrl(String docUrl) {
        this.docUrl = docUrl;
    }

    public String getWeituoshuDocExpireTime() {
        return weituoshuDocExpireTime;
    }

    public void setWeituoshuDocExpireTime(String weituoshuDocExpireTime) {
        this.weituoshuDocExpireTime = weituoshuDocExpireTime;
    }

    private String taxNo;					//纳税人识别号

    private String conpanyAddress;			//企业地址

    private String tel;						//企业电话

    private String openBank;				//开户行

    private String acctNo;					//账号

    private String memo;					//备注

    private String docUrl;					//企业管理员授权委托书

    private String weituoshuDocExpireTime;	//企业管理员授权委托书失效时间

    private byte[] logoFileUrl;  			//企业logo

    public Integer getStaffid() {
        return staffid;
    }

    public void setStaffid(Integer staffid) {
        this.staffid = staffid;
    }

    public byte[] getLogoFileUrl() {
        return logoFileUrl;
    }

    public void setLogoFileUrl(byte[] logoFileUrl) {
        this.logoFileUrl = logoFileUrl;
    }

    public Integer getAccountID() {
        return accountID;
    }

    public void setAccountID(Integer accountID) {
        this.accountID = accountID;
    }

    public Integer getStaffID() {
        return staffID;
    }

    public void setStaffID(Integer staffID) {
        this.staffID = staffID;
    }

    public Integer getCompID() {
        return compID;
    }

    public void setCompID(Integer compID) {
        this.compID = compID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo == null ? null : idCardNo.trim();
    }

    public String getIdCardNoURL() {
        return idCardNoURL;
    }

    public void setIdCardNoURL(String idCardNoURL) {
        this.idCardNoURL = idCardNoURL == null ? null : idCardNoURL.trim();
    }

    public String getIdCardNo2URL() {
        return idCardNo2URL;
    }

    public void setIdCardNo2URL(String idCardNo2URL) {
        this.idCardNo2URL = idCardNo2URL == null ? null : idCardNo2URL.trim();
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName == null ? null : aliasName.trim();
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn == null ? null : msisdn.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public String getAuditInfo() {
        return auditInfo;
    }

    public void setAuditInfo(String auditInfo) {
        this.auditInfo = auditInfo == null ? null : auditInfo.trim();
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getIdCardDate() {
        return idCardDate;
    }

    public void setIdCardDate(Date idCardDate) {
        this.idCardDate = idCardDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }
}