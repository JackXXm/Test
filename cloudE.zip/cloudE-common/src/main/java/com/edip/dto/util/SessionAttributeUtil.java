package com.edip.dto.util;

import com.edip.dto.SessionContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

public class SessionAttributeUtil {

    public static Map<String,Object> getAttribute(HttpServletRequest request) {
        HttpSession session = SessionContext.getContext().getSession(request);
        Map<String,Object> attribute = new HashMap<String,Object>();
        Integer accountID = (Integer)session.getAttribute("accountID");
        Integer compID = (Integer)session.getAttribute("compID");
        Integer province = (Integer)session.getAttribute("province");
        Integer city = (Integer)session.getAttribute("city");
        Integer vip = (Integer)session.getAttribute("vip");
        String createBy = (String)session.getAttribute("createBy");
        String companyName = (String)session.getAttribute("companyName");
        Integer staffID = (Integer)session.getAttribute("STAFFID");
        attribute.put("accountID",accountID);
        attribute.put("compID",compID);
        attribute.put("province",province);
        attribute.put("city",city);
        attribute.put("vip",vip);
        attribute.put("createBy",createBy);
        attribute.put("companyName",companyName);
        attribute.put("staffID",staffID);
        return attribute;
    }

}
