package com.edip.mapper;

import com.edip.entity.Message;
import com.edip.entity.MessageExample;
import com.edip.vo.MessageVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface UserMessageMapper {
    int countByExample(MessageExample example);

    int deleteByExample(MessageExample example);

    int deleteByPrimaryKey(Integer msgID);

    int insert(Message record);

    int insertSelective(Message record);

    List<Message> selectByExampleWithBLOBsWithPage(@Param("example") MessageExample example,
                                                   @Param("from") Integer from, @Param("to") Integer to);

    List<Message> selectByExampleWithBLOBs(MessageExample example);

    List<Message> selectByExampleWithPage(@Param("example") MessageExample example, @Param("from") Integer from,
                                          @Param("to") Integer to);

    List<Message> selectByExample(MessageExample example);

    Message selectByPrimaryKey(Integer msgID);

    int updateByExampleSelective(@Param("record") Message record, @Param("example") MessageExample example);

    int updateByExampleWithBLOBs(@Param("record") Message record, @Param("example") MessageExample example);

    int updateByExample(@Param("record") Message record, @Param("example") MessageExample example);

    int updateByPrimaryKeySelective(Message record);

    int updateByPrimaryKeyWithBLOBs(Message record);

    int updateByPrimaryKey(Message record);

    List<Message>  selectMsgId(Message record);
    int updateStatus(Message record);
    List<Message> selectByPage(@Param("listCompId") List<Integer> listCompId, @Param("starus") Integer starus,
                               @Param("accountID") Integer accountID,
                               @Param("from") Integer from, @Param("to") Integer to, @Param("domain") String domain,
                               @Param("msgTypeList") List<Integer> msgTypeList);
    
    List<Message> selectOfSystem(@Param("from") Integer from, @Param("to") Integer to, @Param("reciveIDs") List<Integer> accountID, @Param("status") List<Integer> status);

    int countByPage(@Param("listCompId") List<Integer> listCompId, @Param("starus") Integer starus,
                    @Param("accountID") Integer accountID,
                    @Param("domain") String domain, @Param("msgTypeList") List<Integer> msgTypeList);

	List<Map<String, Object>> messageList(Map<String, Object> params);

	int getMessageCount(Map<String, Object> params);

	Message searchMessageByMsgID(MessageVo messageVo);

	int editMessageByMsgID(MessageVo messageVo);

	int updateMessageByMsgID(MessageVo messageVo);

	int editMessageInfoByMsgID(MessageVo messageVo);

	int delMessageInfo(Map map);

	int delMessage(Map map);

	List<Map<String, Object>> messageInfoList(Map<String, Object> params);

	int getMessageInfoCount(Map<String, Object> params);

	void messageUpdateRead(MessageVo messageVo);
	
	int countOfSystem(@Param("reciveIDs") List<Integer> accountID, @Param("status") List<Integer> status);

	int updateMessage(Message message);

	int deleteMessage(@Param("msgIds") String[] msgIds, @Param("status") int status, @Param("delFlag") int delFlag);

	List<Integer> queryStaffByCompanyId(@Param("data") Map<String, Object> map);
	
	void insertMessageSystem(@Param("msgId") Integer msgId, @Param("accountID") Integer accountID, @Param("status") int status);

	List<Integer> queryMessageSystem(@Param("accountID") Integer accountID, @Param("status") int status);

    int insertbatch(List<Message> list);

	Map<String, Object> queryMessageDocument(@Param("msgId") int msgId);

    List<Message> getMessageList(@Param("accountID") Integer accountID, @Param("receiveID") Integer receiveID, @Param("from") Integer from, @Param("to") Integer to, @Param("title") String title);
    int countMessageListSize(@Param("accountID") Integer accountID, @Param("receiveID") Integer receiveID, @Param("title") String title);

    //RP消息管理
    List<Map<String , Object >> queryRpMessageList(Map<String, Object> params);
    int countRpMessageList(Map<String, Object> params);
    int updateRpMessageStatus(Map<String, Object> params);

    Message queryMsgByProjectID(Integer proID);

    List<Message> queryMsgByCompID(Object compID);

    void updateReturnSignMessages(Message vo);
}