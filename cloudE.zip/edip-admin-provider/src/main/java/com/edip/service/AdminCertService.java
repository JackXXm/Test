package com.edip.service;

import com.edip.dto.util.Page;
import com.edip.entity.AdminCertWithBLOBs;
import com.edip.vo.AdminAddressVo;
import com.edip.vo.AdminCertVo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public interface AdminCertService {

//    CertVo applyCert(CertWithBLOBs certVo) throws Exception;
//
//    CertVo queryCertificateOne(CertVo certVo) throws Exception;
//
//    Integer updateCertVo (CertWithBLOBs certVo,String publickey) throws Exception;
//
//    List<CertVo> selectByExampleVoWithPage(CertExample example, int from, int to);
//
//    CertWithBLOBs downloadCert(CertWithBLOBs cert) throws Exception;
//
//    Map<String, Object> validExcel(String kbmxml, String filePath);
//
//
    Map<String, Object> checkCertDetil(Integer certId);


    AdminAddressVo getAddress(Integer conmpid);
//
//    BilllingVo getBillling(Integer compId, Integer certId);


    Integer revokeCertificate(Integer certId) throws Exception;

    //优化证书管理查询接口  modify by huyajun 2018/9/12
    List<Map<String,Object>> selectCertVo(Map<String , Object> params);
    Integer countCertNums(Map<String , Object> params);

    Integer CertPayment(Map<String,Integer> params);

    AdminCertWithBLOBs downloadCert(AdminCertWithBLOBs cert) throws Exception;

    Integer isMill(Map<String,Object> params);

    Map<String,Object> getMailInfo(Integer certId);

    Page getUkeyCountInfo(Page page, Map<String,Object> params);

    String writeExcelWithModel(Map<String,Object> params,HttpServletRequest request,HttpServletResponse response);
//
//
//    List<CompInfoForUpRecord> compInfoForUpList(Integer compID);
//
//    int compInfoForUpCount(Integer compID);
}
