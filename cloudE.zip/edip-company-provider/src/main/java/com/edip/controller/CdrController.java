package com.edip.controller;

import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.entity.CertExample;
import com.edip.entity.CertWithBLOBs;
import com.edip.feign.AccountFeign;
import com.edip.feign.CompanyFeign;
import com.edip.mapper.CertMapperVo;
import com.edip.service.CdrService;
import com.edip.service.CertService;
import com.edip.vo.CertApplyRequestVo;
import com.edip.vo.CertVo;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping("/cdr")
public class CdrController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CdrController.class);
    @Autowired
    private HttpServletRequest request;
    @Autowired
    private CdrService cdrService;

    /**
     * 插入短信账单
     * @param mobile 手机号
     * @param cdrType 0 话单类型 短信
     * @param cdrSubType 0 话单子类型 验证短信
     * @param companyId 公司id
     * @return
     */
    @RequestMapping(value="addCdr.ajax")
    public ServerResponse addCdr(String mobile,Integer cdrType,Integer cdrSubType,Integer companyId){
        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer compID = (Integer) httpSession.getAttribute("compID");
            cdrService.addCdr(mobile,cdrType,cdrSubType,compID);
            return ServerResponse.createBySuccessMsg("插入账单成功");
        }catch (Exception e){
            LOGGER.error("addCdr error",e);
            return  ServerResponse.createByErrorMsg("插入账单失败");
        }
    }




}
