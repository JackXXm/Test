package com.edip.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public interface AccountCdrBiz {

    //void insertCdr(String mobile,Integer cdrType,Integer cdrSubType,String companyId);

    void insertCdrs(Integer cdrType, Integer cdrSubType, String companyId, HttpSession session, HttpServletRequest request);

}
