package com.edip.controller;

import com.alibaba.fastjson.JSONObject;
import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.entity.ReturnSignInfo;
import com.edip.entity.SignInfo;
import com.edip.service.SignSendService;
import com.github.pagehelper.PageInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class SignSendContrller {
    private static final Logger log = LoggerFactory.getLogger(SignSendContrller.class);
    @Autowired
    private SignSendService signSendService;
    @Autowired
    private HttpServletRequest request;

    /**
     * create by: hym
     * description:删除任务
     * create time: 9:26 2019/3/29
     *
      * @Param: null
     * @return
     */
    @PostMapping(value="deleteSendTask.ajax")
    @ResponseBody
    public ServerResponse deleteSendTask(@RequestBody Map<String,Object> signInfo) {

        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            signInfo.put("accountName",httpSession.getAttribute("accountName").toString());
            signInfo.put("accountId",httpSession.getAttribute("accountID").toString());
            signSendService.deleteSendTask(signInfo);
            return ServerResponse.createBySuccess();
        } catch (Exception e) {
            log.error("delete task fail ,args:"+ JSONObject.toJSONString(signInfo),e);
            return ServerResponse.createByError(7,"delete task fail");
        }

    }
    /**
     * create by: hym
     * description:删除任务中主题
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping(value="deleteSendTaskTheme.ajax")
    @ResponseBody
    public ServerResponse deleteSendTaskTheme(@RequestBody Map<String,Object> signInfo) {

        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            signSendService.deleteSendTaskTheme(signInfo);
            return ServerResponse.createBySuccess();
        } catch (Exception e) {
            log.error("delete task theme fail ,args:"+ JSONObject.toJSONString(signInfo),e);
            return ServerResponse.createByError(7,"delete task theme fail");
        }

    }
    /**
     * create by: hym
     * description:删除接受公司
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping(value="deleteReceiveCompany.ajax")
    @ResponseBody
    public ServerResponse deleteReceiveCompany(@RequestBody Map<String,Object> signInfo) {

        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            signSendService.deleteReceiveCompany(signInfo);
            return ServerResponse.createBySuccess();
        } catch (Exception e) {
            log.error("delete task doc fail ,args:"+ JSONObject.toJSONString(signInfo),e);
            return ServerResponse.createByError(7,"delete task doc fail");
        }

    }
    /**
     * create by: hym
     * description:删除任务资质
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping(value="deleteSendTaskDocs.ajax")
    @ResponseBody
    public ServerResponse deleteSendTaskDocs(@RequestBody Map<String,Object> signInfo) {

        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            signSendService.deleteSendTaskDocs(signInfo);
            return ServerResponse.createBySuccess();
        } catch (Exception e) {
            log.error("delete task doc fail ,args:"+ JSONObject.toJSONString(signInfo),e);
            return ServerResponse.createByError(7,"delete task doc fail");
        }

    }
    /**
     * create by: hym
     * description:获取任务进度
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping (value="getSignatureProgress.ajax")
    @ResponseBody
    public ServerResponse getSignatureProgress( @RequestBody  Map<String,Object>signInfo) {
        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            JSONObject result=signSendService.getSignatureProgress(signInfo);
            return ServerResponse.createBySuccess(result);
        } catch (Exception e) {
            log.error("get Signature Progress  error",e);
            e.printStackTrace();
            return ServerResponse.createByError(11,"get Signature Progress  error");
        }


    }
    /**
     * create by: hym
     * description:发送任务
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping (value="sendTask.ajax")
    @ResponseBody
    public ServerResponse sendTask(@RequestBody  Map<String,Object>signInfo) {
        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            String accountName = (String) SessionContext.getContext().getSession(request).getAttribute("accountName");
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            signInfo.put("accountId",httpSession.getAttribute("accountID").toString());
            signInfo.put("companyName",httpSession.getAttribute("companyName").toString());
            signInfo.put("accountName",accountName);
            signSendService.sendTask( signInfo);
            return ServerResponse.createBySuccess();
        } catch (Exception e) {
            log.error("send task fail ,args:"+JSONObject.toJSONString(signInfo),e);
            e.printStackTrace();
            return ServerResponse.createByError(6,"send task fail");
        }
    }
    /**
     * create by: hym
     * description:保存自定义签章
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping (value="saveCustomSign.ajax")
    @ResponseBody
    public ServerResponse saveCustomSign(@RequestBody  Map<String,Object>signInfo) {
        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            signSendService.saveCustomSign(signInfo);
            return ServerResponse.createBySuccess();
        } catch (Exception e) {
            log.error("save custome sign fail ,args:"+JSONObject.toJSONString(signInfo),e);
            e.printStackTrace();
            return ServerResponse.createByError(6,"save custome sign fail");
        }

    }
    /**
     * create by: hym
     * description:更改任务状态
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping (value="changeTaskStatus.ajax")
    @ResponseBody
    public ServerResponse changeTaskStatus(@RequestBody  Map<String,Object>signInfo) {
        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            signSendService.changeTaskStatus(signInfo);
            return ServerResponse.createBySuccess();
        } catch (Exception e) {
            log.error("change Task Status fail ,args:"+JSONObject.toJSONString(signInfo),e);
            e.printStackTrace();
            return ServerResponse.createByError(6,"change Task Status fail");
        }

    }
    /**
     * create by: hym
     * description:获取任务列表
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping (value="getTaskList.ajax")
    @ResponseBody
    public ServerResponse getTaskList(@RequestBody  Map<String,Object>signInfo) {
        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            Integer staffID= (Integer) httpSession.getAttribute("STAFFID");
            signInfo.put("companyId",companyId);
            PageInfo sendTaskList = signSendService.getSendTaskList(signInfo);
            Map<String,Object> sendTaskMap = new HashMap<String,Object>();
            sendTaskMap.put("list",sendTaskList.getList());
            sendTaskMap.put("compID",companyId);
            sendTaskMap.put("type","发送资料审核");
            sendTaskMap.put("staffID",staffID);

            return ServerResponse.createBySuccess(sendTaskList);
        } catch (Exception e) {
            log.error("getTaskList Task Status fail ,args:"+JSONObject.toJSONString(signInfo),e);
            e.printStackTrace();
            return ServerResponse.createByError(6,"getTaskListfail");
        }

    }
    /**
     * create by: hym
     * description:获取签章资质列表
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping (value="getSignatureDocList.ajax")
    @ResponseBody
    public ServerResponse getSignatureDocList( @RequestBody  Map<String,Object>signInfo) {

        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            List<SignInfo> result=signSendService.getSignatureDocList(signInfo);
            return ServerResponse.createBySuccess(result);
        } catch (Exception e) {
            log.error("get Signature DocList  error",e);
            e.printStackTrace();
            return ServerResponse.createByError(12,"get Signature DocList  error");
        }

    }

    /**
     * 获取重签资质列表
     * @param signInfo
     * @return
     */
    @PostMapping (value="getReturnSignatureDocList.ajax")
    @ResponseBody
    public ServerResponse getReturnSignatureDocList( @RequestBody  Map<String,Object>signInfo) {

        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            List<SignInfo> result=signSendService.getReturnSignatureDocList(signInfo);
            return ServerResponse.createBySuccess(result);
        } catch (Exception e) {
            log.error("get Signature DocList  error",e);
            e.printStackTrace();
            return ServerResponse.createByError(12,"get Signature DocList  error");
        }

    }

    /**
     * 获取重签信息
     * @param signInfo
     * @return
     */
    @PostMapping (value="getReturnSignatureInfo.ajax")
    @ResponseBody
    public ServerResponse getReturnSignatureInfo( @RequestBody  Map<String,Object>signInfo) {

        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            //signInfo.add(companyId);
            //List<String> list = Arrays.asList(signInfo);
            //JSONObject result=new JSONObject(signInfo);
            List<ReturnSignInfo> result=signSendService.getReturnSignatureInfo(signInfo);
            return ServerResponse.createBySuccess(result);
        } catch (Exception e) {
            log.error("getReturnSignatureInfo  error",e);
            e.printStackTrace();
            return ServerResponse.createByError(12,"getReturnSignatureInfo  error");
        }

    }


    /**
     * create by: hym
     * description:刷新，将签章中任务变成失败
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping (value="updateTaskFail.ajax")
    @ResponseBody
    public ServerResponse updateTaskFail( ) {

        try {
            Map<String,Object>signInfo=new HashMap<>();
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            signSendService.updateTaskFail(signInfo);
            return ServerResponse.createBySuccess();
        } catch (Exception e) {
            log.error("update task Fail  error",e);
            e.printStackTrace();
            return ServerResponse.createByError(12,"update Task Fail   error");
        }

    }
    /**
     * create by: hym
     * description:一键发送
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping (value="allSendTask.ajax")
    @ResponseBody
    public ServerResponse allSendTask( ) {

        try {
            Map<String,Object>signInfo=new HashMap<>();
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("companyId",companyId);
            signInfo.put("accountName",httpSession.getAttribute("accountName").toString());
            signInfo.put("companyName",httpSession.getAttribute("companyName").toString());
            int accountID = (int)SessionContext.getContext().getSession(request).getAttribute("accountID");
            signInfo.put("accountID",accountID);
            int status=signSendService.allSendTask(signInfo);
            return ServerResponse.createBySuccess(status);
        } catch (Exception e) {
            log.error("update task Fail  error",e);
            e.printStackTrace();
            return ServerResponse.createByError(6,"update Task Fail   error");
        }

    }
    /**
     * create by: hym
     * description:开启签章任务
     * create time: 9:26 2019/3/29
     *produces = MediaType.TEXT_PLAIN_VALUE
     * @Param: null
     * @return
     */
    @PostMapping (value="startSignatureTask.ajax")
    @ResponseBody
    public ServerResponse sign(HttpServletRequest request, HttpServletResponse response, @RequestBody  Map<String,Object>signInfo) {

        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("compID",companyId);
            JSONObject result=signSendService.sendSignInfo(signInfo);
            return ServerResponse.createBySuccess(result);
        } catch (Exception e) {
            log.error("send sign task error",e);
            e.printStackTrace();
            return ServerResponse.createByError(12,"send sign task error");
        }
    }

    /**
     * create by: hym
     * description:开启重签章任务
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping (value="startReturnSignatureTask.ajax")
    @ResponseBody
    public ServerResponse retrunsign(HttpServletRequest request, HttpServletResponse response, @RequestBody  Map<String,Object>signInfo) {

        try {
            HttpSession httpSession = SessionContext.getContext().getSession(request);
            Integer companyId= (Integer) httpSession.getAttribute("compID");
            signInfo.put("compID",companyId);
            JSONObject result=signSendService.sendSignInfo(signInfo);

            return ServerResponse.createBySuccess(result);
        } catch (Exception e) {
            log.error("send sign task error",e);
            e.printStackTrace();
            return ServerResponse.createByError(12,"send sign task error");
        }
    }
    /**
     * create by: hym
     * description:获取公司id
     * create time: 9:26 2019/3/29
     *
     * @Param: null
     * @return
     */
    @PostMapping (value="getCompnayInfo.ajax")
    @ResponseBody
    public ServerResponse getCompnayInfo(  @RequestBody  Map<String,Object>signInfo ) {

        try {
            return ServerResponse.createBySuccess(signSendService.getCompnayInfo(signInfo));
        } catch (Exception e) {
            log.error("get companyInfo   error",e);
            e.printStackTrace();
            return ServerResponse.createByError(6,"get companyInfo   error");
        }

    }
}
