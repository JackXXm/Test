package com.edip.service.impl;
import com.alibaba.fastjson.JSONObject;
import com.edip.controller.MessageClient;
import com.edip.mapper.StampMapperVos;
import com.edip.service.StampService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class StampServiceImpl implements StampService {
    @Autowired
    private StampMapperVos stampMapper;
    @Autowired
    private MessageClient messageClient;

    @Override
    public List<Map<String, Object>> queryStampList(Map<String, Object> params) {

        return stampMapper.queryStampList(params);
    }

    @Override
    @Transactional
    public Integer auditStamp(Map param) {
        Map map = stampMapper.getStampById(Integer.valueOf(param.get("stampID").toString()));
        JSONObject json = new JSONObject();
        json.put("msgType",1);//消息类型:1 首营端消息 2 管理端消息
        json.put("dataId",param.get("stampID"));
        json.put("compId",-1);
        json.put("accountId",param.get("accountID"));
        json.put("receiveCompID",map.get("compId"));
        json.put("dataType",4);//实体类型 0:公司 1:人员 2:产品 3:合同 4:图章 5:证书 6:项目
        json.put("sender","印章/证书管理");
        if(param.get("status").equals(0)){
            json.put("title","您的【" + map.get("stampName") + "】印章审核已通过。");
            json.put("content","您的【" + map.get("stampName") +"】印章审核已通过。");
        } else {
            json.put("title","您的【" + map.get("stampName") + "】印章审核不通过，请处理。若已处理，请忽略");
            json.put("content","您的【" + map.get("stampName") + "】印章审核不通过，请处理。若已处理，请忽略");
        }
        json.put("newUrl","account/certificate/index?mid=39&tabIndex=2");
        json.put("classify",0);//消息标识 0 系统消息，1 到期提醒，2 更新提醒，3 系统公告，4 优惠活动
        json.put("roleName","系统管理员");
        messageClient.changeMessageInvalid(Integer.valueOf(param.get("stampID").toString()));
        messageClient.messageSend(json.toJSONString());
        stampMapper.updateStampHistory(param);//维护印章历史审核表相关
        return stampMapper.auditStamp(param);
    }

    @Override
    public List<Map<String, Object>> queryStampDetail(String stampID) {
        return stampMapper.queryStampDetail(stampID);
    }

    @Override
    public String getAddressName(Map<String, Object> params) {
        StringBuilder sb = new StringBuilder();
        if(params.containsKey("proid")){
            sb.append(stampMapper.getProAddress(params.get("proid").toString())+" ");
        }
        if(params.containsKey("cityid")){
            sb.append(stampMapper.getCityAddress(params.get("cityid").toString())+" ");

        }
        if(params.containsKey("areaid")){
            sb.append(stampMapper.getAreaAddress(params.get("areaid").toString())+" ");
        }
        if(params.containsKey("address")){
            sb.append(params.get("address").toString());
        }
        return sb.toString();
    }

    @Override
    public List<Map<String, Object>> stampHistory(String stampID) {
        return stampMapper.getStampHistory(stampID);
    }

    @Override
    @Transactional
    public void deleteCertAndStamp(Map param) throws Exception{
        stampMapper.deleteCert(param);
        stampMapper.deleteStamp(param);
    }

}
