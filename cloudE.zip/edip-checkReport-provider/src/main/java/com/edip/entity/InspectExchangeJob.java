package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class InspectExchangeJob implements Serializable {
    private Integer id;

    /**
     * 公司id
     */
    private Integer companyId;

    /**
     * 收件企业名称
     */
    private String receiveCompanyName;

    /**
     * 资料摘要
     */
    private String dataDigest;

    /**
     * 交接类型 0首次1为补发
     */
    private String type;

    /**
     * 首次任务id
     */
    private Integer fristJobId;

    private Date createTime;

    private Date updateTime;

    private Integer createAccountId;

    private Integer updateAccountId;

    private String deleteFlag;

    /**
     * 1未签章，2等待签章，3签章中，4签章失败，5签章成功，6发送
     */
    private Integer status;

    /**
     * 统计公司发送数目
     */
    private Integer companyNumber;

    /**
     * 统计发送药品种类数量
     */
    private Integer drugsNumber;

    /**
     * 统计器械数目
     */
    private Integer apparatusNumber;

    /**
     * 统计保健品数目
     */
    private Integer healthProductsNumber;

    /**
     * 发送人
     */
    private String sender;

    /**
     * 发送公司
     */
    private String sendCompany;

    /**
     * 1待回传，2已回传
     */
    private Integer returnStatus;

    /**
     * 留言
     */
    private String note;

    /**
     * 印章信息
     */
    private String signature;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public String getReceiveCompanyName() {
        return receiveCompanyName;
    }

    public void setReceiveCompanyName(String receiveCompanyName) {
        this.receiveCompanyName = receiveCompanyName;
    }

    public String getDataDigest() {
        return dataDigest;
    }

    public void setDataDigest(String dataDigest) {
        this.dataDigest = dataDigest;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getFristJobId() {
        return fristJobId;
    }

    public void setFristJobId(Integer fristJobId) {
        this.fristJobId = fristJobId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getCreateAccountId() {
        return createAccountId;
    }

    public void setCreateAccountId(Integer createAccountId) {
        this.createAccountId = createAccountId;
    }

    public Integer getUpdateAccountId() {
        return updateAccountId;
    }

    public void setUpdateAccountId(Integer updateAccountId) {
        this.updateAccountId = updateAccountId;
    }

    public String getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getCompanyNumber() {
        return companyNumber;
    }

    public void setCompanyNumber(Integer companyNumber) {
        this.companyNumber = companyNumber;
    }

    public Integer getDrugsNumber() {
        return drugsNumber;
    }

    public void setDrugsNumber(Integer drugsNumber) {
        this.drugsNumber = drugsNumber;
    }

    public Integer getApparatusNumber() {
        return apparatusNumber;
    }

    public void setApparatusNumber(Integer apparatusNumber) {
        this.apparatusNumber = apparatusNumber;
    }

    public Integer getHealthProductsNumber() {
        return healthProductsNumber;
    }

    public void setHealthProductsNumber(Integer healthProductsNumber) {
        this.healthProductsNumber = healthProductsNumber;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getSendCompany() {
        return sendCompany;
    }

    public void setSendCompany(String sendCompany) {
        this.sendCompany = sendCompany;
    }

    public Integer getReturnStatus() {
        return returnStatus;
    }

    public void setReturnStatus(Integer returnStatus) {
        this.returnStatus = returnStatus;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        InspectExchangeJob other = (InspectExchangeJob) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getCompanyId() == null ? other.getCompanyId() == null : this.getCompanyId().equals(other.getCompanyId()))
            && (this.getReceiveCompanyName() == null ? other.getReceiveCompanyName() == null : this.getReceiveCompanyName().equals(other.getReceiveCompanyName()))
            && (this.getDataDigest() == null ? other.getDataDigest() == null : this.getDataDigest().equals(other.getDataDigest()))
            && (this.getType() == null ? other.getType() == null : this.getType().equals(other.getType()))
            && (this.getFristJobId() == null ? other.getFristJobId() == null : this.getFristJobId().equals(other.getFristJobId()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getCreateAccountId() == null ? other.getCreateAccountId() == null : this.getCreateAccountId().equals(other.getCreateAccountId()))
            && (this.getUpdateAccountId() == null ? other.getUpdateAccountId() == null : this.getUpdateAccountId().equals(other.getUpdateAccountId()))
            && (this.getDeleteFlag() == null ? other.getDeleteFlag() == null : this.getDeleteFlag().equals(other.getDeleteFlag()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getCompanyNumber() == null ? other.getCompanyNumber() == null : this.getCompanyNumber().equals(other.getCompanyNumber()))
            && (this.getDrugsNumber() == null ? other.getDrugsNumber() == null : this.getDrugsNumber().equals(other.getDrugsNumber()))
            && (this.getApparatusNumber() == null ? other.getApparatusNumber() == null : this.getApparatusNumber().equals(other.getApparatusNumber()))
            && (this.getHealthProductsNumber() == null ? other.getHealthProductsNumber() == null : this.getHealthProductsNumber().equals(other.getHealthProductsNumber()))
            && (this.getSender() == null ? other.getSender() == null : this.getSender().equals(other.getSender()))
            && (this.getSendCompany() == null ? other.getSendCompany() == null : this.getSendCompany().equals(other.getSendCompany()))
            && (this.getReturnStatus() == null ? other.getReturnStatus() == null : this.getReturnStatus().equals(other.getReturnStatus()))
            && (this.getNote() == null ? other.getNote() == null : this.getNote().equals(other.getNote()))
            && (this.getSignature() == null ? other.getSignature() == null : this.getSignature().equals(other.getSignature()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getCompanyId() == null) ? 0 : getCompanyId().hashCode());
        result = prime * result + ((getReceiveCompanyName() == null) ? 0 : getReceiveCompanyName().hashCode());
        result = prime * result + ((getDataDigest() == null) ? 0 : getDataDigest().hashCode());
        result = prime * result + ((getType() == null) ? 0 : getType().hashCode());
        result = prime * result + ((getFristJobId() == null) ? 0 : getFristJobId().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getCreateAccountId() == null) ? 0 : getCreateAccountId().hashCode());
        result = prime * result + ((getUpdateAccountId() == null) ? 0 : getUpdateAccountId().hashCode());
        result = prime * result + ((getDeleteFlag() == null) ? 0 : getDeleteFlag().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getCompanyNumber() == null) ? 0 : getCompanyNumber().hashCode());
        result = prime * result + ((getDrugsNumber() == null) ? 0 : getDrugsNumber().hashCode());
        result = prime * result + ((getApparatusNumber() == null) ? 0 : getApparatusNumber().hashCode());
        result = prime * result + ((getHealthProductsNumber() == null) ? 0 : getHealthProductsNumber().hashCode());
        result = prime * result + ((getSender() == null) ? 0 : getSender().hashCode());
        result = prime * result + ((getSendCompany() == null) ? 0 : getSendCompany().hashCode());
        result = prime * result + ((getReturnStatus() == null) ? 0 : getReturnStatus().hashCode());
        result = prime * result + ((getNote() == null) ? 0 : getNote().hashCode());
        result = prime * result + ((getSignature() == null) ? 0 : getSignature().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", companyId=").append(companyId);
        sb.append(", receiveCompanyName=").append(receiveCompanyName);
        sb.append(", dataDigest=").append(dataDigest);
        sb.append(", type=").append(type);
        sb.append(", fristJobId=").append(fristJobId);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", createAccountId=").append(createAccountId);
        sb.append(", updateAccountId=").append(updateAccountId);
        sb.append(", deleteFlag=").append(deleteFlag);
        sb.append(", status=").append(status);
        sb.append(", companyNumber=").append(companyNumber);
        sb.append(", drugsNumber=").append(drugsNumber);
        sb.append(", apparatusNumber=").append(apparatusNumber);
        sb.append(", healthProductsNumber=").append(healthProductsNumber);
        sb.append(", sender=").append(sender);
        sb.append(", sendCompany=").append(sendCompany);
        sb.append(", returnStatus=").append(returnStatus);
        sb.append(", note=").append(note);
        sb.append(", signature=").append(signature);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}