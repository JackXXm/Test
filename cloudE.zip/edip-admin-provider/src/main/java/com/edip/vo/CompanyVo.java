package com.edip.vo;

import java.util.Date;
import java.util.List;

public class CompanyVo {
    // 企业主账号证件类型
    public static final String CARDTYPE = "1";// 1:身份证

    private Integer compID;

    private Integer pcompID;

    private Integer type;

    private Integer departmentID;

    private Integer accountID;

    private String extID;

    private String name;

    private String shortName;

    private String serveType;

    private Integer provinceID;

    private Integer cityID;

    private String address;

    private String postCode;

    private String iconURL;

    private String landline;

    private String fax;

    // 是否三证合一标识
    private String codeFlag;

    private String orgCode;
    // 统一社信用代码证
    private String usCode;
    // 税务登记证号码
    private String taxCode;
    // 营业执照注册号
    private String businessCode;

    private String auditInfo;

    private Integer operStatus;

    private Integer status;

    private Date createDate;

    private Date lupDate;

    // 企业主账号的别名
    private String aliasName;
    // 企业主账号的登录名
    private String accountName;
    // 企业主账号的身份证号
    private String idCardNo;
    // 企业主账号的联系方式
    private String msisdn;
    // 固定电话
    private String phone;
    // 企业主账号的邮箱
    private String email;
    // 统一社信用代码证URL
    private String usCodeUrl;
    // 统一社信用代码证文档名字
    private String usCodeDocName;
    // 统一社信用代码证文档过期时间
    private String usCodeDocExpireTime;

    // 组织机构代码证号码
    private String orgCodeUrl;
    private String orgCodeDocName;
    private String orgCodeDocExpireTime;
    // 营业执照注册号URL
    private String businessLicenseUrl;
    private String businessLicenseDocName;
    private String businessLicenseDocExpireTime;
    // 税务登记证号码URL
    private String taxNumberUrl;
    private String taxNumberDocName;
    private String taxNumberDocExpireTime;

    // 身份证照片
    private String idCardPic;
    private String idCardPic1;

    private String idCardDate;
    // 营业执照照片
    private String yinyePic;
    // 省区中文
    private String pcStr;

    private String areaStr;

    //private List<DicVo> dicList;

    private String severTypeName;

    private String uploadName;

    private String StaffId;

    private boolean add = true;

    private String tab;

    private String stampContent;

    //企业logo
    private byte[] logoFileUrl;

    // 其他文档
    private String[] qtFileName;
    // 有效期
    private String[] date;
    // 文件上传时名称
    private String[] fileName;
    // 文件上传后地址
    private String[] path;
    // 文件类型
    private String[] fileType;

    // 其他文件类型
    private String[] otherName;

    private String[] certno;

    private String[] issuedate;
    //页面跳转表示 1:申请待审核页面 9：申请审核失败页面
    private Integer isApplyFlag;

    private Integer coid;

    // 其他文件发证日期
    private List<String> otherIssueDate;
    // 其他文件失效日期
    private List<String> otherInvalidDate;
    // 其他文件发证日期

    private String logoDocUrl;

    //是否发送过企业资质 0:没有 1:有
    private Integer isExchangeCompany;

    public Integer getIsExchangeCompany() {
        return isExchangeCompany;
    }

    public void setIsExchangeCompany(Integer isExchangeCompany) {
        this.isExchangeCompany = isExchangeCompany;
    }

    public String getLogoDocUrl() {
        return logoDocUrl;
    }

    public void setLogoDocUrl(String logoDocUrl) {
        this.logoDocUrl = logoDocUrl;
    }

    public Integer getCoid() {
        return coid;
    }

    public List<String> getOtherIssueDate() {
        return otherIssueDate;
    }

    public void setOtherIssueDate(List<String> otherIssueDate) {
        this.otherIssueDate = otherIssueDate;
    }

    public List<String> getOtherInvalidDate() {
        return otherInvalidDate;
    }

    public void setOtherInvalidDate(List<String> otherInvalidDate) {
        this.otherInvalidDate = otherInvalidDate;
    }

    public void setCoid(Integer coid) {
        this.coid = coid;
    }

    public String getStampContent() {
        return stampContent;
    }

    public void setStampContent(String stampContent) {
        this.stampContent = stampContent;
    }

    public byte[] getLogoFileUrl() {
        return logoFileUrl;
    }

    public void setLogoFileUrl(byte[] logoFileUrl) {
        this.logoFileUrl = logoFileUrl;
    }

    public Integer getIsApplyFlag() {
        return isApplyFlag;
    }

    public void setIsApplyFlag(Integer isApplyFlag) {
        this.isApplyFlag = isApplyFlag;
    }

    public String[] getCertno() {
        return certno;
    }

    public void setCertno(String[] certno) {
        this.certno = certno;
    }

    public String[] getIssuedate() {
        return issuedate;
    }

    public void setIssuedate(String[] issuedate) {
        this.issuedate = issuedate;
    }




    private String conpanyName;   			//企业名称

    private String taxNo;					//纳税人识别号

    private String conpanyAddress;			//企业地址

    private String tel;						//企业电话

    private String openBank;				//开户行

    private String acctNo;					//账号

    private String memo;					//备注

    private String docUrl;				//企业管理员授权委托书

    private String weituoshuDocExpireTime;	//企业管理员授权委托书失效时间

    private String createBy;


    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getWeituoshuDocExpireTime() {
        return weituoshuDocExpireTime;
    }

    public void setWeituoshuDocExpireTime(String weituoshuDocExpireTime) {
        this.weituoshuDocExpireTime = weituoshuDocExpireTime;
    }

    public String getDocUrl() {
        return docUrl;
    }

    public void setDocUrl(String docUrl) {
        this.docUrl = docUrl;
    }

    public String getConpanyName() {
        return conpanyName;
    }

    public void setConpanyName(String conpanyName) {
        this.conpanyName = conpanyName;
    }

    public String getTaxNo() {
        return taxNo;
    }

    public void setTaxNo(String taxNo) {
        this.taxNo = taxNo;
    }

    public String getConpanyAddress() {
        return conpanyAddress;
    }

    public void setConpanyAddress(String conpanyAddress) {
        this.conpanyAddress = conpanyAddress;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getOpenBank() {
        return openBank;
    }

    public void setOpenBank(String openBank) {
        this.openBank = openBank;
    }

    public String getAcctNo() {
        return acctNo;
    }

    public void setAcctNo(String acctNo) {
        this.acctNo = acctNo;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }



    public String getTab() {
        return tab;
    }

    public void setTab(String tab) {
        this.tab = tab;
    }

    public String getIdCardDate() {
        return idCardDate;
    }

    public void setIdCardDate(String idCardDate) {
        this.idCardDate = idCardDate;
    }

    public String[] getOtherName() {
        return otherName;
    }

    public void setOtherName(String[] otherName) {
        this.otherName = otherName;
    }

    private String[] docID;

    public String getStaffId() {
        return StaffId;
    }

    public void setStaffId(String staffId) {
        StaffId = staffId;
    }

    public String[] getDocID() {
        return docID;
    }

    public void setDocID(String[] docID) {
        this.docID = docID;
    }

    public String[] getQtFileName() {
        return qtFileName;
    }

    public void setQtFileName(String[] qtFileName) {
        this.qtFileName = qtFileName;
    }

    public String[] getDate() {
        return date;
    }

    public void setDate(String[] date) {
        this.date = date;
    }

    public String[] getFileName() {
        return fileName;
    }

    public void setFileName(String[] fileName) {
        this.fileName = fileName;
    }

    public String[] getPath() {
        return path;
    }

    public void setPath(String[] path) {
        this.path = path;
    }

    public String[] getFileType() {
        return fileType;
    }

    public void setFileType(String[] fileType) {
        this.fileType = fileType;
    }

    public String getUploadName() {
        return uploadName;
    }

    public void setUploadName(String uploadName) {
        this.uploadName = uploadName;
    }

    public String getUsCodeDocName() {
        return usCodeDocName;
    }

    public void setUsCodeDocName(String usCodeDocName) {
        this.usCodeDocName = usCodeDocName;
    }

    public String getUsCodeDocExpireTime() {
        return usCodeDocExpireTime;
    }

    public void setUsCodeDocExpireTime(String usCodeDocExpireTime) {
        this.usCodeDocExpireTime = usCodeDocExpireTime;
    }

    public String getOrgCodeDocName() {
        return orgCodeDocName;
    }

    public void setOrgCodeDocName(String orgCodeDocName) {
        this.orgCodeDocName = orgCodeDocName;
    }

    public String getOrgCodeDocExpireTime() {
        return orgCodeDocExpireTime;
    }

    public void setOrgCodeDocExpireTime(String orgCodeDocExpireTime) {
        this.orgCodeDocExpireTime = orgCodeDocExpireTime;
    }

    public String getBusinessLicenseDocName() {
        return businessLicenseDocName;
    }

    public void setBusinessLicenseDocName(String businessLicenseDocName) {
        this.businessLicenseDocName = businessLicenseDocName;
    }

    public String getBusinessLicenseDocExpireTime() {
        return businessLicenseDocExpireTime;
    }

    public void setBusinessLicenseDocExpireTime(String businessLicenseDocExpireTime) {
        this.businessLicenseDocExpireTime = businessLicenseDocExpireTime;
    }

    public String getTaxNumberDocName() {
        return taxNumberDocName;
    }

    public void setTaxNumberDocName(String taxNumberDocName) {
        this.taxNumberDocName = taxNumberDocName;
    }

    public String getTaxNumberDocExpireTime() {
        return taxNumberDocExpireTime;
    }

    public void setTaxNumberDocExpireTime(String taxNumberDocExpireTime) {
        this.taxNumberDocExpireTime = taxNumberDocExpireTime;
    }

    public String getAreaStr() {
        return areaStr;
    }

    public void setAreaStr(String areaStr) {
        this.areaStr = areaStr;
    }

    public String getOrgCodeUrl() {
        return orgCodeUrl;
    }

    public void setOrgCodeUrl(String orgCodeUrl) {
        this.orgCodeUrl = orgCodeUrl;
    }

    public String getUsCodeUrl() {
        return usCodeUrl;
    }

    public void setUsCodeUrl(String usCodeUrl) {
        this.usCodeUrl = usCodeUrl;
    }

    public String getBusinessLicenseUrl() {
        return businessLicenseUrl;
    }

    public void setBusinessLicenseUrl(String businessLicenseUrl) {
        this.businessLicenseUrl = businessLicenseUrl;
    }

    public String getTaxNumberUrl() {
        return taxNumberUrl;
    }

    public void setTaxNumberUrl(String taxNumberUrl) {
        this.taxNumberUrl = taxNumberUrl;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    private String[] checkboxGroup;
    // 营业执照
    private String businessLicense;
    // 税务登记号
    private String taxNumber;
    // 资质名称
    private String docName;
    // 文件状态
    private String documentstatus;

    private String startTime;

    private String endtime;

    // 合同类别
    private String conKind;
    // 合同名称
    private String conName;

    public String getConKind() {
        return conKind;
    }

    public void setConKind(String conKind) {
        this.conKind = conKind;
    }

    public String getConName() {
        return conName;
    }

    public void setConName(String conName) {
        this.conName = conName;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getDocName() {
        return docName;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public String getDocumentstatus() {
        return documentstatus;
    }

    public void setDocumentstatus(String documentstatus) {
        this.documentstatus = documentstatus;
    }

    public static String getCardtype() {
        return CARDTYPE;
    }

    public String getBusinessLicense() {
        return businessLicense;
    }

    public String getPcStr() {
        return pcStr;
    }

    public void setPcStr(String pcStr) {
        this.pcStr = pcStr;
    }

    public void setBusinessLicense(String businessLicense) {
        this.businessLicense = businessLicense;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo;
    }

    public Integer getCompID() {
        return compID;
    }

    public void setCompID(Integer compID) {
        this.compID = compID;
    }

    public Integer getPcompID() {
        return pcompID;
    }

    public void setPcompID(Integer pcompID) {
        this.pcompID = pcompID;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getDepartmentID() {
        return departmentID;
    }

    public void setDepartmentID(Integer departmentID) {
        this.departmentID = departmentID;
    }

    public Integer getAccountID() {
        return accountID;
    }

    public void setAccountID(Integer accountID) {
        this.accountID = accountID;
    }

    public String getExtID() {
        return extID;
    }

    public void setExtID(String extID) {
        this.extID = extID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getServeType() {
        return serveType;
    }

    public void setServeType(String serveType) {
        this.serveType = serveType;
    }

    public Integer getProvinceID() {
        return provinceID;
    }

    public void setProvinceID(Integer provinceID) {
        this.provinceID = provinceID;
    }

    public Integer getCityID() {
        return cityID;
    }

    public void setCityID(Integer cityID) {
        this.cityID = cityID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    public String getIconURL() {
        return iconURL;
    }

    public void setIconURL(String iconURL) {
        this.iconURL = iconURL;
    }

    public String getLandline() {
        return landline;
    }

    public void setLandline(String landline) {
        this.landline = landline;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getCodeFlag() {
        return codeFlag;
    }

    public void setCodeFlag(String codeFlag) {
        this.codeFlag = codeFlag;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getUsCode() {
        return usCode;
    }

    public void setUsCode(String usCode) {
        this.usCode = usCode;
    }

    public String getAuditInfo() {
        return auditInfo;
    }

    public void setAuditInfo(String auditInfo) {
        this.auditInfo = auditInfo;
    }

    public Integer getOperStatus() {
        return operStatus;
    }

    public void setOperStatus(Integer operStatus) {
        this.operStatus = operStatus;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getLupDate() {
        return lupDate;
    }

    public void setLupDate(Date lupDate) {
        this.lupDate = lupDate;
    }

    public String[] getCheckboxGroup() {
        return checkboxGroup;
    }

    public void setCheckboxGroup(String[] checkboxGroup) {
        this.checkboxGroup = checkboxGroup;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdCardPic() {
        return idCardPic;
    }

    public void setIdCardPic(String idCardPic) {
        this.idCardPic = idCardPic;
    }

    public String getYinyePic() {
        return yinyePic;
    }

    public void setYinyePic(String yinyePic) {
        this.yinyePic = yinyePic;
    }

    /*public List<DicVo> getDicList() {
        return dicList;
    }

    public void setDicList(List<DicVo> dicList) {
        this.dicList = dicList;
    }*/

    public String getSeverTypeName() {
        return severTypeName;
    }

    public void setSeverTypeName(String severTypeName) {
        this.severTypeName = severTypeName;
    }

    public String getTaxCode() {
        return taxCode;
    }

    public void setTaxCode(String taxCode) {
        this.taxCode = taxCode;
    }

    public String getBusinessCode() {
        return businessCode;
    }

    public void setBusinessCode(String businessCode) {
        this.businessCode = businessCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIdCardPic1() {
        return idCardPic1;
    }

    public void setIdCardPic1(String idCardPic1) {
        this.idCardPic1 = idCardPic1;
    }

    public boolean isAdd() {
        return add;
    }

    public void setAdd(boolean add) {
        this.add = add;
    }

}

