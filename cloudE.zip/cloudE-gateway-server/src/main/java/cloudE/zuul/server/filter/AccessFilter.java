package cloudE.zuul.server.filter;

import com.edip.dto.SessionContext;
import com.edip.dto.util.CookieUtil;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author vangao1989
 * @Description: filter 前置过滤器
 * @date 2017年7月26日
 */
public class AccessFilter extends ZuulFilter {

    private static Logger logger = LoggerFactory.getLogger(AccessFilter.class);

    // Redis服务器IP
    public static String IP;

    @Value("${spring.redis.host}")
    public void setIP(String ip) {
        this.IP = ip;
    }

    // Redis的端口号
    private static int PORT;

    @Value("${spring.redis.port}")
    public void setPORT(int PORT) {
        this.PORT = PORT;
    }

    // 可用连接实例的最大数目，默认值为8；
    // 如果赋值为-1，则表示不限制；如果pool已经分配了maxActive个jedis实例，则此时pool的状态为exhausted(耗尽)。
    private static int MAX_ACTIVE;

    @Value("${spring.redis.pool.max-active}")
    public void setMAX_ACTIVE(int MAX_ACTIVE) {
        this.MAX_ACTIVE = MAX_ACTIVE;
    }

    // 控制一个pool最多有多少个状态为idle(空闲的)的jedis实例，默认值也是8。
    private static int MAX_IDLE;

    @Value("${spring.redis.pool.max-idle}")
    public void setMAX_IDLE(int MAX_IDLE) {
        this.MAX_IDLE = MAX_IDLE;
    }


    // 等待可用连接的最大时间，单位毫秒，默认值为-1，表示永不超时。如果超过等待时间，则直接抛出JedisConnectionException；
    private static int MAX_WAIT;

    @Value("${spring.redis.pool.max-wait}")
    public void setMAX_WAIT(int MAX_WAIT) {
        this.MAX_WAIT = MAX_WAIT;
    }

    @Override
    public Object run() {
        RequestContext ctx = RequestContext.getCurrentContext();
        try {
            HttpServletRequest request = ctx.getRequest();
            HttpServletResponse response = ctx.getResponse();
            String requestURL = request.getRequestURL().toString();
            logger.info("{} AccessFilter request to {}", request.getMethod(), requestURL);
            //String sessionId = CookieUtil.getCookie(request,"AUTH_TICKET");
            request.setAttribute("ip",IP);
            request.setAttribute("port",PORT);
            request.setAttribute("maxActive",MAX_ACTIVE);
            request.setAttribute("maxIdel",MAX_IDLE);
            request.setAttribute("maxWait",MAX_WAIT);
            String loginName = (String) SessionContext.getContext().getSession(request).getAttribute("LOGIN_NAME");
            /*if (true) {
                ctx.setRequest(request);
                ctx.setSendZuulResponse(true);// 对该请求进行路由
                ctx.setResponseStatusCode(200);
                ctx.set("isSuccess", true);// 设值，让下一个Filter看到上一个Filter的状态
            } else {
                ctx.setSendZuulResponse(false);// 过滤该请求，不对其进行路由
                ctx.setResponseStatusCode(401);// 返回错误码
                ctx.setResponseBody("{\"result\":\"request fail!\"}");// 返回错误内容
                ctx.set("isSuccess", false);
            }*/
            if (loginName!=null) {
                ctx.setRequest(request);
                ctx.setSendZuulResponse(true);// 对该请求进行路由
                ctx.setResponseStatusCode(200);
                ctx.set("isSuccess", true);// 设值，让下一个Filter看到上一个Filter的状态
            } else {
                CookieUtil.delAllCookie(request,response);
                ctx.setSendZuulResponse(false);// 过滤该请求，不对其进行路由
                ctx.setResponseStatusCode(508);// 返回错误码
                ctx.setResponseBody("{\"result\":\"request fail!\"}");// 返回错误内容
                ctx.set("isSuccess", false);
            }

        } catch (Throwable throwable) {
            logger.error("AccessFilter fail", throwable);
            ctx.setSendZuulResponse(false);// 过滤该请求，不对其进行路由
            ctx.setResponseStatusCode(508);// 返回错误码
            ctx.setResponseBody("{\"result\":\"request fail!\"}");// 返回错误内容
            ctx.set("isSuccess", false);
        }
        return null;

    }

    @Override
    public boolean shouldFilter() {
        RequestContext requestContext = RequestContext.getCurrentContext();
        HttpServletRequest request = requestContext.getRequest();

        logger.info("uri:{}", request.getRequestURI());
        //验证码接口和登录不拦截//小工具先调getMenu也不拦截
        if (request.getRequestURI().endsWith("facade.script")||request.getRequestURI().endsWith("getCode.ajax")
                ||request.getRequestURI().endsWith("login.ajax") || request.getRequestURI().endsWith("getAdmin.ajax") ||
                request.getRequestURI().endsWith("checkPhoneNumByLoginName.ajax")|| request.getRequestURI().endsWith("sendToUser.ajax")
                ||request.getRequestURI().endsWith("register.ajax")||request.getRequestURI().endsWith("checkPhoneNum.ajax")
                ||request.getRequestURI().endsWith("checkYzm.ajax")||request.getRequestURI().endsWith("phoneLogin.ajax") || request.getRequestURI().endsWith("changeCompany.ajax")
                || request.getRequestURI().endsWith("remindAuthentication.ajax")|| request.getRequestURI().endsWith("returnSign.ajax")||request.getRequestURI().endsWith("resertPasswordByPassword.ajax")
                ||  request.getRequestURI().endsWith("getProvince.ajax")|| request.getRequestURI().endsWith("remindAuthentication.ajax")|| request.getRequestURI().endsWith("returnSign.ajax")||request.getRequestURI().endsWith("resertPasswordByPassword.ajax")
                ||request.getRequestURI().endsWith("getRole.ajax")
               ) {
            return false;
        }
        return true;// 是否执行该过滤器，此处为true，说明需要过滤
    }

    @Override
    public int filterOrder() {
        return 0;// 优先级为0，数字越大，优先级越低
    }

    @Override
    public String filterType() {
        return "pre";// 前置过滤器
    }
}
