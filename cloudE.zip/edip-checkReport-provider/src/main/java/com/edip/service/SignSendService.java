package com.edip.service;

import com.alibaba.fastjson.JSONObject;
import com.edip.entity.ReturnSignInfo;
import com.edip.entity.SignInfo;
import com.github.pagehelper.PageInfo;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

public interface SignSendService {
    public JSONObject getSignatureProgress(Map<String, Object> signInfo);
    /**
     * create by: hym
     * description:获取待签章任务列表
     * create time: 14:49 2018/12/24
     *
     * @Param: null
     * @return
     */
    public PageInfo getSendTaskList(Map<String, Object> signInfo) throws ParseException;
    /**
     * create by: hym
     * description:删除待签章任务
     * create time: 15:24 2018/12/24
     *
     * @Param: null
     * @return
     */
    public void deleteSendTask(Map<String, Object> signInfo);
    /**
     * create by: hym
     * description:发送签章任务
     * create time: 16:29 2018/12/24
     *
     * @Param: null
     * @return
     */
    public void  sendTask(Map<String, Object> signInfo) throws Exception;
    /**
     * create by: hym
     * description:保存自定义签章信息
     * create time: 14:27 2019/1/8
     *
      * @Param: null
     * @return
     */
    public void saveCustomSign(Map<String, Object> signInfo);
    /**
     * create by: hym
     * description:删除发送任资质务信息
     * create time: 14:27 2019/1/8
     *
      * @Param: null
     * @return
     */
    public void deleteSendTaskDocs(Map<String, Object> signInfo);
    /**
     * create by: hym
     * description:删除发送任务主题信息
     * create time: 16:43 2019/1/8
     *
      * @Param: null
     * @return
     */
    public void deleteSendTaskTheme(Map<String, Object> signInfo);
    /**
     * create by: hym
     * description:更改任务状态
     * create time: 16:46 2019/1/8
     *
      * @Param: null
     * @return
     */
    public void changeTaskStatus(Map<String, Object> signInfo);
    /**
     * create by: hym
     * description:获取签章任务资质
     * create time: 16:46 2019/1/8
     *
     * @Param: null
     * @return
     */
    List<SignInfo> getSignatureDocList(Map<String, Object> signInfo);
    /**
     * create by: hym
     * description:进入页面将正在进行，等待的签章任务刷失败
     * create time: 8:47 2019/1/17
     *
      * @Param: null
     * @return
     */
    public void updateTaskFail(Map<String, Object> signInfo);
    /**
     * create by: hym
     * description:删除接受公司
     * create time: 15:38 2019/2/26
     *
      * @Param: null
     * @return
     */
    public void deleteReceiveCompany(Map<String, Object> signInfo);
    /**
     * create by: hym
     * description:一键发送签章任务
     * create time: 16:29 2018/12/24
     *
     * @Param: null
     * @return
     */
    public int  allSendTask(Map<String, Object> signInfo) throws Exception;
    /**
     * create by: hym
     * description:发送签章信息到签章服务
     * create time: 10:58 2018/12/22
     *
     * @Param: HttpServletRequest request, HttpServletResponse response,Map<String,Object> signInfo
     * @return JsonObject
     */
    public JSONObject sendSignInfo(Map<String, Object> signInfo) throws UnsupportedEncodingException, InterruptedException;
    /**
     * create by: hym
     * description:匹配公司id
     * create time: 10:58 2018/12/22
     *
     * @Param: HttpServletRequest request, HttpServletResponse response,Map<String,Object> signInfo
     * @return JsonObject
     */
    public JSONObject getCompnayInfo(Map<String, Object> signInfo) ;


    List<SignInfo> getReturnSignatureDocList(Map<String, Object> signInfo);


    List<ReturnSignInfo> getReturnSignatureInfo(Map<String, Object> signInfo);
}
