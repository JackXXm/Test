package com.edip.mapper;

import com.edip.entity.ProjectCoopcompany;
import com.edip.entity.ProjectCoopcompanyExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ProjectCoopcompanyMapper {
    long countByExample(ProjectCoopcompanyExample example);

    int deleteByExample(ProjectCoopcompanyExample example);

    int deleteByPrimaryKey(Integer itemid);

    int insert(ProjectCoopcompany record);

    int insertSelective(ProjectCoopcompany record);

    List<ProjectCoopcompany> selectByExample(ProjectCoopcompanyExample example);

    ProjectCoopcompany selectByPrimaryKey(Integer itemid);

    int updateByExampleSelective(@Param("record") ProjectCoopcompany record, @Param("example") ProjectCoopcompanyExample example);

    int updateByExample(@Param("record") ProjectCoopcompany record, @Param("example") ProjectCoopcompanyExample example);

    int updateByPrimaryKeySelective(ProjectCoopcompany record);

    int updateByPrimaryKey(ProjectCoopcompany record);

}