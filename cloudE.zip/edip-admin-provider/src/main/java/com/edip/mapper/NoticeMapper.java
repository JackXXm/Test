package com.edip.mapper;

import java.util.List;
import java.util.Map;

public interface NoticeMapper {
    void addNotice(Map<String, Object> params);

    List<Map<String, Object>> getNotice(Map<String, Object> params);

    void editNotice(Map<String, Object> params);

    void deleteNotice(List<String> ids);

    void sendNotice(Map<String, Object> params);
}
