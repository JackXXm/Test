package com.edip.service.impl;

import com.edip.dto.util.RedisUtil;
import com.edip.dto.util.StringUtils;
import com.edip.entity.*;
import com.edip.mapper.AuditStampHistoryMapper;
import com.edip.mapper.StampChangeResoreMapper;
import com.edip.mapper.StampMapper;
import com.edip.mapper.StampMapperVo;
import com.edip.service.StampService;
import com.edip.util.FileUtil;
import com.edip.vo.MessageVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class StampServiceImpl implements StampService {

    @Autowired
    private StampMapper stampMapper;
    @Autowired
    private RedisUtil redisUtil;
    @Autowired
    private StampMapperVo stampMapperVo;
    @Autowired
    private StampChangeResoreMapper stampChangeResoreMapper;
    @Autowired
    private AuditStampHistoryMapper auditStampHistoryMapper;

    @Override
    public List<Stamp> getStampList(String stampName,int companyId,boolean signList,boolean checkReportFlag) {
        StampExample stampExample=new StampExample();
        stampExample.setOrderByClause("lupDate desc");
        StampExample.Criteria criteria=stampExample.createCriteria();
        if(signList==true)
            criteria.andStatusEqualTo(0);
        else
            criteria.andStatusNotEqualTo(-1);
        if(stampName!=null&&!stampName.trim().equals(""))
            criteria.andStampnameLike("%"+stampName+"%");
        if(checkReportFlag){
            List<String>stampType=new ArrayList<>();
            stampType.add("公章");
            stampType.add("质检章");
            criteria.andStamptypeIn(stampType);
        }
        criteria.andCompidEqualTo(companyId);
        List<Stamp> result = FileUtil.getFileUrl(stampMapper.selectByExample(stampExample),redisUtil);
        if (signList){
            for (int i = 0;i<result.size();i++){
                if(result.get(i).getStamptype().equals("公章")){
                    Stamp s = result.get(0);
                    result.set(0,result.get(i));
                    result.set(i,s);
                }
            }
        }
        return result;
    }

    @Override
    @Transactional
    public int  addStamp(Stamp stamp) throws Exception {
        String stampUrl=stamp.getDocurl();
        stamp.setDocurl(FileUtil.fileMove(stampUrl,"stamp",stamp.getCompid()+"",redisUtil));
        stamp.setCreatedate(new Date());
        stamp.setLupdate(new Date());
        stamp.setStatus(1);
        if(stamp.getStamptype()!=null&&"其他".equals(stamp.getStamptype())){
            stamp.setStampname(stamp.getStamptype()+"("+stamp.getStampname()+")");
        }
        StampExample example = new StampExample();
        StampExample.Criteria criteria = example.createCriteria();
        criteria.andCompidEqualTo(stamp.getCompid());
        criteria.andStampnameEqualTo(stamp.getStampname());
        criteria.andStatusNotEqualTo(-1);
        List<Stamp>list = stampMapper.selectByExample(example);
        int amount=0;
        if(list.size()>0){
            return amount;
        }
        amount=stampMapper.insertSelective(stamp);
        //添加印章审核
        AuditStampHistory auditStampHistory = new AuditStampHistory();
        auditStampHistory.setStampid(stamp.getStampid());
        auditStampHistory.setStatus(1);
        auditStampHistory.setCreateTime(new Date());
        auditStampHistoryMapper.insertSelective(auditStampHistory);

        return amount;
    }

    @Override
    public Integer updateStamp(Integer stampID, String tempUrl, Integer compID,String accountName,Integer accountID) throws Exception {
        Stamp sta = stampMapper.selectByPrimaryKey(stampID);
        String oldPath = sta.getDocurl();
        String path="";
        if(StringUtils.isNotBlank(tempUrl)&&tempUrl.startsWith("/temp")){
            try {
                //移动文件从临时目录到正式目录
                path = FileUtil.fileMove(tempUrl,"stamp",compID+"",redisUtil);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            sta.setDocurl(path);
            sta.setStatus(1);
            sta.setAccountName(accountName);
    //docurl: "http://192.168.122.142:80/public/10/11/public-10-11-2bb9a28f-8cff-4d79-b9b1-8b8283c48ea2.png
    //docUrl: "http://192.168.122.142:80/public/10/11/public-10-11-1b9505a2-bc91-4a30-8bed-1097e3264cba.jpg"
        }
        sta.setLupdate(new Date());
        int amount=stampMapper.updateByPrimaryKeySelective(sta);

        /*
        //新增印章变更记录
        StampChangeResore changeResore = new StampChangeResore();
        changeResore.setCreateAccountId(accountID);
        changeResore.setCreateAccountName(accountName);
        changeResore.setOldStampUrl(oldPath);
        changeResore.setNewStampUrl(path);
        changeResore.setCreateTime(new Date());
        changeResore.setStampId(stampID);
        changeResore.setStatus(1);
        stampChangeResoreMapper.insertSelective(changeResore);
        */
        AuditStampHistoryExample example = new AuditStampHistoryExample();
        example.createCriteria().andStampidEqualTo(stampID).andStatusEqualTo(1);
        List<AuditStampHistory> list = auditStampHistoryMapper.selectByExample(example);
        AuditStampHistory auditStampHistory = null;
        if (list!=null&&list.size()==0){
            auditStampHistory = new AuditStampHistory();
            auditStampHistory.setStampid(stampID);
            auditStampHistory.setStatus(1);
        } else{
            auditStampHistory = list.get(0);
        }
        auditStampHistory.setCreateTime(new Date());
        if (auditStampHistory.getId()!=null)
            auditStampHistoryMapper.updateByPrimaryKeySelective(auditStampHistory);
        else
            auditStampHistoryMapper.insertSelective(auditStampHistory);
        return amount;
    }


    @Override
    public int deleteData(Integer stampID) {
        Stamp stamp=new Stamp();
        stamp.setStatus(-1);
        stamp.setStampid(stampID);
        int amount=stampMapper.updateByPrimaryKeySelective(stamp);
        return amount;
    }

    @Override
    public int deleteDataByCompID(Integer compID) {
//        Integer stampID = stampMapperVo.selectStampID(compID);
//        int amount=0;
//        if(stampID!=null){
//            Stamp stamp=new Stamp();
//            stamp.setStatus(-1);
//            stamp.setStampid(stampID);
//
//            amount=stampMapper.updateByPrimaryKeySelective(stamp);
//
//        }
        return 0;
    }

    @Override
    public int deleteData2(Integer compID) {
        Integer stampID = stampMapperVo.selectStampID(compID);
        int amount=0;
        if(stampID!=null){
            Stamp stamp=new Stamp();
            stamp.setStatus(-1);
            stamp.setStampid(stampID);

            amount=stampMapper.updateByPrimaryKeySelective(stamp);
        }
        return amount;
    }

}
