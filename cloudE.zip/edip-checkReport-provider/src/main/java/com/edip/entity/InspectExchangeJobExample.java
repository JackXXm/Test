package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class InspectExchangeJobExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    private Integer limit;

    private Integer offset;

    public InspectExchangeJobExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getOffset() {
        return offset;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andCompanyIdIsNull() {
            addCriterion("company_id is null");
            return (Criteria) this;
        }

        public Criteria andCompanyIdIsNotNull() {
            addCriterion("company_id is not null");
            return (Criteria) this;
        }

        public Criteria andCompanyIdEqualTo(Integer value) {
            addCriterion("company_id =", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotEqualTo(Integer value) {
            addCriterion("company_id <>", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdGreaterThan(Integer value) {
            addCriterion("company_id >", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("company_id >=", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdLessThan(Integer value) {
            addCriterion("company_id <", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdLessThanOrEqualTo(Integer value) {
            addCriterion("company_id <=", value, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdIn(List<Integer> values) {
            addCriterion("company_id in", values, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotIn(List<Integer> values) {
            addCriterion("company_id not in", values, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdBetween(Integer value1, Integer value2) {
            addCriterion("company_id between", value1, value2, "companyId");
            return (Criteria) this;
        }

        public Criteria andCompanyIdNotBetween(Integer value1, Integer value2) {
            addCriterion("company_id not between", value1, value2, "companyId");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameIsNull() {
            addCriterion("receive_company_name is null");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameIsNotNull() {
            addCriterion("receive_company_name is not null");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameEqualTo(String value) {
            addCriterion("receive_company_name =", value, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameNotEqualTo(String value) {
            addCriterion("receive_company_name <>", value, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameGreaterThan(String value) {
            addCriterion("receive_company_name >", value, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameGreaterThanOrEqualTo(String value) {
            addCriterion("receive_company_name >=", value, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameLessThan(String value) {
            addCriterion("receive_company_name <", value, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameLessThanOrEqualTo(String value) {
            addCriterion("receive_company_name <=", value, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameLike(String value) {
            addCriterion("receive_company_name like", value, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameNotLike(String value) {
            addCriterion("receive_company_name not like", value, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameIn(List<String> values) {
            addCriterion("receive_company_name in", values, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameNotIn(List<String> values) {
            addCriterion("receive_company_name not in", values, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameBetween(String value1, String value2) {
            addCriterion("receive_company_name between", value1, value2, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andReceiveCompanyNameNotBetween(String value1, String value2) {
            addCriterion("receive_company_name not between", value1, value2, "receiveCompanyName");
            return (Criteria) this;
        }

        public Criteria andDataDigestIsNull() {
            addCriterion("data_digest is null");
            return (Criteria) this;
        }

        public Criteria andDataDigestIsNotNull() {
            addCriterion("data_digest is not null");
            return (Criteria) this;
        }

        public Criteria andDataDigestEqualTo(String value) {
            addCriterion("data_digest =", value, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestNotEqualTo(String value) {
            addCriterion("data_digest <>", value, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestGreaterThan(String value) {
            addCriterion("data_digest >", value, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestGreaterThanOrEqualTo(String value) {
            addCriterion("data_digest >=", value, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestLessThan(String value) {
            addCriterion("data_digest <", value, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestLessThanOrEqualTo(String value) {
            addCriterion("data_digest <=", value, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestLike(String value) {
            addCriterion("data_digest like", value, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestNotLike(String value) {
            addCriterion("data_digest not like", value, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestIn(List<String> values) {
            addCriterion("data_digest in", values, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestNotIn(List<String> values) {
            addCriterion("data_digest not in", values, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestBetween(String value1, String value2) {
            addCriterion("data_digest between", value1, value2, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andDataDigestNotBetween(String value1, String value2) {
            addCriterion("data_digest not between", value1, value2, "dataDigest");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            addCriterion("type is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            addCriterion("type is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(String value) {
            addCriterion("type =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(String value) {
            addCriterion("type <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(String value) {
            addCriterion("type >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(String value) {
            addCriterion("type >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(String value) {
            addCriterion("type <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(String value) {
            addCriterion("type <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLike(String value) {
            addCriterion("type like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotLike(String value) {
            addCriterion("type not like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<String> values) {
            addCriterion("type in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<String> values) {
            addCriterion("type not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(String value1, String value2) {
            addCriterion("type between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(String value1, String value2) {
            addCriterion("type not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andFristJobIdIsNull() {
            addCriterion("frist_job_id is null");
            return (Criteria) this;
        }

        public Criteria andFristJobIdIsNotNull() {
            addCriterion("frist_job_id is not null");
            return (Criteria) this;
        }

        public Criteria andFristJobIdEqualTo(Integer value) {
            addCriterion("frist_job_id =", value, "fristJobId");
            return (Criteria) this;
        }

        public Criteria andFristJobIdNotEqualTo(Integer value) {
            addCriterion("frist_job_id <>", value, "fristJobId");
            return (Criteria) this;
        }

        public Criteria andFristJobIdGreaterThan(Integer value) {
            addCriterion("frist_job_id >", value, "fristJobId");
            return (Criteria) this;
        }

        public Criteria andFristJobIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("frist_job_id >=", value, "fristJobId");
            return (Criteria) this;
        }

        public Criteria andFristJobIdLessThan(Integer value) {
            addCriterion("frist_job_id <", value, "fristJobId");
            return (Criteria) this;
        }

        public Criteria andFristJobIdLessThanOrEqualTo(Integer value) {
            addCriterion("frist_job_id <=", value, "fristJobId");
            return (Criteria) this;
        }

        public Criteria andFristJobIdIn(List<Integer> values) {
            addCriterion("frist_job_id in", values, "fristJobId");
            return (Criteria) this;
        }

        public Criteria andFristJobIdNotIn(List<Integer> values) {
            addCriterion("frist_job_id not in", values, "fristJobId");
            return (Criteria) this;
        }

        public Criteria andFristJobIdBetween(Integer value1, Integer value2) {
            addCriterion("frist_job_id between", value1, value2, "fristJobId");
            return (Criteria) this;
        }

        public Criteria andFristJobIdNotBetween(Integer value1, Integer value2) {
            addCriterion("frist_job_id not between", value1, value2, "fristJobId");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdIsNull() {
            addCriterion("create_account_id is null");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdIsNotNull() {
            addCriterion("create_account_id is not null");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdEqualTo(Integer value) {
            addCriterion("create_account_id =", value, "createAccountId");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdNotEqualTo(Integer value) {
            addCriterion("create_account_id <>", value, "createAccountId");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdGreaterThan(Integer value) {
            addCriterion("create_account_id >", value, "createAccountId");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("create_account_id >=", value, "createAccountId");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdLessThan(Integer value) {
            addCriterion("create_account_id <", value, "createAccountId");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdLessThanOrEqualTo(Integer value) {
            addCriterion("create_account_id <=", value, "createAccountId");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdIn(List<Integer> values) {
            addCriterion("create_account_id in", values, "createAccountId");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdNotIn(List<Integer> values) {
            addCriterion("create_account_id not in", values, "createAccountId");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdBetween(Integer value1, Integer value2) {
            addCriterion("create_account_id between", value1, value2, "createAccountId");
            return (Criteria) this;
        }

        public Criteria andCreateAccountIdNotBetween(Integer value1, Integer value2) {
            addCriterion("create_account_id not between", value1, value2, "createAccountId");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdIsNull() {
            addCriterion("update_account_id is null");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdIsNotNull() {
            addCriterion("update_account_id is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdEqualTo(Integer value) {
            addCriterion("update_account_id =", value, "updateAccountId");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdNotEqualTo(Integer value) {
            addCriterion("update_account_id <>", value, "updateAccountId");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdGreaterThan(Integer value) {
            addCriterion("update_account_id >", value, "updateAccountId");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("update_account_id >=", value, "updateAccountId");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdLessThan(Integer value) {
            addCriterion("update_account_id <", value, "updateAccountId");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdLessThanOrEqualTo(Integer value) {
            addCriterion("update_account_id <=", value, "updateAccountId");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdIn(List<Integer> values) {
            addCriterion("update_account_id in", values, "updateAccountId");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdNotIn(List<Integer> values) {
            addCriterion("update_account_id not in", values, "updateAccountId");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdBetween(Integer value1, Integer value2) {
            addCriterion("update_account_id between", value1, value2, "updateAccountId");
            return (Criteria) this;
        }

        public Criteria andUpdateAccountIdNotBetween(Integer value1, Integer value2) {
            addCriterion("update_account_id not between", value1, value2, "updateAccountId");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNull() {
            addCriterion("delete_flag is null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIsNotNull() {
            addCriterion("delete_flag is not null");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagEqualTo(String value) {
            addCriterion("delete_flag =", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotEqualTo(String value) {
            addCriterion("delete_flag <>", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThan(String value) {
            addCriterion("delete_flag >", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagGreaterThanOrEqualTo(String value) {
            addCriterion("delete_flag >=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThan(String value) {
            addCriterion("delete_flag <", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLessThanOrEqualTo(String value) {
            addCriterion("delete_flag <=", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagLike(String value) {
            addCriterion("delete_flag like", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotLike(String value) {
            addCriterion("delete_flag not like", value, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagIn(List<String> values) {
            addCriterion("delete_flag in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotIn(List<String> values) {
            addCriterion("delete_flag not in", values, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagBetween(String value1, String value2) {
            addCriterion("delete_flag between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andDeleteFlagNotBetween(String value1, String value2) {
            addCriterion("delete_flag not between", value1, value2, "deleteFlag");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberIsNull() {
            addCriterion("company_number is null");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberIsNotNull() {
            addCriterion("company_number is not null");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberEqualTo(Integer value) {
            addCriterion("company_number =", value, "companyNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberNotEqualTo(Integer value) {
            addCriterion("company_number <>", value, "companyNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberGreaterThan(Integer value) {
            addCriterion("company_number >", value, "companyNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberGreaterThanOrEqualTo(Integer value) {
            addCriterion("company_number >=", value, "companyNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberLessThan(Integer value) {
            addCriterion("company_number <", value, "companyNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberLessThanOrEqualTo(Integer value) {
            addCriterion("company_number <=", value, "companyNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberIn(List<Integer> values) {
            addCriterion("company_number in", values, "companyNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberNotIn(List<Integer> values) {
            addCriterion("company_number not in", values, "companyNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberBetween(Integer value1, Integer value2) {
            addCriterion("company_number between", value1, value2, "companyNumber");
            return (Criteria) this;
        }

        public Criteria andCompanyNumberNotBetween(Integer value1, Integer value2) {
            addCriterion("company_number not between", value1, value2, "companyNumber");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberIsNull() {
            addCriterion("drugs_number is null");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberIsNotNull() {
            addCriterion("drugs_number is not null");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberEqualTo(Integer value) {
            addCriterion("drugs_number =", value, "drugsNumber");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberNotEqualTo(Integer value) {
            addCriterion("drugs_number <>", value, "drugsNumber");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberGreaterThan(Integer value) {
            addCriterion("drugs_number >", value, "drugsNumber");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberGreaterThanOrEqualTo(Integer value) {
            addCriterion("drugs_number >=", value, "drugsNumber");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberLessThan(Integer value) {
            addCriterion("drugs_number <", value, "drugsNumber");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberLessThanOrEqualTo(Integer value) {
            addCriterion("drugs_number <=", value, "drugsNumber");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberIn(List<Integer> values) {
            addCriterion("drugs_number in", values, "drugsNumber");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberNotIn(List<Integer> values) {
            addCriterion("drugs_number not in", values, "drugsNumber");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberBetween(Integer value1, Integer value2) {
            addCriterion("drugs_number between", value1, value2, "drugsNumber");
            return (Criteria) this;
        }

        public Criteria andDrugsNumberNotBetween(Integer value1, Integer value2) {
            addCriterion("drugs_number not between", value1, value2, "drugsNumber");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberIsNull() {
            addCriterion("apparatus_number is null");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberIsNotNull() {
            addCriterion("apparatus_number is not null");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberEqualTo(Integer value) {
            addCriterion("apparatus_number =", value, "apparatusNumber");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberNotEqualTo(Integer value) {
            addCriterion("apparatus_number <>", value, "apparatusNumber");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberGreaterThan(Integer value) {
            addCriterion("apparatus_number >", value, "apparatusNumber");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberGreaterThanOrEqualTo(Integer value) {
            addCriterion("apparatus_number >=", value, "apparatusNumber");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberLessThan(Integer value) {
            addCriterion("apparatus_number <", value, "apparatusNumber");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberLessThanOrEqualTo(Integer value) {
            addCriterion("apparatus_number <=", value, "apparatusNumber");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberIn(List<Integer> values) {
            addCriterion("apparatus_number in", values, "apparatusNumber");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberNotIn(List<Integer> values) {
            addCriterion("apparatus_number not in", values, "apparatusNumber");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberBetween(Integer value1, Integer value2) {
            addCriterion("apparatus_number between", value1, value2, "apparatusNumber");
            return (Criteria) this;
        }

        public Criteria andApparatusNumberNotBetween(Integer value1, Integer value2) {
            addCriterion("apparatus_number not between", value1, value2, "apparatusNumber");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberIsNull() {
            addCriterion("health_products_number is null");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberIsNotNull() {
            addCriterion("health_products_number is not null");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberEqualTo(Integer value) {
            addCriterion("health_products_number =", value, "healthProductsNumber");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberNotEqualTo(Integer value) {
            addCriterion("health_products_number <>", value, "healthProductsNumber");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberGreaterThan(Integer value) {
            addCriterion("health_products_number >", value, "healthProductsNumber");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberGreaterThanOrEqualTo(Integer value) {
            addCriterion("health_products_number >=", value, "healthProductsNumber");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberLessThan(Integer value) {
            addCriterion("health_products_number <", value, "healthProductsNumber");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberLessThanOrEqualTo(Integer value) {
            addCriterion("health_products_number <=", value, "healthProductsNumber");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberIn(List<Integer> values) {
            addCriterion("health_products_number in", values, "healthProductsNumber");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberNotIn(List<Integer> values) {
            addCriterion("health_products_number not in", values, "healthProductsNumber");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberBetween(Integer value1, Integer value2) {
            addCriterion("health_products_number between", value1, value2, "healthProductsNumber");
            return (Criteria) this;
        }

        public Criteria andHealthProductsNumberNotBetween(Integer value1, Integer value2) {
            addCriterion("health_products_number not between", value1, value2, "healthProductsNumber");
            return (Criteria) this;
        }

        public Criteria andSenderIsNull() {
            addCriterion("sender is null");
            return (Criteria) this;
        }

        public Criteria andSenderIsNotNull() {
            addCriterion("sender is not null");
            return (Criteria) this;
        }

        public Criteria andSenderEqualTo(String value) {
            addCriterion("sender =", value, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderNotEqualTo(String value) {
            addCriterion("sender <>", value, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderGreaterThan(String value) {
            addCriterion("sender >", value, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderGreaterThanOrEqualTo(String value) {
            addCriterion("sender >=", value, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderLessThan(String value) {
            addCriterion("sender <", value, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderLessThanOrEqualTo(String value) {
            addCriterion("sender <=", value, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderLike(String value) {
            addCriterion("sender like", value, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderNotLike(String value) {
            addCriterion("sender not like", value, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderIn(List<String> values) {
            addCriterion("sender in", values, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderNotIn(List<String> values) {
            addCriterion("sender not in", values, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderBetween(String value1, String value2) {
            addCriterion("sender between", value1, value2, "sender");
            return (Criteria) this;
        }

        public Criteria andSenderNotBetween(String value1, String value2) {
            addCriterion("sender not between", value1, value2, "sender");
            return (Criteria) this;
        }

        public Criteria andSendCompanyIsNull() {
            addCriterion("send_company is null");
            return (Criteria) this;
        }

        public Criteria andSendCompanyIsNotNull() {
            addCriterion("send_company is not null");
            return (Criteria) this;
        }

        public Criteria andSendCompanyEqualTo(String value) {
            addCriterion("send_company =", value, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyNotEqualTo(String value) {
            addCriterion("send_company <>", value, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyGreaterThan(String value) {
            addCriterion("send_company >", value, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyGreaterThanOrEqualTo(String value) {
            addCriterion("send_company >=", value, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyLessThan(String value) {
            addCriterion("send_company <", value, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyLessThanOrEqualTo(String value) {
            addCriterion("send_company <=", value, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyLike(String value) {
            addCriterion("send_company like", value, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyNotLike(String value) {
            addCriterion("send_company not like", value, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyIn(List<String> values) {
            addCriterion("send_company in", values, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyNotIn(List<String> values) {
            addCriterion("send_company not in", values, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyBetween(String value1, String value2) {
            addCriterion("send_company between", value1, value2, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andSendCompanyNotBetween(String value1, String value2) {
            addCriterion("send_company not between", value1, value2, "sendCompany");
            return (Criteria) this;
        }

        public Criteria andReturnStatusIsNull() {
            addCriterion("return_status is null");
            return (Criteria) this;
        }

        public Criteria andReturnStatusIsNotNull() {
            addCriterion("return_status is not null");
            return (Criteria) this;
        }

        public Criteria andReturnStatusEqualTo(Integer value) {
            addCriterion("return_status =", value, "returnStatus");
            return (Criteria) this;
        }

        public Criteria andReturnStatusNotEqualTo(Integer value) {
            addCriterion("return_status <>", value, "returnStatus");
            return (Criteria) this;
        }

        public Criteria andReturnStatusGreaterThan(Integer value) {
            addCriterion("return_status >", value, "returnStatus");
            return (Criteria) this;
        }

        public Criteria andReturnStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("return_status >=", value, "returnStatus");
            return (Criteria) this;
        }

        public Criteria andReturnStatusLessThan(Integer value) {
            addCriterion("return_status <", value, "returnStatus");
            return (Criteria) this;
        }

        public Criteria andReturnStatusLessThanOrEqualTo(Integer value) {
            addCriterion("return_status <=", value, "returnStatus");
            return (Criteria) this;
        }

        public Criteria andReturnStatusIn(List<Integer> values) {
            addCriterion("return_status in", values, "returnStatus");
            return (Criteria) this;
        }

        public Criteria andReturnStatusNotIn(List<Integer> values) {
            addCriterion("return_status not in", values, "returnStatus");
            return (Criteria) this;
        }

        public Criteria andReturnStatusBetween(Integer value1, Integer value2) {
            addCriterion("return_status between", value1, value2, "returnStatus");
            return (Criteria) this;
        }

        public Criteria andReturnStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("return_status not between", value1, value2, "returnStatus");
            return (Criteria) this;
        }

        public Criteria andNoteIsNull() {
            addCriterion("note is null");
            return (Criteria) this;
        }

        public Criteria andNoteIsNotNull() {
            addCriterion("note is not null");
            return (Criteria) this;
        }

        public Criteria andNoteEqualTo(String value) {
            addCriterion("note =", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotEqualTo(String value) {
            addCriterion("note <>", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThan(String value) {
            addCriterion("note >", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteGreaterThanOrEqualTo(String value) {
            addCriterion("note >=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThan(String value) {
            addCriterion("note <", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLessThanOrEqualTo(String value) {
            addCriterion("note <=", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteLike(String value) {
            addCriterion("note like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotLike(String value) {
            addCriterion("note not like", value, "note");
            return (Criteria) this;
        }

        public Criteria andNoteIn(List<String> values) {
            addCriterion("note in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotIn(List<String> values) {
            addCriterion("note not in", values, "note");
            return (Criteria) this;
        }

        public Criteria andNoteBetween(String value1, String value2) {
            addCriterion("note between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andNoteNotBetween(String value1, String value2) {
            addCriterion("note not between", value1, value2, "note");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNull() {
            addCriterion("signature is null");
            return (Criteria) this;
        }

        public Criteria andSignatureIsNotNull() {
            addCriterion("signature is not null");
            return (Criteria) this;
        }

        public Criteria andSignatureEqualTo(String value) {
            addCriterion("signature =", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotEqualTo(String value) {
            addCriterion("signature <>", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThan(String value) {
            addCriterion("signature >", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureGreaterThanOrEqualTo(String value) {
            addCriterion("signature >=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThan(String value) {
            addCriterion("signature <", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLessThanOrEqualTo(String value) {
            addCriterion("signature <=", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureLike(String value) {
            addCriterion("signature like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotLike(String value) {
            addCriterion("signature not like", value, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureIn(List<String> values) {
            addCriterion("signature in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotIn(List<String> values) {
            addCriterion("signature not in", values, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureBetween(String value1, String value2) {
            addCriterion("signature between", value1, value2, "signature");
            return (Criteria) this;
        }

        public Criteria andSignatureNotBetween(String value1, String value2) {
            addCriterion("signature not between", value1, value2, "signature");
            return (Criteria) this;
        }
    }

    /**
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}