package com.edip.mapper;


import com.edip.entity.Bill;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


public interface BillMapperVo {


	Integer updateBillAmount(Map params);
    Integer addBillAmount(Map parmas);
    Map<String,Double> getLeaveMoney(Map parmas);

	

}
