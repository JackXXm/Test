package com.edip.utils;


import com.edip.entity.AdminMessagestatus;
import com.edip.vo.AdminMessagestatusVo;
import com.google.common.collect.Lists;

import java.util.List;


public class AdminMessagestatusConvert {
    private AdminMessagestatusConvert() {

    }
    public static AdminMessagestatus convert(AdminMessagestatusVo messagestatusVo){
        if (null == messagestatusVo) {
            return null;
        }
        AdminMessagestatus messagestatus=new AdminMessagestatus();
        messagestatus.setAccountid(messagestatusVo.getAccountid());
        messagestatus.setFromflag(messagestatusVo.getFromflag());
        messagestatus.setFromid(messagestatusVo.getFromid());
        return messagestatus;
    }
    public static final List<AdminMessagestatus> convert(List<AdminMessagestatusVo> messagestatusVoList) {
        if (messagestatusVoList == null) {
            return Lists.newArrayList();
        }
        List<AdminMessagestatus> messagestatusList = Lists.newArrayList();
        for (AdminMessagestatusVo messagestatusVo : messagestatusVoList) {
            messagestatusList.add(AdminMessagestatusConvert.convert(messagestatusVo));
        }
        return messagestatusList;
    }
}