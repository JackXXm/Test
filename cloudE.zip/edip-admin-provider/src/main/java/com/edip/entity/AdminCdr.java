package com.edip.entity;

import java.util.Date;

public class AdminCdr {
	private Integer cdrID;

	private Integer cdrType;

	private Integer cdrsubType;

	private Integer compID;

	private Integer modeID;

	private Integer targetID;

	private Date createDate;

	private String name;

	private Integer dataType;

	private Integer dataID;

	private Double signMoney ;
	private Double accountCharging ;
	private Double giveCharging ;

	private Double remainAmount;

	private Double remainGiveAmount;

	public Double getRemainGiveAmount() {
		return remainGiveAmount;
	}

	public void setRemainGiveAmount(Double remainGiveAmount) {
		this.remainGiveAmount = remainGiveAmount;
	}

	public Double getRemainAmount() {
		return remainAmount;
	}

	public void setRemainAmount(Double remainAmount) {
		this.remainAmount = remainAmount;
	}

	public Integer getCdrID() {
		return cdrID;
	}

	public void setCdrID(Integer cdrID) {
		this.cdrID = cdrID;
	}

	public Integer getCdrType() {
		return cdrType;
	}

	public void setCdrType(Integer cdrType) {
		this.cdrType = cdrType;
	}

	public Integer getCdrsubType() {
		return cdrsubType;
	}

	public void setCdrsubType(Integer cdrsubType) {
		this.cdrsubType = cdrsubType;
	}

	public Integer getCompID() {
		return compID;
	}

	public void setCompID(Integer compID) {
		this.compID = compID;
	}

	public Integer getModeID() {
		return modeID;
	}

	public void setModeID(Integer modeID) {
		this.modeID = modeID;
	}

	public Integer getTargetID() {
		return targetID;
	}

	public void setTargetID(Integer targetID) {
		this.targetID = targetID;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	public Integer getDataType() {
		return dataType;
	}

	public void setDataType(Integer dataType) {
		this.dataType = dataType;
	}

	public Integer getDataID() {
		return dataID;
	}

	public void setDataID(Integer dataID) {
		this.dataID = dataID;
	}

	public Double getSignMoney() {
		return signMoney;
	}

	public void setSignMoney(Double signMoney) {
		this.signMoney = signMoney;
	}

	public Double getAccountCharging() {
		return accountCharging;
	}

	public void setAccountCharging(Double accountCharging) {
		this.accountCharging = accountCharging;
	}

	public Double getGiveCharging() {
		return giveCharging;
	}

	public void setGiveCharging(Double giveCharging) {
		this.giveCharging = giveCharging;
	}

}