package com.edip.controller;

import com.edip.dto.ServerResponse;
import com.edip.dto.SessionContext;
import com.edip.service.OutBoxService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * @author 发件箱
 * @description TODO
 * @DATE 2019/1/2 0002 17:11
 */
@RestController
@RequestMapping(value = "outBox")
public class OutBoxController {

    @Autowired
    private OutBoxService outBoxService;
    @Autowired
    private HttpServletRequest request;

    /**
     * 发件箱列表
     * @return
     */
    @RequestMapping (value = "outBoxInfo.ajax")
    public ServerResponse queryOutBoxInfo(@RequestBody Map<String,Object>info){
        HttpSession httpSession = SessionContext.getContext().getSession(request);
        Integer companyId= (Integer) httpSession.getAttribute("compID");
        info.put("compID",companyId);

        Integer page= (Integer) info.get("page");
        Integer rows= (Integer) info.get("rows");
        PageHelper.startPage(page,rows);

        PageInfo pageInfo=new PageInfo(  outBoxService.queryOutBoxInfo(info));

        return ServerResponse.createBySuccess("success",pageInfo);
    }

    /**
     *
     * @return
     */
    @RequestMapping(value = "queryReissueInfo.ajax")
    public ServerResponse queryReissueInfo(String projectId,String infoId,String type) throws Exception{
        Map<String,Object> result =  outBoxService.queryReissueInfo(projectId,infoId,type);
        return ServerResponse.createBySuccess("success",result);
    }

    /**
     *
     * @param jobId
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "queryReissueProjectDetail.ajax")
    public ServerResponse queryReissueProjectDetail(String jobId) throws Exception{
        Map<String,Object> result = outBoxService.queryReissueProjectDetail(jobId);
        return ServerResponse.createBySuccess("success",result);
    }
}
