package com.edip.mapper;

import com.edip.entity.OutBox;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface OutBoxMapper {
    /**
     * 查询发件箱列表
     * @param compID
     * @return
     */
    List<OutBox> queryOutBoxInfo(@Param("compID") Integer outBoxMapper,
                                 @Param("sender") String sender,
                                 @Param("receiveCompany") String receiveCompany,
                                 @Param("startTime") String startTime,
                                 @Param("endTime") String endTime,
                                 @Param("status") String status,
                                 @Param("dataDigest") String dataDigest
    );

    List<Map<String,Object>> queryReissueProjectDetail(@Param("jobId") String jobId);

    List<Map<String,Object>> queryReissueCompany(@Param("jobId") String jobId);

    List<Map<String,Object>> querySendDocDetail(Map<String, Object> param);

    List<Map<String,Object>> queryReissueProjectInfoByJob(@Param("projectId") String projectId);

    Integer statisticsOutBox(@Param("compID") Integer compID);
}
