package com.edip.service.impl;

import com.edip.dto.ServerResponse;
import com.edip.entity.ExchangeJob;
import com.edip.entity.OutBox;
import com.edip.feign.ContractFeign;
import com.edip.feign.DocFeign;
import com.edip.feign.MemberFeign;
import com.edip.feign.ProductFeign;
import com.edip.mapper.ExchangeJobMapper;
import com.edip.mapper.OutBoxMapper;
import com.edip.service.ExchangeService;
import com.edip.service.OutBoxService;
import com.edip.utils.ExchangeUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author Administrator
 * @description TODO
 * @DATE 2019/1/2 0002 17:38
 */
@Service
public class OutBoxServiceImpl implements OutBoxService {
    private static final Logger logger = LoggerFactory.getLogger(OutBoxServiceImpl.class);
    @Autowired
    private OutBoxMapper outBoxMapper;
    @Autowired
    private ProductFeign productFeign;
    @Autowired
    private ExchangeService exchangeService;
    @Autowired
    private MemberFeign memberFeign;
    @Autowired
    private ContractFeign contractFeign;
    @Autowired
    private DocFeign docFeign;
    @Autowired
    private ExchangeJobMapper exchangeJobMapper;
    @Autowired
    private ExchangeUtil exchangeUtil;

    @Override
    public List<OutBox> queryOutBoxInfo(Map<String,Object>info) {
        String sender= (String) info.get("sender");
        String receiveCompany= (String) info.get("receiveCompany");

        String startTime= (String) info.get("startTime");
        String endTime= (String) info.get("endTime");
        String status= (String) info.get("status");
        Integer compID= (Integer) info.get("compID");
        String dataDigest= (String) info.get("dataDigest");
        return outBoxMapper.queryOutBoxInfo(compID, sender, receiveCompany, startTime, endTime, status,dataDigest);
    }

    @Override
    public Map<String, Object> queryReissueInfo(String id, String productId, String type) {
        Map<String, Object> reissueDocInfoResult = new HashMap<>(8);
        try {
            //已发送的资质docId
            List<Map<String, Object>> isSendDocList = this.getIsSendDocList(id);
            if (StringUtils.equalsIgnoreCase(type, "1")) {
                //公司现有的资质
                Map<String, Object> resultMap = new HashMap<>();
                Map<String, Object> companyInfo =null;// exchangeService.queryDocInfo();
                Integer companyInfoID = (Integer) companyInfo.get("companyInfoID");
                List<Map<String, Object>> companyDicDetail = (List<Map<String, Object>>) companyInfo.get("allAttribute");
                ServerResponse memberInfoList = memberFeign.memberInfoList(companyInfoID, "N");
                Map<String, Object> memberInfo = getMemberList(memberInfoList);
                List<Integer> memberIDList = (List<Integer>) memberInfo.get("memberIDList");
                List<Map<String, Object>> memberList = (List<Map<String, Object>>) memberInfo.get("memberList");
                ServerResponse memberDocList = docFeign.memberListDoc(memberIDList);
                List<Map<String, Object>> memberDocResult = exchangeUtil.getMemberDocResult(memberList, (Map<String, Object>) memberDocList.getData());
                ServerResponse contractInfo = contractFeign.queryCompanyContractInfo(companyInfoID);
                List<Map<String, Object>> contractDoc = getContractDoc((List<Map<String, Object>>) contractInfo.getData());
                resultMap.put("memberDicDetail", ExchangeUtil.clearZeroDocData(memberDocResult));
                resultMap.put("contractDicDetail", contractDoc);
                resultMap.put("companyDicDetail", companyDicDetail);
                resultMap.put("manufName", null);
                reissueDocInfoResult = this.getReissueDocResult(resultMap, isSendDocList);
            } else {
                //产品
                ServerResponse response = productFeign.queryProductDetail(productId);
                Map<String, Object> data = (Map<String, Object>) response.getData();
                if (data != null) {
                    Map<String, Object> productInfo = (Map<String, Object>) data.get("productInfo");
                    Integer manufId = (Integer) productInfo.get("manufId");
                    //总的资质信息
                    ServerResponse productDetail = null;//exchangeService.queryProductDetail(productId, manufId == null ? null : String.valueOf(manufId));
                    Map<String, Object> receiveMap = (Map<String, Object>) productDetail.getData();
                    //已发送的资质信息
                    reissueDocInfoResult = this.getReissueDocResult(receiveMap, isSendDocList);
                }
            }

        } catch (Exception e) {
            logger.error(this.getClass().getName() + ".queryReissueInfo error: " + e.getMessage(), e);
        }
        return reissueDocInfoResult;
    }

    @Override
    public Map<String, Object> queryReissueProjectDetail(String jobId) {
        Map<String, Object> result = new HashMap<>();
        try {
            ExchangeJob exchangeJob = exchangeJobMapper.selectByPrimaryKey(Integer.parseInt(jobId));
            List<Map<String, Object>> reissueCompany = outBoxMapper.queryReissueCompany(jobId);
            List<Map<String, Object>> reissueProjectDetail = outBoxMapper.queryReissueProjectDetail(jobId);
            result.put("receiveInfo", reissueCompany);
            result.put("projectInfo", reissueProjectDetail);
            result.put("exchangeJob", exchangeJob);
        } catch (Exception e) {
            logger.error(this.getClass().getName() + ".queryReissueProjectDetail error: " + e.getMessage(), e);
        }
        return result;
    }

    /**
     * 设置发送状态
     *
     * @param reissueList
     * @param isSendList
     */
    private void setExchangeStatus(List<Map<String, Object>> reissueList, List<Map<String, Object>> isSendList) {
        try {
            if (!CollectionUtils.isEmpty(reissueList)) {
                reissueList.forEach(reissue -> {
                    List<Map<String, Object>> docList = (List<Map<String, Object>>) reissue.get("docList");
                    if (!CollectionUtils.isEmpty(docList)) {
                        docList.forEach(docMap -> {
                            String exchangeStatus = "未发送";
                            Integer type=0;
                            if (!CollectionUtils.isEmpty(isSendList)) {
                                for (Map isSend : isSendList) {
                                    int sendDocId = (int) isSend.get("docId");
                                    int deleteFlag=Integer.parseInt((String)isSend.get("deleteFlag")) ;
                                    if ((int) docMap.get("id") == sendDocId&&deleteFlag!=-1) {
                                        exchangeStatus = "已发送";
                                        type=(Integer) isSend.get("replaceFlag");
                                        break;
                                    }
                                }
                            }
                            docMap.put("exchangeStatus", exchangeStatus);
                            docMap.put("type", type);
                        });

                    }
                });
            }
        } catch (Exception e) {
            logger.error("setExchangeStatus error :" + e.getMessage(), e);
        }
    }

    /**
     * 处理补发的详细数据
     *
     * @param reissue
     * @param isSendDocList
     * @return
     * @throws Exception
     */
    private Map<String, Object> getReissueDocResult(Map<String, Object> reissue, List<Map<String, Object>> isSendDocList) throws Exception {
        if (reissue != null) {
            Iterator<String> iterator = reissue.keySet().iterator();
            while (iterator.hasNext()) {
                String key = iterator.next();
                if (!StringUtils.equalsIgnoreCase(key, "manufName")) {
                    List<Map<String, Object>> reissueList;
                    reissueList = (List<Map<String, Object>>) reissue.get(key);
                    if (!StringUtils.equalsIgnoreCase(key, "memberDicDetail")) {
                        setExchangeStatus(reissueList, isSendDocList);
                    } else {
                        //人员的资质做特殊处理
                        if (!CollectionUtils.isEmpty(reissueList)) {
                            reissueList.forEach(reissueMap -> {
                                List<Map<String, Object>> memberDocList = (List<Map<String, Object>>) reissueMap.get("allAttribute");
                                setExchangeStatus(memberDocList, isSendDocList);
                            });
                        }
                    }
                }
            }
        }
        return reissue;
    }

    //获取人员信息
    private Map<String, Object> getMemberList(ServerResponse response) throws Exception {
        Map<String, Object> result = new HashMap<>(2);
        Map<String, Object> data = (Map<String, Object>) response.getData();
        if (data != null) {
            List<Map<String, Object>> memberList = (List<Map<String, Object>>) data.get("datas");
            List<Integer> memberIDList = new ArrayList<>();
            if (!CollectionUtils.isEmpty(memberList)) {
                memberList.stream().forEach(member -> {
                    Integer memberId = (Integer) member.get("id");
                    memberIDList.add(memberId);
                });
            }
            result.put("memberList", memberList);
            result.put("memberIDList", memberIDList);
        }
        return result;
    }

    /**
     * 获取合同资质
     *
     * @param contractList
     * @return
     */
    private List<Map<String, Object>> getContractDoc(List<Map<String, Object>> contractList) throws Exception {
        if (!CollectionUtils.isEmpty(contractList)) {
            List<Integer> contractIdList = new ArrayList<>();
            contractList.stream().forEach(contract -> {
                contractIdList.add((Integer) contract.get("id"));
            });
            ServerResponse response = contractFeign.queryContractDetailList(contractIdList);
            return (List<Map<String, Object>>) response.getData();
        }
        return null;
    }

    private List<Map<String, Object>> getIsSendDocList(String projectId) throws Exception {
        Map<String, Object> map = new HashMap<>(2);
        Map<String, Object> param = new HashMap<>(2);
        map.put("projectId", projectId);
        List<Map<String, Object>> projectIdList = new ArrayList<>();
        List<Map<String, Object>> projectList = outBoxMapper.queryReissueProjectInfoByJob(projectId);
        projectIdList.addAll(projectList);
        projectIdList.add(map);
        param.put("projectIdList", projectIdList);
        List<Map<String, Object>> sendDocDetail = outBoxMapper.querySendDocDetail(param);
        return sendDocDetail;
    }
}
