package com.edip.mapper;

import com.edip.entity.CompanyBenefitDetail;
import com.edip.entity.CompanyBenefitDetailExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CompanyBenefitDetailMapper {
    long countByExample(CompanyBenefitDetailExample example);

    int deleteByExample(CompanyBenefitDetailExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CompanyBenefitDetail record);

    int insertSelective(CompanyBenefitDetail record);

    List<CompanyBenefitDetail> selectByExample(CompanyBenefitDetailExample example);

    CompanyBenefitDetail selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CompanyBenefitDetail record, @Param("example") CompanyBenefitDetailExample example);

    int updateByExample(@Param("record") CompanyBenefitDetail record, @Param("example") CompanyBenefitDetailExample example);

    int updateByPrimaryKeySelective(CompanyBenefitDetail record);

    int updateByPrimaryKey(CompanyBenefitDetail record);

    List<CompanyBenefitDetail> getFreeDelivery(@Param("companyID")Integer companyID);
}