package com.edip.utils;

import com.edip.entity.AdminMessagestatus;
import com.edip.vo.AdminMessagestatusVo;
import com.google.common.collect.Lists;

import java.util.List;


public class AdminMessagestatusVoConvert {
    private AdminMessagestatusVoConvert() {

    }
    public static AdminMessagestatusVo convert(AdminMessagestatus messagestatus){
        if (null == messagestatus) {
            return null;
        }
        AdminMessagestatusVo messagestatusVo=new AdminMessagestatusVo();
        messagestatusVo.setAccountid(messagestatus.getAccountid());
        messagestatusVo.setFromflag(messagestatus.getFromflag());
        messagestatusVo.setFromid(messagestatus.getFromid());
        return messagestatusVo;
    }
    public static final List<AdminMessagestatusVo> convert(List<AdminMessagestatus> messagestatusList) {
        if (messagestatusList == null) {
            return Lists.newArrayList();
        }
        List<AdminMessagestatusVo> messagestatusVoList = Lists.newArrayList();
        for (AdminMessagestatus messagestatus : messagestatusList) {
            messagestatusVoList.add(AdminMessagestatusVoConvert.convert(messagestatus));
        }
        return messagestatusVoList;
    }
}