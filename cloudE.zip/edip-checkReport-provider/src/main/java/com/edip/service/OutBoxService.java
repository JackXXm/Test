package com.edip.service;

import com.edip.entity.OutBox;

import java.util.List;
import java.util.Map;

public interface OutBoxService {
    /**
     * 查询发件箱
     * @param compID
     * @return
     */
    List<OutBox> queryOutBoxInfo(Map<String, Object> info);

    /**
     * 根据id获取补发的资质
     * @param infoId
     * @return
     */
    Map<String,Object> queryReissueInfo(String projectId, String infoId, String type);

    Map<String,Object> queryReissueProjectDetail(String jobId);
}
