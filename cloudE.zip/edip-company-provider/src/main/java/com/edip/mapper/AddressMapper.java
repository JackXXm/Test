package com.edip.mapper;

import com.edip.entity.Address;
import com.edip.entity.AddressExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AddressMapper {
    int countByExample(AddressExample example);

    int deleteByExample(AddressExample example);

    int deleteByPrimaryKey(Integer adrID);

    int insert(Address record);

    int insertSelective(Address record);

    List<Address> selectByExampleWithPage(@Param("example") AddressExample example, @Param("from") Integer from, @Param("to") Integer to);

    List<Address> selectByExample(AddressExample example);

    Address selectByPrimaryKey(Integer adrID);

    int updateByExampleSelective(@Param("record") Address record, @Param("example") AddressExample example);

    int updateByExample(@Param("record") Address record, @Param("example") AddressExample example);

    int updateByPrimaryKeySelective(Address record);

    int updateByPrimaryKey(Address record);
    
    Address selectByCompId(Integer compId);
}