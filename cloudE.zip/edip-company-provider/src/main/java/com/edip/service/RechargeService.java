package com.edip.service;

import com.edip.entity.Bill;

import java.util.List;
import java.util.Map;

public interface RechargeService {
    List<Map<String , Object>> queryBill(Integer compID) throws Exception;

    List<Map<String , Object>> queryTopView(Integer compID) throws Exception;

    List<Map<String , Object>> queryBenefit(Integer compID) throws Exception;

    List<Map<String , Object>> queryExchangeList(Integer compID) throws Exception;
    int charging( String info,Integer compId);

    Bill billMaintain(Integer compId);
}
