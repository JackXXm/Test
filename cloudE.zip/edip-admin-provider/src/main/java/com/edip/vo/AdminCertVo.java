package com.edip.vo;

import java.util.Date;

public class AdminCertVo {
	public static final Integer CERT_OK = 0;//正常（已下载）
	public static final Integer CERT_TOAUDIT = 1;//待审批
	public static final Integer CERT_TODOWNLOAD = 2;//待下载
	public static final Integer CERT_EXPIRED = 3;//已过期
	public static final Integer CERT_EXPIRING = 5;//即将过期
	public static final Integer CERT_REVOKE = 4;//已吊销
	public static final Integer CERT_AUDITNOPASS = 9;//审核不通过
	public static final String cert_storagetype = "1";//ukey证书
	

    private String billAccount;//付款账户

    private Integer billNum;//付款金额

    private Integer billFlag;//是否付款
    
    private Date billTime;//付款时间
    private String billTimeS;//付款时间
    
    private String isBill;
    
    private String isDeliver;
    
    private String applyTypeC;
    private String compName;
    private String certStatus;
    private String accountName;

    private Integer ukStatus;//申请证书类型
    
    private String certSN;//证书序列号

    private String ukeyCode;//Ukey序列号

    private Integer deliverFlag;//是否已邮寄

    private Date activeDate;//激活日期
    private String activeDateS;//激活日期

	private Integer certID;//证书ID  主键自增长

    private Integer compID;//企业ID

    private Integer accountID;// ukey管理员ID

    private Date validDate; //生效日期

    private Date invalidDate;//失效日期
    
    private String validDateS; //生效日期
    
    private String invalidDateS;//失效日期

    private Integer status;//证书状态

    private Date createDate;//创建时间

    private Date lupDate;//更新时间
    private String createDateS;//创建时间
    
    private String lupDateS;//更新时间

    private byte[] x509;//X509证书

    private byte[] publicKey;//公钥
    
    private String certNo;
    
    private String txcode;

    private Integer userID;
    //追加Ukey申请身份证
    private String IDCardFace;
	//追加Ukey申请身份证
    private String IDCardBack;

	private String mailName;

	private String mailNum;

	private Integer userid;

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getMailName() {
		return mailName;
	}

	public void setMailName(String mailName) {
		this.mailName = mailName;
	}

	public String getMailNum() {
		return mailNum;
	}

	public void setMailNum(String mailNum) {
		this.mailNum = mailNum;
	}

    public String getIsBill() {
    	return isBill;
    }
    
    public void setIsBill(String isBill) {
    	this.isBill = isBill;
    }
    
    public String getIsDeliver() {
    	return isDeliver;
    }
    
    public void setIsDeliver(String isDeliver) {
    	this.isDeliver = isDeliver;
    }
    
    public String getApplyTypeC() {
		return applyTypeC;
	}

	public void setApplyTypeC(String applyTypeC) {
		this.applyTypeC = applyTypeC;
	}
    
    public Integer getUkStatus() {
		return ukStatus;
	}

	public void setUkStatus(Integer ukStatus) {
		this.ukStatus = ukStatus;
	}

	public String getCompName() {
    	return compName;
    }
    
    public void setCompName(String compName) {
    	this.compName = compName;
    }
    
    public String getCertStatus() {
    	return certStatus;
    }
    
    public void setCertStatus(String certStatus) {
    	this.certStatus = certStatus;
    }
    
    public String getAccountName() {
    	return accountName;
    }
    
    public void setAccountName(String accountName) {
    	this.accountName = accountName;
    }
    
    public byte[] getX509() {
        return x509;
    }


	public void setX509(byte[] x509) {
        this.x509 = x509;
    }

    public byte[] getPublicKey() {
        return publicKey;
    }

    public void setPublicKey(byte[] publicKey) {
        this.publicKey = publicKey;
    }
    
    public Integer getCertID() {
        return certID;
    }

    public void setCertID(Integer certID) {
        this.certID = certID;
    }

    public Integer getCompID() {
        return compID;
    }

    public void setCompID(Integer compID) {
        this.compID = compID;
    }

    public Integer getAccountID() {
        return accountID;
    }

    public void setAccountID(Integer accountID) {
        this.accountID = accountID;
    }

    public Date getValidDate() {
        return validDate;
    }

    public void setValidDate(Date validDate) {
        this.validDate = validDate;
    }

    public Date getInvalidDate() {
        return invalidDate;
    }

    public void setInvalidDate(Date invalidDate) {
        this.invalidDate = invalidDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getLupDate() {
        return lupDate;
    }

    public void setLupDate(Date lupDate) {
        this.lupDate = lupDate;
    }

	public String getCertNo() {
		return certNo;
	}

	public void setCertNo(String certNo) {
		this.certNo = certNo;
	}

	public String getBillAccount() {
		return billAccount;
	}

	public void setBillAccount(String billAccount) {
		this.billAccount = billAccount;
	}

	public Integer getBillNum() {
		return billNum;
	}

	public void setBillNum(Integer billNum) {
		this.billNum = billNum;
	}

	public Integer getBillFlag() {
		return billFlag;
	}

	public void setBillFlag(Integer billFlag) {
		this.billFlag = billFlag;
	}

	public Date getBillTime() {
		return billTime;
	}

	public void setBillTime(Date billTime) {
		this.billTime = billTime;
	}

	public String getCertSN() {
		return certSN;
	}

	public void setCertSN(String certSN) {
		this.certSN = certSN;
	}

	public String getUkeyCode() {
		return ukeyCode;
	}

	public void setUkeyCode(String ukeyCode) {
		this.ukeyCode = ukeyCode;
	}

	public Integer getDeliverFlag() {
		return deliverFlag;
	}

	public void setDeliverFlag(Integer deliverFlag) {
		this.deliverFlag = deliverFlag;
	}

	public Date getActiveDate() {
		return activeDate;
	}

	public void setActiveDate(Date activeDate) {
		this.activeDate = activeDate;
	}

	public String getTxcode() {
		return txcode;
	}

	public void setTxcode(String txcode) {
		this.txcode = txcode;
	}

	public String getActiveDateS() {
		return activeDateS;
	}

	public void setActiveDateS(String activeDateS) {
		this.activeDateS = activeDateS;
	}

	public String getValidDateS() {
		return validDateS;
	}

	public void setValidDateS(String validDateS) {
		this.validDateS = validDateS;
	}

	public String getInvalidDateS() {
		return invalidDateS;
	}

	public void setInvalidDateS(String invalidDateS) {
		this.invalidDateS = invalidDateS;
	}

	public String getCreateDateS() {
		return createDateS;
	}

	public void setCreateDateS(String createDateS) {
		this.createDateS = createDateS;
	}

	public String getLupDateS() {
		return lupDateS;
	}

	public void setLupDateS(String lupDateS) {
		this.lupDateS = lupDateS;
	}

	public String getBillTimeS() {
		return billTimeS;
	}

	public void setBillTimeS(String billTimeS) {
		this.billTimeS = billTimeS;
	}

	public Integer getUserID() {
		return userID;
	}

	public void setUserID(Integer userID) {
		this.userID = userID;
	}

	public String getIDCardFace() {
		return IDCardFace;
	}

	public void setIDCardFace(String IDCardFace) {
		this.IDCardFace = IDCardFace;
	}

	public String getIDCardBack() {
		return IDCardBack;
	}

	public void setIDCardBack(String IDCardBack) {
		this.IDCardBack = IDCardBack;
	}
}
