package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class Cdr implements Serializable {
    /**
     * 话单ID
     */
    private Integer cdrid;

    /**
     * 话单类型:
  	                                                                     0:短信
  	                                                                     1:资质查询
  	                                                                     2:证书
                                                                         3:数据交换
     */
    private Integer cdrtype;

    /**
     * 话单类型:
                                     																		 00:验证短信
                                     																		 10:通知短信
                                     																		 10:企业资质
                                     																		 11:个人资质
                                     																		 20:个人证书
                                     																		 21:企业证书
                                                                         30:数据交换
     */
    private Integer cdrsubtype;

    /**
     * 归属公司ID
     */
    private Integer compid;

    /**
     * 计费策略ID
     */
    private Integer modeid;

    /**
     * 目标公司ID
     */
    private Integer targetid;

    /**
     * 线下交换的公司名称
     */
    private String name;

    /**
     * 实体记录ID
     */
    private Integer dataid;

    /**
     * 实体类型
                                                                         0:公司
                                                                         1:人员
                                                                         2:产品
                                                                         3:合同
                                                                         4:图章
                                                                         5:证书
                                                                         6:项目
     */
    private Integer datatype;

    /**
     * 创建时间
     */
    private Date createdate;

    /**
     * 本次扣费总金额
     */
    private Float signmoney;

    /**
     * 账户金额扣费金额
     */
    private Float accountcharging;

    /**
     * 赠送金额扣费金额
     */
    private Float givecharging;

    /**
     * 剩余赠送金额
     */
    private Double remaingiveamount;

    /**
     * 剩余金额
     */
    private Double remainamount;

    private static final long serialVersionUID = 1L;

    public Integer getCdrid() {
        return cdrid;
    }

    public void setCdrid(Integer cdrid) {
        this.cdrid = cdrid;
    }

    public Integer getCdrtype() {
        return cdrtype;
    }

    public void setCdrtype(Integer cdrtype) {
        this.cdrtype = cdrtype;
    }

    public Integer getCdrsubtype() {
        return cdrsubtype;
    }

    public void setCdrsubtype(Integer cdrsubtype) {
        this.cdrsubtype = cdrsubtype;
    }

    public Integer getCompid() {
        return compid;
    }

    public void setCompid(Integer compid) {
        this.compid = compid;
    }

    public Integer getModeid() {
        return modeid;
    }

    public void setModeid(Integer modeid) {
        this.modeid = modeid;
    }

    public Integer getTargetid() {
        return targetid;
    }

    public void setTargetid(Integer targetid) {
        this.targetid = targetid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getDataid() {
        return dataid;
    }

    public void setDataid(Integer dataid) {
        this.dataid = dataid;
    }

    public Integer getDatatype() {
        return datatype;
    }

    public void setDatatype(Integer datatype) {
        this.datatype = datatype;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Float getSignmoney() {
        return signmoney;
    }

    public void setSignmoney(Float signmoney) {
        this.signmoney = signmoney;
    }

    public Float getAccountcharging() {
        return accountcharging;
    }

    public void setAccountcharging(Float accountcharging) {
        this.accountcharging = accountcharging;
    }

    public Float getGivecharging() {
        return givecharging;
    }

    public void setGivecharging(Float givecharging) {
        this.givecharging = givecharging;
    }

    public Double getRemaingiveamount() {
        return remaingiveamount;
    }

    public void setRemaingiveamount(Double remaingiveamount) {
        this.remaingiveamount = remaingiveamount;
    }

    public Double getRemainamount() {
        return remainamount;
    }

    public void setRemainamount(Double remainamount) {
        this.remainamount = remainamount;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Cdr other = (Cdr) that;
        return (this.getCdrid() == null ? other.getCdrid() == null : this.getCdrid().equals(other.getCdrid()))
            && (this.getCdrtype() == null ? other.getCdrtype() == null : this.getCdrtype().equals(other.getCdrtype()))
            && (this.getCdrsubtype() == null ? other.getCdrsubtype() == null : this.getCdrsubtype().equals(other.getCdrsubtype()))
            && (this.getCompid() == null ? other.getCompid() == null : this.getCompid().equals(other.getCompid()))
            && (this.getModeid() == null ? other.getModeid() == null : this.getModeid().equals(other.getModeid()))
            && (this.getTargetid() == null ? other.getTargetid() == null : this.getTargetid().equals(other.getTargetid()))
            && (this.getName() == null ? other.getName() == null : this.getName().equals(other.getName()))
            && (this.getDataid() == null ? other.getDataid() == null : this.getDataid().equals(other.getDataid()))
            && (this.getDatatype() == null ? other.getDatatype() == null : this.getDatatype().equals(other.getDatatype()))
            && (this.getCreatedate() == null ? other.getCreatedate() == null : this.getCreatedate().equals(other.getCreatedate()))
            && (this.getSignmoney() == null ? other.getSignmoney() == null : this.getSignmoney().equals(other.getSignmoney()))
            && (this.getAccountcharging() == null ? other.getAccountcharging() == null : this.getAccountcharging().equals(other.getAccountcharging()))
            && (this.getGivecharging() == null ? other.getGivecharging() == null : this.getGivecharging().equals(other.getGivecharging()))
            && (this.getRemaingiveamount() == null ? other.getRemaingiveamount() == null : this.getRemaingiveamount().equals(other.getRemaingiveamount()))
            && (this.getRemainamount() == null ? other.getRemainamount() == null : this.getRemainamount().equals(other.getRemainamount()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getCdrid() == null) ? 0 : getCdrid().hashCode());
        result = prime * result + ((getCdrtype() == null) ? 0 : getCdrtype().hashCode());
        result = prime * result + ((getCdrsubtype() == null) ? 0 : getCdrsubtype().hashCode());
        result = prime * result + ((getCompid() == null) ? 0 : getCompid().hashCode());
        result = prime * result + ((getModeid() == null) ? 0 : getModeid().hashCode());
        result = prime * result + ((getTargetid() == null) ? 0 : getTargetid().hashCode());
        result = prime * result + ((getName() == null) ? 0 : getName().hashCode());
        result = prime * result + ((getDataid() == null) ? 0 : getDataid().hashCode());
        result = prime * result + ((getDatatype() == null) ? 0 : getDatatype().hashCode());
        result = prime * result + ((getCreatedate() == null) ? 0 : getCreatedate().hashCode());
        result = prime * result + ((getSignmoney() == null) ? 0 : getSignmoney().hashCode());
        result = prime * result + ((getAccountcharging() == null) ? 0 : getAccountcharging().hashCode());
        result = prime * result + ((getGivecharging() == null) ? 0 : getGivecharging().hashCode());
        result = prime * result + ((getRemaingiveamount() == null) ? 0 : getRemaingiveamount().hashCode());
        result = prime * result + ((getRemainamount() == null) ? 0 : getRemainamount().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", cdrid=").append(cdrid);
        sb.append(", cdrtype=").append(cdrtype);
        sb.append(", cdrsubtype=").append(cdrsubtype);
        sb.append(", compid=").append(compid);
        sb.append(", modeid=").append(modeid);
        sb.append(", targetid=").append(targetid);
        sb.append(", name=").append(name);
        sb.append(", dataid=").append(dataid);
        sb.append(", datatype=").append(datatype);
        sb.append(", createdate=").append(createdate);
        sb.append(", signmoney=").append(signmoney);
        sb.append(", accountcharging=").append(accountcharging);
        sb.append(", givecharging=").append(givecharging);
        sb.append(", remaingiveamount=").append(remaingiveamount);
        sb.append(", remainamount=").append(remainamount);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}