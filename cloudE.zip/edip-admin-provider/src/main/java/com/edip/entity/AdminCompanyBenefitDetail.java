package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class AdminCompanyBenefitDetail implements Serializable {
    private Integer id;

    /**
     * 公司ID
     */
    private Integer compid;

    /**
     * 优惠活动ID
     */
    private Integer benefitid;

    /**
     * 0 优惠活动赠送   1 客服手动赠送
     */
    private Integer isgive;

    /**
     * 优惠方式
  1 充值赠送金额  2 赠送免费天数  3 赠送免费次数
     */
    private Integer benefittype;

    /**
     * 优惠数据
     */
    private Float benefitdata;

    private String fromcontent;

    /**
     * 创建人ID
     */
    private Integer createid;

    /**
     * 创建时间
     */
    private Date createtime;

    /**
     *
     */
    private Date startTime;

    /**
     * 结束时间
     */
    private Date endTime;

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCompid() {
        return compid;
    }

    public void setCompid(Integer compid) {
        this.compid = compid;
    }

    public Integer getBenefitid() {
        return benefitid;
    }

    public void setBenefitid(Integer benefitid) {
        this.benefitid = benefitid;
    }

    public Integer getIsgive() {
        return isgive;
    }

    public void setIsgive(Integer isgive) {
        this.isgive = isgive;
    }

    public Integer getBenefittype() {
        return benefittype;
    }

    public void setBenefittype(Integer benefittype) {
        this.benefittype = benefittype;
    }

    public Float getBenefitdata() {
        return benefitdata;
    }

    public void setBenefitdata(Float benefitdata) {
        this.benefitdata = benefitdata;
    }

    public String getFromcontent() {
        return fromcontent;
    }

    public void setFromcontent(String fromcontent) {
        this.fromcontent = fromcontent;
    }

    public Integer getCreateid() {
        return createid;
    }

    public void setCreateid(Integer createid) {
        this.createid = createid;
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AdminCompanyBenefitDetail other = (AdminCompanyBenefitDetail) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getCompid() == null ? other.getCompid() == null : this.getCompid().equals(other.getCompid()))
            && (this.getBenefitid() == null ? other.getBenefitid() == null : this.getBenefitid().equals(other.getBenefitid()))
            && (this.getIsgive() == null ? other.getIsgive() == null : this.getIsgive().equals(other.getIsgive()))
            && (this.getBenefittype() == null ? other.getBenefittype() == null : this.getBenefittype().equals(other.getBenefittype()))
            && (this.getBenefitdata() == null ? other.getBenefitdata() == null : this.getBenefitdata().equals(other.getBenefitdata()))
            && (this.getFromcontent() == null ? other.getFromcontent() == null : this.getFromcontent().equals(other.getFromcontent()))
            && (this.getCreateid() == null ? other.getCreateid() == null : this.getCreateid().equals(other.getCreateid()))
            && (this.getCreatetime() == null ? other.getCreatetime() == null : this.getCreatetime().equals(other.getCreatetime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getCompid() == null) ? 0 : getCompid().hashCode());
        result = prime * result + ((getBenefitid() == null) ? 0 : getBenefitid().hashCode());
        result = prime * result + ((getIsgive() == null) ? 0 : getIsgive().hashCode());
        result = prime * result + ((getBenefittype() == null) ? 0 : getBenefittype().hashCode());
        result = prime * result + ((getBenefitdata() == null) ? 0 : getBenefitdata().hashCode());
        result = prime * result + ((getFromcontent() == null) ? 0 : getFromcontent().hashCode());
        result = prime * result + ((getCreateid() == null) ? 0 : getCreateid().hashCode());
        result = prime * result + ((getCreatetime() == null) ? 0 : getCreatetime().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", compid=").append(compid);
        sb.append(", benefitid=").append(benefitid);
        sb.append(", isgive=").append(isgive);
        sb.append(", benefittype=").append(benefittype);
        sb.append(", benefitdata=").append(benefitdata);
        sb.append(", fromcontent=").append(fromcontent);
        sb.append(", createid=").append(createid);
        sb.append(", createtime=").append(createtime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}