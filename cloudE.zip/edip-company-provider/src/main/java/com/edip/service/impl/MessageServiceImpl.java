package com.edip.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.edip.dto.ServerResponse;
import com.edip.dto.util.StringUtils;
import com.edip.feign.AccountSubscriptionFeign;
import com.edip.mapper.UserMessageMapper;
import com.edip.entity.AccountSubscription;
import com.edip.entity.Message;
import com.edip.entity.MessageExample;
import com.edip.service.MessageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Stephen
 * @createdDate 2017-11-29
 */
@Service("messageService")
public class MessageServiceImpl implements MessageService {
	private static final Logger LOGGER = LoggerFactory.getLogger(MessageServiceImpl.class);
	//记录用户订阅数据
	@Autowired
	private UserMessageMapper messageMapper;
	@Autowired
	private AccountSubscriptionFeign accountSubscriptionFeign;
	
	//该对象用于初始化用户订阅信息
	private AccountSubscription initUser = new AccountSubscription();

	
	@Override
	public List<Message> messageList(Integer accountID, Map<String,Object> params) {
		LOGGER.debug("---------------------------------消息加载------------------------------------");
		Integer start =((Integer)params.get("page")-1)*(Integer)params.get("rows");
		Integer size = (Integer)params.get("rows");
		//加载具体消息分类列表(日志)
		if(accountID < 1 || accountID == null)
			throw new RuntimeException("accountID不合法");
		if(params.get("messageType") == null)
			throw new RuntimeException("messageType为null");
		if(size == null || size <1)
			throw new RuntimeException("size值不合法");
		if(start == null || start <0)
			throw new RuntimeException("start值不合法");
		List<Message> list = new ArrayList<Message>();
		//消息筛选条件
		List<Integer> msgstatus = new ArrayList<Integer>();
		MessageExample example = new MessageExample();
		if(!StringUtils.isBlank(params.get("type").toString())) {
			if(params.get("type").toString().equals("0")) {
				//未读
				msgstatus.add(0);
			}			
			if(params.get("type").toString().equals("1")) {
				//已读
				msgstatus.add(6);
			}			
		}else if(Integer.parseInt(params.get("messageType").toString())==9){
			msgstatus.add(0);
		}else {
			msgstatus.add(0);
			msgstatus.add(6);			
		}
		/*if(messageType==9){
			msgstatus.add(0);
		}*/
		if(Integer.parseInt(params.get("messageType").toString()) != 0) {
			MessageExample.Criteria criteria = example.createCriteria();
			MessageExample.Criteria criteria1 = example.or();
			List<Integer> accountid = new ArrayList<Integer>();
			accountid.add(0);
			accountid.add(accountID);
			if(Integer.parseInt(params.get("messageType").toString()) !=9) {
				//返回该用户是否订阅
				List<Integer> subscription = judgeAccountSubscription(accountID, (Integer)params.get("messageType"));
				if (accountID == null || subscription.size() == 0)
					throw new RuntimeException("未订阅此消息");

				criteria.andClassifyIn(subscription);

				criteria.andStatusIn(msgstatus);

				example.or(criteria1);
				criteria.andReceiveIDIn(accountid);
				example.setOrderByClause("createDate DESC");
			}else{
				criteria.andStatusIn(msgstatus);
				criteria.andMsgTypeEqualTo((Integer)params.get("messageType"));
				criteria.andAccountIDEqualTo(accountID);
			}
			
			list = messageMapper.selectByExampleWithPage(example, start, size);
			example = null;
			
			if(Integer.parseInt(params.get("messageType").toString()) == 2 ||Integer.parseInt(params.get("messageType").toString()) == 3){
				List<Integer> systems = messageMapper.queryMessageSystem(accountID, (Integer)params.get("messageType"));
				List<Message> lists = new ArrayList<>();
				if(systems.size() > 0){
					if(params.get("type") != null && params.get("type").toString().equals("0")){
						for (Message message : list) {
							boolean flag = true;
							for (int i = 0; i < systems.size(); i++) {
								if(message.getMsgID().equals(systems.get(i))){
									flag = false;
									break;
								}
							}
							if(flag){
								lists.add(message);
							}
						}
					}else{
						for (Message message : list) {
							for (int i = 0; i < systems.size(); i++) {
								if(systems.get(i).equals(message.getMsgID())){
									message.setStatus(6);
								}
							}
							lists.add(message);
						}
					}
					list = lists;
				}
			}
		} else {
			//messageType为0时需要加载classify为0和null的message
			List<Integer> accountid = new ArrayList<Integer>();
			accountid.add(0);
			accountid.add(accountID);
			list = messageMapper.selectOfSystem(start,size,accountid,msgstatus);
		}
		return list;
	}
	//消息条数
	@Override
	public int countMessageList(Integer accountID, Map<String,Object> params) {
		LOGGER.debug("---------------------------------消息加载------------------------------------");
		//加载具体消息分类列表(日志)
		if(accountID < 1 || accountID == null)
			throw new RuntimeException("accountID不合法");
		if(params.get("messageType") == null)
			throw new RuntimeException("messageType为null");
		int count = 0;
		List<Message> list = new ArrayList<Message>();
		//消息筛选条件
		List<Integer> msgstatus = new ArrayList<Integer>();
		MessageExample example = new MessageExample();
		if(!StringUtils.isBlank(params.get("type").toString())) {
			if(params.get("type").toString().equals("0")) {
				//未读
				msgstatus.add(0);
			}
			if(params.get("type").toString().equals("1")) {
				//已读
				msgstatus.add(6);
			}
		}else {
			msgstatus.add(0);
			msgstatus.add(6);
		}
		if(Integer.parseInt(params.get("messageType").toString()) != 0) {
			MessageExample.Criteria criteria = example.createCriteria();
			MessageExample.Criteria criteria1 = example.or();
			List<Integer> accountid = new ArrayList<Integer>();
			accountid.add(0);
			accountid.add(accountID);
			//返回该用户是否订阅
			List<Integer> subscription = judgeAccountSubscription(accountID,(Integer)params.get("messageType"));
			if(accountID == null || subscription.size() == 0)
				throw new RuntimeException("未订阅此消息");
			criteria.andClassifyIn(subscription);
			criteria.andStatusIn(msgstatus);

			example.or(criteria1);
			criteria.andReceiveIDIn(accountid);
			example.setOrderByClause("createDate DESC");

			count = messageMapper.countByExample(example);
			example = null;
		} else {
			//messageType为0时需要加载classify为0和null的message
			List<Integer> accountid = new ArrayList<Integer>();
			accountid.add(0);
			accountid.add(accountID);
			count  = messageMapper.countOfSystem(accountid,msgstatus);
		}
		return count;
	}
	
	//判断该用户是否订阅该分类消息
	private List<Integer> judgeAccountSubscription(Integer accountID, Integer messageType) {
		List<Integer> subscription = new ArrayList<Integer>();
		ServerResponse result = accountSubscriptionFeign.getAccountSubscriptionByAccountId(accountID);
		AccountSubscription accountSubscription = JSONObject.parseObject(result.getData().toString(),AccountSubscription.class);
		if(accountSubscription==null)
			throw new RuntimeException("用户订阅未初始化");
		//系统消息提醒(默认不给关闭)
		if(messageType == 0) {
			if(accountSubscription.getSystemstatus())
				subscription.add(0);
		}
		//交易信息
		if(messageType ==1) {
			if(accountSubscription.getExchangestatus())
				subscription.add(1);
		}
		//公告信息
		if(messageType ==2) {
			if(accountSubscription.getAnnouncementstatus())
				subscription.add(2);
		}
		//优惠信息
		if(messageType ==3) {
			if(accountSubscription.getFavourablestatus())
				subscription.add(3);
		}
		//索取申请
		if(messageType ==10) {
			subscription.add(10);
		}
		//替换申请
		if(messageType ==11) {
			subscription.add(11);
		}
		//到期提醒(测试为空的情况)
		if(messageType ==4) {
			if(accountSubscription.getTimeremind()) {
				if(accountSubscription.getCompanydocument())
					subscription.add(5);
				if(accountSubscription.getProductdocument())
					subscription.add(6);
				if(accountSubscription.getMemberdocument())
					subscription.add(7);
				if(accountSubscription.getContractdocument())
					subscription.add(8);
				if(accountSubscription.getUkeydocument())
					subscription.add(9);
			} else {
				throw new RuntimeException("你未订阅到期提醒");
			}
		}
		return subscription;
	}
}
