package com.edip.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 
 */
public class Exchangeitem implements Serializable {
    /**
     * 数据交换ID
     */
    private Integer itemid;

    /**
     * 项目ID
     */
    private Integer proid;

    /**
     * 文档ID
     */
    private Integer docid;

    /**
     * 是否需要签章回传
                                                                     0:不需要
                                                                     1:需要
     */
    private Integer signflag;

    /**
     * 发送方签名总数
     */
    private Integer sendsigncount;

    /**
     * 发送方已签名总数
     */
    private Integer sendsignnum;

    /**
     * 接收方签名总数
     */
    private Integer recvsigncount;

    /**
     * 接收方已签名总数
     */
    private Integer recvsignnum;

    /**
     * 实体记录ID,对应资质表
     */
    private Integer dataid;

    /**
     * 实体类型,对应资质表
     */
    private Integer datatype;

    /**
     * 发送品种批次
     */
    private Integer productid;

    /**
     * 发送状态 0:待签章
 1:已签章
	
     */
    private Integer status;

    /**
     * ǩ
     */
    private Date createdate;

    /**
     * 是否首次发送 0:首次新建
 1:补发

     */
    private Integer isfrist;

    /**
     * 签章发送状态 0 正常待签章,1 签章待发送 2 已发送
     */
    private Integer sendflag;

    private String signinfo;

    private String destsigninfo;
    private Integer coopProID;
    private String manuf;
    private String dataId;
    private Integer recordID;
    private String signedPdfName;
    private Integer error;
    private Integer productFlag;


    public Integer getCoopProID() {
        return coopProID;
    }

    public void setCoopProID(Integer coopProID) {
        this.coopProID = coopProID;
    }

    public String getManuf() {
        return manuf;
    }

    public void setManuf(String manuf) {
        this.manuf = manuf;
    }

    private static final long serialVersionUID = 1L;

    public Integer getItemid() {
        return itemid;
    }

    public void setItemid(Integer itemid) {
        this.itemid = itemid;
    }

    public Integer getProid() {
        return proid;
    }

    public void setProid(Integer proid) {
        this.proid = proid;
    }

    public Integer getDocid() {
        return docid;
    }

    public void setDocid(Integer docid) {
        this.docid = docid;
    }

    public Integer getSignflag() {
        return signflag;
    }

    public void setSignflag(Integer signflag) {
        this.signflag = signflag;
    }

    public Integer getSendsigncount() {
        return sendsigncount;
    }

    public void setSendsigncount(Integer sendsigncount) {
        this.sendsigncount = sendsigncount;
    }

    public Integer getSendsignnum() {
        return sendsignnum;
    }

    public void setSendsignnum(Integer sendsignnum) {
        this.sendsignnum = sendsignnum;
    }

    public Integer getRecvsigncount() {
        return recvsigncount;
    }

    public void setRecvsigncount(Integer recvsigncount) {
        this.recvsigncount = recvsigncount;
    }

    public Integer getRecvsignnum() {
        return recvsignnum;
    }

    public void setRecvsignnum(Integer recvsignnum) {
        this.recvsignnum = recvsignnum;
    }

    public Integer getDataid() {
        return dataid;
    }

    public void setDataid(Integer dataid) {
        this.dataid = dataid;
    }

    public Integer getDatatype() {
        return datatype;
    }

    public void setDatatype(Integer datatype) {
        this.datatype = datatype;
    }

    public Integer getProductid() {
        return productid;
    }

    public void setProductid(Integer productid) {
        this.productid = productid;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Integer getIsfrist() {
        return isfrist;
    }

    public void setIsfrist(Integer isfrist) {
        this.isfrist = isfrist;
    }

    public Integer getSendflag() {
        return sendflag;
    }

    public void setSendflag(Integer sendflag) {
        this.sendflag = sendflag;
    }

    public String getSigninfo() {
        return signinfo;
    }

    public void setSigninfo(String signinfo) {
        this.signinfo = signinfo;
    }

    public String getDestsigninfo() {
        return destsigninfo;
    }

    public void setDestsigninfo(String destsigninfo) {
        this.destsigninfo = destsigninfo;
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Exchangeitem other = (Exchangeitem) that;
        return (this.getItemid() == null ? other.getItemid() == null : this.getItemid().equals(other.getItemid()))
            && (this.getProid() == null ? other.getProid() == null : this.getProid().equals(other.getProid()))
            && (this.getDocid() == null ? other.getDocid() == null : this.getDocid().equals(other.getDocid()))
            && (this.getSignflag() == null ? other.getSignflag() == null : this.getSignflag().equals(other.getSignflag()))
            && (this.getSendsigncount() == null ? other.getSendsigncount() == null : this.getSendsigncount().equals(other.getSendsigncount()))
            && (this.getSendsignnum() == null ? other.getSendsignnum() == null : this.getSendsignnum().equals(other.getSendsignnum()))
            && (this.getRecvsigncount() == null ? other.getRecvsigncount() == null : this.getRecvsigncount().equals(other.getRecvsigncount()))
            && (this.getRecvsignnum() == null ? other.getRecvsignnum() == null : this.getRecvsignnum().equals(other.getRecvsignnum()))
            && (this.getDataid() == null ? other.getDataid() == null : this.getDataid().equals(other.getDataid()))
            && (this.getDatatype() == null ? other.getDatatype() == null : this.getDatatype().equals(other.getDatatype()))
            && (this.getProductid() == null ? other.getProductid() == null : this.getProductid().equals(other.getProductid()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getCreatedate() == null ? other.getCreatedate() == null : this.getCreatedate().equals(other.getCreatedate()))
            && (this.getIsfrist() == null ? other.getIsfrist() == null : this.getIsfrist().equals(other.getIsfrist()))
            && (this.getSendflag() == null ? other.getSendflag() == null : this.getSendflag().equals(other.getSendflag()))
            && (this.getSigninfo() == null ? other.getSigninfo() == null : this.getSigninfo().equals(other.getSigninfo()))
            && (this.getDestsigninfo() == null ? other.getDestsigninfo() == null : this.getDestsigninfo().equals(other.getDestsigninfo()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getItemid() == null) ? 0 : getItemid().hashCode());
        result = prime * result + ((getProid() == null) ? 0 : getProid().hashCode());
        result = prime * result + ((getDocid() == null) ? 0 : getDocid().hashCode());
        result = prime * result + ((getSignflag() == null) ? 0 : getSignflag().hashCode());
        result = prime * result + ((getSendsigncount() == null) ? 0 : getSendsigncount().hashCode());
        result = prime * result + ((getSendsignnum() == null) ? 0 : getSendsignnum().hashCode());
        result = prime * result + ((getRecvsigncount() == null) ? 0 : getRecvsigncount().hashCode());
        result = prime * result + ((getRecvsignnum() == null) ? 0 : getRecvsignnum().hashCode());
        result = prime * result + ((getDataid() == null) ? 0 : getDataid().hashCode());
        result = prime * result + ((getDatatype() == null) ? 0 : getDatatype().hashCode());
        result = prime * result + ((getProductid() == null) ? 0 : getProductid().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getCreatedate() == null) ? 0 : getCreatedate().hashCode());
        result = prime * result + ((getIsfrist() == null) ? 0 : getIsfrist().hashCode());
        result = prime * result + ((getSendflag() == null) ? 0 : getSendflag().hashCode());
        result = prime * result + ((getSigninfo() == null) ? 0 : getSigninfo().hashCode());
        result = prime * result + ((getDestsigninfo() == null) ? 0 : getDestsigninfo().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", itemid=").append(itemid);
        sb.append(", proid=").append(proid);
        sb.append(", docid=").append(docid);
        sb.append(", signflag=").append(signflag);
        sb.append(", sendsigncount=").append(sendsigncount);
        sb.append(", sendsignnum=").append(sendsignnum);
        sb.append(", recvsigncount=").append(recvsigncount);
        sb.append(", recvsignnum=").append(recvsignnum);
        sb.append(", dataid=").append(dataid);
        sb.append(", datatype=").append(datatype);
        sb.append(", productid=").append(productid);
        sb.append(", status=").append(status);
        sb.append(", createdate=").append(createdate);
        sb.append(", isfrist=").append(isfrist);
        sb.append(", sendflag=").append(sendflag);
        sb.append(", signinfo=").append(signinfo);
        sb.append(", destsigninfo=").append(destsigninfo);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }

    public String getDataId() {
        return dataId;
    }

    public void setDataId(String dataId) {
        this.dataId = dataId;
    }

    public Integer getRecordID() {
        return recordID;
    }

    public void setRecordID(Integer recordID) {
        this.recordID = recordID;
    }

    public String getSignedPdfName() {
        return signedPdfName;
    }

    public void setSignedPdfName(String signedPdfName) {
        this.signedPdfName = signedPdfName;
    }

    public Integer getError() {
        return error;
    }

    public void setError(Integer error) {
        this.error = error;
    }

    public Integer getProductFlag() {
        return productFlag;
    }

    public void setProductFlag(Integer productFlag) {
        this.productFlag = productFlag;
    }
}