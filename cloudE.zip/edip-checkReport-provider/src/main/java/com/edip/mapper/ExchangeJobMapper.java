package com.edip.mapper;

import com.edip.entity.ExchangeJob;
import com.edip.entity.ExchangeJobExample;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ExchangeJobMapper {
    long countByExample(ExchangeJobExample example);

    int deleteByExample(ExchangeJobExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ExchangeJob record);

    int insertSelective(ExchangeJob record);

    List<ExchangeJob> selectByExample(ExchangeJobExample example);

    ExchangeJob selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ExchangeJob record, @Param("example") ExchangeJobExample example);

    int updateByExample(@Param("record") ExchangeJob record, @Param("example") ExchangeJobExample example);

    int updateByPrimaryKeySelective(ExchangeJob record);

    int updateByPrimaryKey(ExchangeJob record);
}