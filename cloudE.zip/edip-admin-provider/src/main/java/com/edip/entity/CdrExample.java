package com.edip.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class CdrExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CdrExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCdrIDIsNull() {
            addCriterion("cdrID is null");
            return (Criteria) this;
        }

        public Criteria andCdrIDIsNotNull() {
            addCriterion("cdrID is not null");
            return (Criteria) this;
        }

        public Criteria andCdrIDEqualTo(Integer value) {
            addCriterion("cdrID =", value, "cdrID");
            return (Criteria) this;
        }

        public Criteria andCdrIDNotEqualTo(Integer value) {
            addCriterion("cdrID <>", value, "cdrID");
            return (Criteria) this;
        }

        public Criteria andCdrIDGreaterThan(Integer value) {
            addCriterion("cdrID >", value, "cdrID");
            return (Criteria) this;
        }

        public Criteria andCdrIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("cdrID >=", value, "cdrID");
            return (Criteria) this;
        }

        public Criteria andCdrIDLessThan(Integer value) {
            addCriterion("cdrID <", value, "cdrID");
            return (Criteria) this;
        }

        public Criteria andCdrIDLessThanOrEqualTo(Integer value) {
            addCriterion("cdrID <=", value, "cdrID");
            return (Criteria) this;
        }

        public Criteria andCdrIDIn(List<Integer> values) {
            addCriterion("cdrID in", values, "cdrID");
            return (Criteria) this;
        }

        public Criteria andCdrIDNotIn(List<Integer> values) {
            addCriterion("cdrID not in", values, "cdrID");
            return (Criteria) this;
        }

        public Criteria andCdrIDBetween(Integer value1, Integer value2) {
            addCriterion("cdrID between", value1, value2, "cdrID");
            return (Criteria) this;
        }

        public Criteria andCdrIDNotBetween(Integer value1, Integer value2) {
            addCriterion("cdrID not between", value1, value2, "cdrID");
            return (Criteria) this;
        }

        public Criteria andCdrTypeIsNull() {
            addCriterion("cdrType is null");
            return (Criteria) this;
        }

        public Criteria andCdrTypeIsNotNull() {
            addCriterion("cdrType is not null");
            return (Criteria) this;
        }

        public Criteria andCdrTypeEqualTo(Integer value) {
            addCriterion("cdrType =", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeNotEqualTo(Integer value) {
            addCriterion("cdrType <>", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeGreaterThan(Integer value) {
            addCriterion("cdrType >", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("cdrType >=", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeLessThan(Integer value) {
            addCriterion("cdrType <", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeLessThanOrEqualTo(Integer value) {
            addCriterion("cdrType <=", value, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeIn(List<Integer> values) {
            addCriterion("cdrType in", values, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeNotIn(List<Integer> values) {
            addCriterion("cdrType not in", values, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeBetween(Integer value1, Integer value2) {
            addCriterion("cdrType between", value1, value2, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("cdrType not between", value1, value2, "cdrType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeIsNull() {
            addCriterion("cdrsubType is null");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeIsNotNull() {
            addCriterion("cdrsubType is not null");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeEqualTo(Integer value) {
            addCriterion("cdrsubType =", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeNotEqualTo(Integer value) {
            addCriterion("cdrsubType <>", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeGreaterThan(Integer value) {
            addCriterion("cdrsubType >", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("cdrsubType >=", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeLessThan(Integer value) {
            addCriterion("cdrsubType <", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeLessThanOrEqualTo(Integer value) {
            addCriterion("cdrsubType <=", value, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeIn(List<Integer> values) {
            addCriterion("cdrsubType in", values, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeNotIn(List<Integer> values) {
            addCriterion("cdrsubType not in", values, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeBetween(Integer value1, Integer value2) {
            addCriterion("cdrsubType between", value1, value2, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCdrsubTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("cdrsubType not between", value1, value2, "cdrsubType");
            return (Criteria) this;
        }

        public Criteria andCompIDIsNull() {
            addCriterion("compID is null");
            return (Criteria) this;
        }

        public Criteria andCompIDIsNotNull() {
            addCriterion("compID is not null");
            return (Criteria) this;
        }

        public Criteria andCompIDEqualTo(Integer value) {
            addCriterion("compID =", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotEqualTo(Integer value) {
            addCriterion("compID <>", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDGreaterThan(Integer value) {
            addCriterion("compID >", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("compID >=", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDLessThan(Integer value) {
            addCriterion("compID <", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDLessThanOrEqualTo(Integer value) {
            addCriterion("compID <=", value, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDIn(List<Integer> values) {
            addCriterion("compID in", values, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotIn(List<Integer> values) {
            addCriterion("compID not in", values, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDBetween(Integer value1, Integer value2) {
            addCriterion("compID between", value1, value2, "compID");
            return (Criteria) this;
        }

        public Criteria andCompIDNotBetween(Integer value1, Integer value2) {
            addCriterion("compID not between", value1, value2, "compID");
            return (Criteria) this;
        }

        public Criteria andModeIDIsNull() {
            addCriterion("modeID is null");
            return (Criteria) this;
        }

        public Criteria andModeIDIsNotNull() {
            addCriterion("modeID is not null");
            return (Criteria) this;
        }

        public Criteria andModeIDEqualTo(Integer value) {
            addCriterion("modeID =", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDNotEqualTo(Integer value) {
            addCriterion("modeID <>", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDGreaterThan(Integer value) {
            addCriterion("modeID >", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("modeID >=", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDLessThan(Integer value) {
            addCriterion("modeID <", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDLessThanOrEqualTo(Integer value) {
            addCriterion("modeID <=", value, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDIn(List<Integer> values) {
            addCriterion("modeID in", values, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDNotIn(List<Integer> values) {
            addCriterion("modeID not in", values, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDBetween(Integer value1, Integer value2) {
            addCriterion("modeID between", value1, value2, "modeID");
            return (Criteria) this;
        }

        public Criteria andModeIDNotBetween(Integer value1, Integer value2) {
            addCriterion("modeID not between", value1, value2, "modeID");
            return (Criteria) this;
        }

        public Criteria andTargetIDIsNull() {
            addCriterion("targetID is null");
            return (Criteria) this;
        }

        public Criteria andTargetIDIsNotNull() {
            addCriterion("targetID is not null");
            return (Criteria) this;
        }

        public Criteria andTargetIDEqualTo(Integer value) {
            addCriterion("targetID =", value, "targetID");
            return (Criteria) this;
        }

        public Criteria andTargetIDNotEqualTo(Integer value) {
            addCriterion("targetID <>", value, "targetID");
            return (Criteria) this;
        }

        public Criteria andTargetIDGreaterThan(Integer value) {
            addCriterion("targetID >", value, "targetID");
            return (Criteria) this;
        }

        public Criteria andTargetIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("targetID >=", value, "targetID");
            return (Criteria) this;
        }

        public Criteria andTargetIDLessThan(Integer value) {
            addCriterion("targetID <", value, "targetID");
            return (Criteria) this;
        }

        public Criteria andTargetIDLessThanOrEqualTo(Integer value) {
            addCriterion("targetID <=", value, "targetID");
            return (Criteria) this;
        }

        public Criteria andTargetIDIn(List<Integer> values) {
            addCriterion("targetID in", values, "targetID");
            return (Criteria) this;
        }

        public Criteria andTargetIDNotIn(List<Integer> values) {
            addCriterion("targetID not in", values, "targetID");
            return (Criteria) this;
        }

        public Criteria andTargetIDBetween(Integer value1, Integer value2) {
            addCriterion("targetID between", value1, value2, "targetID");
            return (Criteria) this;
        }

        public Criteria andTargetIDNotBetween(Integer value1, Integer value2) {
            addCriterion("targetID not between", value1, value2, "targetID");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNull() {
            addCriterion("createDate is null");
            return (Criteria) this;
        }

        public Criteria andCreateDateIsNotNull() {
            addCriterion("createDate is not null");
            return (Criteria) this;
        }

        public Criteria andCreateDateEqualTo(Date value) {
            addCriterion("createDate =", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotEqualTo(Date value) {
            addCriterion("createDate <>", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThan(Date value) {
            addCriterion("createDate >", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("createDate >=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThan(Date value) {
            addCriterion("createDate <", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateLessThanOrEqualTo(Date value) {
            addCriterion("createDate <=", value, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateIn(List<Date> values) {
            addCriterion("createDate in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotIn(List<Date> values) {
            addCriterion("createDate not in", values, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateBetween(Date value1, Date value2) {
            addCriterion("createDate between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andCreateDateNotBetween(Date value1, Date value2) {
            addCriterion("createDate not between", value1, value2, "createDate");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("name is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("name is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("name =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("name <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("name >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("name >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("name <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("name <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("name like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("name not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("name in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("name not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("name between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("name not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andDataTypeIsNull() {
            addCriterion("dataType is null");
            return (Criteria) this;
        }

        public Criteria andDataTypeIsNotNull() {
            addCriterion("dataType is not null");
            return (Criteria) this;
        }

        public Criteria andDataTypeEqualTo(Integer value) {
            addCriterion("dataType =", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeNotEqualTo(Integer value) {
            addCriterion("dataType <>", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeGreaterThan(Integer value) {
            addCriterion("dataType >", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("dataType >=", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeLessThan(Integer value) {
            addCriterion("dataType <", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeLessThanOrEqualTo(Integer value) {
            addCriterion("dataType <=", value, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeIn(List<Integer> values) {
            addCriterion("dataType in", values, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeNotIn(List<Integer> values) {
            addCriterion("dataType not in", values, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeBetween(Integer value1, Integer value2) {
            addCriterion("dataType between", value1, value2, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("dataType not between", value1, value2, "dataType");
            return (Criteria) this;
        }

        public Criteria andDataIDIsNull() {
            addCriterion("dataID is null");
            return (Criteria) this;
        }

        public Criteria andDataIDIsNotNull() {
            addCriterion("dataID is not null");
            return (Criteria) this;
        }

        public Criteria andDataIDEqualTo(Integer value) {
            addCriterion("dataID =", value, "dataID");
            return (Criteria) this;
        }

        public Criteria andDataIDNotEqualTo(Integer value) {
            addCriterion("dataID <>", value, "dataID");
            return (Criteria) this;
        }

        public Criteria andDataIDGreaterThan(Integer value) {
            addCriterion("dataID >", value, "dataID");
            return (Criteria) this;
        }

        public Criteria andDataIDGreaterThanOrEqualTo(Integer value) {
            addCriterion("dataID >=", value, "dataID");
            return (Criteria) this;
        }

        public Criteria andDataIDLessThan(Integer value) {
            addCriterion("dataID <", value, "dataID");
            return (Criteria) this;
        }

        public Criteria andDataIDLessThanOrEqualTo(Integer value) {
            addCriterion("dataID <=", value, "dataID");
            return (Criteria) this;
        }

        public Criteria andDataIDIn(List<Integer> values) {
            addCriterion("dataID in", values, "dataID");
            return (Criteria) this;
        }

        public Criteria andDataIDNotIn(List<Integer> values) {
            addCriterion("dataID not in", values, "dataID");
            return (Criteria) this;
        }

        public Criteria andDataIDBetween(Integer value1, Integer value2) {
            addCriterion("dataID between", value1, value2, "dataID");
            return (Criteria) this;
        }

        public Criteria andDataIDNotBetween(Integer value1, Integer value2) {
            addCriterion("dataID not between", value1, value2, "dataID");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}