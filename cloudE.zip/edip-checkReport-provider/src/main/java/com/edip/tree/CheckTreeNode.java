package com.edip.tree;

public class CheckTreeNode extends TreeNode {
    private boolean checked = false;
    private boolean isDisabled = false;
    private String dependByNodes;
    private String dependNodes;

    public CheckTreeNode() {
    }

    public CheckTreeNode(String id, String parentId, String text, String dependByNodes, String dependNodes) {
        super(id, parentId, text);
        this.dependByNodes = dependByNodes;
        this.dependNodes = dependNodes;
    }

    public boolean isChecked() {
        return this.checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public boolean isDisabled() {
        return this.isDisabled;
    }

    public void setDisabled(boolean isDisabled) {
        this.isDisabled = isDisabled;
    }

    public String getDependByNodes() {
        return this.dependByNodes;
    }

    public void setDependByNodes(String dependByNodes) {
        this.dependByNodes = dependByNodes;
    }

    public String getDependNodes() {
        return this.dependNodes;
    }

    public void setDependNodes(String dependNodes) {
        this.dependNodes = dependNodes;
    }
}
