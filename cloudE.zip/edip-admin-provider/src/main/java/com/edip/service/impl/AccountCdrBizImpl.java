package com.edip.service.impl;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.edip.dto.util.SessionAttributeUtil;
import com.edip.entity.Cdr;
import com.edip.mapper.CdrMapper;
import com.edip.service.AccountCdrBiz;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * Created by qiulingyun on 2017/5/9.
 */
@Service("accountCdrBiz")
public class AccountCdrBizImpl implements AccountCdrBiz {
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountCdrBizImpl.class);
    /*@Autowired
    protected AccountMapper     accountMapper;*/
    @Autowired
    @Qualifier("cdrMapper")
    private CdrMapper cdrMapper;


    /*@Override
    public void insertCdr(String mobile,Integer cdrType,Integer cdrSubType,String companyId){
        AccountExample accountExample = new AccountExample();
        accountExample.createCriteria().andMsisdnEqualTo(mobile);

        List<Account> accountList = accountMapper.selectByExample(accountExample);
        Account account = null;
        if (accountList.size() != 0 && accountList != null) {
            account = accountList.get(0);
        }

        Cdr cdr = new Cdr();
        if(companyId !=null && companyId !=""){
            cdr.setCompID(Integer.parseInt(companyId));
        }else{
            if (account != null) {
                cdr.setCompID(account.getCompID());
            }else{
                cdr.setCompID(-2);
            }
        }
        cdr.setCdrType(cdrType);
        cdr.setCdrsubType(cdrSubType);
        Date createDate = new Date();
        cdr.setCreateDate(createDate);
        cdr.setTargetID(cdr.getCompID());
        cdrMapper.insertSelective(cdr);
    }*/


    @Override
    public void insertCdrs(Integer cdrType, Integer cdrSubType, String companyId, HttpSession session, HttpServletRequest request) {
        //Integer co= (Integer)session.getAttribute("COMPID");
        Integer co= (Integer) SessionAttributeUtil.getAttribute(request).get("compID");
        Cdr cdr = new Cdr();
        cdr.setCompID(co);
        cdr.setCdrType(cdrType);
        cdr.setCdrsubType(cdrSubType);
        Date createDate = new Date();
        cdr.setCreateDate(createDate);
        cdr.setTargetID(Integer.parseInt(companyId));
        cdrMapper.insertSelective(cdr);
    }
}
